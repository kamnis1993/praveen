"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CompiledTypes.d.ts" />
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var Logger = require("../cs-logging/Logger");
var MapperActionDispatcher = require("./MapperActionDispatcher");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RuleConditionAuditor = require("./RuleConditionAuditor");
/**
 * Performs the mapping actions on the decompose contexts
 */
var Mapper = /** @class */ (function () {
    /**
     * @constructor
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts The decompose contexts
     * @param {CsErrorContext} errorContext The error context on which mapping errors should be reported
     */
    function Mapper(decomposeContexts, errorContext) {
        this._errorContext = errorContext;
        this._ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, errorContext);
    }
    /**
     * Continue the processing of mapping rules for a single Decompose Context.
     * If a rule fires actions, this method will return without processing any further rules.
     * You therefore MUST continue calling this method until DC.MappingRuleIndex >= count-of-mapping-rules
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {number} decomposeContextIdx The index of the current decompose context we are processing
     */
    Mapper.prototype.ContinueMappingForDecomposeContext = function (decomposeContext) {
        Logger.debug(0, "Mapping Rule", "Starting Mapping Rules", {});
        // If the root entity is unchanged or deleted, then don't run any mapping rules on it
        if (!OrderfolioQueries.IsRootOrderfolioItemInAffectedPortfolio(decomposeContext.Orderfolio)) {
            Logger.debug(10, "Mapping Rule", "The root orderfolio item is unchanged so no rules have been run", { SubType: "MappingForDecomposeContext" });
            return false;
        }
        var mappingRules = decomposeContext.CompiledSpec.MappingRules;
        var startIndex = decomposeContext.MappingRuleIndex;
        Logger.debug(10, "Mapping Rule", "Continuing mapping rules from index", { SubType: "MappingForDecomposeContext", MappingRuleIndex: startIndex, OrderCandidate: decomposeContext.CandidateOrderId });
        if (!mappingRules || mappingRules.length <= startIndex) {
            Logger.debug(10, "Mapping Rule", "No unprocessed rules were found in the specification", { SubType: "MappingForDecomposeContext" });
            return false; // nothing to process
        }
        for (var mappingRuleIdx = startIndex; mappingRuleIdx < mappingRules.length; mappingRuleIdx++) {
            var mappingRule = mappingRules[mappingRuleIdx];
            var parentEntityId = decomposeContext.CompiledSpec.UuidToGuidPathLookup[mappingRule.ContainerKey.toString()];
            Logger.debug(10, "Mapping Rule", "Processing Rule:" + mappingRule.Name, { SubType: "MappingForDecomposeContext", ParentEntityId: parentEntityId, RuleInfo: mappingRule });
            var orderfolioItemSet = decomposeContext.Orderfolio[mappingRule.ContainerKey];
            // If we don't have the entity that the mapping rule belongs to then this rule should not fire
            if (!orderfolioItemSet || orderfolioItemSet.length === 0) {
                Logger.debug(20, "Mapping Rule", "0 Orderfolio items found that match EntityId", { SubType: "MappingForDecomposeContext", ParentEntityId: parentEntityId });
                continue;
            }
            decomposeContext.MappingRuleIndex = mappingRuleIdx + 1; // next rule to run
            var inferenceRequired = false;
            for (var orderfolioItemIdx = 0; orderfolioItemIdx < orderfolioItemSet.length; orderfolioItemIdx++) {
                var currentContainer = orderfolioItemSet[orderfolioItemIdx];
                if (currentContainer.IsInvalid) {
                    Logger.debug(20, "Mapping Rule", currentContainer.PortfolioItemId + " is invalid", { SubType: "ContainerExist", ContainerId: currentContainer.EntityId });
                    continue;
                }
                Logger.debug(20, "Mapping Rule", "Evaluating Mapping rule on: " + currentContainer.PortfolioItemId, { SubType: "ContainerExist", EntityId: currentContainer.EntityId });
                if (this.IsRuleCriteriaMet(mappingRule, decomposeContext, currentContainer)) {
                    var actionsToApply = this.GatherMappingActions(mappingRule, currentContainer, decomposeContext);
                    if (actionsToApply && actionsToApply.length > 0) {
                        var actionDispatcher = new MapperActionDispatcher(this._errorContext);
                        var entityCreated = actionDispatcher.ExecuteMappingActions(actionsToApply, decomposeContext, currentContainer);
                        if (entityCreated) {
                            inferenceRequired = true;
                        }
                    }
                    else {
                        Logger.debug(50, "Mapping Rule", "No Rule actions found", { SubType: "Rule Action" });
                    }
                }
            }
            if (inferenceRequired) {
                Logger.debug(20, "Mapping Rule", "Re-running inference", { SubType: "MappingForDecomposeContext" });
                return true;
            }
        }
        // Completed all mapping rules
        return false;
    };
    /**
     * Checks whether all criteria for a rule to fire has been met
     * @param {CsTypes.CompiledMappingRule} mappingRule The mapping rule to check
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} mappingRuleContainer The orderfolio item that contains the mapping rule
     * @returns {boolean}
     */
    Mapper.prototype.IsRuleCriteriaMet = function (mappingRule, decomposeContext, mappingRuleContainer) {
        if (mappingRuleContainer.Action === OrderActions.Delete) {
            Logger.debug(20, "Mapping Rule", "Container Entity does not have correct action to fire the mapping rule", { SubType: "MappingForDecomposeContext", ContainerOrderAction: mappingRuleContainer.Action });
            return false;
        }
        if (!OrderfolioQueries.RuleDateCriteriaIsMet(mappingRule.StartDate, mappingRule.EndDate, decomposeContext.ActivationDate)) {
            Logger.debug(20, "Mapping Rule", "Rule Criteria not met:Date out of range", { SubType: "RuleDateInvalid", OrderDate: decomposeContext.ActivationDate, RuleStartDate: mappingRule.StartDate, RuleEndDate: mappingRule.EndDate });
            return false;
        }
        if (!this.RuleContainsTriggerType(mappingRule, decomposeContext.BoundaryCondition)) {
            Logger.debug(20, "Mapping Rule", "Rule Criteria not met: Trigger type doesn't match", { SubType: "TriggerType", DecomposeBoundaryCondition: decomposeContext.BoundaryCondition, RuleTriggerType: mappingRule.TriggerEvents });
            return false;
        }
        return true;
    };
    /**
     * Checks if the rule has the correct trigger type for the decompose operation we are doing
     * @param {CsTypes.CompiledMappingRule} mappingRule The mapping rule to check
     * @param {string} boundaryCondition The boundary condition for the current request (technical or commercial)
     */
    Mapper.prototype.RuleContainsTriggerType = function (mappingRule, boundaryCondition) {
        if (boundaryCondition === BoundaryConditionConstants.Technical && mappingRule.TriggerEvents.Decompose) {
            return true;
        }
        if (boundaryCondition === BoundaryConditionConstants.Commercial && mappingRule.TriggerEvents.CommercialDecompose) {
            return true;
        }
        return false;
    };
    /**
     * Gathers the mapping actions for the rule, if the conditions pass then use true actions, otherwise use false actions
     * @param {CsTypes.CompiledMappingRule} mappingRule The mapping rule to use
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that the mapping rule belongs to
     * @param {CsTypes.DecomposeContex} decomposeContext The decompose context
     * @returns {Array<CsTypes.CompiledMappingAction>}
     */
    Mapper.prototype.GatherMappingActions = function (mappingRule, container, decomposeContext) {
        // Get true and false actions that apply.
        if (this._ruleConditionAuditor.AreMappingRuleConditionsMet(mappingRule, container, decomposeContext)) {
            Logger.debug(30, "Mapping Rule", "Executing TRUE actions for: " + mappingRule.Name, { SubType: "TrueAction", TrueAction: mappingRule.TrueActions });
            return mappingRule.TrueActions;
        }
        else {
            Logger.debug(2, "Mapping Rule", "Executing FALSE actions for rule Id", { SubType: "FalseActions", RuleId: mappingRule.Id });
            return mappingRule.FalseActions;
        }
    };
    return Mapper;
}());
module.exports = Mapper;

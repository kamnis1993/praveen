"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CompiledTypes.d.ts" />
var Utilities = require("../cs-lib-utilities/Utilities");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var RuleConditionType = require("../cs-lib-constants/RuleConditionType");
var ComparerTypes = require("../cs-lib-constants/ComparerTypes");
/**
 * Class that evaluates count conditions
 */
var CountConditionMethods = /** @class */ (function () {
    function CountConditionMethods(errorContext) {
        this._errorContext = errorContext;
    }
    /**
    * Assigns values to the count criteria in question
    * @param {CsTypes.CountConditionCriteria} countCriteria The count criteria that needs values assigned to it
    * @param {CsTypes.Condition} condition The overall condition
    * @param {CsTypes.TargetPath} targetPathItem Target Path Item
    * @param {CsTypes.OrderfolioItem[]} targetChildOrderfolioItems Array of orderfolio items that we need to check before assigning values
    */
    CountConditionMethods.prototype.AssignValuesToCountCriteria = function (countCriteria, condition, targetPathItem, targetChildOrderfolioItems) {
        // if the targetPathItem has IsElementReference set then this must be a target that has a UDC value.
        if (Utilities.IsDefined(targetPathItem.IsElementReference)) {
            if (condition.ConditionType === RuleConditionType.EntToUDC) {
                this.FindUdcValue(targetChildOrderfolioItems, countCriteria, targetPathItem.UseId);
            }
        }
        else {
            // Add values to the criteria based on if they belong on the left or right hand side on the equation.
            // we need to make sure we are not adding duplications too.
            for (var oi = 0; oi < targetChildOrderfolioItems.length; oi++) {
                var code = targetChildOrderfolioItems[oi].EntityUniqueCode;
                if (Utilities.IsDefined(targetPathItem.LeftHandSide)) {
                    if (countCriteria.LeftCountNames.indexOf(code) === -1) {
                        countCriteria.LeftCountNames.push(code);
                    }
                }
                else {
                    if (countCriteria.RightCountNames.indexOf(code) === -1) {
                        countCriteria.RightCountNames.push(code);
                    }
                }
            }
        }
    };
    /**
    * Finds which count condition we are targeting and performs a compare
    * @param {CsTypes.Condition} condition The conditions to check
    * @param {number} leftHandSideCount The number of entities that exist on th LHS
    * @param {number} rightHandSideCount The number of entities that exist on th RHS
    * @param {string} udcValue The udcValue to compare against, if condition is EntToUdc
    * @returns {boolean}
    */
    CountConditionMethods.prototype.CompareCountConditionCriterias = function (condition, leftHandSideCount, rightHandSideCount, udcValue) {
        switch (condition.ConditionType) {
            case RuleConditionType.EntToEnt:
                return this.CompareCount(condition.Comparer, leftHandSideCount, rightHandSideCount);
            case RuleConditionType.EntToStatic:
                return this.CompareCount(condition.Comparer, leftHandSideCount, Number(condition.Value));
            case RuleConditionType.EntToUDC:
                if (Utilities.IsNotDefined(udcValue)) {
                    this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidUserDefinedCharacteristicNumberType);
                }
                return this.CompareCount(condition.Comparer, leftHandSideCount, Number(udcValue));
            default:
                return false;
        }
    };
    /**
    * Finds the udc value and adds it to the count criteria. Raise errors too if we have ambiguity.
    * @param {CsTypes.OrderfolioItem[]} arrayOfEntities The conditions to check
    * @param {CsTypes.CountConditionCriteria} countCriteria The Number of entities that exist on th LHS
    * @param {string} useId Target Path Items use id
    */
    CountConditionMethods.prototype.FindUdcValue = function (arrayOfEntities, countCriteria, useId) {
        for (var x = 0; x < arrayOfEntities.length; x++) {
            var udcToCheck = LodashUtilities.Where(arrayOfEntities[x].UserDefinedCharacteristics, { UseId: useId });
            // There should only be one Udc value for a valid request
            if (Utilities.IsDefined(udcToCheck) && udcToCheck.length > 0) {
                for (var y = 0; y < udcToCheck.length; y++) {
                    var udc = udcToCheck[y];
                    // Iterate through each of the Values to see which has the udc
                    for (var z = 0; z < udc.Values.length; z++) {
                        if (Utilities.IsDefined(udc.Values[z])) {
                            var udcValueToCheck = Number(udc.Values[z].Value);
                            if (udcValueToCheck === 0 || udcValueToCheck < 0 || udcValueToCheck % 1 !== 0) {
                                this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidUserDefinedCharacteristicNumberType);
                            }
                            if (Utilities.IsNotDefined(countCriteria.UDCValue) || udcValueToCheck === countCriteria.UDCValue) {
                                countCriteria.UDCValue = udcValueToCheck;
                            }
                            else {
                                // Udc was already defined so there was more than one in the request
                                this._errorContext.RaiseCsError(500, ErrorCode.BadData.MultipleUDCValue);
                            }
                        }
                    }
                }
                if (Utilities.IsNotDefined(countCriteria.UDCValue)) {
                    this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidUserDefinedCharacteristicNumberType);
                }
            }
        }
    };
    /**
    * Gets the Count Criteria from the collection based on the given ID. Else created a new one if its not present.
    * @param {string} id The conditions to check
    * @param {CsTypes.CountConditionCriteria[]} countCriteria The Number of entities that exist on th LHS
    */
    CountConditionMethods.prototype.GetCountCriteria = function (id, countCriterias) {
        var countCriteria = {};
        if (countCriterias.length > 0) {
            var foundCondition = countCriterias.find(function (x) { return x.ParentId === id; });
            if (Utilities.IsDefined(foundCondition)) {
                return foundCondition;
            }
        }
        countCriteria.ParentId = id;
        countCriteria.LeftCountNames = [];
        countCriteria.RightCountNames = [];
        return countCriteria;
    };
    /**
    * Gets the orderfolio items based on the further scope on the condition
    * @param {CsTypes.DecomposeContext} targetDecomposeContext Decompose Context
    * @param {CsTypes.Condition} condition condition
    * @returns {CsTypes.OrderfolioItem[]}
    */
    CountConditionMethods.prototype.GetFurtherScopedOrderfolioItems = function (targetDecomposeContext, condition) {
        /// Get the UUID based on the further scope and use that to get the correct Orderfolios
        var orderfolioItems;
        var pathLook = targetDecomposeContext.CompiledSpec.BusinessIdPathToUuidLookup;
        var uuid = pathLook[condition.FurtherScope];
        if (Utilities.IsDefined(uuid)) {
            orderfolioItems = targetDecomposeContext.Orderfolio[uuid];
        }
        return orderfolioItems;
    };
    /**
    * Return boolean based on if the passed in array needs to have all values as true or just one.
    * @param {CsTypes.boolean} matchAny matchAny value
    * @param {boolean[]} matchAnyArray array of boolean
    * @returns {boolean}
    */
    CountConditionMethods.prototype.MatchAny = function (matchAny, matchAnyArray) {
        if (matchAnyArray.length > 0) {
            if (matchAny) {
                // just need one of the items to have true
                return LodashUtilities.Contains(matchAnyArray, true);
            }
            else {
                // every item needs to be true
                return matchAnyArray.every(function (x) { return x === true; });
            }
        }
        return false;
    };
    /**
    * Return boolean based on if we have found a count criteria with a given parent ID.
    * @param {CsTypes.CountConditionCriteria[]} countConditionCriterias Collection of count criterias
    * @param {string} countObjectName Name to find.
    * @returns {boolean}
    */
    CountConditionMethods.prototype.IsCountCriteriaInCollection = function (countConditionCriterias, countObjectName) {
        return countConditionCriterias.some(function (element) { return element.ParentId === countObjectName; });
    };
    /**
* Performs a mathematical operation
* @param {string} comparisonOperator The Comparison operator
* @param {number} leftHandSideCount The Number of entities that exist on th LHS
* @param {number} rightHandSideCount The Number of entities that exist on th RHS
* @param {string} udcValue The udcValue to compare against, if condition is EntToUdc
* @returns {boolean}
*/
    CountConditionMethods.prototype.CompareCount = function (comparisonOperator, leftHandSide, rightHandSide) {
        switch (comparisonOperator) {
            case ComparerTypes.Equals:
                return (leftHandSide === rightHandSide);
            case ComparerTypes.NotEquals:
                return (leftHandSide !== rightHandSide);
            case ComparerTypes.LessThan:
                return (leftHandSide < rightHandSide);
            case ComparerTypes.GreaterThan:
                return (leftHandSide > rightHandSide);
            case ComparerTypes.LessThanOrEqualTo:
                return (leftHandSide <= rightHandSide);
            case ComparerTypes.GreaterThanOrEqualTo:
                return (leftHandSide >= rightHandSide);
            default:
                return false;
        }
    };
    return CountConditionMethods;
}());
module.exports = CountConditionMethods;

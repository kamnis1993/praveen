"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var RuleConditionAuditor = require("../RuleConditionAuditor");
var chai = require("chai");
var fs = require("fs");
describe("when asking the RuleConditionAuditor if a TargetExists with an ItemValueAction for a MappingRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var orderfolioItemSet;
    var condition;
    it("should return true for an ExistsOrderValueAction of ADD on a SpecChar Value", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/Mapping/decomposeContextMappingSpecChar.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/Mapping/MappingExistsValueActionSpecCharAddCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/Mapping/MappingExistsValueActionSpecCharAddOrderfolio.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(true);
                    done();
                });
            });
        });
    });
});
describe("when asking the RuleConditionAuditor if a TargetExists with an ItemValueAction for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var orderfolioItemSet;
    var condition;
    it("should return true for an ExistsOrderValueAction of NOCHANGE on a SpecCharUse", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsNoChangeSpecCharUse.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionNoChangeCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionNoChangeOrderfolioItemSet.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(true);
                    done();
                });
            });
        });
    });
    it("should return false for an ExistsOrderValueAction of ADD on a SpecCharUse", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsNoChangeSpecCharUse.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionAddCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionNoChangeOrderfolioItemSet.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(false);
                    done();
                });
            });
        });
    });
    it("should return false for an ExistsOrderValueAction of MODIFY on a ConfigurableFactValue", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsModifyConfFact.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionModifyConfFactCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionModifyConfFactOrderfolio.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(false);
                    done();
                });
            });
        });
    });
    it("should return true for an ExistsOrderValueAction of ADD on a ConfigurableFactValue", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsModifyConfFact.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionAddConfFactCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/ExistsValueActionAddConfFactOrderfolio.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(true);
                    done();
                });
            });
        });
    });
    it("should return false for an NotExistsOrderValueAction of ADD on a ConfigurableFact", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsNotExistsValueActionAddConfFact.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/NotExistsValueActionAddConfFactCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/NotExistsValueActionAddConfFactOrderfolio.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(false);
                    done();
                });
            });
        });
    });
    it("should return false for a NoValueExistsOrderValueAction of DELETE on a SpecChar Value", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/decomposeContextsDeleteSpecCharValue.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/NoValueExistsValueActionDeleteSpecCharValueCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/NoValueExistsValueActionDeleteSpecCharValueOrderfolio.json', { encoding: 'utf8' }, function (error, orderfolioItemSetFileContents) {
                    orderfolioItemSet = JSON.parse(orderfolioItemSetFileContents);
                    condition = JSON.parse(conditionFileContents);
                    var result = ruleConditionAuditor.TargetExists(decomposeContexts[0], orderfolioItemSet, condition);
                    chai.expect(result).to.be.a('boolean');
                    chai.expect(result).to.equal(false);
                    done();
                });
            });
        });
    });
});
describe("when asking the RuleConditionAuditor for a CountEntToEnt with Entities for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var condition;
    xit("should return true if entityCount is Equal and the comparer is equal", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(true);
                done();
            });
        });
    });
    it("should return false if entityCount is Equal and the comparer is Not Equals", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.Comparer = "!=";
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
    it("should return false if entityCount is Equal and the comparer is Less Than", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.Comparer = "<";
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
    it("should return false if entityCount is Equal and the comparer is Equals, but the item actions do not match", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToEntityDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.TargetPaths[0].Action = "delete";
                // Note the item action the sample request is add
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
});
describe("When asking the RuleConditionAuditor for a CountEntToStatic Condition with Entities for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var orderfolioItemSet;
    var condition;
    xit("should return true if entityCount is Greater than the static value and the comparer is Greater than", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToStaticCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules//EntityToStaticDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(true);
                done();
            });
        });
    });
    it("should return false if entityCount is Greater than the Static Value and the comparer is Less Than", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToStaticCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules//EntityToStaticDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.Comparer = "<";
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
    it("should return false if entityCount is Greater Than and the static value and the comparer is greater Than, but the item actions do not match", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToStaticCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules//EntityToStaticDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.TargetPaths[0].Action = "delete";
                // Note the item action the sample request is add
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
});
describe("When asking the RuleConditionAuditor for a CountEntToUdc Condition with Entities for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var orderfolioItemSet;
    var condition;
    xit("should return true if entityCount is Less Than than the Udc value on a package level and the comparer is Less than", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToUdcCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToUdcDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(true);
                done();
            });
        });
    });
    it("should return false if entityCount is Less than the Udc Value and the comparer is Equals", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToUdcCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules//EntityToUdcDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.Comparer = "=";
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(false);
                done();
            });
        });
    });
    xit("should return true if entityCount is Greater Than and the Udc value and the comparer is Less Than, but the item actions dont match", function (done) {
        fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules/EntityToUdcCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
            fs.readFile('cs-mapping/test/data/ItemValueAction/CompatRules//EntityToUdcDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                condition = JSON.parse(conditionFileContents);
                condition.TargetPaths[1].Action = "add";
                // Note the item action the sample request is add
                decomposeContexts = JSON.parse(decomposeContextFileContents);
                var a = decomposeContexts[0].Orderfolio[2][0];
                decomposeContexts[0].Orderfolio[2].push(a);
                decomposeContexts[0].Orderfolio[2].push(a);
                var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
                var result = ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[0], null, false);
                chai.expect(result).to.be.a('boolean');
                chai.expect(result).to.equal(true);
                done();
            });
        });
    });
});
describe("when asking the RuleConditionAuditor if a MultipleValueConditionIsMet with SpecCharValues for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var orderfolioItemSet;
    var condition;
    var index;
    var scoped;
    var containerItem;
    xit("should return true for MatchAny = false for two values that exist", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2ValuesExistsReturnsTrueContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2ValuesExistsReturnsTrueConditon.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2ValuesExistsReturnsTrueIndex.json', { encoding: 'utf8' }, function (error, indexContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2ValuesExistsReturnsTrueScoped.json', { encoding: 'utf8' }, function (error, scopedContents) {
                        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2ValuesExistsReturnsTrueContainer.json', { encoding: 'utf8' }, function (error, containerItemContents) {
                            index = JSON.parse(indexContents);
                            condition = JSON.parse(conditionFileContents);
                            scoped = JSON.parse(scopedContents);
                            containerItem = JSON.parse(containerItemContents);
                            var result = ruleConditionAuditor.MultipleValueConditionsMetForCompatibilityRule(condition, index, scoped, containerItem);
                            chai.expect(result).to.be.a('boolean');
                            chai.expect(result).to.equal(true);
                            done();
                        });
                    });
                });
            });
        });
    });
    it("should return false for MatchAny = true, AnyEmpty = true for no values that NotExists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyTrueAnyEmptyTrueNotExistsNoValuesDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyTrueAnyEmptyTrueNotExistsNoValuesCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyTrueAnyEmptyTrueNotExistsNoValuesCurrentContextIndex.json', { encoding: 'utf8' }, function (error, indexContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyTrueAnyEmptyTrueNotExistsNoValuesScoped.json', { encoding: 'utf8' }, function (error, scopedContents) {
                        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyTrueAnyEmptyTrueNotExistsNoValuesContainerEntity.json', { encoding: 'utf8' }, function (error, containerItemContents) {
                            index = JSON.parse(indexContents);
                            condition = JSON.parse(conditionFileContents);
                            scoped = JSON.parse(scopedContents);
                            containerItem = JSON.parse(containerItemContents);
                            var result = ruleConditionAuditor.MultipleValueConditionsMetForCompatibilityRule(condition, index, scoped, containerItem);
                            chai.expect(result).to.be.a('boolean');
                            chai.expect(result).to.equal(false);
                            done();
                        });
                    });
                });
            });
        });
    });
});
describe("when asking the RuleConditionAuditor if a MultipleValueConditionIsMet with Entities for a CompatibilityRule, it should return the desired boolean values", function () {
    var decomposeContexts;
    var condition;
    var index;
    var scoped;
    var containerItem;
    it("should return false for MatchAny = false for only one entity that exists of the two in the condition", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2EntitiesOnlyOneExistReturnsFalseContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2EntitiesOnlyOneExistReturnsFalseCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2EntitiesOnlyOneExistReturnsFalseIndex.json', { encoding: 'utf8' }, function (error, indexContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2EntitiesOnlyOneExistReturnsFalseScoped.json', { encoding: 'utf8' }, function (error, scopedContents) {
                        fs.readFile('cs-mapping/test/data/MultipleValueConditions/CompatibilityRules/matchAnyFalse2EntitiesOnlyOneExistReturnsFalseContainer.json', { encoding: 'utf8' }, function (error, containerItemContents) {
                            index = JSON.parse(indexContents);
                            condition = JSON.parse(conditionFileContents);
                            scoped = JSON.parse(scopedContents);
                            containerItem = JSON.parse(containerItemContents);
                            var result = ruleConditionAuditor.MultipleValueConditionsMetForCompatibilityRule(condition, index, scoped, containerItem);
                            chai.expect(result).to.be.a('boolean');
                            chai.expect(result).to.equal(false);
                            done();
                        });
                    });
                });
            });
        });
    });
});
describe("when asking the RuleConditionAuditor if a MultipleValueConditionIsMet with Entities and Values for a MappingRule, it should return the desired values", function () {
    var decomposeContexts;
    var condition;
    var containerItem;
    var decomposeContext;
    xit("should return 3 for MatchAny = true for all values and one entity that exists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesEntitiesExistContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesEntitiesExistCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesEntitiesExistDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesEntitiesExistContainer.json', { encoding: 'utf8' }, function (error, containerFileContents) {
                        condition = JSON.parse(conditionFileContents);
                        containerItem = JSON.parse(containerFileContents);
                        decomposeContext = JSON.parse(decomposeContextFileContents);
                        var result = ruleConditionAuditor.MultipleValueConditionsMetForMappingRule(condition, containerItem, decomposeContext, false);
                        chai.expect(result).to.be.a('number');
                        chai.expect(result).to.equal(3);
                        done();
                    });
                });
            });
        });
    });
    it("should return 0 for MatchAny = true for no values and no entity that exists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueNoValuesEntitiesExistContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueNoValuesEntitiesExistCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueNoValuesEntitiesExistDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueNoValuesEntitiesExistContainer.json', { encoding: 'utf8' }, function (error, containerFileContents) {
                        condition = JSON.parse(conditionFileContents);
                        containerItem = JSON.parse(containerFileContents);
                        decomposeContext = JSON.parse(decomposeContextFileContents);
                        var result = ruleConditionAuditor.MultipleValueConditionsMetForMappingRule(condition, containerItem, decomposeContext, false);
                        chai.expect(result).to.be.a('number');
                        chai.expect(result).to.equal(0);
                        done();
                    });
                });
            });
        });
    });
});
describe("when asking the RuleConditionAuditor if a MultipleValueConditionIsMet with Values for a MappingRule, it should return the desired values", function () {
    var decomposeContexts;
    var condition;
    var containerItem;
    var decomposeContext;
    xit("should return 3 for MatchAny = true for all values that exists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesExistContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesExistCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesExistDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueAllValuesExistContainer.json', { encoding: 'utf8' }, function (error, containerFileContents) {
                        condition = JSON.parse(conditionFileContents);
                        containerItem = JSON.parse(containerFileContents);
                        decomposeContext = JSON.parse(decomposeContextFileContents);
                        var result = ruleConditionAuditor.MultipleValueConditionsMetForMappingRule(condition, containerItem, decomposeContext, false);
                        chai.expect(result).to.be.a('number');
                        chai.expect(result).to.equal(3);
                        done();
                    });
                });
            });
        });
    });
    it("should return 2 for MatchAny = true for 2 values and no entity that exists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueSomeValuesExistContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueSomeValuesExistCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueSomeValuesExistDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyTrueSomeValuesExistContainer.json', { encoding: 'utf8' }, function (error, containerFileContents) {
                        condition = JSON.parse(conditionFileContents);
                        containerItem = JSON.parse(containerFileContents);
                        decomposeContext = JSON.parse(decomposeContextFileContents);
                        var result = ruleConditionAuditor.MultipleValueConditionsMetForMappingRule(condition, containerItem, decomposeContext, false);
                        chai.expect(result).to.be.a('number');
                        chai.expect(result).to.equal(0);
                        done();
                    });
                });
            });
        });
    });
    xit("should return 1 for MatchAny = false for all values that NotExists", function (done) {
        fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyFalseNotExistsOnePkgDecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, null);
            fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyFalseNotExistsOnePkgCondition.json', { encoding: 'utf8' }, function (error, conditionFileContents) {
                fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyFalseNotExistsOnePkgCurrentContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                    fs.readFile('cs-mapping/test/data/MultipleValueConditions/MappingRules/matchAnyFalseNotExistsOnePkgContainer.json', { encoding: 'utf8' }, function (error, containerFileContents) {
                        condition = JSON.parse(conditionFileContents);
                        containerItem = JSON.parse(containerFileContents);
                        decomposeContext = JSON.parse(decomposeContextFileContents);
                        var result = ruleConditionAuditor.MultipleValueConditionsMetForMappingRule(condition, containerItem, decomposeContext, false);
                        chai.expect(result).to.be.a('number');
                        chai.expect(result).to.equal(1);
                        done();
                    });
                });
            });
        });
    });
});

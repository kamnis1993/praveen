"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CompiledTypes.d.ts" />
var BadDataTypes = require("../cs-lib-constants/BadDataTypes");
var DateStatus = require("../cs-lib-constants/DateStatus");
var DecomposeGeneratedTypes = require("../cs-lib-constants/DecomposeGeneratedTypes");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var ItemSources = require("../cs-lib-constants/ItemSources");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MappingActionAggregator = require("./MappingActionAggregator");
var MappingActionType = require("../cs-lib-constants/MappingActionType");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityActions = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityActions");
var OrderfolioLinkedEntityQueries = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Executes the mapping actions on the orderfolio that is passed in
 */
var MapperActionDispatcher = /** @class */ (function () {
    /**
     * @constructor
     * @param {CsErrorContext} errorContext The error context on which mapping errors should be reported
     */
    function MapperActionDispatcher(errorContext) {
        this._errorContext = errorContext;
        this._mappingActionAggregator = new MappingActionAggregator();
    }
    /**
     * Executes the mapping actions passed in on the orderfolio
     * @param {Array<CsTypes.CompiledMappingAction>} actions The actions to execute
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio The orderfolio to apply the actions to
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context for the supplied mapping actions
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ExecuteMappingActions = function (actions, decomposeContext, container) {
        var entityCreated = false;
        var actionGroups = this.BuildActionGroups(actions, decomposeContext, container);
        for (var actionGroupIdx = 0; actionGroupIdx < actionGroups.length; actionGroupIdx++) {
            var actionGroup = actionGroups[actionGroupIdx];
            Logger.debug(40, "Mapping Rule", "Executing Action:" + actionGroup.Action.Name, { SubType: "MappingAction", ActionInfo: actionGroup.Action });
            actionGroup.LinkedSourceTargets = this.GatherMappingActionLinkedTargets(actionGroup, decomposeContext, container, entityCreated);
            if (actionGroup.LinkedSourceTargets.length < 1) {
                Logger.debug(50, "Mapping Rule", "Unable to process rule as no linked Source Targets were found", { SubType: "MappingActionLinkedSource" });
                continue;
            }
            switch (actionGroup.Action.ActionType.toLowerCase()) {
                case MappingActionType.SetConfigValue:
                    this.ApplySetConfigValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.CopyConfigValue:
                case MappingActionType.CopyConfigValueMapped:
                    this.ApplyCopyConfigValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.SetLiteralValue:
                    this.ApplySetLiteralValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.CopyUDCValue:
                    this.ApplyCopyUdcValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.CreateEntity:
                    if (this.ApplyCreateEntityAction(actionGroup, decomposeContext, container)) {
                        entityCreated = true;
                    }
                    break;
                case MappingActionType.DeleteEntity:
                    this.ApplyDeleteEntityAction(actionGroup, decomposeContext, container);
                    OrderfolioLinkedEntityActions.ApplyLinkDependencies(decomposeContext);
                    break;
                case MappingActionType.SetUDCToSpecValue:
                case MappingActionType.SetUDCToSpecValueMapped:
                    this.ApplySetUdcToSpecValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.DeleteConfigValue:
                    this.ApplyDeleteConfigValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.DeleteConfigUse:
                    this.ApplyDeleteConfigUseAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.SetRAtoLiteral:
                    this.ApplySetRAToLiteralValueAction(actionGroup, decomposeContext, container);
                    break;
                case MappingActionType.CreateMissingEntityLink:
                    if (this.ApplyCreateMissingEntityLinkAction(actionGroup, decomposeContext, container)) {
                        entityCreated = true;
                    }
                    break;
                default:
                    Logger.debug(50, "Mapping Rule", "Unknown action type:" + actionGroup.Action.ActionType + ". Ignoring!", { SubType: "MappingAction" }); // Not yet supported
                    break;
            }
        }
        return entityCreated;
    };
    /**
     * Builds the actions and the orderfolio items they source and target
     * @param {Array<CsTypes.CompiledMappingAction>} actions The actions to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container entity
     */
    MapperActionDispatcher.prototype.BuildActionGroups = function (actions, decomposeContext, container) {
        var actionGroups = [];
        for (var actionIdx = 0; actionIdx < actions.length; actionIdx++) {
            var action = actions[actionIdx];
            var actionGroup = { Action: action, LinkedSourceTargets: [] };
            // If the action has action conditions, then we need to gather the orderfolio items before the actions can execute
            // This is because the conditions MUST be evaluated before any actions execute
            if (MapperActionDispatcher.HasActionConditions(action)) {
                actionGroup.LinkedSourceTargets = this._mappingActionAggregator.GatherMappingActionLinkedTargets(action, decomposeContext, container);
            }
            actionGroups.push(actionGroup);
        }
        return actionGroups;
    };
    /**
     * Get the source and target pairs that are affected when the mapping action executes
     * @param {CsTypes.MappingActionGroup} actionGroup The mapping action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     * @param {boolean} entityCreated Flag to indicate whether an entity has been created
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MapperActionDispatcher.prototype.GatherMappingActionLinkedTargets = function (actionGroup, decomposeContext, container, entityCreated) {
        var action = actionGroup.Action;
        if (!MapperActionDispatcher.HasActionConditions(action)) {
            return this._mappingActionAggregator.GatherMappingActionLinkedTargets(action, decomposeContext, container);
        }
        if (entityCreated && Utilities.IsNotDefined(actionGroup.LinkedSourceTargets, true)) {
            var newTargets = this._mappingActionAggregator.GatherMappingActionLinkedTargets(action, decomposeContext, container);
            return newTargets;
        }
        if (!entityCreated || Utilities.IsNotDefined(action.Source) || MapperActionDispatcher.HasSourceActionConditions(action) === MapperActionDispatcher.HasDestinationActionConditions(action)) {
            return actionGroup.LinkedSourceTargets;
        }
        // We have either source conditions, or destination conditions, but not both
        // If an entity has been created it means that our orderfolio item for our source or destination does not include the entity that has been recently created
        // This is because when we gather orderfolio items for an action with conditions we do it before any actions execute
        // We need to update the orderfolio items, depending on which target (Source or Destination) DOES NOT have action conditions to include the newly created entities.
        if (MapperActionDispatcher.HasSourceActionConditions(action)) {
            return this.BuildActionDestinationOrderfolioItems(actionGroup, decomposeContext, container);
        }
        else {
            return this.BuildActionSourceOrderfolioItems(actionGroup, decomposeContext, container);
        }
    };
    /**
     * Builds the source orderfolio items and adds them to the destination orderfolio items that were filtered by the action conditions
     * @param {CsTypes.MappingActionGroup} actionGroup the action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     */
    MapperActionDispatcher.prototype.BuildActionSourceOrderfolioItems = function (actionGroup, decomposeContext, container) {
        var existingTargets = actionGroup.LinkedSourceTargets;
        var newSources = this._mappingActionAggregator.GatherMappingActionLinkedTargets(actionGroup.Action, decomposeContext, container);
        this.UpdateSources(existingTargets, newSources);
        return existingTargets;
    };
    /**
     * Builds the destination orderfolio items and adds the sources filtered by the action conditions to each of them
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MapperActionDispatcher.prototype.BuildActionDestinationOrderfolioItems = function (actionGroup, decomposeContext, container) {
        var existingSources = actionGroup.LinkedSourceTargets;
        var newTargets = this._mappingActionAggregator.GatherMappingActionLinkedTargets(actionGroup.Action, decomposeContext, container);
        this.UpdateSources(newTargets, existingSources);
        return newTargets;
    };
    /**
     * Updates the sources on the array of MappingTargetLinkedSourceSet passed in
     * @param {Array<CsTypes.MappingTargetLinkedSourceSet>} targets The targets to change
     * @param {Array<CsTypes.MappingTargetLinkedSourceSet>} sources The sources
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MapperActionDispatcher.prototype.UpdateSources = function (targets, sources) {
        for (var targetIdx = 0; targetIdx < targets.length; targetIdx++) {
            var target = targets[targetIdx];
            // Try to find the new target in our existing set
            var existingLinkTarget = LodashUtilities.Find(sources, function (t) {
                return OrderfolioQueries.CompareOrderfolioItemLookup(target.Target.CompoundKey, t.Target.CompoundKey);
            });
            if (Utilities.IsDefined(existingLinkTarget)) {
                target.Sources = existingLinkTarget.Sources;
            }
        }
        return targets;
    };
    /**
     * Applies the delete config use action to the orderfolio
     * @param {CsTypes.MappingActionGroup} action The mapping action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     */
    MapperActionDispatcher.prototype.ApplyDeleteConfigUseAction = function (actionGroup, decomposeContext, container) {
        MapperActionDispatcher.DeleteCharValuesFromOrderfolioItems(actionGroup, decomposeContext, true, container);
    };
    /**
     * Applies the delete config value action to the orderfolio
     * @param {CsTypes.MappingActionGroup} action The mapping action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     */
    MapperActionDispatcher.prototype.ApplyDeleteConfigValueAction = function (actionGroup, decomposeContext, container) {
        MapperActionDispatcher.DeleteCharValuesFromOrderfolioItems(actionGroup, decomposeContext, false, container);
    };
    /**
     * Applies the set config value action to the orderfolio
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplySetConfigValueAction = function (actionGroup, decomposeContext, container) {
        var action = actionGroup.Action;
        var valueIds = [actionGroup.Action.Destination.LiteralValue];
        var retrieveCharUses = function (orderfolioItem) { return orderfolioItem.CharacteristicUses; };
        this.AddCharacteristicValuesToOrderfolioItems(actionGroup, decomposeContext, valueIds, retrieveCharUses, container);
        if (this._errorContext.HasBreakingErrors) {
            return;
        }
    };
    /**
     * Applies the copy config value action and the mapped version
     * @param {CsTypes.MappingActionGroup} actionGroup The mapping action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplyCopyConfigValueAction = function (actionGroup, decomposeContext, container) {
        var action = actionGroup.Action;
        // function for getting characteristic Uses
        var retrieveCharUses = function (orderfolioItem) { return orderfolioItem.CharacteristicUses; };
        this.ApplyCopyValueAction(actionGroup, decomposeContext, container, retrieveCharUses);
    };
    /**
     * Applies the set literal value mapping action
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplySetLiteralValueAction = function (actionGroup, decomposeContext, container) {
        var action = actionGroup.Action;
        var valueIds = [actionGroup.Action.Destination.LiteralValue];
        var retrieveCharUses = function (orderfolioItem) { return orderfolioItem.UserDefinedCharacteristics; };
        this.AddCharacteristicValuesToOrderfolioItems(actionGroup, decomposeContext, valueIds, retrieveCharUses, container);
    };
    /**
     * Applies the copy UDC value action
     * @param {CsTypes.MappingActionGroup} action The action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplyCopyUdcValueAction = function (actionGroup, decomposeContext, container) {
        var action = actionGroup.Action;
        // function for getting characteristic Uses
        var retrieveCharUses = function (orderfolioItem) { return orderfolioItem.UserDefinedCharacteristics; };
        this.ApplyCopyValueAction(actionGroup, decomposeContext, container, retrieveCharUses);
    };
    /**
     * Apply the Copy Characteristic Value mapping action (Characteristic or UDC) given a function for retrieving the appropriate characteristics
     * This takes note of any entity links set on the Mapping Action
     * @param {CsTypes.MappingActionGroup} actionGroup the Mapping Action group being applied
     * @param {CsTypes.DecomposeContext} decomposeContext the decomposeContext where the mapping action resides
     * @param {CsTypes.OrderfolioItem} container the OrderFolioItem which contains the mapping action
     * @param {(orderfolio: CsTypes.OrderfolioItem) => Array<CsTypes.CharacteristicUse>} retrieveCharUses function to collect characteristic uses
     */
    MapperActionDispatcher.prototype.ApplyCopyValueAction = function (actionGroup, decomposeContext, container, retrieveCharUses) {
        var _this = this;
        var action = actionGroup.Action;
        // For each target source set
        actionGroup.LinkedSourceTargets.forEach(function (targetSourceSet) {
            if (targetSourceSet.Sources.length < 1) {
                Logger.debug(50, "Mapping Rule", "Unable to process rule as no linked Source were found", { SubType: "CopyValueAction" });
                return;
            }
            // Get the MergedIDs of the sources
            var mergedValueIds = _this.GetMergedValueIds(targetSourceSet.Sources, action.Source, action.TranslationTable, retrieveCharUses);
            if (mergedValueIds.length < 1) {
                Logger.debug(50, "Mapping Rule", "Rule not fired - unable to find matching merged values on source items", { SubType: "CopyValueAction" });
                return;
            }
            // Apply to Target
            if (targetSourceSet.Target.Action !== OrderActions.Delete) {
                _this.AddCharacteristicValueItemsToTargetOrderfolioItem(action, targetSourceSet.Target, decomposeContext, mergedValueIds, retrieveCharUses);
            }
        });
    };
    /**
     * Applies the set UDC to spec value action and the mapped version
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} orderfolio The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplySetUdcToSpecValueAction = function (actionGroup, decomposeContext, container) {
        var _this = this;
        var action = actionGroup.Action;
        actionGroup.LinkedSourceTargets.forEach(function (targetSourceSet) {
            if (targetSourceSet.Sources.length < 1) {
                return;
            }
            var retrieveCharUses = function (orderfolioItem) { return orderfolioItem.CharacteristicUses; };
            var mergedValueIds = _this.GetMergedValueIds(targetSourceSet.Sources, action.Source, action.TranslationTable, retrieveCharUses);
            var retrieveUdcs = function (orderfolioItem) { return orderfolioItem.UserDefinedCharacteristics; };
            _this.AddCharacteristicValueItemsToTargetOrderfolioItem(action, targetSourceSet.Target, decomposeContext, mergedValueIds, retrieveUdcs);
        });
    };
    /**
     * Applies the create entity action
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     * @returns {boolean} Whether an entity has been created
     */
    MapperActionDispatcher.prototype.ApplyCreateEntityAction = function (actionGroup, decomposeContext, container) {
        var entityCreated = false;
        var action = actionGroup.Action;
        for (var targetIdx = 0; targetIdx < actionGroup.LinkedSourceTargets.length; targetIdx++) {
            // The parent of the entity we are creating
            var orderfolioItem = actionGroup.LinkedSourceTargets[targetIdx].Target;
            Logger.debug(50, "Mapping Rule", "Attempting to create child entity on: " + orderfolioItem.PortfolioItemId, {
                SubType: "EntityAction",
                EntityID: orderfolioItem.EntityId
            });
            if (orderfolioItem.Action === OrderActions.Delete) {
                Logger.debug(50, "Mapping Rule", "Unable to create entity when ItemAction is Delete", { SubType: "EntityAction" });
                continue;
            }
            // If flag is set, we don't create a new instance of the target entity if one already exists
            if (action.SkipIfEntityExists) {
                var existingChildLookups = decomposeContext.ParentToChildTable[OrderfolioQueries.GetOrderfolioItemKey(orderfolioItem.CompoundKey)];
                if (Utilities.IsDefined(existingChildLookups, true)) {
                    var childAlreadyExists = existingChildLookups.some(function (lookup) {
                        return lookup.Key === action.Destination.Key;
                    });
                    if (childAlreadyExists) {
                        Logger.debug(50, "Mapping Rule", "Skipping action because the child entity already exists", {
                            SubType: "ExistChild",
                            ExistingChild: action.Destination.Key
                        });
                        continue;
                    }
                }
            }
            var entityDates = decomposeContext.CompiledSpec.EntityDates[action.Destination.Key];
            if (Utilities.IsDefined(entityDates) && entityDates.DateStatus !== DateStatus.Available) {
                Logger.debug(50, "Mapping Rule", "Unable to add child entity due to date status", {
                    SubType: "InvalidEntityDates",
                    EntityDate: entityDates.DateStatus
                });
                return entityCreated;
            }
            var childOrderfolioItem = MapperActionDispatcher.AddChildToOrderfolio(orderfolioItem, decomposeContext, action.Destination.Key, action);
            if (Utilities.IsDefined(childOrderfolioItem)) {
                entityCreated = true;
            }
        }
        return entityCreated;
    };
    /**
     * Applies the delete entity action
     * @param {CsTypes.MappingActionGroup} actionGroup The mapping action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.ApplyDeleteEntityAction = function (actionGroup, decomposeContext, container) {
        for (var targetIdx = 0; targetIdx < actionGroup.LinkedSourceTargets.length; targetIdx++) {
            var orderfolioItem = actionGroup.LinkedSourceTargets[targetIdx].Target;
            this.DeleteChildFromOrderfolio(decomposeContext, orderfolioItem, actionGroup.Action);
        }
    };
    /**
    * Applies the set rate attribute to literal value mapping action
    * @param {CsTypes.MappingActionGroup} action The mapping action group
    * @param {CsTypes.DecomposeContext} orderfolio The decompose context
    * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
    */
    MapperActionDispatcher.prototype.ApplySetRAToLiteralValueAction = function (actionGroup, decomposeContext, container) {
        var action = actionGroup.Action;
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        for (var targetIdx = 0; targetIdx < actionGroup.LinkedSourceTargets.length; targetIdx++) {
            var orderfolioItem = actionGroup.LinkedSourceTargets[targetIdx].Target;
            var selectedRateAttributes = orderfolioItem.RatingAttributes.filter(function (rateAttr) { return rateAttr.Name === action.Destination.RateAttributeName; });
            if (action.Replace) {
                MapperActionDispatcher.DeleteRateAttributes(selectedRateAttributes, action.Destination.LiteralValue);
            }
            var existingRateValue = LodashUtilities.Find(selectedRateAttributes, function (v) { return v.Value === action.Destination.LiteralValue; });
            if (Utilities.IsDefined(existingRateValue)) {
                continue;
            }
            var rateAttribute = {
                Name: action.Destination.RateAttributeName,
                Value: action.Destination.LiteralValue,
                Action: MergedActions.AddMissing,
                OrderItemSource: itemSource,
                PortfolioItemSource: itemSource
            };
            orderfolioItem.RatingAttributes.push(rateAttribute);
            Logger.debug(50, "Mapping Rule", "Setting Rate attribute to: " + action.Destination.LiteralValue + "on: " + orderfolioItem.PortfolioItemId, {
                SubType: "SetRAToLiteralValue",
                Rateattribute: rateAttribute
            });
        }
    };
    /**
     * Applies the Create Missing Entity Link action
     * @param {CsTypes.MappingActionGroup} actionGroup The mapping action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     * {boolean} Whether an entity was created
     */
    MapperActionDispatcher.prototype.ApplyCreateMissingEntityLinkAction = function (actionGroup, decomposeContext, container) {
        return MapperActionDispatcher.CreateEntityLinks(actionGroup, decomposeContext);
    };
    /**
    * Deletes a configured value from the orderfolio
    * @param {CsTypes.MappingActionGroup} actionGroup The mapping action group
    * @param {CsTypes.DecomposeContext} decomposeContext the decompose context to use during this operation
    * @param {boolean} deleteAllValues indicates whether all the values on the targeted char use should be deleted, or just the one supplied in the ValueID on action.Destination
    * @param {string} mappingScope The scope of the mapping rule
    * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
    */
    MapperActionDispatcher.DeleteCharValuesFromOrderfolioItems = function (actionGroup, decomposeContext, deleteAllValues, container) {
        var action = actionGroup.Action;
        var getCharacteristicUse = function (useID, orderfolioItem) {
            var matchingCharUses = orderfolioItem.CharacteristicUses.filter(function (charUse) {
                return charUse.UseId === useID;
            });
            if (matchingCharUses.length === 0) {
                return null;
            }
            return matchingCharUses[0];
        };
        for (var targetIdx = 0; targetIdx < actionGroup.LinkedSourceTargets.length; targetIdx++) {
            var targetOrderfolioItem = actionGroup.LinkedSourceTargets[targetIdx].Target;
            var characteristicUse = getCharacteristicUse(action.Destination.UseId, targetOrderfolioItem);
            if (!characteristicUse) {
                Logger.debug(50, "Mapping Rule", "Unable to delete value because charuse: " + characteristicUse + " is in-use", {
                    SubType: "InvalidCharacteristicUse",
                    CharacteristicUse: characteristicUse,
                    ValueToBeDeleted: action.Destination.ValueId
                });
                return;
            }
            // If a reassigned item has characteristics deleted via mapping rules, its action must be changed to reassignedupdate
            if (targetOrderfolioItem.Action === OrderActions.Reassigned) {
                targetOrderfolioItem.Action = OrderActions.ReassignedUpdate;
            }
            var characteristicValues = characteristicUse.Values;
            var needToEnsureActionChain = false;
            for (var k = 0; k < characteristicValues.length; k++) {
                var charValue = characteristicValues[k];
                if (!deleteAllValues && charValue.Value !== action.Destination.ValueId) {
                    continue;
                }
                Logger.debug(50, "Mapping Rule", "Deleting characteristic value Id: " + charValue.Value, {
                    SubType: "DeleteCharacteristicValueId",
                    CharacteristicValues: charValue.Value
                });
                charValue.Action = MergedActions.DeleteExisting;
                needToEnsureActionChain = true;
                if (!deleteAllValues) {
                    break;
                }
            }
            if (needToEnsureActionChain) {
                OrderfolioQueries.EnsureActionHierarchy(decomposeContext, targetOrderfolioItem);
            }
        }
    };
    /**
     * Adds the characteristic values to the orderfolio items specified on the destinations on the mapping action
     * @param {CsTypes.MappingActionGroup} actionGroup The action group to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {(orderfolio: CsTypes.OrderfolioItem) => Array<CsTypes.CharacteristicUse>} retrieveCharUses Retrieves the characteristic uses from an orderfolio (required so we can reuse for UDC's)
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     */
    MapperActionDispatcher.prototype.AddCharacteristicValuesToOrderfolioItems = function (actionGroup, decomposeContext, valueIds, retrieveCharUses, container) {
        var _this = this;
        var action = actionGroup.Action;
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        actionGroup.LinkedSourceTargets.forEach(function (linkedSet) {
            var destinationOrderfolioItem = linkedSet.Target;
            _this.AddCharacteristicValueItemsToTargetOrderfolioItem(action, destinationOrderfolioItem, decomposeContext, valueIds, retrieveCharUses);
        });
    };
    /**
     * Adds the characteristic values to the specified Target orderfolio item
     * @param {CsTypes.CompiledMappingAction} action The MappingAction which fired the Add
     * @param {CsTypes.OrderfolioItem} targetOrderfolioItem The orderfolio item that is a Target of the action
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context containing the action
     * @param {Array<string>} valueIds The set of ValueIds to set on the Target
     * @param {(orderfolio: CsTypes.OrderfolioItem) => Array<CsTypes.CharacteristicUse>} retrieveCharUses Function to retrieve the characteristic uses (or UDC) from an orderfolio
     */
    MapperActionDispatcher.prototype.AddCharacteristicValueItemsToTargetOrderfolioItem = function (action, targetOrderfolioItem, decomposeContext, valueIds, retrieveCharUses) {
        var _this = this;
        // Get the char uses to use for this orderfolio item
        // This allows us to use this same method for handling UDC's and Characteristic Uses
        var orderfolioCharUses = retrieveCharUses(targetOrderfolioItem);
        Logger.debug(50, "Mapping Rule", "Evaluating addition of Char values to: " + targetOrderfolioItem.PortfolioItemId, {
            SubType: "CharacteristicEntityId",
            EntityId: targetOrderfolioItem.EntityId,
            orderItemId: targetOrderfolioItem.OrderItemId,
            portfolioId: targetOrderfolioItem.PortfolioItemId
        });
        // Find the target SpecCharUse or ConfigFact from orderfolioCharUses
        var existingCharacteristicUse = MapperActionDispatcher.FindCharacteristicUse(action.Destination, orderfolioCharUses);
        // There is nothing to do if SkipIfValuesExist is set and there are values
        if (action.SkipIfValuesExist && (Utilities.IsDefined(existingCharacteristicUse) && existingCharacteristicUse.Values.length > 0)) {
            Logger.debug(50, "Mapping Rule", "Skipping action because value already exists", { SubType: "SkippingAction", CharacteristicUse: existingCharacteristicUse });
            return;
        }
        var orderItemChanged = false;
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        // If a reassigned item has characteristics added via mapping rules, its action must be changed to reassignedupdate
        if (targetOrderfolioItem.Action === OrderActions.Reassigned) {
            targetOrderfolioItem.Action = OrderActions.ReassignedUpdate;
        }
        if (Utilities.IsNotDefined(existingCharacteristicUse)) {
            orderItemChanged = true;
            existingCharacteristicUse = {
                Action: OrderActions.Modify,
                UseId: action.Destination.UseId,
                Values: [],
                OrderItemSource: itemSource,
                PortfolioItemSource: itemSource
            };
            orderfolioCharUses.push(existingCharacteristicUse);
        }
        if (action.Replace && existingCharacteristicUse.Values.length > 0) {
            orderItemChanged = this.MarkExistingCharacteristicValuesAsDeleted(existingCharacteristicUse, valueIds, decomposeContext);
        }
        if (this._errorContext.HasBreakingErrors) {
            Logger.debug(50, "Mapping Rule", "An error occurred", { SubType: "CharacteristicEntityId", ErrorContext: this._errorContext });
            return;
        }
        MapperActionDispatcher.AddMissingCharValues(valueIds, existingCharacteristicUse, decomposeContext);
        var copiedValues = existingCharacteristicUse.Values.filter(function (value) {
            return valueIds.indexOf(value.Value) > -1;
        });
        copiedValues.forEach(function (existingValue) {
            existingValue.Action = _this.GetAddMergedAction(existingValue.Action);
            if (MapperActionDispatcher.IsChange(existingValue.Action)) {
                orderItemChanged = true;
            }
        });
        if (orderItemChanged) {
            existingCharacteristicUse.Action = OrderActions.Modify;
            if (Utilities.IsNotDefined(existingCharacteristicUse.OrderItemSource, true)) {
                existingCharacteristicUse.OrderItemSource = itemSource;
            }
            OrderfolioQueries.EnsureActionHierarchy(decomposeContext, targetOrderfolioItem);
        }
    };
    /**
    * Returns true if value action is a change to existing portfolio (including adds)
    * @param {string} mergedAction
    * @returns {boolean}
    */
    MapperActionDispatcher.IsChange = function (mergedAction) {
        switch (mergedAction) {
            case MergedActions.DeleteExisting:
            case MergedActions.AddMissing:
                return true;
            default:
            case MergedActions.AddExisting:
            case MergedActions.SkipExisting:
            case MergedActions.DeleteMissing:
                return false;
        }
    };
    /**
     * Finds the characteristic use for a mapping target
     * @param {CsTypes.MappingTarget} mappingTarget The mapping target
     * @param {Array<CsTypes.CharacteristicUse>} orderfolioItem The characteristic uses to check
     * @returns {CsTypes.CharacteristicUse}
     */
    MapperActionDispatcher.FindCharacteristicUse = function (mappingTarget, charUses) {
        return LodashUtilities.Find(charUses, function (charUse) {
            return charUse.UseId === mappingTarget.UseId;
        });
    };
    /**
     * Marks all existing characteristic values as deleted. Returns true if any values affected
     * @param {CsTypes.CharacteristicUse} charUse The characteristic use to change
     * @param {Array<string>} valueIds The value IDs that will be added by the mapping rule
     */
    MapperActionDispatcher.prototype.MarkExistingCharacteristicValuesAsDeleted = function (charUse, valueIds, decomposeContext) {
        // Only delete values from characteristic use that are not going to be re-added as a result of running the mapping rule
        // Need to know whether deleting char values has changed the order once mapping rule has fired
        // The mapping rule could re-add the values we just deleted, so the order hasn't really changed
        var valuesToDelete = charUse.Values.filter(function (value) { return valueIds.indexOf(value.Value) === -1; });
        if (!valuesToDelete || valuesToDelete.length === 0) {
            return false;
        }
        for (var charValueIdx = 0; charValueIdx < charUse.Values.length; charValueIdx++) {
            var charValue = charUse.Values[charValueIdx];
            charValue.Action = MapperActionDispatcher.GetDeleteMergedAction(charValue.Action, this._errorContext);
            charValue.ItemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        }
        return true;
    };
    /**
     * Gets the new merged action for a delete operation, based on the current merged action
     * @param {string} mergedAction The current merged action
     * @returns {string}
     */
    MapperActionDispatcher.prototype.GetAddMergedAction = function (mergedAction) {
        switch (mergedAction) {
            case MergedActions.AddExisting:
            case MergedActions.DeleteExisting:
            case MergedActions.SkipExisting:
                return MergedActions.AddExisting;
            case MergedActions.AddMissing:
            case MergedActions.DeleteMissing:
                return MergedActions.AddMissing;
            default:
                this._errorContext.RaiseBadDataError(ErrorCode.BadData.UnrecognisedMergeAction, undefined, BadDataTypes.InvalidProperty);
                return undefined;
        }
    };
    /**
     * Gets the new merged action for a delete operation, based on the current merged action
     * @param {string} mergedAction The current merged action
     * @returns {string}
     */
    MapperActionDispatcher.GetDeleteMergedAction = function (mergedAction, errorContext) {
        switch (mergedAction) {
            case MergedActions.AddExisting:
            case MergedActions.DeleteExisting:
            case MergedActions.SkipExisting:
                return MergedActions.DeleteExisting;
            case MergedActions.AddMissing:
            case MergedActions.DeleteMissing:
                return MergedActions.DeleteMissing;
            default:
                errorContext.RaiseBadDataError(ErrorCode.BadData.UnrecognisedMergeAction, undefined, BadDataTypes.InvalidProperty);
                return undefined;
        }
    };
    /**
     * Returns the unique list of value ID's in the list of orderfolio items
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The orderfolio items
     * @param {CsTypes.MappingTarget} target The mapping target
     * @param {CsTypes.Dictionary<string>} translationTable The translation table to convert the value IDs
     * @param {(orderfolio: CsTypes.OrderfolioItem) => Array<CsTypes.CharacteristicUse>} retrieveCharUses Retrieves the characteristic uses from an orderfolio (required so we can reuse for UDC's)
     * @returns {Array<string>}
     */
    MapperActionDispatcher.prototype.GetMergedValueIds = function (orderfolioItems, target, translationTable, retrieveCharUses) {
        var mergedValueIds = [];
        orderfolioItems.forEach(function (orderfolioItem) {
            // Find the matching CharacteristicUse
            var charUses = retrieveCharUses(orderfolioItem);
            var matchingCharUse = LodashUtilities.Find(charUses, function (charUse) { return charUse.UseId === target.UseId; });
            if (Utilities.IsNotDefined(matchingCharUse, true)) {
                return;
            }
            // Get the Characteristic Values off that CharacteristicUse
            var charValues = matchingCharUse.Values.filter(function (value) { return MapperActionDispatcher.ShouldCharValueBeUsed(value); });
            if (Utilities.IsNotDefined(charValues, true)) {
                return;
            }
            // If there is no translation table, push Value Ids into Array
            var valueIds = charValues.map(function (charValue) { return charValue.Value; });
            if (Utilities.IsNotDefined(translationTable) || Object.keys(translationTable).length <= 0) {
                mergedValueIds.push.apply(mergedValueIds, valueIds);
                return;
            }
            // Otherwise run through translation table
            valueIds.forEach(function (valueId) {
                if (Utilities.IsNotDefined(translationTable[valueId])) {
                    Logger.debug(30, "Mapping Rule", "Failed to translate Value Id", { SubType: "ValueId", ValueId: valueId });
                    return;
                }
                mergedValueIds.push(translationTable[valueId]);
            });
        });
        return LodashUtilities.Uniq(mergedValueIds);
    };
    /**
     * Adds the characteristic values that are missing to the characteristic use
     * @param {Array<string>} valueIds -- The list of values that are required
     * @param {CsTypes.CharacteristicUse} charUse -- The characteristic value to check
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    MapperActionDispatcher.AddMissingCharValues = function (valueIds, charUse, decomposeContext) {
        if (valueIds.length < 1) {
            Logger.debug(50, "Mapping Rule", "No missing values found for: " + charUse.UseId, { SubType: "CharUse", CharUse: charUse });
        }
        // Add the values that are missing.
        // Could have Red and Green already, but Blue is also copied
        // In that case we just need to add Blue
        valueIds.forEach(function (valueId) {
            var selectedValue = LodashUtilities.Find(charUse.Values, function (value) { return value.Value === valueId; });
            if (!selectedValue) {
                Logger.debug(50, "Mapping Rule", "Adding Characteristic use: " + valueId, {
                    SubType: "CharUse",
                    CharacteristicUseAction: charUse.Action,
                    Value: valueId,
                    CharUseID: charUse.UseId
                });
                charUse.Values.push({
                    Action: MergedActions.AddMissing,
                    Value: valueId,
                    ItemSource: OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId)
                });
            }
            else {
                Logger.debug(50, "Mapping Rule", "No changes required as " + valueId + " exits", { SubType: "CharUse", Value: valueId, CharUseID: charUse.UseId });
            }
        });
    };
    /**
     * Checks whether the characteristic value is in a state where should be read
     * @param {CsTypes.MergedValue} value The value to check
     * @returns {boolean}
     */
    MapperActionDispatcher.ShouldCharValueBeUsed = function (value) {
        switch (value.Action) {
            case MergedActions.AddExisting:
            case MergedActions.SkipExisting:
            case MergedActions.AddMissing:
                return true;
            default:
                return false;
        }
    };
    /**
     * Creates the entity link if it does not already exist
     * @param {CsTypes.MappingActionGroup} actionGroup The action group
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {boolean} Whether an entity was created
     */
    MapperActionDispatcher.CreateEntityLinks = function (actionGroup, decomposeContext) {
        var action = actionGroup.Action;
        var entityCreated = false;
        var entityLink = action.EntityLink;
        Logger.debug(50, "Mapping Rule", "Creating Entity Link", {
            SubType: "CreateEntityLink",
            EntityLink: entityLink,
            LinkedSourceTargets: actionGroup.LinkedSourceTargets
        });
        for (var targetIdx = 0; targetIdx < actionGroup.LinkedSourceTargets.length; targetIdx++) {
            var linkedTarget = actionGroup.LinkedSourceTargets[targetIdx];
            var orderfolioItem = linkedTarget.Target;
            var sourceLookup = orderfolioItem.CompoundKey;
            // Must not exclude deleted, if the link is being deleted in the order, then we should not create it again
            var sourceToTargetLink = OrderfolioLinkedEntityQueries.GetBySourceAndLinkType(decomposeContext.LinkedEntities, sourceLookup, entityLink.Id);
            if (sourceToTargetLink.length > 0) {
                continue;
            }
            for (var parentIdx = 0; parentIdx < linkedTarget.Sources.length; parentIdx++) {
                var selectedParent = linkedTarget.Sources[parentIdx];
                var childOrderfolioItem = MapperActionDispatcher.AddChildToOrderfolio(selectedParent, decomposeContext, entityLink.Target, action);
                if (Utilities.IsNotDefined(childOrderfolioItem)) {
                    break;
                }
                entityCreated = true;
                var targetLookup = childOrderfolioItem.CompoundKey;
                var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
                orderfolioItem.OrderItemId = (Utilities.IsDefined(orderfolioItem.OrderItemId)) ? (orderfolioItem.OrderItemId) : (Utilities.CreateID());
                var decomposeGenId = OrderfolioQueries.GetDecomposeGenID(DecomposeGeneratedTypes.EntityLinkMapping, [orderfolioItem.OrderItemId, actionGroup.Action.Id]);
                // Child needs to have different DecomposeGenID if we created it through Create Missing EL
                // This is so we can match up the ID's correctly
                childOrderfolioItem.DecomposeGenID = OrderfolioQueries.GetDecomposeGenID(DecomposeGeneratedTypes.EntityLinkChildMapping, [orderfolioItem.OrderItemId, actionGroup.Action.Id]);
                var newEntityLink = {
                    LinkTypeID: entityLink.Id,
                    EntityLinkAction: OrderActions.Add,
                    Source: sourceLookup,
                    Target: targetLookup,
                    ExpectedSource: entityLink.Source,
                    ExpectedTarget: entityLink.Target,
                    IsMulti: entityLink.IsMulti,
                    IsUnique: entityLink.IsUnique,
                    TargetIsDependent: entityLink.TargetIsDependent,
                    LinkAction: MergedActions.AddMissing,
                    IsInvalid: false,
                    PortfolioItemID: childOrderfolioItem.PortfolioItemId,
                    OrderEntityLinkItemSource: itemSource,
                    OrderLinkItemSource: itemSource,
                    PortfolioEntityLinkItemSource: itemSource,
                    PortfolioLinkItemSource: itemSource,
                    DecomposeGenID: decomposeGenId
                };
                decomposeContext.LinkedEntities.push(newEntityLink);
                OrderfolioQueries.EnsureActionHierarchy(decomposeContext, orderfolioItem);
                Logger.debug(50, "Mapping Rule", "Created Entity Link: " + entityLink.Id, { SubType: "CreateEntityLink", EntityLinkDetails: newEntityLink });
            }
        }
        return entityCreated;
    };
    /**
     * Adds the child item specified by the mapping action to the orderfolio
     * @param {CsTypes.OrderfolioItem} parentOrderfolioItem The parent orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {string} targetKey The uuid of the child that is going to be created
     * @param {CsTypes.CompiledMappingAction} action The compiled mapping action
     * @returns {CsTypes.OrderfolioItem} The child that was created
     */
    MapperActionDispatcher.AddChildToOrderfolio = function (parentOrderfolioItem, decomposeContext, targetKey, action) {
        var childOrderfolioItem = undefined;
        // Clone out the template
        if (Object.keys(decomposeContext.CompiledSpec.EntityTemplateLookup).indexOf(targetKey) > -1) {
            childOrderfolioItem = JSON.parse(JSON.stringify(decomposeContext.CompiledSpec.EntityTemplateLookup[targetKey]));
        }
        if (!childOrderfolioItem) {
            Logger.debug(50, "Mapping Rule", "Child Order item not found for targetKey" + targetKey.toString(), { SubType: "MappingAction" });
            return undefined;
        }
        if (Utilities.IsNotDefined(parentOrderfolioItem.OrderItemId, true)) {
            // Need parent ID for DecomposeGenID so if we don't have one then generate one
            // This happens if the parent we are mapping on exists in the portfolio and not in the order
            parentOrderfolioItem.OrderItemId = Utilities.CreateID();
        }
        childOrderfolioItem.OrderItemId = Utilities.CreateID().toLowerCase();
        childOrderfolioItem.PortfolioItemId = Utilities.CreateID().toLowerCase();
        childOrderfolioItem.EntityUniqueCode = childOrderfolioItem.OrderItemId;
        childOrderfolioItem.OrderItemSource = ItemSources.Decompose + decomposeContext.OrderRequestId;
        childOrderfolioItem.PortfolioItemSource = childOrderfolioItem.OrderItemSource;
        childOrderfolioItem.ItemAdded = true;
        var existingOrderfolioSet = decomposeContext.Orderfolio[targetKey];
        if (existingOrderfolioSet && existingOrderfolioSet.length > 0) {
            childOrderfolioItem.CompoundKey.Index = existingOrderfolioSet.length;
            existingOrderfolioSet.push(childOrderfolioItem);
        }
        else {
            childOrderfolioItem.CompoundKey.Index = 0;
            decomposeContext.Orderfolio[targetKey] = [childOrderfolioItem];
        }
        var decomposeGenIndex = 0;
        if (childOrderfolioItem.CompoundKey.Index > 0) {
            decomposeGenIndex = OrderfolioQueries.FilterChildrenToParent(parentOrderfolioItem.CompoundKey, existingOrderfolioSet, decomposeContext, true).length;
        }
        childOrderfolioItem.DecomposeGenID = OrderfolioQueries.GetDecomposeGenID(DecomposeGeneratedTypes.Mapping, [parentOrderfolioItem.OrderItemId, action.Id, decomposeGenIndex.toString()]);
        var parentKey = parentOrderfolioItem.CompoundKey.Key + "-" + parentOrderfolioItem.CompoundKey.Index;
        var childKey = childOrderfolioItem.CompoundKey.Key + "-" + childOrderfolioItem.CompoundKey.Index;
        // Update parent -> child table
        MapperActionDispatcher.UpdateParentToChildTable(decomposeContext.ParentToChildTable, parentKey, childOrderfolioItem.CompoundKey);
        // Update child -> parent table
        decomposeContext.ChildToParentTable[childKey] = parentOrderfolioItem.CompoundKey;
        // Update the action of the parent and its ancestors
        OrderfolioQueries.EnsureActionHierarchy(decomposeContext, parentOrderfolioItem);
        Logger.debug(50, "Mapping Rule", "Created child entity: " + childOrderfolioItem.PortfolioItemId, {
            SubType: "MappingAction",
            ChildEntityId: childOrderfolioItem.EntityId,
            orderitemId: childOrderfolioItem.OrderItemId,
            portfolioId: childOrderfolioItem.PortfolioItemId
        });
        return childOrderfolioItem;
    };
    /**
     * Deletes the specified child from the orderfolio
     * @param {CsTypes.DecomposeContext} decomposeContext THe decompose context
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item to delete
     */
    MapperActionDispatcher.prototype.DeleteChildFromOrderfolio = function (decomposeContext, orderfolioItem, action) {
        orderfolioItem.Action = OrderActions.Delete;
        // TODO: This needs to propagate to all affected links - recursively
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        Logger.debug(50, "Mapping Rule", "Delete child entity: " + orderfolioItem.PortfolioItemId, {
            SubType: "MappingAction",
            EntityId: orderfolioItem.EntityId,
            ActionID: action.Id
        });
        orderfolioItem.DecomposeGenID = DecomposeGeneratedTypes.Existing;
        orderfolioItem.OrderItemSource = itemSource;
        MapperActionDispatcher.CascadeDeleteActionToProperties(orderfolioItem, decomposeContext);
        var recurseChildren = function (parentOrderfolioItem) {
            var parentKey = parentOrderfolioItem.CompoundKey.Key + "-" + parentOrderfolioItem.CompoundKey.Index;
            var children = decomposeContext.ParentToChildTable[parentKey];
            if (Utilities.IsNotDefined(children, true)) {
                return;
            }
            for (var i = 0; i < children.length; i++) {
                var childOrderfolioItem = decomposeContext.Orderfolio[children[i].Key][children[i].Index];
                childOrderfolioItem.Action = OrderActions.Delete;
                childOrderfolioItem.DecomposeGenID = DecomposeGeneratedTypes.Existing;
                childOrderfolioItem.OrderItemSource = itemSource;
                MapperActionDispatcher.CascadeDeleteActionToProperties(childOrderfolioItem, decomposeContext);
                recurseChildren(childOrderfolioItem);
            }
        };
        recurseChildren(orderfolioItem);
        var orderfolioItemKey = orderfolioItem.CompoundKey.Key + "-" + orderfolioItem.CompoundKey.Index;
        var parentLookup = decomposeContext.ChildToParentTable[orderfolioItemKey];
        if (!parentLookup) {
            return;
        }
        var parentOrderFolioItem = decomposeContext.Orderfolio[parentLookup.Key][parentLookup.Index];
        OrderfolioQueries.EnsureActionHierarchy(decomposeContext, parentOrderFolioItem);
    };
    /**
     * Updates the parent -> child table using the supplied parent key and child lookup
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItemLookup>>} parentToChildTable The parent -> child lookup to update
     * @param {string} parentKey The parent key (uuid-index)
     * @param {CsTypes.OrderfolioItemLookup} childLookup The child lookup
     */
    MapperActionDispatcher.UpdateParentToChildTable = function (parentToChildTable, parentKey, childLookup) {
        if (parentToChildTable[parentKey]) {
            parentToChildTable[parentKey].push(childLookup);
        }
        else {
            parentToChildTable[parentKey] = [childLookup];
        }
    };
    /**
     * Marks all of the rate attributes as deleted, except the ones that match the value
     * @param {CsTypes.RateAttribute[]} rateAttributes The rate attributes
     * @param {string} value the rate attribute value
     */
    MapperActionDispatcher.DeleteRateAttributes = function (rateAttributes, value) {
        rateAttributes.forEach(function (r) {
            if (r.Value !== value) {
                r.Action = MergedActions.DeleteExisting;
            }
        });
    };
    /**
     * Cascades delete action to properties of an entity
     * @param   {CsTypes.OrderfolioItem} orderfolioItem the deleted orderfolio item
     * @param   {CsTypes.DecomposeContext} decomposeContext the decompose context
     */
    MapperActionDispatcher.CascadeDeleteActionToProperties = function (orderfolioItem, decomposeContext) {
        MapperActionDispatcher.CascadeDeleteToCharacteristicUses(orderfolioItem.CharacteristicUses, decomposeContext);
        MapperActionDispatcher.CascadeDeleteToUserDefinedCharacteristics(orderfolioItem.UserDefinedCharacteristics, decomposeContext);
        MapperActionDispatcher.CascadeDeleteToRateAttributes(orderfolioItem.RatingAttributes, decomposeContext);
        if (Utilities.IsNotDefined(decomposeContext.LinkedEntities)) {
            return;
        }
        var entityLinksForOrderfolioItem = OrderfolioLinkedEntityQueries.GetBySource(decomposeContext.LinkedEntities, orderfolioItem.CompoundKey);
        MapperActionDispatcher.CascadeDeleteToEntityLinks(entityLinksForOrderfolioItem, decomposeContext);
    };
    /**
     * Cascades delete action to characteristicUse children
     * @param   {CsTypes.CharacteristicUse[]} characteristicUses the to be deleted characteristicUses
     * @param   {CsTypes.DecomposeContext} The decompose context
     */
    MapperActionDispatcher.CascadeDeleteToCharacteristicUses = function (characteristicUses, decomposeContext) {
        if (Utilities.IsNotDefined(characteristicUses)) {
            return;
        }
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        characteristicUses.forEach(function (charUse) {
            charUse.Action = MergedActions.DeleteExisting;
            charUse.OrderItemSource = itemSource;
            charUse.Values.forEach(function (val) {
                val.Action = MergedActions.DeleteExisting;
                val.ItemSource = itemSource;
            });
        });
    };
    /**
     * Cascades delete action to UserDefinedCharacteristic children
     * @param   {CsTypes.CharacteristicUse[]} udcs the to be deleted udcs
     * @param   {CsTypes.DecomposeContext} The decompose context
     */
    MapperActionDispatcher.CascadeDeleteToUserDefinedCharacteristics = function (udcs, decomposeContext) {
        if (Utilities.IsNotDefined(udcs)) {
            return;
        }
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        udcs.forEach(function (udc) {
            udc.Action = MergedActions.DeleteExisting;
            udc.OrderItemSource = itemSource;
            udc.Values.forEach(function (val) {
                val.Action = MergedActions.DeleteExisting;
                val.ItemSource = itemSource;
            });
        });
    };
    /**
     * Cascades delete action to rateAttribute children
     * @param   {CsTypes.RateAttribute[]} rateAttributes the to be deleted rateAttributes
     * @param   {CsTypes.DecomposeContext} The decompose context
     */
    MapperActionDispatcher.CascadeDeleteToRateAttributes = function (rateAttributes, decomposeContext) {
        if (Utilities.IsNotDefined(rateAttributes)) {
            return;
        }
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        rateAttributes.forEach(function (ra) {
            ra.Action = MergedActions.DeleteExisting;
            ra.OrderItemSource = itemSource;
        });
    };
    /**
     * Cascades delete action to entityLink children
     * @param   {CsTypes.SourceToTargetEntityLink[]} entityLinks the to be deleted entityLinks
     * @param   {CsTypes.DecomposeContext} The decompose context
     */
    MapperActionDispatcher.CascadeDeleteToEntityLinks = function (entityLinks, decomposeContext) {
        if (Utilities.IsNotDefined(entityLinks)) {
            return;
        }
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        entityLinks.forEach(function (link) {
            link.OrderEntityLinkItemSource = itemSource;
            link.OrderLinkItemSource = itemSource;
            link.LinkAction = MergedActions.DeleteExisting;
        });
    };
    /**
     * Whether an action has any action conditions on either the source or destination
     * @param {CsTypes.CompiledMappingAction} action The action to check
     * @returns {boolean}
     */
    MapperActionDispatcher.HasActionConditions = function (action) {
        return MapperActionDispatcher.HasSourceActionConditions(action) || MapperActionDispatcher.HasDestinationActionConditions(action);
    };
    /**
     * Whether an action has any source conditions
     * @param {CsTypes.CompiledMappingAction} action The action to check
     * @returns {boolean}
     */
    MapperActionDispatcher.HasSourceActionConditions = function (action) {
        return Utilities.IsDefined(action.Source) && Utilities.IsDefined(action.Source.ActionConditions, true);
    };
    /**
     * Whether an action has any destination conditions
     * @param {CsTypes.CompiledMappingAction} action The action to check
     * @returns {boolean}
     */
    MapperActionDispatcher.HasDestinationActionConditions = function (action) {
        return Utilities.IsDefined(action.Destination.ActionConditions, true);
    };
    return MapperActionDispatcher;
}());
module.exports = MapperActionDispatcher;

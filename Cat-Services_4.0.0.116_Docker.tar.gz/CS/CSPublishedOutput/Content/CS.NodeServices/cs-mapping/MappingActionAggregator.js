"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CompiledTypes.d.ts" />
var DecomposeActivities = require("../cs-lib-constants/DecomposeActivities");
var Logger = require("../cs-logging/Logger");
var MappingActionType = require("../cs-lib-constants/MappingActionType");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityQueries = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RuleConditionAuditor = require("./RuleConditionAuditor");
var Utilities = require("../cs-lib-utilities/Utilities");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
/**
 * Class that builds the source and target orderfolio items for a mapping action
 */
var MappingActionAggregator = /** @class */ (function () {
    function MappingActionAggregator() {
    }
    /**
     * Gathers the source and target orderfolio items for a mapping action
     * @param {CsTypes.CompiledMappingAction} action The mapping action
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container entity for the mapping rule
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MappingActionAggregator.prototype.GatherMappingActionLinkedTargets = function (action, decomposeContext, container) {
        var mappingTargetLinkedSourceSet = [];
        // If there is no Destination or the Destination.TargetId is undefined or -1, then the action is not actioned
        if (Utilities.IsDefined(action.Destination) && (Utilities.IsNotDefined(action.Destination.Key) || action.Destination.Key === '-1')) {
            Logger.debug(40, "Mapping Rule", "Skipped action", { SubType: "MappingAction", Action: action.ActionType });
            return mappingTargetLinkedSourceSet;
        }
        switch (action.ActionType.toLowerCase()) {
            case MappingActionType.SetConfigValue:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.CopyConfigValue:
            case MappingActionType.CopyConfigValueMapped:
                mappingTargetLinkedSourceSet = this.BuildSourceDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.SetLiteralValue:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.CopyUDCValue:
                mappingTargetLinkedSourceSet = this.BuildSourceDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.CreateEntity:
                mappingTargetLinkedSourceSet = this.BuildCreateEntityAction(action, decomposeContext, container);
                break;
            case MappingActionType.DeleteEntity:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.SetUDCToSpecValue:
            case MappingActionType.SetUDCToSpecValueMapped:
                mappingTargetLinkedSourceSet = this.BuildSourceDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.DeleteConfigValue:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.DeleteConfigUse:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.SetRAtoLiteral:
                mappingTargetLinkedSourceSet = this.BuildDestinationAction(action, decomposeContext, container);
                break;
            case MappingActionType.CreateMissingEntityLink:
                mappingTargetLinkedSourceSet = this.CreateMissingEntityLinkAction(action, decomposeContext, container);
                break;
            default:
                Logger.debug(40, "Mapping Rule", "Unknown action type. Ignoring", { SubType: "MappingAction" }); // Not yet supported
                break;
        }
        return mappingTargetLinkedSourceSet;
    };
    /**
     * Builds an action that just has a destination
     * @param {CsTypes.CompiledMappingAction} action The action to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MappingActionAggregator.prototype.BuildDestinationAction = function (action, decomposeContext, container) {
        var targets = [];
        var destinationOrderfolioItems = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, action.Destination, action.Destination.Key, container, action.Destination.ActionConditions);
        destinationOrderfolioItems.forEach(function (o) { targets.push({ Sources: [], Target: o }); });
        return targets;
    };
    /**
     * Build for an action that has both a source and destination
     * @param {CsTypes.CompiledMappingAction} action The action to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MappingActionAggregator.prototype.BuildSourceDestinationAction = function (action, decomposeContext, container) {
        return this.GetTargetLinkedSourceSets(action, decomposeContext, container);
    };
    /**
     * Build for a create entity action
     * @param {CsTypes.CompiledMappingAction} action The action to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container entity
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MappingActionAggregator.prototype.BuildCreateEntityAction = function (action, decomposeContext, container) {
        var targets = [];
        var destinationOrderfolioItems = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, action.Destination, action.Destination.ParentKey, container, action.Destination.ActionConditions);
        destinationOrderfolioItems.forEach(function (o) {
            targets.push({ Sources: [], Target: o });
        });
        return targets;
    };
    /**
     * Build for a create missing entity link action
     * @param {CsTypes.CompiledMappingAction} action The action to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container entity
     * @returns {Array<CsTypes.MappingTargetLinkedSourceSet>}
     */
    MappingActionAggregator.prototype.CreateMissingEntityLinkAction = function (action, decomposeContext, container) {
        var targets = [];
        var entityLinkSources = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, action.Source, action.Source.Key, container, action.Source.ActionConditions);
        for (var sourceIdx = 0; sourceIdx < entityLinkSources.length; sourceIdx++) {
            var orderfolioItem = entityLinkSources[sourceIdx];
            var sourceLookup = orderfolioItem.CompoundKey;
            // Must not exclude deleted, if the link is being deleted in the order, then we should not create it again
            var sourceToTargetLink = OrderfolioLinkedEntityQueries.GetBySourceAndLinkType(decomposeContext.LinkedEntities, sourceLookup, action.EntityLink.Id);
            if (sourceToTargetLink.length > 0) {
                continue;
            }
            var parents = MappingActionAggregator.GetEntityLinkParents(sourceLookup, decomposeContext, action);
            // Must only have one parent to create the target on, if there are multiple possible parents, then the entity link
            // must have IsMulti=true otherwise the action does not execute
            if (parents.length < 1 || (parents.length > 1 && !action.EntityLink.IsMulti)) {
                continue;
            }
            // If we have multiple sources and targets, then the mapping rule fails
            if (parents.length > 1 && entityLinkSources.length > 1) {
                continue;
            }
            // Target is the source of the entity link
            // Sources are the potential parents that can hold the child the target is linked to
            targets.push({ Target: orderfolioItem, Sources: parents });
        }
        return targets;
    };
    /**
     * Gets the potential parents that an entity can be created on to satisfy an entity link
     * @param {CsTypes.OrderfolioItemLookup} sourceLookup The lookup for the source orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.CompiledMappingAction} action The mapping action
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    MappingActionAggregator.GetEntityLinkParents = function (sourceLookup, decomposeContext, action) {
        // Find the orderfolio item for this child that has the entity link definition
        var entityLinkContainerKey = OrderfolioQueries.FindParentForChild(action.EntityLink.Container, sourceLookup, decomposeContext);
        if (Utilities.IsNotDefined(entityLinkContainerKey)) {
            return undefined;
        }
        var entityLinkContainer = decomposeContext.Orderfolio[entityLinkContainerKey.Key][entityLinkContainerKey.Index];
        var parents = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, action.Destination, action.Destination.Key, entityLinkContainer, action.Destination.ActionConditions);
        return parents;
    };
    /**
     * For an mapping action get the collection of the set of Source OrderfolioItems which can affect each Target of the action
     * If there is no EntityLink defined on a MappingAction then each Target can be affected by all Sources
     * Otherwise, the Sources which can affect each target is limited by the EntityLink.
     * If a Target has no Sources then it is not returned.
     * @param {CsTypes.CompiledMappingAction} action the Mapping Action being applied
     * @param {CsTypes.DecomposeContext} decomposeContext the decomposeContext where the mapping action resides
     * @param {CsTypes.OrderfolioItem} container the OrderFolioItem which contains the mapping action
     * @param {(orderfolio: CsTypes.OrderfolioItem) => Array<CsTypes.CharacteristicUse>} retrieveCharUses function to collect characteristic uses
     * @return {Array<CsTypes.MappingTargetLinkedSourceSet>} the collection of Target linked source sets
     */
    MappingActionAggregator.prototype.GetTargetLinkedSourceSets = function (action, decomposeContext, container) {
        // Get applicable Target & Source OrderfolioItems
        var targetOrderfolioItems = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, action.Destination, action.Destination.Key, container, action.Destination.ActionConditions);
        if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
            return [];
        }
        var sourceOrderfolioItems = MappingActionAggregator.GetApplicableSourceOrderfolioItems(decomposeContext, action.Source, container);
        // +++++++ If there's NO EntityLink on the action,
        // return all sources coupled with every target
        if (Utilities.IsNotDefined(action.EntityLink, true)) {
            return targetOrderfolioItems.map(function (target) {
                var newPair = {
                    Target: target,
                    Sources: sourceOrderfolioItems
                };
                return newPair;
            });
        }
        // ++++++ There IS an EntityLink on the action
        // Lets slog through the links to see which targets can see which sources via links
        var linkedSets = [];
        // Get all EntityLink instances which match the link on the action
        var sourceTargetLinks = OrderfolioLinkedEntityQueries.GetByEntityLink(decomposeContext.LinkedEntities, action.EntityLink, true);
        // And collect all descendent items connected by each link
        var linkedDescendentCollections = sourceTargetLinks.map(function (stl) { return OrderfolioLinkedEntityQueries.GetLinkedOrderfolioItemCollection(stl, decomposeContext); });
        // Go through each target item in turn looking to see which sources can affect it
        targetOrderfolioItems.forEach(function (target) {
            var targetKey = OrderfolioQueries.GetOrderfolioItemKey(target.CompoundKey);
            var sourcesFound = [];
            var sourceKeys = [];
            // Function to check the sources against a collection and put any found into the sourcesFound set
            // only doing so if it's not already in the set
            var checkForSources = function (keySearchCollection) {
                sourceOrderfolioItems.forEach(function (sourceItem) {
                    var sourceKey = OrderfolioQueries.GetOrderfolioItemKey(sourceItem.CompoundKey);
                    if (keySearchCollection.indexOf(sourceKey) >= 0 && sourceKeys.indexOf(sourceKey) < 0) {
                        sourcesFound.push(sourceItem);
                        sourceKeys.push(sourceKey);
                    }
                });
            };
            // Look for the target in each of the linked Orderfolio sets
            linkedDescendentCollections.forEach(function (linkedOrderfolioCollection) {
                if (linkedOrderfolioCollection.TargetDescendents.indexOf(targetKey) >= 0) {
                    // If it's found in the TargetDescendents then any of the sources in the SourceDescendents can see it
                    checkForSources(linkedOrderfolioCollection.SourceDescendents);
                }
                else if (linkedOrderfolioCollection.SourceDescendents.indexOf(targetKey) >= 0) {
                    // If it's found in the SourceDescendents then any of the sources in the TargetDescendents can see it
                    checkForSources(linkedOrderfolioCollection.TargetDescendents);
                }
            });
            var newLinkedPair = {
                Target: target,
                Sources: sourcesFound
            };
            linkedSets.push(newLinkedPair);
        });
        return linkedSets;
    };
    /**
     * Gets the collection of orderfolio items applicable after checking state and conditions
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.MappingTarget} mappingTarget The mapping target
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    MappingActionAggregator.GetApplicableSourceOrderfolioItems = function (decomposeContext, mappingTarget, container) {
        var validOrderfolioItems = [];
        var orderfolioItems = MappingActionAggregator.GetApplicableOrderfolioItems(decomposeContext, mappingTarget, mappingTarget.Key, container, mappingTarget.ActionConditions);
        for (var ofIndex = 0; ofIndex < orderfolioItems.length; ofIndex++) {
            if (MappingActionAggregator.AreSourceConditionsMet(mappingTarget.Conditions, orderfolioItems[ofIndex])) {
                validOrderfolioItems.push(orderfolioItems[ofIndex]);
            }
        }
        return validOrderfolioItems;
    };
    /**
     * Gets the collection of orderfolio items applicable after checking state
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.CompiledMappingAction} mappingTarget The mapping target
     * @param {CsTypes.Uuid} mappingTarget The Uuid of the orderfolio items we are looking at
     * @param {CsTypes.OrderfolioItem} container The orderfolio item that contains the mapping rule
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    MappingActionAggregator.GetApplicableOrderfolioItems = function (decomposeContext, mappingTarget, key, container, actionConditions) {
        var orderfolioItems = decomposeContext.Orderfolio[key];
        if (Utilities.IsNotDefined(orderfolioItems, true)) {
            return [];
        }
        var selectedOrderfolioItems = MappingActionAggregator.GetOrderfolioItemsInCorrectState(orderfolioItems, mappingTarget);
        // Ensure we only use the orderfolio items that belong to our parent
        selectedOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(container.CompoundKey, selectedOrderfolioItems, decomposeContext);
        // Check the conditions on the action
        selectedOrderfolioItems = MappingActionAggregator.FilterOrderfolioItemsByActionConditions(selectedOrderfolioItems, actionConditions, decomposeContext);
        // Check the dates on the orderfolio item
        selectedOrderfolioItems = MappingActionAggregator.FilterOrderfolioItemsByDate(decomposeContext, selectedOrderfolioItems);
        return selectedOrderfolioItems;
    };
    /**
     * Filters the orderfolio items by the action conditions
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The orderfolio items
     * @param {Array<CsTypes.Condition>} actionConditions The action conditions
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    MappingActionAggregator.FilterOrderfolioItemsByActionConditions = function (orderfolioItems, actionConditions, decomposeContext) {
        if (Utilities.IsNotDefined(actionConditions) || actionConditions.length === 0) {
            return orderfolioItems;
        }
        var errorContext = new CsErrorContext();
        var ruleAuditor = new RuleConditionAuditor([decomposeContext], errorContext);
        var filteredOrderfolioItems = orderfolioItems.filter(function (o) {
            return ruleAuditor.AreMappingActionConditionsMet(actionConditions, o, decomposeContext);
        });
        return filteredOrderfolioItems;
    };
    /**
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem[]} orderfolioItems The orderfolio items
     * @returns {CsTypes.OrderfolioItem[]} returns an orderfolio item back in an array
     */
    MappingActionAggregator.FilterOrderfolioItemsByDate = function (decomposeContext, orderfolioItems) {
        var filteredOrderfolioItems = [];
        orderfolioItems.forEach(function (ofi) {
            if (Utilities.IsNotDefined(decomposeContext.CompiledSpec.EntityDates)) {
                filteredOrderfolioItems.push(ofi);
                return;
            }
            if (ofi.IsInvalid || !OrderfolioQueries.IsActivityValidForOrderfolioItem(decomposeContext.CompiledSpec, ofi.CompoundKey.Key, DecomposeActivities.Mapping)) {
                return;
            }
            filteredOrderfolioItems.push(ofi);
            return;
        });
        return filteredOrderfolioItems;
    };
    /**
     * Gets the list of orderfolio items that are in the correct state
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The list of orderfolio items to check
     * @param {CsTypes.CompiledMappingAction} mappingTarget The mapping target
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    MappingActionAggregator.GetOrderfolioItemsInCorrectState = function (orderfolioItems, mappingTarget) {
        if (Utilities.IsNotDefined(mappingTarget)) {
            return orderfolioItems;
        }
        var itemsInCorrectState = [];
        for (var positionIdx = 0; positionIdx < orderfolioItems.length; positionIdx++) {
            var orderfolioItem = orderfolioItems[positionIdx];
            if (MappingActionAggregator.IsCorrectState(mappingTarget.State, orderfolioItem)) {
                itemsInCorrectState.push(orderfolioItem);
            }
        }
        return itemsInCorrectState;
    };
    /**
     * Checks whether the orderfolio item is in the correct state for the action to fire
     * @param {CsTypes.State} states The list of states
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item to check
     * @returns {boolean}
     */
    MappingActionAggregator.IsCorrectState = function (states, orderfolioItem) {
        var stateOfOrderfolioItem = orderfolioItem.Action ? orderfolioItem.Action : OrderActions.NoChange;
        if (states.NoChange && stateOfOrderfolioItem === OrderActions.NoChange) {
            return true;
        }
        if (states.Add && stateOfOrderfolioItem === OrderActions.Add) {
            return true;
        }
        if (states.Delete && stateOfOrderfolioItem === OrderActions.Delete) {
            return true;
        }
        if (states.Update && stateOfOrderfolioItem === OrderActions.Update) {
            return true;
        }
        if (states.Reassigned && stateOfOrderfolioItem === OrderActions.Reassigned) {
            return true;
        }
        if (states.ReassignedUpdate && stateOfOrderfolioItem === OrderActions.Reassigned) {
            return true;
        }
        return false;
    };
    /**
     * Checks the conditions on a mapping rule
     * @param {CsTypes.CompatibilityRule} conditions The conditions on the mapping rule to check
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts The decompose contexts
     */
    MappingActionAggregator.AreSourceConditionsMet = function (conditions, source) {
        // If we have nothing to check, return true
        if (!conditions) {
            return true;
        }
        if (MappingActionAggregator.CheckExistsForConditions(conditions.ExistsValue, source) < conditions.ExistsValue.length) {
            Logger.debug(41, "Mapping Rule", "Failed ExistsValue source conditions", { SubType: "SourceConditions", Condition: conditions });
            return false;
        }
        if (MappingActionAggregator.CheckExistsForConditions(conditions.NotExistsValue, source) > 0) {
            Logger.debug(41, "Mapping Rule", "Failed NotExistsValue source conditions", { SubType: "SourceConditions", Condition: conditions });
            return false;
        }
        // All conditions pass
        return true;
    };
    /**
 * Checks whether an item can be found for each condition
 * @param {Array<CsTypes.Condition>} conditions The conditions to check
 * @param {CsTypes.DecomposeContextCollection} decomposeContexts The decompose contexts
 * @returns number of matches found
 */
    MappingActionAggregator.CheckExistsForConditions = function (conditions, source) {
        var found = 0;
        for (var conditionIdx = 0; conditionIdx < conditions.length; conditionIdx++) {
            var condition = conditions[conditionIdx];
            for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                var targetPathItem = condition.TargetPaths[targetPath];
                if (targetPathItem.ValueId) {
                    var foundValueId = OrderfolioQueries.HasValueId(targetPathItem.ValueId, targetPathItem.UseId, [source]);
                    if (foundValueId) {
                        found++;
                        continue;
                    }
                }
                else {
                    if (!Utilities.IsDefined(targetPathItem.UseId)) {
                        continue;
                    }
                    // Check to ensure we have at least one characteristic use or user defined characteristic
                    // which has not been deleted and which matches the target UseId
                    var characteristicsToCheck = [];
                    characteristicsToCheck = characteristicsToCheck.concat(source.CharacteristicUses);
                    characteristicsToCheck = characteristicsToCheck.concat(source.UserDefinedCharacteristics);
                    for (var cuIndex = 0; cuIndex < characteristicsToCheck.length; cuIndex++) {
                        var cUse = characteristicsToCheck[cuIndex];
                        if ((cUse.UseId !== targetPathItem.UseId)) {
                            continue;
                        }
                        if (cUse.Values.some(function (value) { return !OrderfolioQueries.IsDeleted(value); })) {
                            found++;
                            continue;
                        }
                    }
                }
            }
        }
        return found;
    };
    return MappingActionAggregator;
}());
module.exports = MappingActionAggregator;

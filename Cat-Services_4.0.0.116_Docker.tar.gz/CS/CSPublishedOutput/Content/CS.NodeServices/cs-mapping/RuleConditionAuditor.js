"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CompiledTypes.d.ts" />
var CompiledSpecificationQueries = require("../cs-lib-composition/CompiledSpecificationQueries");
var CountConditionMethods = require("./CountConditionMethods");
var DecomposeActivities = require("../cs-lib-constants/DecomposeActivities");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityQueries = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RuleConditionType = require("../cs-lib-constants/RuleConditionType");
var RuleScope = require("../cs-lib-constants/RuleScope");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class that evaluates rule conditions
 */
var RuleConditionAuditor = /** @class */ (function () {
    function RuleConditionAuditor(decomposeContexts, errorContext) {
        this._decomposeContexts = decomposeContexts;
        this._countConditionMethods = new CountConditionMethods(errorContext);
    }
    /**
     * Checks whether the mapping rule conditions are met
     * @param {CsTypes.CompiledMappingRule} mappingRule The compiled mapping rule
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     * @param {CsTypes.DecomposeContext} currentDecomposeContext The current decompose context
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.AreMappingRuleConditionsMet = function (mappingRule, container, currentDecomposeContext) {
        var conditions = CompiledSpecificationQueries.AllRuleConditions(mappingRule.Conditions);
        return this.AreMappingConditionsMet(conditions, container, currentDecomposeContext, false);
    };
    /**
     * Checks whether the mapping action conditions are met
     * @param {Array<CsTypes.Condition>} conditions The conditions to check
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     * @param {string} mappingRuleScope The mapping rule scope
     * @param {CsTypes.DecomposeContext} currentDecomposeContext The current decompose context
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.AreMappingActionConditionsMet = function (conditions, container, currentDecomposeContext) {
        Logger.debug(30, "Mapping Rule", "Evaluating Action Conditions for: " + container.PortfolioItemId, { SubType: "ActionCondition", EntityId: container.EntityId });
        return this.AreMappingConditionsMet(conditions, container, currentDecomposeContext, true);
    };
    /**
     * Checks the conditions on a mapping rule
     * @param {Array<CsTypes.Condition>} conditions The conditions to check
     * @param {CsTypes.OrderfolioItem} container The mapping rule container
     * @param {string} mappingRuleScope The mapping rule scope
     * @param {CsTypes.DecomposeContext} decomposeContext The current decompose context
     * @param {boolean} isActionCondition Flag to indicate if we are checking action conditions
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.AreMappingConditionsMet = function (conditions, container, decomposeContext, isActionCondition) {
        Logger.debug(40, "Mapping Rule", conditions.length + " Conditions found on Mapping rule", { SubType: "RuleCondition", Condition: conditions });
        for (var conditionIdx = 0; conditionIdx < conditions.length; conditionIdx++) {
            var condition = conditions[conditionIdx];
            var matchesFound = 0;
            if (condition.ConditionType === RuleConditionType.EntToEnt || condition.ConditionType === RuleConditionType.EntToStatic
                || condition.ConditionType === RuleConditionType.EntToUDC) {
                if (this.CheckCountCondition(condition, decomposeContext, container, isActionCondition)) {
                    matchesFound++;
                }
            }
            else if (condition.ConditionType === RuleConditionType.ExistsData || condition.ConditionType === RuleConditionType.NotExistsData) {
                matchesFound = this.MultipleValueConditionsMetForMappingRule(condition, container, decomposeContext, isActionCondition);
            }
            else {
                matchesFound = this.CheckExistsForCondition(condition, container, decomposeContext, isActionCondition);
            }
            if (condition.ExistsCondition) {
                if (matchesFound > 0) {
                    Logger.debug(41, "Mapping Rule", condition.Name + " Exists condition Satisfied", { SubType: "RuleCondition", Condition: condition });
                    continue;
                }
                Logger.debug(41, "Mapping Rule", condition.Name + " Exists condition not Satisfied", { SubType: "RuleCondition", Condition: condition });
                return false;
            }
            else {
                if (matchesFound === 0) {
                    Logger.debug(41, "Mapping Rule", condition.Name + " NotExists condition Satisfied", { SubType: "RuleCondition", Condition: condition });
                    continue;
                }
                Logger.debug(41, "Mapping Rule", condition.Name + " NotExists conditions are not Satisfied", { SubType: "RuleCondition", Condition: condition });
                return false;
            }
        }
        return true;
    };
    /**
     * Determines whether the multiple target paths defined in a multiple value condition meet the conditions
     * @param condition
     * @param container
     * @param decomposeContext
     * @param isActionCondition
     */
    RuleConditionAuditor.prototype.MultipleValueConditionsMetForMappingRule = function (condition, container, currentDecomposeContext, isActionCondition) {
        var matchesFound = [];
        var matchedTargets = 0;
        var entityPaths = [];
        var _loop_1 = function () {
            var targetPathItem = condition.TargetPaths[targetPath];
            // Add the EntityPath for match comparison if defined
            if (Utilities.IsDefined(targetPathItem.EntityPath)) {
                entityPaths.push(targetPathItem.EntityPath);
            }
            var _loop_2 = function () {
                if (condition.Scope !== RuleScope.ProductCandidate) {
                    // We count every target for the MatchAny property in order to compare AND conditions
                    matchedTargets++;
                }
                var existsTarget = condition.TargetPaths[targetPath].Targets[targetIdx];
                var decomposeContext = (Utilities.IsDefined(existsTarget.DecomposeContextIndex)) ? this_1._decomposeContexts[existsTarget.DecomposeContextIndex] : currentDecomposeContext;
                var orderfolioItemSet = this_1.GatherOrderfolioItems(decomposeContext, container, existsTarget, condition.Scope, isActionCondition);
                var foundOrderfolio = orderfolioItemSet.length > 0;
                if (Utilities.IsNotDefined(foundOrderfolio)) {
                    return "continue";
                }
                var targetOrderfolioItems = decomposeContext.Orderfolio[existsTarget.Key];
                if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
                    return "continue";
                }
                if (condition.Scope === RuleScope.ProductCandidate) {
                    // When it's a ProductCandidate scope we want to count up the targets when they actually exist in the OrderFolio
                    matchedTargets++;
                }
                // Do all the value/container checks. If a match is found, add to the target collection.
                if (targetPathItem.IsElementReference) {
                    this_1.CheckElementReferenceTargets(targetPathItem, targetOrderfolioItems, matchesFound, existsTarget);
                }
                // This is targeting an entity
                else if (Utilities.IsDefined(targetPathItem.Action)) {
                    // Ensure the order action on the orderfolio items match the condition
                    var actionMatches_1 = false;
                    targetOrderfolioItems.forEach(function (orderfolioItem) {
                        if (orderfolioItem.Action === targetPathItem.Action) {
                            actionMatches_1 = true;
                            return;
                        }
                    });
                    if (actionMatches_1) {
                        matchesFound.push(this_1.CreateTargetMatchContext(existsTarget, targetPathItem));
                    }
                }
                else if (Utilities.IsNotDefined(targetPathItem.Action)) {
                    matchesFound.push(this_1.CreateTargetMatchContext(existsTarget, targetPathItem));
                }
            };
            for (var targetIdx = 0; targetIdx < condition.TargetPaths[targetPath].Targets.length; targetIdx++) {
                _loop_2();
            }
        };
        var this_1 = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            _loop_1();
        }
        if (matchesFound.length > 0) {
            // The OR condition.. just return true if ANY matches found
            if (condition.MatchAny) {
                return matchesFound.length;
            }
            // This is the AND condition.. counts the number of matches against the number of targets
            else if (matchedTargets === matchesFound.length) {
                // If the scope is a ProductCandidate, we need to filter down the matches and AND them based on the EntityPath
                if (condition.Scope === RuleScope.ProductCandidate) {
                    var candidateWideMatches = [];
                    for (var m = 0; m < matchesFound.length; m++) {
                        var match = matchesFound[m].TargetPathItem;
                        if (entityPaths.includes(match.EntityPath)) {
                            candidateWideMatches.push(match.EntityPath);
                        }
                    }
                    // Return number of matches if not exists condition so it can be checked in calling method
                    if (!condition.ExistsCondition) {
                        return candidateWideMatches.length;
                    }
                    // Get any items that were not matched throughout the Product Candidate
                    // If there are no differences, we have matched all items, and the condition has been met
                    return LodashUtilities.Difference(entityPaths, candidateWideMatches).length;
                }
                // If it's any other scope, we have a match
                else {
                    return matchesFound.length;
                }
            }
            else if (matchedTargets !== matchesFound.length) {
                // If we do not match all targets, we return 0 as the condition is not met
                return 0;
            }
        }
        return matchesFound.length;
    };
    /**
     * Checks whether an item can be found for each condition
     * @param {CsTypes.Condition} condition The conditions to check
     * @param {CsTypes.DecomposeContextCollection} container The orderfolio item that the mapping rule belongs to
     * @param {CsTypes.DecomposeContext} currentDecomposeContext The current decompose context
     * @param {boolean} isActionCondition Flag to indicate if we are checking action conditions
     * @returns number of matches found
     */
    RuleConditionAuditor.prototype.CheckExistsForCondition = function (condition, container, currentDecomposeContext, isActionCondition) {
        var found = 0;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            for (var targetIdx = 0; targetIdx < condition.TargetPaths[targetPath].Targets.length; targetIdx++) {
                var existsTarget = condition.TargetPaths[targetPath].Targets[targetIdx];
                var decomposeContext = (Utilities.IsDefined(existsTarget.DecomposeContextIndex)) ? this._decomposeContexts[existsTarget.DecomposeContextIndex] : currentDecomposeContext;
                var orderfolioItemSet = this.GatherOrderfolioItems(decomposeContext, container, existsTarget, condition.Scope, isActionCondition);
                var foundOrderfolio = orderfolioItemSet.length > 0;
                if (Utilities.IsNotDefined(foundOrderfolio)) {
                    continue;
                }
                if (this.TargetExists(decomposeContext, orderfolioItemSet, condition)) {
                    found++;
                }
            }
        }
        return found;
    };
    /**
   * Checks decompose contexts, gathering all count criterias that need to be check to see if the condition is satisfied.
   * @param {CsTypes.Condition} condition The conditions to check
   * @param {CsTypes.DecomposeContext} currentDecomposeContext The current decompose context
   * @param {CsTypes.DecomposeContextCollection} container The orderfolio item that the mapping rule belongs to
   * @returns an array of boolean based on if the count matches the condition
   */
    RuleConditionAuditor.prototype.CheckCountCondition = function (condition, currentDecomposeContext, containerEntity, isActionCondition) {
        var countConditionCriterias = new Array();
        var matchAnyArray = new Array();
        var _loop_3 = function (targetPath) {
            var targetPathItem = condition.TargetPaths[targetPath];
            // Iterate through each target inside each target path
            for (var targets = 0; targets < targetPathItem.Targets.length; targets++) {
                var target = targetPathItem.Targets[targets];
                var targetHasDecomposeContextIndex = Utilities.IsDefined(target.DecomposeContextIndex);
                currentDecomposeContext = targetHasDecomposeContextIndex ? this_2._decomposeContexts[target.DecomposeContextIndex] : currentDecomposeContext;
                var targetOrderfolioItems = this_2.GatherOrderfolioItems(currentDecomposeContext, containerEntity, target, condition.Scope, isActionCondition, false);
                targetOrderfolioItems = targetOrderfolioItems.filter(function (x) { return Utilities.IsDefined(x.OrderItemId) && Utilities.IsNotDefined(x.DecomposeGenID); });
                if (Utilities.IsDefined(targetPathItem.Action)) {
                    targetOrderfolioItems = targetOrderfolioItems.filter(function (element) {
                        return element.Action === targetPathItem.Action && Utilities.IsDefined(element.OrderItemId) && Utilities.IsNotDefined(element.DecomposeGenID);
                    });
                }
                if (targetOrderfolioItems.length === 0) {
                    continue;
                }
                if (Utilities.IsDefined(condition.FurtherScope)) {
                    // Get the scoped orderfolio items that we will need to filter out its children.
                    var parentOrderfolioItems = this_2._countConditionMethods.GetFurtherScopedOrderfolioItems(currentDecomposeContext, condition);
                    if (Utilities.IsNotDefined(parentOrderfolioItems) || parentOrderfolioItems.length === 0) {
                        continue;
                    }
                    for (var poi = 0; poi < parentOrderfolioItems.length; poi++) {
                        var countCriteria = this_2._countConditionMethods.GetCountCriteria(parentOrderfolioItems[poi].EntityUniqueCode, countConditionCriterias);
                        var targetChildOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(parentOrderfolioItems[poi].CompoundKey, targetOrderfolioItems, currentDecomposeContext);
                        this_2._countConditionMethods.AssignValuesToCountCriteria(countCriteria, condition, targetPathItem, targetChildOrderfolioItems);
                        if (!this_2._countConditionMethods.IsCountCriteriaInCollection(countConditionCriterias, parentOrderfolioItems[poi].EntityUniqueCode)) {
                            countConditionCriterias.push(countCriteria);
                        }
                    }
                }
                else {
                    var countCriteria = this_2._countConditionMethods.GetCountCriteria(currentDecomposeContext.OrderRequestId, countConditionCriterias);
                    this_2._countConditionMethods.AssignValuesToCountCriteria(countCriteria, condition, targetPathItem, targetOrderfolioItems);
                    if (!this_2._countConditionMethods.IsCountCriteriaInCollection(countConditionCriterias, currentDecomposeContext.OrderRequestId)) {
                        countConditionCriterias.push(countCriteria);
                    }
                }
            }
        };
        var this_2 = this;
        // Iterate through each Target Path
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            _loop_3(targetPath);
        }
        for (var con = 0; con < countConditionCriterias.length; con++) {
            matchAnyArray.push(this._countConditionMethods.CompareCountConditionCriterias(condition, countConditionCriterias[con].LeftCountNames.length, countConditionCriterias[con].RightCountNames.length, countConditionCriterias[con].UDCValue));
        }
        return this._countConditionMethods.MatchAny(condition.MatchAny, matchAnyArray);
    };
    /**
     * Determines whether the given item target exists, true if it exists, false if it can't be found
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem[]} orderfolioItemSet The orderfolio item set
     * @param {CsTypes.ItemPath} condition
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.TargetExists = function (decomposeContext, orderfolioItemSet, condition) {
        var _this = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            var targetPathItem = condition.TargetPaths[targetPath];
            var orderfolioItemSetContainsValidItems = orderfolioItemSet.some(function (orderfolioItem) {
                return !orderfolioItem.IsInvalid
                    && _this.OrderFolioItemHasNotBeenDeleted(orderfolioItem, targetPathItem);
            });
            if (!orderfolioItemSetContainsValidItems) {
                return false;
            }
            if (condition.ConditionType === RuleConditionType.UDCMatchesValue) {
                // Matches UDC Regex Values
                return this.UDCMatchValues(orderfolioItemSet, targetPathItem);
            }
            else if (condition.ConditionType === RuleConditionType.ItemValueAction && Utilities.IsDefined(targetPathItem.Action) && !condition.ExpectedEmptyValue) {
                // The Exists or NotExistsOrderAction conditions
                return this.MatchesItemValueAction(orderfolioItemSet, targetPathItem);
            }
            else if (condition.ConditionType === RuleConditionType.ItemValueAction && Utilities.IsDefined(targetPathItem.Action) && condition.ExpectedEmptyValue) {
                // The NoValueExistsOrderAction condition
                return this.AllValuesMatchItemValueAction(orderfolioItemSet, targetPathItem);
            }
            else if (Utilities.IsDefined(targetPathItem.ValueId, true)) {
                // Exists Value
                return OrderfolioQueries.HasValueId(targetPathItem.ValueId, targetPathItem.UseId, orderfolioItemSet);
            }
            else if (condition.ExpectedEmptyValue && Utilities.IsDefined(targetPathItem.UseId, true)) {
                // No Value Exists
                return !this.AllHaveValues(targetPathItem.UseId, orderfolioItemSet);
            }
            else if (Utilities.IsDefined(targetPathItem.UseId)) {
                // Container Exists
                return this.HasUseId(targetPathItem.UseId, orderfolioItemSet);
            }
            else if (Utilities.IsDefined(targetPathItem.LinkTypeID, true)) {
                // Entity Link exists
                return this.HasEntityLink(targetPathItem.LinkTypeID, orderfolioItemSet, decomposeContext.LinkedEntities);
            }
            else if (Utilities.IsDefined(targetPathItem.Action, true)) {
                return orderfolioItemSet.some(function (ofItem) { return ofItem.Action === targetPathItem.Action; });
            }
            else {
                // This is an entity exists condition
                return true;
            }
        }
    };
    /**
     * Determines whether the multiple target paths defined in a multiple value condition meet the conditions
     * @param condition
     * @param decomposeContexts
     * @param currentDecomposeIndex
     * @param scopedEntity
     * @param containerEntity
     */
    RuleConditionAuditor.prototype.MultipleValueConditionsMetForCompatibilityRule = function (condition, currentDecomposeIndex, scopedEntity, containerEntity) {
        var matchesFound = [];
        var matchedTargets = 0;
        var entityPaths = [];
        var _loop_4 = function () {
            var targetPathItem = condition.TargetPaths[targetPath];
            // Add the EntityPath for match comparison if defined
            if (Utilities.IsDefined(targetPathItem.EntityPath)) {
                entityPaths.push(targetPathItem.EntityPath);
            }
            var _loop_5 = function () {
                if (condition.Scope !== RuleScope.ProductCandidate) {
                    // We count every target for the MatchAny property in order to compare AND conditions
                    matchedTargets++;
                }
                var target = targetPathItem.Targets[j];
                var targetDecomposeContext = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? this_3._decomposeContexts[currentDecomposeIndex] : this_3._decomposeContexts[target.DecomposeContextIndex];
                var targetOrderfolioItems = targetDecomposeContext.Orderfolio[target.Key];
                if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
                    return "continue";
                }
                if (condition.Scope === RuleScope.ProductCandidate) {
                    // When it's a ProductCandidate scope we want to count up the targets when they actually exist in the OrderFolio
                    matchedTargets++;
                }
                if (condition.Scope === RuleScope.Child) {
                    var scopedKey = (target.UseFurtherScope) ? (scopedEntity.CompoundKey) : (containerEntity.CompoundKey);
                    // If we have a scope of child ensure that we only look at children underneath the instance of the container entity
                    targetOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(scopedKey, targetOrderfolioItems, targetDecomposeContext);
                    if (targetOrderfolioItems.length < 1) {
                        return "continue";
                    }
                }
                // Do all the value/container checks. If a match is found, add to the target collection.
                if (targetPathItem.IsElementReference) {
                    this_3.CheckElementReferenceTargets(targetPathItem, targetOrderfolioItems, matchesFound, target);
                }
                // This is targeting an entity
                else if (Utilities.IsDefined(targetPathItem.Action)) {
                    // Ensure the order action on the orderfolio items match the condition
                    var actionMatches_2 = false;
                    targetOrderfolioItems.forEach(function (orderfolioItem) {
                        if (orderfolioItem.Action === targetPathItem.Action) {
                            actionMatches_2 = true;
                            return;
                        }
                    });
                    if (actionMatches_2) {
                        matchesFound.push(this_3.CreateTargetMatchContext(target, targetPathItem));
                    }
                }
                else if (Utilities.IsNotDefined(targetPathItem.Action)) {
                    matchesFound.push(this_3.CreateTargetMatchContext(target, targetPathItem));
                }
            };
            for (var j = 0; j < targetPathItem.Targets.length; j++) {
                _loop_5();
            }
        };
        var this_3 = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            _loop_4();
        }
        if (matchesFound.length > 0) {
            // The OR condition.. just return true if ANY matches found
            if (condition.MatchAny) {
                return true;
            }
            // This is the AND condition.. counts the number of matches against the number of targets
            else if (matchedTargets === matchesFound.length) {
                // If the scope is a ProductCandidate, we need to filter down the matches and AND them based on the EntityPath
                if (condition.Scope === RuleScope.ProductCandidate) {
                    var candidateWideMatches = [];
                    for (var m = 0; m < matchesFound.length; m++) {
                        var match = matchesFound[m].TargetPathItem;
                        if (entityPaths.includes(match.EntityPath)) {
                            candidateWideMatches.push(match.EntityPath);
                        }
                    }
                    // Get any items that were not matched throughout the Product Candidate
                    var conditionTargetsNotMatched = LodashUtilities.Difference(entityPaths, candidateWideMatches);
                    // If there are no differences, we have matched all items, and the condition has been met
                    if (conditionTargetsNotMatched.length === 0) {
                        return true;
                    }
                    return false;
                }
                // If it's any other scope, we have a match
                else {
                    return true;
                }
            }
        }
        return false;
    };
    RuleConditionAuditor.prototype.CheckElementReferenceTargets = function (targetPathItem, targetOrderfolioItems, matchesFound, target) {
        // Item value action
        if (Utilities.IsDefined(targetPathItem.Action, true)) {
            if (this.MatchesItemValueAction(targetOrderfolioItems, targetPathItem)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        // UDC
        else if ((Utilities.IsDefined(targetPathItem.RegExp, true) || targetPathItem.ElementPath.includes("UserDefinedChar"))) {
            if (this.UDCMatchValues(targetOrderfolioItems, targetPathItem)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        // Value
        else if (Utilities.IsDefined(targetPathItem.ValueId, true) && Utilities.IsNotDefined(targetPathItem.Action) && targetPathItem.UseId !== targetPathItem.ValueId && !targetPathItem.AnyEmpty) {
            if (OrderfolioQueries.HasValueId(targetPathItem.ValueId, targetPathItem.UseId, targetOrderfolioItems)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        // AnyEmpty value (no value exists)
        else if (Utilities.IsDefined(targetPathItem.ValueId, true) && targetPathItem.AnyEmpty) {
            if (this.AllHaveValues(targetPathItem.UseId, targetOrderfolioItems, targetPathItem.ValueId)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        // AnyEmpty container (no value exists)
        else if (Utilities.IsNotDefined(targetPathItem.ValueId) && Utilities.IsDefined(targetPathItem.UseId, true) && targetPathItem.AnyEmpty) {
            if (this.AllHaveValues(targetPathItem.UseId, targetOrderfolioItems)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        // Container
        else if ((targetPathItem.UseId === targetPathItem.ValueId || (Utilities.IsDefined(targetPathItem.UseId, true) && Utilities.IsNotDefined(targetPathItem.ValueId)))) {
            if (this.HasUseId(targetPathItem.UseId, targetOrderfolioItems)) {
                matchesFound.push(this.CreateTargetMatchContext(target, targetPathItem));
            }
        }
        return;
    };
    RuleConditionAuditor.prototype.CreateTargetMatchContext = function (target, targetPathItem) {
        return {
            Target: target,
            TargetPathItem: targetPathItem
        };
    };
    /**
    * Determines if the orderfolio item has been deleted in the portfolio
    * Note. If the condition explicitly references a delete action, the orderfolio item should be returned as valid.
    * See D-06720.
    * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
    * @param {CsTypes.Condition} targetPath The rule condition
    * @returns {boolean}
    */
    RuleConditionAuditor.prototype.OrderFolioItemHasNotBeenDeleted = function (orderfolioItem, targetPath) {
        return orderfolioItem.Action !== OrderActions.Delete || (targetPath.Action === OrderActions.Delete && orderfolioItem.Action === OrderActions.Delete);
    };
    /**
     * Gathers the orderfolio items needed to evaluate the condition
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container
     * @param {CsTypes.ItemTarget} existsTarget The target of the condition
     * @param {string} mappingRuleScope The mapping rule scope
     * @param {boolean} isActionCondition Indicates if this is an action condition or rule condition
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    RuleConditionAuditor.prototype.GatherOrderfolioItems = function (decomposeContext, container, existsTarget, mappingRuleScope, isActionCondition, excludeDeleted) {
        if (excludeDeleted === void 0) { excludeDeleted = true; }
        if (isActionCondition) {
            return this.GatherActionConditionOrderfolioItems(decomposeContext, container, existsTarget.Key, mappingRuleScope);
        }
        else {
            return this.GatherRuleConditionOrderfolioItems(decomposeContext, container, existsTarget.Key, mappingRuleScope, excludeDeleted);
        }
    };
    /**
     * Get the orderfolio items for checking the conditions
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     * @param {CsTypes.Uuid} childId The child Uuid to look for
     * @param {string} mappingRuleScope The mapping rule scope
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    RuleConditionAuditor.prototype.GatherRuleConditionOrderfolioItems = function (decomposeContext, container, childId, mappingRuleScope, excludeDeleted) {
        if (excludeDeleted === void 0) { excludeDeleted = true; }
        var orderfolioItemSet = decomposeContext.Orderfolio[childId];
        if (Utilities.IsNotDefined(orderfolioItemSet, true)) {
            return [];
        }
        orderfolioItemSet = orderfolioItemSet.filter(function (ofi) {
            return !ofi.IsInvalid && OrderfolioQueries.IsActivityValidForOrderfolioItem(decomposeContext.CompiledSpec, ofi.CompoundKey.Key, DecomposeActivities.Mapping);
        });
        if (Utilities.IsNotDefined(orderfolioItemSet, true)) {
            return [];
        }
        if (mappingRuleScope === RuleScope.Child) {
            orderfolioItemSet = OrderfolioQueries.FilterChildrenToParent(container.CompoundKey, orderfolioItemSet, decomposeContext, excludeDeleted);
        }
        return orderfolioItemSet;
    };
    /**
     * Get the orderfolio items for checking the conditions
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} container The container for the mapping rule
     * @param {CsTypes.Uuid} childId The child Uuid to look for
     * @param {string} mappingRuleScope The mapping rule scope
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    RuleConditionAuditor.prototype.GatherActionConditionOrderfolioItems = function (decomposeContext, actionTargetLookup, conditionKey, mappingRuleScope) {
        var orderfolioItemSet = [];
        var conditionId = parseInt(conditionKey);
        var actionTargetId = parseInt(actionTargetLookup.CompoundKey.Key);
        // Find out whether the action target is the parent or the child in the structure
        // We need to filter our orderfolio items when checking conditions based on this
        // If the action target is the child, then the condition exists on an entity above, we need to find the parent entity and check that entity for using the condition
        // If the action target is the parent, then the condition exists on an entity below, so we filter our condition targets based on everything underneath the action target
        // In this case there can be multiple targets for the condition, where as the first case there can only be one
        if (conditionId < actionTargetId) {
            var parent = OrderfolioQueries.FindParentForChild(conditionKey, actionTargetLookup.CompoundKey, decomposeContext);
            if (Utilities.IsDefined(parent)) {
                var orderfolioItem = decomposeContext.Orderfolio[parent.Key][parent.Index];
                if (orderfolioItem.IsInvalid || !OrderfolioQueries.IsActivityValidForOrderfolioItem(decomposeContext.CompiledSpec, parent.Key, DecomposeActivities.Mapping)) {
                    return orderfolioItemSet;
                }
                if (orderfolioItem.Action !== OrderActions.Delete) {
                    orderfolioItemSet.push(orderfolioItem);
                }
            }
        }
        else {
            orderfolioItemSet = this.GatherRuleConditionOrderfolioItems(decomposeContext, actionTargetLookup, conditionKey, mappingRuleScope);
        }
        return orderfolioItemSet;
    };
    /**
    * Checks whether the the characteristic use for the use ID provided has no values
    * @param {string} useId The use ID to check
    * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The orderfolio items
    * @returns {boolean}
    */
    RuleConditionAuditor.prototype.AllHaveValues = function (useId, orderfolioItems, valueId) {
        var valueFound = function (orderfolioItem) {
            var combinedUses = orderfolioItem.CharacteristicUses.concat(orderfolioItem.UserDefinedCharacteristics);
            var charUse = LodashUtilities.Find(combinedUses, function (charUse) { return charUse.UseId === useId; });
            if (Utilities.IsDefined(charUse) && Utilities.IsDefined(valueId)) {
                var charValue = LodashUtilities.Find(charUse.Values, function (value) { return value.Value === valueId; });
                return Utilities.IsDefined(charValue);
            }
            return Utilities.IsDefined(charUse) && charUse.Values.length > 0;
        };
        return orderfolioItems.every(function (o) { return valueFound(o); });
    };
    /**
    * Checks whether the characteristic uses on an orderfolio item contain the specified use ID
    * @param {string} useId The use ID to find
    * @param {CsTypes.OrderfolioItem} orderfolioItems The orderfolio items to check
    * @returns {boolean}
    */
    RuleConditionAuditor.prototype.HasUseId = function (useId, orderfolioItems) {
        for (var orderfolioIdx = 0; orderfolioIdx < orderfolioItems.length; orderfolioIdx++) {
            var orderfolioItem = orderfolioItems[orderfolioIdx];
            var combinedCharacteristics = orderfolioItem.CharacteristicUses.concat(orderfolioItem.UserDefinedCharacteristics);
            if (combinedCharacteristics.some(function (charUse) { return charUse.UseId === useId; })) {
                return true;
            }
        }
        return false;
    };
    /**
     * Determines whether the orderfolio has the link type ID provided
     * @param {string} linkTypeID The link type ID
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The orderfolio items to check
     * @param {CsTypes.IOrderfolioLinkedEntityQueries} queryableLinkedEntities The queryable linked entities
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.HasEntityLink = function (linkTypeID, orderfolioItems, linkedEntities) {
        for (var orderfolioIndex = 0; orderfolioIndex < orderfolioItems.length; orderfolioIndex++) {
            var orderfolioItem = orderfolioItems[orderfolioIndex];
            var matchingLinkedEntities = OrderfolioLinkedEntityQueries.GetBySourceAndLinkType(linkedEntities, orderfolioItem.CompoundKey, linkTypeID);
            if (Utilities.IsDefined(matchingLinkedEntities) && matchingLinkedEntities.length > 0) {
                return true;
            }
        }
        return false;
    };
    /**
     * Check if the UDCMatchesValue has the regex provided
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The orderfolio items to check
     * @param {CsTypes.Condition} targetPathItem the details of the condition to check against
     * @returns {boolean}
     */
    RuleConditionAuditor.prototype.UDCMatchValues = function (orderfolioItems, targetPathItem) {
        var matchAll = Utilities.ParseAsBoolean(targetPathItem.MatchAll, false);
        var conditionMatch = false;
        for (var i = 0; i < orderfolioItems.length; i++) {
            var orderfolioItem = orderfolioItems[i];
            var udcToCheck = LodashUtilities.Find(orderfolioItem.UserDefinedCharacteristics, function (udc) { return udc.UseId === targetPathItem.UseId; });
            // if we couldn't find an instance of the UDC to check against, we can't successfully match
            if (Utilities.IsNotDefined(udcToCheck)) {
                continue;
            }
            var udcValuesToCheck = udcToCheck.Values.filter(function (value) {
                return value.Action !== MergedActions.DeleteExisting && value.Action !== MergedActions.DeleteMissing;
            });
            // evaluate udc values based on whether all values or just some must match to succeed
            // IMPORTANT: RegExp evaluation can change after each call. To ensure the evaluation is valid, create a new instance of
            // RegExp for each value to check.
            switch (matchAll) {
                case true:
                    // if all values match, return true, else return false
                    conditionMatch = udcValuesToCheck.every(function (value) { return new RegExp(targetPathItem.RegExp, "g").test(value.Value); });
                    break;
                case false:
                    // if any value matches, return true, only return false if no values match
                    conditionMatch = udcValuesToCheck.some(function (value) { return new RegExp(targetPathItem.RegExp, "g").test(value.Value); });
                    break;
            }
            if (conditionMatch) {
                return conditionMatch;
            }
        }
        return conditionMatch;
    };
    RuleConditionAuditor.prototype.MatchesItemValueAction = function (orderfolioItems, targetPathItem) {
        //let matchAll: boolean = Utilities.ParseAsBoolean(condition.MatchAll, false);
        var conditionMatch = false;
        var targetIsValue = Utilities.IsDefined(targetPathItem.ValueId) && targetPathItem.ValueId !== targetPathItem.UseId;
        for (var o = 0; o < orderfolioItems.length; o++) {
            var orderfolioItem = orderfolioItems[o];
            // Get the last item in the element path
            // NOTE: We do this because the item can be a container or a value
            var lastElementInPath = this.GetLastElementInPath(targetPathItem);
            var charUseToCheck = LodashUtilities.Find(orderfolioItem.CharacteristicUses, function (charUse) {
                return charUse.UseId === targetPathItem.UseId;
            });
            if (Utilities.IsDefined(charUseToCheck)) {
                conditionMatch = this.CheckContainerActions(charUseToCheck, targetPathItem, targetIsValue, lastElementInPath);
                // Otherwise, if the CharUseId is not the last element in the path, the target must be a value
                if (targetIsValue) {
                    for (var v = 0; v < charUseToCheck.Values.length; v++) {
                        var charUseValueToCheck = charUseToCheck.Values[v];
                        if (charUseValueToCheck.Value === targetPathItem.ValueId) {
                            conditionMatch = this.CheckValueActions(charUseValueToCheck, targetPathItem);
                        }
                    }
                }
            }
            var udcToCheck = LodashUtilities.Find(orderfolioItem.UserDefinedCharacteristics, function (udc) {
                return udc.UseId === targetPathItem.UseId;
            });
            // We don't check against UDC Values, only against the UDC itself
            // This was thought to be an issue when developing SesameStreet - but confirmed Catalog will only let you target the Container
            // NOT the value
            if (Utilities.IsDefined(udcToCheck)) {
                conditionMatch = this.CheckContainerActions(udcToCheck, targetPathItem, targetIsValue, lastElementInPath);
            }
            return conditionMatch;
        }
    };
    RuleConditionAuditor.prototype.AllValuesMatchItemValueAction = function (orderfolioItems, targetPathItem) {
        //let matchAll: boolean = Utilities.ParseAsBoolean(condition.MatchAll, false);
        var targetIsValue = Utilities.IsDefined(targetPathItem.ValueId);
        // For NoValueExistsOrderAction conditions - we need to ensure that all target actions match the action condition.
        // We do this by counting the number of items matching the action target, then comparing against the number of those items matching the action.
        var numberOfInstances = 0;
        var numberOfMatches = 0;
        for (var o = 0; o < orderfolioItems.length; o++) {
            var orderfolioItem = orderfolioItems[o];
            // Get the last item in the element path
            // NOTE: We do this because the item can be a container or a value
            var lastElementInPath = this.GetLastElementInPath(targetPathItem);
            if (Utilities.IsDefined(orderfolioItem.CharacteristicUses)) {
                for (var _i = 0, _a = orderfolioItem.CharacteristicUses; _i < _a.length; _i++) {
                    var char = _a[_i];
                    if ((char.UseId === targetPathItem.UseId) && (char.UseId === lastElementInPath)) {
                        numberOfInstances++;
                        if (char.Action === targetPathItem.Action) {
                            numberOfMatches++;
                        }
                    }
                    // Otherwise, if the CharUseId is not the last element in the path, the target must be a value
                    else if (targetIsValue) {
                        for (var v = 0; v < char.Values.length; v++) {
                            var charUseValueToCheck = char.Values[v];
                            if (charUseValueToCheck.Value === targetPathItem.ValueId) {
                                numberOfInstances++;
                                if (this.CheckValueActions(charUseValueToCheck, targetPathItem)) {
                                    numberOfMatches++;
                                }
                            }
                        }
                    }
                }
            }
            // We don't check against UDC Values, only against the UDC itself
            if (Utilities.IsDefined(orderfolioItem.UserDefinedCharacteristics)) {
                for (var _b = 0, _c = orderfolioItem.UserDefinedCharacteristics; _b < _c.length; _b++) {
                    var udc = _c[_b];
                    // If the Udc UseId is the last element in the path, check the ItemAction
                    if ((udc.UseId === targetPathItem.UseId) && (udc.UseId === lastElementInPath)) {
                        numberOfInstances++;
                        if (udc.Action === targetPathItem.Action) {
                            numberOfMatches++;
                        }
                    }
                }
            }
        }
        return numberOfMatches === numberOfInstances;
    };
    /**
     * Returns the last element in a RawValue path
     * @param rawValue
     */
    RuleConditionAuditor.prototype.GetLastElementInPath = function (targetPath) {
        if (Utilities.IsNotDefined(targetPath.RawValue)) {
            return null;
        }
        var itemsInPath = targetPath.RawValue.split(',');
        if (itemsInPath[itemsInPath.length - 1] === '') {
            return itemsInPath[itemsInPath.length - 2];
        }
        else {
            return itemsInPath[itemsInPath.length - 1];
        }
    };
    /**
     * Returns true if the ItemAction on the Condition matches the MergedValue Action
     * @param charValue
     * @param targetPathItem
     */
    RuleConditionAuditor.prototype.CheckValueActions = function (charValue, targetPathItem) {
        if (targetPathItem.Action === "add") {
            if (charValue.Action === MergedActions.AddExisting
                || charValue.Action === MergedActions.AddMissing) {
                return true;
            }
        }
        if (targetPathItem.Action === "delete") {
            if (charValue.Action === MergedActions.DeleteExisting
                || charValue.Action === MergedActions.DeleteMissing) {
                return true;
            }
        }
        return false;
    };
    /**
     *
     * @param container Returns true if the ItemAction on the Condition matches the Action on the container
     * @param targetPathItem
     * @param targetIsValue
     * @param lastElementInPath
     */
    RuleConditionAuditor.prototype.CheckContainerActions = function (container, targetPathItem, targetIsValue, lastElementInPath) {
        // If the UseId is the last element in the path, check the ItemAction
        if (!targetIsValue && container.UseId === lastElementInPath) {
            return container.Action === targetPathItem.Action;
        }
        return false;
    };
    return RuleConditionAuditor;
}());
module.exports = RuleConditionAuditor;

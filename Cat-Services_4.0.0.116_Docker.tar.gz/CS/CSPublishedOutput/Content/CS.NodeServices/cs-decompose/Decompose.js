"use strict";
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var Inferrer = require("../cs-inference/Inferrer");
var Mapper = require("../cs-mapping/Mapper");
var OrderCandidateResponseBuilder = require("../cs-lib-composition/OrderCandidateResponseBuilder");
var ProductCandidateResponseBuilder = require("../cs-lib-composition/ProductCandidateResponseBuilder");
var ValidateDecomposeContexts = require("../cs-validate/ValidateDecomposeContexts");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
* Class responsible for decomposition of product and order candidate requests
*/
var Decompose = /** @class */ (function () {
    function Decompose() {
    }
    /**
    * Perform decomposition on order candidate
    */
    Decompose.prototype.DecomposeOrderCandidate = function (request, compiledSpecs, boundaryCondition, callback) {
        var _this = this;
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromOrderCandidateRequest(request, compiledSpecs, function (decomposeContexts) {
            _this.PerformDecomposeProcess("OrderCandidate", decomposeContexts, errorContext, function (error, result) {
                return callback(error, result);
            });
        });
    };
    /**
    * Perform decomposition on product candidate
    */
    Decompose.prototype.DecomposeProductCandidate = function (request, compiledSpecs, boundaryCondition, callback) {
        var _this = this;
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromProductCandidate(request, compiledSpecs, function (decomposeContexts) {
            _this.PerformDecomposeProcess("ProductCandidate", decomposeContexts, errorContext, function (error, result) {
                return callback(error, result);
            });
        });
    };
    /**
    * Get the DecomposeContexts for an order candidate
    */
    Decompose.prototype.GetDecomposeContextsForOrderCandidate = function (request, compiledSpecs, boundaryCondition, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromOrderCandidateRequest(request, compiledSpecs, function (decomposeContexts) {
            if (Utilities.IsNotDefined(decomposeContexts, true)) {
                return callback(null, errorContext.GetValidationErrorsForResponse());
            }
            return callback(null, decomposeContexts);
        });
    };
    /**
    * Get the DecomposeContexts for a product candidate
    */
    Decompose.prototype.GetDecomposeContextsForProductCandidate = function (request, compiledSpecs, boundaryCondition, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromProductCandidate(request, compiledSpecs, function (decomposeContexts) {
            if (Utilities.IsNotDefined(decomposeContexts, true)) {
                return callback(null, errorContext.GetValidationErrorsForResponse());
            }
            return callback(null, decomposeContexts);
        });
    };
    Decompose.prototype.PerformDecomposeProcess = function (candidateType, decomposeContexts, errorContext, callback) {
        // If there exists breaking error from building decompose context then dont process further and return with error.
        if (errorContext.HasBreakingErrors) {
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrors(), null);
            }
            if (errorContext.HasSevereValidationError) {
                return callback(errorContext.GetValidationErrorsForResponse(), null);
            }
        }
        this.PerformInferrenceAndMapping(decomposeContexts, errorContext);
        if (errorContext.HasBreakingErrors) {
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrors(), null);
            }
            if (errorContext.HasSevereValidationError) {
                return callback(errorContext.GetValidationErrorsForResponse(), null);
            }
        }
        // Unflatten, possibly including extra validation
        var builder = undefined;
        if (candidateType === "OrderCandidate") {
            builder = new OrderCandidateResponseBuilder(errorContext);
        }
        if (candidateType === "ProductCandidate") {
            builder = new ProductCandidateResponseBuilder(errorContext);
        }
        var result = builder.Build(decomposeContexts);
        if (errorContext.HasBreakingErrors) {
            return callback(null, null); // TODO: handle error response
        }
        return callback(null, result);
    };
    Decompose.prototype.PerformInferrenceAndMapping = function (decomposeContexts, errorContext) {
        // Infer / Mapping loop
        var mapper = new Mapper(decomposeContexts, errorContext);
        decomposeContexts.forEach(function (context, dci) {
            Inferrer.InferOrderfolioItemsForSingleContext(context);
            // Process mapping rules until one triggers some actions.
            // Run inference again, then continue rules.
            while (mapper.ContinueMappingForDecomposeContext(context)) {
                Inferrer.InferOrderfolioItemsForSingleContext(context);
            }
        });
        ValidateDecomposeContexts.ValidateDecomposeContexts(decomposeContexts, errorContext);
    };
    return Decompose;
}());
module.exports = Decompose;

"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CustomerPortfolio = require("../../cs-lib-types/BusinessEntities/CustomerPortfolio");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var OrderCandidate = require("../../cs-lib-types/BusinessEntities/OrderCandidate");
var OrderItem = require("../../cs-lib-types/BusinessEntities/OrderItem");
var DecomposeContextBuilder = require("../../cs-lib-composition/DecomposeContextBuilder");
var BoundaryCondition = require("../../cs-lib-constants/BoundaryConditionConstants");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
describe("An order candidate with validation limits", function () {
    var orq = new OrderCandidateRequest();
    orq.ID = "ORQ001";
    orq.ActivationDate = new Date("2014-10-10");
    var orderCandidate = new OrderCandidate();
    orderCandidate.OrderID = "ORD001";
    orderCandidate.OrderItems = new Array();
    var rootOrderItem = new OrderItem();
    rootOrderItem.ID = "oi_1";
    rootOrderItem.EntityID = "1af62c90-213c-4a89-8985-b2083cf692c1";
    rootOrderItem.ItemAction = "add";
    orderCandidate.OrderItems.push(rootOrderItem);
    orderCandidate.Limits = [];
    orderCandidate.Limits.push("Credit_Status_Good");
    orq.OrderCandidate = orderCandidate;
    orq.CustomerPortfolio = new CustomerPortfolio();
    chai.expect(orq).is.not.undefined;
    chai.expect(orq.OrderCandidate).is.not.undefined;
    chai.expect(orq.OrderCandidate.Limits).is.not.undefined;
    describe("can be decomposed and retain its limits", function () {
        var errorContext = new CsErrorContext({});
        var decomposer = new DecomposeContextBuilder(BoundaryCondition.Technical, errorContext);
        var compiledSpecification = JSON.parse(fs.readFileSync('cs-decompose/test/files/DecomposeContextLimitsCompiledDal.json', { encoding: 'utf8' }));
        var compiledSpecs = { "1af62c90-213c-4a89-8985-b2083cf692c1": compiledSpecification };
        decomposer.BuildFromOrderCandidate(orq, compiledSpecs, function (result) {
            // Check state of decompose context here
            chai.expect(result).is.not.undefined;
            chai.expect(result.length).equals(1);
            var decomposeContext = result[0];
            chai.expect(decomposeContext).is.not.undefined;
            chai.expect(decomposeContext.ContextData).is.not.undefined;
            chai.expect(decomposeContext.ContextData.Limits).is.not.undefined;
            chai.expect(decomposeContext.ContextData.Limits.length).equals(1);
            chai.expect(decomposeContext.ContextData.Limits[0]).is.not.undefined;
            chai.expect(decomposeContext.ContextData.Limits[0]).equals("Credit_Status_Good");
        });
    });
});

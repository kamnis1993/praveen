"use strict";
/// <reference types="node" />
var Pricing = require("../cs-pricing/Pricing");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var ApiBase = require("./ApiBase");
/**
* Handles calls for CS.DotNetServices PriceForProductCandidate
*/
var PricingApi;
(function (PricingApi) {
    /**
    * ordercandidate/price/fixed
    * price/forOrderCandidate/fixed DEPRECATED
    */
    function PriceForOrderCandidate(callback, context, requestBody, compiledSpecs) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Pricing().PriceForOrderCandidate(requestBody, compiledSpecs, function (error, result) {
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    PricingApi.PriceForOrderCandidate = PriceForOrderCandidate;
    /**
    * productcandidate/price/fixed
    * price/forProductCandidate/fixed DEPRECATED
    * pricing/GetPriceForProductCandidate DEPRECATED
    */
    function PriceForProductCandidate(callback, context, requestBody, compiledSpec) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Pricing().PriceForProductCandidate(requestBody, compiledSpec, function (error, result) {
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    PricingApi.PriceForProductCandidate = PriceForProductCandidate;
    /**
    * productCandidate/GetPriceForPartialProductCandidate
    */
    function PriceForPartialProductCandidate(callback, context, requestBody, compiledSpec) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Pricing().PriceForPartialProductCandidate(requestBody, compiledSpec, function (error, result) {
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    PricingApi.PriceForPartialProductCandidate = PriceForPartialProductCandidate;
})(PricingApi || (PricingApi = {}));
module.exports = PricingApi;

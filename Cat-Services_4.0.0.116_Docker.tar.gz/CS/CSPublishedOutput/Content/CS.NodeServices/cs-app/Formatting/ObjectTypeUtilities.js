"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var ObjectTypeUtilities = /** @class */ (function () {
    function ObjectTypeUtilities() {
    }
    /**
    * Returns the relevant objectType from the responseNode _meta data or returns a default
    * @param {string} elementName - The element name
    * @param {any} responseNode - The node we are currently processing
    * @param {string} defaultObjectType - The default type to use in the absense of meta data
    * @param {any} schema - The schema
    */
    ObjectTypeUtilities.GetObjectType = function (elementName, responseNode, defaultObjectType, schema) {
        var child = responseNode[elementName];
        if (!Utilities.IsDefined(child)) {
            return defaultObjectType;
        }
        // Get the meta data in the responseNode
        // if the named element meta does not exist, assume the element is the root of the responseNode
        var meta = Utilities.IsDefined(responseNode[elementName]['_meta']) ? responseNode[elementName]['_meta'] : meta = responseNode['_meta'];
        if (Utilities.IsNotDefined(meta)) {
            return defaultObjectType;
        }
        // Get the relevant parent objectType from _meta.xsi:type or _meta.Path[0] or _meta.Pattern
        var result;
        if (Utilities.IsDefined(meta['xsi:type'])) {
            result = meta['xsi:type'];
        }
        else if (Utilities.IsDefined(meta['Path'])) {
            result = meta['Path'].split(',')[0];
        }
        else if (Utilities.IsDefined(meta['Pattern'])) {
            result = meta['Pattern'];
        }
        else {
            result = defaultObjectType;
        }
        // If the actual objectType is not defined in the schema, use the default objectType
        if (result !== defaultObjectType && Utilities.IsDefined(schema) && Utilities.IsNotDefined(schema[result])) {
            result = defaultObjectType;
        }
        return result;
    };
    return ObjectTypeUtilities;
}());
module.exports = ObjectTypeUtilities;

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var path = require("path");
var Logger = require("../../cs-logging/Logger");
var Utilities = require("../../cs-lib-utilities/Utilities");
var ObjectTypeUtilities = require("./ObjectTypeUtilities");
var OutputFormatter = require("./OutputFormatter");
/**
 * Formats JSON objects according to the schema.
 * This class generates the response output in JSON format.
 */
var JsonOutputFormatter = /** @class */ (function (_super) {
    __extends(JsonOutputFormatter, _super);
    function JsonOutputFormatter() {
        return _super.call(this) || this;
    }
    /**
     * Formats the JSON object according to the schema
     * @param {any} response The response to format
     * @param {any} schemaName The object type
     * @returns {any}
     */
    JsonOutputFormatter.prototype.Format = function (response, schemaContext) {
        if (Utilities.IsNotDefined(schemaContext)
            && Utilities.IsNotDefined(schemaContext.SchemaName)) {
            return response;
        }
        // Read in schema files
        var schemaFolder = path.resolve(__dirname, './Schemas');
        var schemaFileName = "schema" + schemaContext.SchemaName + ".json";
        var schemaPath = path.resolve(schemaFolder, schemaFileName);
        try {
            this._schema = require(schemaPath);
        }
        catch (ex) {
            // If we cannot find the schema file it hasn't been defined properly in the
            // .Net controller or the validation in SchemaUtils.cs is not working as intended.
            Logger.error("JsonFormatter", "Unable to find schema file: " + schemaPath);
            return response;
        }
        var formattedResponse = (this.IsArray(response)) ? ([]) : ({});
        this.ParseChildElement(formattedResponse, response, schemaContext.SchemaRootElementName);
        return formattedResponse;
    };
    /**
     * Parses the child element
     * @param {any} formattedResponseNode The current formatted response node
     * @param {any} responseNode The current node we are processing
     * @param {string} objectType The object type
     */
    JsonOutputFormatter.prototype.ParseChildElement = function (formattedResponseNode, responseNode, objectType) {
        var _this = this;
        var remainingKeys;
        var includedCount = 0;
        var processRemainingElements = true;
        var validAttributes;
        remainingKeys = (this.IsEnumerable(responseNode)) ? (Object.keys(responseNode)) : ([]);
        if (Utilities.IsDefined(this._schema) && Utilities.IsDefined(objectType, true)) {
            var objectSchema = this._schema[objectType];
            if (Utilities.IsDefined(objectSchema)) {
                if (Utilities.IsDefined(objectSchema['IncludeNamedElementsOnly']) && objectSchema['IncludeNamedElementsOnly'] === true) {
                    processRemainingElements = false;
                }
                validAttributes = objectSchema['ValidAttributes'];
                var elementInfo;
                var elementNumber = 0;
                while (elementInfo = objectSchema[elementNumber++]) // eslint-disable-line no-cond-assign
                 {
                    if (responseNode[elementInfo.ElementName] !== undefined) {
                        includedCount++;
                    }
                    // Get the actual instance objectType from the responseNode
                    var currentObjectType = ObjectTypeUtilities.GetObjectType(elementInfo.ElementName, responseNode, elementInfo.Type, this._schema);
                    this.ProcessChildElement(elementInfo.ElementName, formattedResponseNode, responseNode, currentObjectType, validAttributes);
                    // Remove from the list of keys processed
                    delete remainingKeys[remainingKeys.indexOf(elementInfo.ElementName)];
                }
            }
        }
        // Process any remaining properties in object key order
        // Skipped if schema states known objects only.
        // If schema didn't match any supplied elements, we output everything.
        // Attributes are always added regardless of schema
        remainingKeys.forEach(function (key) {
            if (_this.IsAttribute(key) || processRemainingElements || includedCount < 1) {
                _this.ProcessChildElement(key, formattedResponseNode, responseNode, objectType, validAttributes);
            }
        });
    };
    /**
     * Processes a child element
     * @param {string} elementName The element name
     * @param {any} formattedResponseNode The current formatted response node we are processing
     * @param {any} responseNode The node we are currently processing
     * @param {string} objectType The type of the object
     * @param {string[]} validAttributes The list of valid attributes
     */
    JsonOutputFormatter.prototype.ProcessChildElement = function (elementName, formattedResponseNode, responseNode, objectType, validAttributes) {
        if (!responseNode.hasOwnProperty(elementName)) {
            return;
        }
        var child = responseNode[elementName];
        if (this.IsAttribute(elementName)) {
            if (Utilities.IsNotDefined(validAttributes, true) || validAttributes.indexOf(elementName)) {
                formattedResponseNode[elementName] = child;
            }
        }
        else if (Utilities.IsNotDefined(child)) {
            formattedResponseNode[elementName] = child;
        }
        else if (this.IsArray(child)) {
            formattedResponseNode[elementName] = [];
            for (var innerKey in child) {
                if (child.hasOwnProperty(innerKey) && typeof child[innerKey] === 'object') {
                    var subElement = {};
                    formattedResponseNode[elementName].push(subElement);
                    this.ParseChildElement(subElement, child[innerKey], objectType);
                }
                else {
                    formattedResponseNode[elementName].push(child[innerKey]);
                }
            }
        }
        else if (child instanceof Date) {
            formattedResponseNode[elementName] = child;
        }
        else if (typeof child === 'object') {
            formattedResponseNode[elementName] = {};
            this.ParseChildElement(formattedResponseNode[elementName], child, objectType);
        }
        else {
            formattedResponseNode[elementName] = child;
        }
    };
    return JsonOutputFormatter;
}(OutputFormatter));
module.exports = JsonOutputFormatter;

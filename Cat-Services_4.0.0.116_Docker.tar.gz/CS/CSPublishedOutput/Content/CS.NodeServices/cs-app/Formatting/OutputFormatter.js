"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
* Class containing common/base methods for formatting JSON objects.
*
*/
var OutputFormatter = /** @class */ (function () {
    function OutputFormatter() {
        this.UNDERSCORE_CHAR = '_';
    }
    /**
     * Indicates whether the object passed in is Enumerable
     * @param {any} value The object to check
     * @returns {boolean}
     */
    OutputFormatter.prototype.IsEnumerable = function (value) {
        return ((!!value) && ((typeof value === 'object') || (typeof value === 'function')) && ((typeof value !== 'string')));
    };
    /**
     * Indicates whether the object passed in is an array
     * @param {any} item The object to check
     * @returns {boolean}
     */
    OutputFormatter.prototype.IsArray = function (item) {
        return typeof item === 'object' && Utilities.IsDefined(item.constructor) && Utilities.IsDefined(item.constructor.name, true) && item.constructor.name === 'Array';
    };
    /**
     * Indicates whether the element name is an attribute (if it starts with an underscore)
     * @param {string} elementName The element name
     * @returns {boolean}
     */
    OutputFormatter.prototype.IsAttribute = function (elementName) {
        return Utilities.IsDefined(elementName, true) && elementName[0] === this.UNDERSCORE_CHAR;
    };
    return OutputFormatter;
}());
module.exports = OutputFormatter;

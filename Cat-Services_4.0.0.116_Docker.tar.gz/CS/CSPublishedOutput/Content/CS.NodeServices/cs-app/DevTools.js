"use strict";
/// <reference types="node" />
var cmd = require("child_process");
var fs = require("fs");
var ApiBase = require("./ApiBase");
var Utilities = require("../cs-lib-utilities/Utilities");
var DevTools;
(function (DevTools) {
    function ValidateAndBuildTests(nodeServiceCallback, context, request) {
        ApiBase.CreateCsContext(context, function () {
            var result = {
                Success: true,
                Result: "",
                StatusCode: 200,
                Logs: []
            };
            // Requests may be comma separated, line break separated or comma and line break separated,
            // Passing line breaks into test builder causes errors
            // This logic makes sure we pass comma separated requests to the test builder.
            var originalRequest = request.RequestFileName;
            request.RequestFileName = originalRequest.replace(/\n/g, ",").replace(/,,/g, ",");
            ValidateRequest(request, result, function (resultInfo) {
                if (!result.Success) {
                    // Return the failures
                    result.Result = "Input failed validation.";
                    result.StatusCode = 400;
                    return nodeServiceCallback(null, ApiBase.HandleCallback(null, result, context));
                }
                // At this point we have validated all the requests, However some of them will have different root guids
                // Group together the requests that share the same root guid
                // We would then end up with a group of requests each with there own requests and rootguid, they would also have to have there own Story name
                // story is valid and request is valid therefore we need to kick off test builder
                CallTestBuilder(request, result, function (resultObj) {
                    return nodeServiceCallback(null, ApiBase.HandleCallback(null, resultObj, context));
                });
            });
        });
    }
    DevTools.ValidateAndBuildTests = ValidateAndBuildTests;
    function ValidateRequest(request, result, callback) {
        var splitRequest = request.RequestFileName.split(",");
        var requestArray = [];
        for (var i = 0; i < splitRequest.length; i++) {
            console.log(JSON.stringify(splitRequest[i]));
            requestArray.push(request.ApplicationRootPath + '/Tests/CS.AcceptanceTests/features/' + request.FeatureName + '/requests/' + request.Story + '/' + splitRequest[i]);
        }
        var dataSet = request.ApplicationRootPath
            + '/Tests/CS.AcceptanceTests/Data_Sets/'
            + request.DataSetName;
        try {
            fs.exists(dataSet, function (existData) {
                var _loop_1 = function (i) {
                    fs.exists(requestArray[i], function (existRequest) {
                        if (!existRequest) {
                            result.Logs.push("FAIL: Request not found at " + requestArray[i]);
                        }
                        if (!existData) {
                            result.Logs.push("FAIL: Data not found at " + dataSet);
                        }
                        if (result.Logs.length > 0) {
                            result.Success = false;
                            callback(result);
                        }
                        // Only return a callback to build tests if the last request has been validated
                        if (i === (requestArray.length - 1)
                            && result.Success === true) {
                            callback(result);
                        }
                    });
                };
                for (var i = 0; i < requestArray.length; i++) {
                    _loop_1(i);
                }
            });
        }
        catch (err) {
            result.Logs.push("FAIL: An error occurred while validating the test configuration");
            result.Success = false;
            result.Result = err;
            result.StatusCode = 500;
            callback(result);
        }
    }
    function CallTestBuilder(request, result, callback) {
        if (request.Date === null || request.Date === undefined) {
            // This if statement sets the default date as todays date if not already set
            request.Date = Utilities.TodaysDate();
        }
        else if (request.Date.includes("T00:00:00.000Z")) {
            // This else if statement removes the unnecessary time component from the date if date was manually set
            request.Date = request.Date.slice(0, 10);
        }
        request.StoryName = "\"" + request.StoryName + "\""; // This line allows whitespaces to be added within the variable story name
        request.Date = "\"" + request.Date + "\"";
        var command = "node " + "\"" + request.ApplicationRootPath + "/CS.NodeServices/cs-tools/TestBuilder/TestBuilder.js" + "\" "
            + request.ApplicationRootPath + ' '
            + request.FeatureName + ' '
            + request.DataSetName + ' '
            + request.Story + ' '
            + request.StoryName + ' '
            + request.RootEntityGuid + ' '
            + request.RequestFileName + ' '
            + request.RequestUrl + ' '
            + request.Date + '\n';
        result.StatusCode = 200;
        try {
            console.log('Starting TestBuilder Command');
            var testBuilderCommand = cmd.exec(command, null);
            testBuilderCommand.stdout.on('data', function (data) {
                result.Logs.push(data);
                console.log('[TestBuilder]: ' + data);
            });
            testBuilderCommand.stderr.on('data', function (data) {
                console.log('FAIL: Error Calling TestBuilder: ' + data);
                result.Logs.push('FAIL: [TestBuilder]: ' + data);
                result.Result = 'Encountered an issue running TestBuilder';
                result.StatusCode = 500;
                result.Success = false;
                return callback(result);
            });
            testBuilderCommand.on('close', function (code) {
                console.log('TestBuilder Command Complete');
                if (result.Logs.length > 0) {
                    // remove the first out because it's just the std
                    //result.logs.splice(0, 0);
                    //result.logs.shift();
                }
                result.Result = 'TestBuilder Command Complete';
                return callback(result);
            });
        }
        catch (err) {
            result.Result = '[TestBuilder] FAIL: Error calling test builder';
            result.Success = false;
            result.Logs.push('FAIL: [TestBuilder]: ' + err);
            return callback(result);
        }
    }
})(DevTools || (DevTools = {}));
module.exports = DevTools;

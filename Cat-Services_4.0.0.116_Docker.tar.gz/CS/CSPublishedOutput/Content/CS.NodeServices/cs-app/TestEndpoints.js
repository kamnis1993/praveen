"use strict";
/// <reference types="node" />
var BadDataErrorsResponse = require("../cs-lib-types/BusinessEntities/BadDataErrorsResponse");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var Logger = require("../cs-logging/Logger");
var OrderCandidateResponse = require("../cs-lib-types/BusinessEntities/OrderCandidateResponse");
var ProductCandidateResponse = require("../cs-lib-types/CPQ-BusinessEntities/ProductCandidateResponse");
var Utilities = require("../cs-lib-utilities/Utilities");
var ApiBase = require("./ApiBase");
/**
* This is the pass through class for test endpoint calls from CS.DotNetServices
*/
var TestEndpoints;
(function (TestEndpoints) {
    function Ping(callback, context) {
        ApiBase.CreateCsContext(context, function () {
            var responseMessage = "Ping from CS.NodeServices";
            var result = { "result": responseMessage };
            // Create information log for testing
            // Create trace event for testing diagnostics
            Logger.debug(0, "TEST", responseMessage, result);
            callback(null, ApiBase.HandleCallback(null, result, context));
        });
    }
    TestEndpoints.Ping = Ping;
    function EchoCandidateResponse(callback, context, req) {
        ApiBase.CreateCsContext(context, function () {
            var candidateResponse = BuildOrderCandidateResponse(req);
            candidateResponse = ConverterUtils.OrderSingularize(candidateResponse);
            callback(null, ApiBase.HandleCallback(null, candidateResponse, context));
        });
    }
    TestEndpoints.EchoCandidateResponse = EchoCandidateResponse;
    function EchoProductCandidate(callback, context, req) {
        ApiBase.CreateCsContext(context, function () {
            req = ConverterUtils.OrderPluralize(req);
            var candidateResponse = new ProductCandidateResponse(req);
            candidateResponse = ConverterUtils.OrderSingularize(candidateResponse);
            callback(null, ApiBase.HandleCallback(null, candidateResponse, context));
        });
    }
    TestEndpoints.EchoProductCandidate = EchoProductCandidate;
    function EchoSupplementalOrder(callback, context, req) {
        ApiBase.CreateCsContext(context, function () {
            var candidateResponse = BuildOrderCandidateResponse(req);
            candidateResponse = ConverterUtils.OrderSingularize(candidateResponse);
            callback(null, ApiBase.HandleCallback(null, candidateResponse, context));
        });
    }
    TestEndpoints.EchoSupplementalOrder = EchoSupplementalOrder;
    function EchoBadDataErrors(callback, context, req) {
        ApiBase.CreateCsContext(context, function () {
            req = ConverterUtils.OrderPluralize(req);
            var body = req;
            var badDataResponse = new BadDataErrorsResponse(body.StatusCode, body.Title, body.BadDataErrors);
            badDataResponse = ConverterUtils.OrderSingularize(badDataResponse);
            callback(null, ApiBase.HandleCallback(null, badDataResponse, context));
        });
    }
    TestEndpoints.EchoBadDataErrors = EchoBadDataErrors;
    /**
     * Builds an order candidate response from the response passed in
     * @param req The order candidate response passed in
     * @returns {OrderCandidateResponse}
     */
    function BuildOrderCandidateResponse(req) {
        req = ConverterUtils.OrderPluralize(req);
        var candidateResponse = new OrderCandidateResponse(req);
        if (Utilities.IsDefined(req)) {
            candidateResponse.ActivationDate = Utilities.DateString(req.ActivationDate);
        }
        candidateResponse.RemoveInternalData();
        candidateResponse.ValidationErrors = req.ValidationErrors;
        return candidateResponse;
    }
})(TestEndpoints || (TestEndpoints = {}));
module.exports = TestEndpoints;

"use strict";
/// <reference types="node" />
var Interpret = require("../cs-interpret/Interpret");
var ApiBase = require("./ApiBase");
/**
* Handles calls from CS.DotNetServices to Interpret
*/
var InterpretApi;
(function (InterpretApi) {
    /**
    * productcandidate/deriveOrderCandidate
    */
    function DeriveOrderCandidate(callback, context, requestBody) {
        ApiBase.CreateCsContext(context, function () {
            new Interpret().DeriveOrderCandidate(requestBody, function (error, result, statusCode) {
                return callback(null, ApiBase.HandleCallback(error, result, context, statusCode), statusCode);
            });
        });
    }
    InterpretApi.DeriveOrderCandidate = DeriveOrderCandidate;
})(InterpretApi || (InterpretApi = {}));
module.exports = InterpretApi;

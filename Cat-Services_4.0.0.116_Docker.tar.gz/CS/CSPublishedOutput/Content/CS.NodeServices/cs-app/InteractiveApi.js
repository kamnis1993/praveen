"use strict";
/// <reference types="node" />
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var Interactive = require("../cs-interactive/Interactive");
var ApiBase = require("./ApiBase");
/**
* Handles calls from CS.DotNetServices to MarkCompatibility
*/
var InteractiveApi;
(function (InteractiveApi) {
    /**
    * productCandidate/markCompatibility
    */
    function MarkCompatibility(callback, context, requestBody, compiledSpecs) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Interactive().MarkPossibleIncompatibilities(requestBody, compiledSpecs, function (error, result) {
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    InteractiveApi.MarkCompatibility = MarkCompatibility;
})(InteractiveApi || (InteractiveApi = {}));
module.exports = InteractiveApi;

"use strict";
/// <reference types="node" />
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var Decompose = require("../cs-decompose/Decompose");
var ApiBase = require("./ApiBase");
var using = require("disposable-cls").using;
var getCurrentObject = require("disposable-cls").getCurrentObject;
/**
* Handles calls for CS.DotNetServices Decompose
*/
var DecomposeApi;
(function (DecomposeApi) {
    /**
    *  ordercandidate/decompose
    */
    function OrderCandidateDecompose(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Decompose().DecomposeOrderCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
        // TODO: Handle 400/500 Errors on .Net side
    }
    DecomposeApi.OrderCandidateDecompose = OrderCandidateDecompose;
    /**
     *  productcandidate/decompose
    */
    function ProductCandidateDecompose(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Decompose().DecomposeProductCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
        // TODO: Handle 400/500 Errors on .Net side
    }
    DecomposeApi.ProductCandidateDecompose = ProductCandidateDecompose;
    /**
    *  ordercandidate/decomposecontexts
    */
    function OrderCandidateDecomposeContexts(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Decompose().GetDecomposeContextsForOrderCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                //result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    DecomposeApi.OrderCandidateDecomposeContexts = OrderCandidateDecomposeContexts;
    /**
    *  productcandidate/decomposecontexts
    */
    function ProductCandidateDecomposeContexts(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Decompose().GetDecomposeContextsForProductCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                //result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    DecomposeApi.ProductCandidateDecomposeContexts = ProductCandidateDecomposeContexts;
})(DecomposeApi || (DecomposeApi = {}));
module.exports = DecomposeApi;

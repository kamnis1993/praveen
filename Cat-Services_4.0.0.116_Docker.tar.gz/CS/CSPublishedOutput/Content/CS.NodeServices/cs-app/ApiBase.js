"use strict";
/// <reference types="node" />
var Utilities = require("../cs-lib-utilities/Utilities");
var JsonOutputFormatter = require("./Formatting/JsonOutputFormatter");
var CsContext = require("../cs-lib-types/CsContext");
var using = require("disposable-cls").using;
var getCurrentObject = require("disposable-cls").getCurrentObject;
var ApiBase;
(function (ApiBase) {
    function CreateCsContext(context, func) {
        var csContext = new CsContext();
        if (Utilities.IsDefined(context)) {
            csContext.IncludeDiagnostics = context.IncludeDiagnostics;
            csContext.LogLevel = context.LogLevel;
            csContext.TraceEvents = [];
            csContext.SchemaContext = context.SchemaContext;
        }
        // Create the per request context for this call
        using([csContext], function () {
            func();
        });
    }
    ApiBase.CreateCsContext = CreateCsContext;
    function HandleCallback(error, result, context, statusCode) {
        if (statusCode === void 0) { statusCode = 200; }
        // Here we wrap error or result in a 'result' object - ensuring that even arrays are wrapped around a JObject when passed back to dotnet.
        // We then extract the contents of the 'result' object and handle the response on dotnet side.
        var returnObj = { result: [], statusCode: 200, Context: null };
        returnObj.result = result;
        returnObj.statusCode = statusCode;
        if (Utilities.IsDefined(error, true) && Object.keys(error).length > 0) {
            returnObj.result = error;
        }
        else {
            if (Utilities.IsDefined(context.SchemaContext)
                && Utilities.IsDefined(context.SchemaContext.SchemaName, true)) {
                // Apply the schema
                var formatter = new JsonOutputFormatter();
                returnObj.result = formatter.Format(result, context.SchemaContext);
            }
            else {
                returnObj.result = result;
            }
        }
        // Include the context in the response, Provides a carrier for Trace Events/diagnostics etc.
        returnObj.Context = getCurrentObject(CsContext);
        return returnObj;
    }
    ApiBase.HandleCallback = HandleCallback;
})(ApiBase || (ApiBase = {}));
module.exports = ApiBase;

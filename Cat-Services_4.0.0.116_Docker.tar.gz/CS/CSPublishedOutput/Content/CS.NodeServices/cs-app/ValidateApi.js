"use strict";
/// <reference types="node" />
var Validate = require("../cs-validate/Validate");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var ApiBase = require("./ApiBase");
/**
* Handles calls for CS.DotNetServices to Validate
*/
var ValidateApi;
(function (ValidateApi) {
    /**
    * ordercandidate/validate/locked
    * ordercandidate/validate/locked/commercial
    */
    function ValidateOrderCandidateLocked(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Validate().ValidateOrderCandidateLocked(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
        // TODO: Handle 400/500 Errors on .Net side
    }
    ValidateApi.ValidateOrderCandidateLocked = ValidateOrderCandidateLocked;
    /**
   * productcandidate/validate/Locked
   * productcandidate/validate/Locked/commercial
   */
    function ValidateProductCandidateLocked(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Validate().ValidateProductCandidateLocked(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    ValidateApi.ValidateProductCandidateLocked = ValidateProductCandidateLocked;
    /**
    * ordercandidate/validate
    * ordercandidate/validate/commercial
    */
    function ValidateOrderCandidate(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Validate().ValidateOrderCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    ValidateApi.ValidateOrderCandidate = ValidateOrderCandidate;
    /**
    * productcandidate/validate
    * productcandidate/validate/commercial
    */
    function ValidateProductCandidate(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Validate().ValidateProductCandidate(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    ValidateApi.ValidateProductCandidate = ValidateProductCandidate;
    /**
    * portfolio/validate
    */
    function ValidatePortfolio(callback, context, requestBody, compiledSpecs, boundaryCondition) {
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new Validate().ValidatePortfolio(requestBody, compiledSpecs, boundaryCondition, function (error, result) {
                error = ConverterUtils.OrderSingularize(error);
                result = ConverterUtils.OrderSingularize(result);
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    ValidateApi.ValidatePortfolio = ValidatePortfolio;
})(ValidateApi || (ValidateApi = {}));
module.exports = ValidateApi;

"use strict";
/// <reference types="node" />
var SupplementalOrder = require("../cs-supplement-order/SupplementalOrder");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var ApiBase = require("./ApiBase");
/**
* Handles calls for CS.DotNetServices to SupplementalOrders
*/
var SupplementalOrderApi;
(function (SupplementalOrderApi) {
    /**
    * orderCandidate/supplementalOrder
    */
    function ProcessSupplementalOrder(callback, context, requestBody, compiledSpecs) {
        /**
        * This method modifies the structure of the request to match the way the typescript code was written (i.e. incorrectly).
        *  TODO: Ultimately the TS code should be changed to match the raw request (which matches the schema).  This will improve performance
        */
        ApiBase.CreateCsContext(context, function () {
            requestBody = ConverterUtils.OrderPluralize(requestBody);
            new SupplementalOrder().ProcessSupplementalOrder(requestBody, compiledSpecs, function (error, result) {
                return callback(null, ApiBase.HandleCallback(error, result, context));
            });
        });
    }
    SupplementalOrderApi.ProcessSupplementalOrder = ProcessSupplementalOrder;
})(SupplementalOrderApi || (SupplementalOrderApi = {}));
module.exports = SupplementalOrderApi;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RelationEntity = require("./RelationEntity");
/**
 * Represents a PRODUCT_TO_PRODUCT relationship in the product specification
 */
var ProductRelation = /** @class */ (function (_super) {
    __extends(ProductRelation, _super);
    /**
     * Create a new ProductRelation SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [relationSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function ProductRelation(relationSpec, errorContext) {
        var _this = _super.call(this, relationSpec, errorContext) || this;
        if (!relationSpec) {
            return _this;
        }
        return _this;
        // Note: Because of the dual object nature of the ProductEntity tree, Node gets upset
        //       if you try to create the Product when this relation was created from a Product
        //       (the ProductEntity import is undefined)
        //       When hydrating a Product, use the static method ProductEntity.CreateFromSpec()
    }
    return ProductRelation;
}(RelationEntity));
module.exports = ProductRelation;

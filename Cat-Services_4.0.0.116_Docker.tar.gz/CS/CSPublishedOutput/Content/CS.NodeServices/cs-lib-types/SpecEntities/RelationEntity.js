"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var EntityLimit = require("./EntityLimit");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Base class of relation ships. Extend this class for specific relations, e.g. ProductRelation
 */
var RelationEntity = /** @class */ (function (_super) {
    __extends(RelationEntity, _super);
    /**
     * Create a new RelationEntity SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [relationSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function RelationEntity(relationSpec, errorContext) {
        var _this = _super.call(this, relationSpec, errorContext) || this;
        _this.RelationLimits = [];
        if (!relationSpec) {
            return _this;
        }
        _this.Association_Start_Date = Utilities.ValueOrDefault(relationSpec.Association_Start_Date, undefined);
        _this.Association_End_Date = Utilities.ValueOrDefault(relationSpec.Association_End_Date, undefined);
        _this.Default_Cardinality = Utilities.ValueOrDefault(relationSpec.Default_Cardinality, undefined);
        _this.Min_Occurs = Utilities.ValueOrDefault(relationSpec.Min_Occurs, undefined);
        _this.Max_Occurs = Utilities.ValueOrDefault(relationSpec.Max_Occurs, undefined);
        _this.Type = Utilities.ValueOrDefault(relationSpec._meta.path, "Relation_Entity");
        _this.ChargePath = Utilities.ValueOrDefault(relationSpec.ChargePath, undefined);
        _this.DiscountPath = Utilities.ValueOrDefault(relationSpec.DiscountPath, undefined);
        _this.ChargeRole = Utilities.ValueOrDefault(relationSpec.ChargeRole, undefined);
        if (Utilities.IsDefined(relationSpec.CommPhases)) {
            _this.CommPhases = [];
            Utilities.asArray(relationSpec.CommPhases).forEach(function (phase) {
                _this.CommPhases.push(phase.CSCode);
            });
        }
        if (Utilities.IsDefined(relationSpec.TechPhases)) {
            _this.TechPhases = [];
            Utilities.asArray(relationSpec.TechPhases).forEach(function (phase) {
                _this.TechPhases.push(phase.CSCode);
            });
        }
        for (var propertyName in relationSpec) {
            // Entity Limits
            var relationLimitsFound = Utilities.ConvertToArrayOf(relationSpec[propertyName], function (item) {
                if (LodashUtilities.IsPlainObject(item)) {
                    var itemName = Utilities.GetDeepValue(item, '_meta.name', undefined);
                    if (itemName === 'TLookup_Limit' || itemName === 'TTree_Leaf_Limit') {
                        return new EntityLimit(item, propertyName, errorContext);
                    }
                }
                return undefined;
            });
            if (relationLimitsFound.length > 0) {
                _this.RelationLimits = _this.RelationLimits.concat(relationLimitsFound);
            }
        }
        return _this;
    }
    Object.defineProperty(RelationEntity.prototype, "CardinalityString", {
        /**
         * Property (read-only) Get the cardinality as a min:max string
         * If Min is undefined, it's set to 0
         * If Max is undefined, it's set to n
         * @returns {string} a string representation of the relation
         */
        get: function () {
            var min = this.Min_Occurs === undefined ? '0' : this.Min_Occurs.toString();
            var max = this.Max_Occurs === undefined ? 'n' : this.Max_Occurs.toString();
            return (min + ':' + max);
        },
        enumerable: true,
        configurable: true
    });
    return RelationEntity;
}(SpecEntityBase));
module.exports = RelationEntity;

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Represents a TChild_Group_Cardinality_Rule in the specification
 */
var ChildGroupCardinalityRule = /** @class */ (function (_super) {
    __extends(ChildGroupCardinalityRule, _super);
    /**
     * Creates a new instance of ChildGroupCardinalityRule
     * @param {any} groupCardinalityRule? DescriptionOfParam
     */
    function ChildGroupCardinalityRule(groupCardinalityRule, errorContext) {
        var _this = _super.call(this, groupCardinalityRule, errorContext) || this;
        if (!groupCardinalityRule) {
            return _this;
        }
        _this.MinimumChildElements = groupCardinalityRule.Minimum_Child_Elements;
        _this.MaximumChildElements = groupCardinalityRule.Maximum_Child_Elements;
        _this.Description = groupCardinalityRule.Rule_Description;
        if (Utilities.IsDefined(groupCardinalityRule.CommPhases)) {
            _this.CommPhases = [];
            Utilities.asArray(groupCardinalityRule.CommPhases).forEach(function (phase) {
                _this.CommPhases.push(phase.CSCode);
            });
        }
        if (Utilities.IsDefined(groupCardinalityRule.TechPhases)) {
            _this.TechPhases = [];
            Utilities.asArray(groupCardinalityRule.TechPhases).forEach(function (phase) {
                _this.TechPhases.push(phase.CSCode);
            });
        }
        return _this;
    }
    return ChildGroupCardinalityRule;
}(SpecEntityBase));
module.exports = ChildGroupCardinalityRule;

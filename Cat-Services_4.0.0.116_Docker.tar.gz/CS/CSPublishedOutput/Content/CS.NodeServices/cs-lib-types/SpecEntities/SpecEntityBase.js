"use strict";
/// <reference types="node" />
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * The base class for all Product Specification entities.
 */
var SpecEntityBase = /** @class */ (function () {
    /**
     * Create a new SpecEntityBase, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [productSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function SpecEntityBase(productSpec, errorContext) {
        this._errorContext = errorContext;
        if (!productSpec) {
            return;
        }
        this.Meta = Utilities.ValueOrDefault(productSpec._meta, {});
        this.Guid = Utilities.ValueOrDefault(this.Meta.ID, undefined, true);
        this.Name = Utilities.ValueOrDefault(productSpec.Name, undefined);
        this.Description = Utilities.ValueOrDefault(productSpec.Description, undefined);
    }
    Object.defineProperty(SpecEntityBase.prototype, "Path", {
        /**
         * Property (read only): Path
         * The path proerty from the _meta object
         * @returns {string} undefined if path is not present or not a string, otherwise path
         */
        get: function () {
            if (!this.Meta || this.Meta.path === undefined || this.Meta.path === null) {
                return undefined;
            }
            return typeof (this.Meta.path) === 'string' ? this.Meta.path : undefined;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Get a specific part of the Path (path is split by '/').
     * @param {number} part the part of the path to get. 0 is first, -1 is last
     * @returns {string} the appropriate part of the path
     */
    SpecEntityBase.prototype.GetPathPart = function (part) {
        if (this.Path === undefined) {
            return undefined;
        }
        if (part < -1) {
            return undefined;
        }
        var pathParts = this.Path.split('/');
        if (part === -1) {
            return pathParts[pathParts.length - 1];
        }
        else {
            return (part < pathParts.length) ? pathParts[part] : undefined;
        }
    };
    /**
     * Raises a bad data error
     * @param   {string} entityId The Id of the Entity
     * @param   {string} badDataType The category of bad data
     * @param   {any}   messageParameters any parameters required by the message translation
     * @param   {string} sourceEntityId The entity ID of the source entity
     * @param   {string} targetEntityId The entity ID of the target entity
     *
     */
    SpecEntityBase.prototype.RaiseBadDataError = function (errorDescriptor, entityId, badDataType, messageParameters, sourceEntityId, targetEntityId) {
        if (Utilities.IsNotDefined(this._errorContext)) {
            return undefined;
        }
        return this._errorContext.RaiseBadDataError(errorDescriptor, entityId, badDataType, messageParameters, sourceEntityId, targetEntityId);
    };
    Object.defineProperty(SpecEntityBase.prototype, "HasBreakingErrors", {
        get: function () {
            if (Utilities.IsNotDefined(this._errorContext)) {
                return false;
            }
            return this._errorContext.HasBadDataError || this._errorContext.HasProcessError;
        },
        enumerable: true,
        configurable: true
    });
    return SpecEntityBase;
}());
module.exports = SpecEntityBase;

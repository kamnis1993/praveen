"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
/**
 * Represents a CostRateType relationship in the product specification
 */
var CostRateType = /** @class */ (function (_super) {
    __extends(CostRateType, _super);
    /**
     * Creates a new CostRateType SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [costRateType] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function CostRateType(costRateType) {
        return _super.call(this, costRateType) || this;
    }
    return CostRateType;
}(SpecEntityBase));
module.exports = CostRateType;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MappingTarget = require("./MappingTarget");
var MappingSource = require("./MappingSource");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
var MappingAction = /** @class */ (function (_super) {
    __extends(MappingAction, _super);
    /**
     * Create a new MappingAction.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [mappingSpec] Optional. An object literal to hydrate the MappingAction from
     */
    function MappingAction(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        _this.ParentSequence = 1;
        /**
         * Holds the list of states that the target entity must be in if it is to have this action applied
         */
        _this.TargetStates = [];
        if (!mappingSpec) {
            return _this;
        }
        _this.Replace = Utilities.ParseAsBoolean(mappingSpec.Replace, false);
        _this.Sequence = Utilities.ParseAsNumber(mappingSpec.Sequence, 1);
        _this.Literal = Utilities.ValueOrDefault(mappingSpec.Literal, null);
        _this.SkipIfEntityExists = Utilities.ParseAsBoolean(mappingSpec.SkipIfEntityExists, false);
        _this.SkipIfValuesExist = Utilities.ParseAsBoolean(mappingSpec.SkipIfValuesExist, false);
        if (!mappingSpec.TargetState) {
            _this.TargetStates = null; // if states are empty, all are false. If not supplied, all are true.
        }
        else {
            _this.TargetStates = Utilities.asArray(mappingSpec.TargetState).map(function (value) { return new SpecEntityBase(value, errorContext); });
        }
        if (typeof mappingSpec.Target === 'string') {
            _this.SimpleTarget = mappingSpec.Target.toLowerCase();
            if (mappingSpec.Target.indexOf(',|,') >= 0) //is this target a instance element pipe separated path to a characteristic?
             {
                _this.Target = new MappingTarget(mappingSpec, errorContext);
            }
            else if (mappingSpec.Target_RA_OFName) //is this a target for a rate attribute?
             {
                _this.Target = new MappingTarget(null, errorContext);
                _this.Target.EntityBusinessIDPath = mappingSpec.Target;
                _this.Target.RateAttributeName = mappingSpec.Target_RA_OFName;
            }
        }
        else {
            _this.Target = new MappingTarget(Utilities.ValueOrDefault(mappingSpec.Target, undefined));
        }
        if (Utilities.IsDefined(mappingSpec.Link)) {
            _this.EntityLink = new MappingTarget(mappingSpec.Link, errorContext);
        }
        if (_this.HasBreakingErrors) {
            return _this;
        }
        _this.Source = new MappingSource(Utilities.ValueOrDefault(mappingSpec.Source, undefined), errorContext);
        return _this;
    }
    Object.defineProperty(MappingAction.prototype, "ActionType", {
        /**
         * Property (read-only): ActionType
         * Should match the constants in MappingActionType
         * @returns {string} ActionType
         */
        get: function () {
            var actionType = this.GetPathPart(0);
            return Utilities.ValueOrDefault(actionType, undefined);
        },
        enumerable: true,
        configurable: true
    });
    return MappingAction;
}(SpecEntityBase));
module.exports = MappingAction;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CharacteristicUseBaseEntity = require("./CharacteristicUseBaseEntity");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Represents a ConfiguredValue in the Spec
 */
var ConfiguredValueEntity = /** @class */ (function (_super) {
    __extends(ConfiguredValueEntity, _super);
    /**
     * Create a new ConfiguredValueEntity.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [charUseSpec] Optional. An object literal to hydrate the entity from
     * @param {string} [parentProductGuid] Optional The Guid of the parent product.
     */
    function ConfiguredValueEntity(configValueSpec, useAreaName, parentProductGuid, errorContext) {
        var _this = _super.call(this, configValueSpec, useAreaName, parentProductGuid, errorContext) || this;
        _this.RegularExpression = Utilities.ValueOrDefault(configValueSpec.Regular_Expression, undefined);
        _this.RegexMessage = Utilities.ValueOrDefault(configValueSpec.Regex_Message, undefined);
        _this.CharacteristicType = Utilities.GetDeepValue(configValueSpec, "Characteristic.Datatype._meta.ID");
        return _this;
    }
    return ConfiguredValueEntity;
}(CharacteristicUseBaseEntity));
module.exports = ConfiguredValueEntity;

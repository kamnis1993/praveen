"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadDataTypes = require("../../cs-lib-constants/BadDataTypes");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/*
 * Class describes an entity link value
 */
var EntityLinkValue = /** @class */ (function (_super) {
    __extends(EntityLinkValue, _super);
    /**
     * Creates a new instance of an EntityLinkValue
     * @param {RuleEntityValue} entityLinkValue the object to use to populate this one
     */
    function EntityLinkValue(entityLinkValue, errorContext) {
        var _this = _super.call(this, entityLinkValue, errorContext) || this;
        if (Utilities.IsNotDefined(entityLinkValue)) {
            _this.ExtractTargetPaths(undefined);
        }
        else {
            _this.ExtractTargetPaths(entityLinkValue.EntityLink);
        }
        _this.Scope = Utilities.ValueOrDefault(entityLinkValue.Scope, undefined);
        return _this;
    }
    /**
     * Extract Entity and Element paths from the entity link from the SPEC
     * @param {any} linkValue the Action.Target.EntityValue as supplied from the spec
     */
    EntityLinkValue.prototype.ExtractTargetPaths = function (linkValue) {
        this.EntityLink = linkValue;
        if (Utilities.IsNotDefined(linkValue)) {
            this.EntityPath = undefined;
            this.InstancePath = undefined;
            this.SchemaElementPath = undefined;
            return;
        }
        var pathParts = linkValue.split('|').map(function (a) {
            return a.split(',').filter(function (b) { return b.length > 1; });
        });
        if (Utilities.IsNotDefined(pathParts) || pathParts.length !== 2) {
            this.RaiseBadDataError(ErrorCode.BadData.InvalidEntityLinkTarget, undefined, BadDataTypes.InvalidProperty, { LinkTarget: linkValue });
        }
        this.EntityPath = pathParts[0].join(',').toLowerCase();
        this.InstancePath = pathParts[1].filter(function (part, index) { return index % 2 !== 0; }).join(',').toLowerCase();
        this.SchemaElementPath = pathParts[1].filter(function (part, index) { return index % 2 === 0; }).join(',').toLowerCase();
    };
    return EntityLinkValue;
}(SpecEntityBase));
module.exports = EntityLinkValue;

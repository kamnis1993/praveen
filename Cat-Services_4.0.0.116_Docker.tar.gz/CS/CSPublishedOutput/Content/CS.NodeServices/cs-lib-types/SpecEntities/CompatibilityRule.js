"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RuleScope = require("../../cs-lib-constants/RuleScope");
var RuleConditionCollection = require("./RuleConditionCollection");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a compatibility rule in the catalog
 */
var CompatibilityRule = /** @class */ (function (_super) {
    __extends(CompatibilityRule, _super);
    /**
     * Creates a new instance of a CompatibilityRule
     * @param {any} compatibilityRule? the rule info to use when creating this one
     */
    function CompatibilityRule(compatibilityRule, errorContext) {
        var _this = _super.call(this, compatibilityRule, errorContext) || this;
        _this.StartDate = undefined;
        _this.EndDate = undefined;
        _this.Name = compatibilityRule.Name;
        _this.ErrorMessage = compatibilityRule.ErrorMessage;
        _this.Conditions = new RuleConditionCollection(compatibilityRule, errorContext);
        _this.Scope = _this.GetRuleScope(compatibilityRule._meta.path);
        _this.FurtherScope = Utilities.ValueOrDefault(compatibilityRule.Scope, undefined);
        _this.StartDate = Utilities.ParseDateFromString(compatibilityRule.StartDate);
        _this.EndDate = Utilities.ParseDateFromString(compatibilityRule.EndDate);
        if (Utilities.IsDefined(compatibilityRule.CommPhases)) {
            _this.CommPhases = [];
            Utilities.asArray(compatibilityRule.CommPhases).forEach(function (phase) {
                _this.CommPhases.push(phase.CSCode);
            });
        }
        if (Utilities.IsDefined(compatibilityRule.TechPhases)) {
            _this.TechPhases = [];
            Utilities.asArray(compatibilityRule.TechPhases).forEach(function (phase) {
                _this.TechPhases.push(phase.CSCode);
            });
        }
        return _this;
    }
    /**
     * Gets the scope of this rule based on its type
     * @param {string} typePath the type information for this rule
     * @returns {RuleScope} the rule scope for this rule
     */
    CompatibilityRule.prototype.GetRuleScope = function (typePath) {
        var typeHierarchy = typePath.split('/');
        var typeOfRule = typeHierarchy[typeHierarchy.length - 2];
        switch (typeOfRule) {
            case 'SigmaPortfolioCompatibilityRule':
                return RuleScope.Portfolio;
            case 'SigmaChildCompatibilityRule':
                return RuleScope.Child;
            case 'SigmaPCCompatibilityRule':
                return RuleScope.ProductCandidate;
            default:
                return RuleScope.Child;
        }
    };
    return CompatibilityRule;
}(SpecEntityBase));
module.exports = CompatibilityRule;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
var MappingTriggerType = require("../Enums/MappingTriggerType");
var SpecificationGuids = require("../../cs-lib-constants/SpecificationGuids");
var MappingTriggerEvent = /** @class */ (function (_super) {
    __extends(MappingTriggerEvent, _super);
    /**
     * Create a new RuleCondition.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [mappingSpec] Optional. An object literal to hydrate the MappingTriggerEvent from
     */
    function MappingTriggerEvent(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        if (!mappingSpec) {
            return _this;
        }
        return _this;
    }
    Object.defineProperty(MappingTriggerEvent.prototype, "Type", {
        /**
         * (ReadOnly) Get the trigger type (MappingTriggerType enum)
         * @returns {MappingTriggerType}
         */
        get: function () {
            if (this.Guid.toLowerCase() === SpecificationGuids.Mapping.TriggerEvents.Decompose) {
                return MappingTriggerType.Decompose;
            }
            if (this.Guid.toLowerCase() === SpecificationGuids.Mapping.TriggerEvents.CommercialDecompose) {
                return MappingTriggerType.CommercialDecompose;
            }
            return MappingTriggerType.Unknown;
        },
        enumerable: true,
        configurable: true
    });
    return MappingTriggerEvent;
}(SpecEntityBase));
module.exports = MappingTriggerEvent;

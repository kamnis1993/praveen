"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RelationEntity = require("./RelationEntity");
/**
 * Represents a Product_To_Discount_Group relationship in the product specification
 */
var DiscountGroupRelation = /** @class */ (function (_super) {
    __extends(DiscountGroupRelation, _super);
    /**
     * Create a new ProductRelation SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [relationSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function DiscountGroupRelation(relationSpec, errorContext) {
        var _this = _super.call(this, relationSpec, errorContext) || this;
        if (!relationSpec) {
            return _this;
        }
        _this.Discount_Group = relationSpec.Discount_Group;
        return _this;
    }
    return DiscountGroupRelation;
}(RelationEntity));
module.exports = DiscountGroupRelation;

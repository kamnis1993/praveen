"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CharacteristicUseBaseEntity = require("./CharacteristicUseBaseEntity");
/**
 * Represents a CharacteristicUse in the Spec
 */
var CharacteristicUseEntity = /** @class */ (function (_super) {
    __extends(CharacteristicUseEntity, _super);
    /**
     * Create a new CharacteristicUseEntity.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [charUseSpec] Optional. An object literal to hydrate the CharacteristicUseEntity from
     * @param {string} [parentProductGuid] Optional The Guid of the parent product.
     */
    function CharacteristicUseEntity(charUseSpec, useAreaName, parentProductGuid, errorContext) {
        return _super.call(this, charUseSpec, useAreaName, parentProductGuid, errorContext) || this;
    }
    return CharacteristicUseEntity;
}(CharacteristicUseBaseEntity));
module.exports = CharacteristicUseEntity;

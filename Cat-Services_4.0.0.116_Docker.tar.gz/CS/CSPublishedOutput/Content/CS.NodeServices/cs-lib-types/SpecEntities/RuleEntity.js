"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
var SpecificationGuids = require("../../cs-lib-constants/SpecificationGuids");
var Utilities = require("../../cs-lib-utilities/Utilities");
var RuleScope = require("../../cs-lib-constants/RuleScope");
/*
 * Class describes a sigma rule that points at an entity
 */
var RuleEntity = /** @class */ (function (_super) {
    __extends(RuleEntity, _super);
    /**
     * Creates a new instance of a rule entity
     * @param {any} ruleEntity the object to use to populate this one
     */
    function RuleEntity(ruleEntity, errorContext) {
        var _this = _super.call(this, ruleEntity, errorContext) || this;
        if (ruleEntity !== undefined && ruleEntity !== null) {
            _this.Entity = ruleEntity.Entity.toLowerCase();
            _this.ItemAction = RuleEntity.GetItemAction(ruleEntity);
            _this.Scope = RuleEntity.GetRuleScope(ruleEntity);
        }
        return _this;
    }
    /**
    * Get the ItemAction based on the ruleEntity guid
    * Note. Using the guid ensures that rule matching is not affected if customer changes action names
    * @param {any} ruleEntity
    * @returns {string}
    */
    RuleEntity.GetItemAction = function (ruleEntity) {
        if (!ruleEntity || !ruleEntity.ItemAction || !ruleEntity.ItemAction._meta || !ruleEntity.ItemAction._meta.ID) {
            return undefined;
        }
        for (var property in SpecificationGuids.Mapping.SourceTargetState) {
            // Compare the ItemAction Guid to the SpecificationGuids constants
            if (ruleEntity.ItemAction._meta.ID === SpecificationGuids.Mapping.SourceTargetState[property]) {
                return property.toLowerCase();
            }
        }
        return undefined;
    };
    /**
     * Returns the rule scope for a rule entity
     * Scope name in Catalog is configured as "PORTFOLIO", "CHILD" and "PRODUCT_CANDIDATE".
     * Below logic make sure that it is been stored as defined RuleScope so that future
     * string comparisions won't fail.
     * @param {any} ruleEntity
     * @returns {string}
     */
    RuleEntity.GetRuleScope = function (ruleEntity) {
        var ruleScope = undefined;
        if (Utilities.IsDefined(ruleEntity.Scope) && Utilities.IsDefined(ruleEntity.Scope.Name, true)) {
            switch (ruleEntity.Scope.Name.toUpperCase()) {
                case "PORTFOLIO":
                    ruleScope = RuleScope.Portfolio;
                    break;
                case "CHILD":
                    ruleScope = RuleScope.Child;
                    break;
                case "PRODUCT_CANDIDATE":
                    ruleScope = RuleScope.ProductCandidate;
                    break;
                default:
                    ruleScope = undefined;
            }
        }
        return ruleScope;
    };
    return RuleEntity;
}(SpecEntityBase));
module.exports = RuleEntity;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SigmaEntityLink = require("./SigmaEntityLink");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Base class for Catalog LaunchableEntities. Extend this for specific entities, e.g. Product
 */
var LaunchEntity = /** @class */ (function (_super) {
    __extends(LaunchEntity, _super);
    /**
     * Create a new LaunchEntity SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [productSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function LaunchEntity(productSpec, errorContext) {
        var _this = _super.call(this, productSpec, errorContext) || this;
        if (!productSpec) {
            return _this;
        }
        _this.Element_Guid = Utilities.ValueOrDefault(productSpec.Element_Guid, undefined, true);
        _this.Element_Type_Guid = Utilities.ValueOrDefault(productSpec.Element_Type_Guid, undefined, true);
        _this.Business_ID = Utilities.ValueOrDefault(productSpec.Business_ID, undefined, true);
        _this.Category_ID = Utilities.ValueOrDefault(productSpec.Category_ID, undefined, true);
        _this.Effective_Start_Date = Utilities.ValueOrDefault(productSpec.Effective_Start_Date, undefined);
        _this.Effective_End_Date = Utilities.ValueOrDefault(productSpec.Effective_End_Date, undefined);
        _this.Available_Start_Date = Utilities.ValueOrDefault(productSpec.Available_Start_Date, undefined);
        _this.Available_End_Date = Utilities.ValueOrDefault(productSpec.Available_End_Date, undefined);
        _this.LinkedEntities = Utilities.ConvertToArrayOf(productSpec.SigmaEntLinks, function (link) {
            return new SigmaEntityLink(link, errorContext);
        });
        return _this;
    }
    Object.defineProperty(LaunchEntity.prototype, "BusinessID", {
        /**
         * Property (read only): BusinessID synonym for Business_ID
         * @returns {boolean}
         */
        get: function () { return this.Business_ID; },
        enumerable: true,
        configurable: true
    });
    return LaunchEntity;
}(SpecEntityBase));
module.exports = LaunchEntity;

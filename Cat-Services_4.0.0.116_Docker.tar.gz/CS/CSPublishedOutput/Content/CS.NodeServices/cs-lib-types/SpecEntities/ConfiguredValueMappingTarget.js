"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MappingTarget = require("./MappingTarget");
var ConfiguredValueMappingTarget = /** @class */ (function (_super) {
    __extends(ConfiguredValueMappingTarget, _super);
    /**
     * Create a new ConfiguredValueMappingTarget.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [mappingSpec] Optional. An object literal to hydrate the MappingAction from
     * @param {string} [parentProductGuid] Optional The Guid of the parent product.
     */
    function ConfiguredValueMappingTarget(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        if (!mappingSpec) {
            return _this;
        }
        //I have to do this because typescript is garbage. Default values on the base class are set AFTER the super call. So any constructor initialisation of
        //of properties on the base class is pointless as they revert to their default values after the super call.
        //Hence why this class does the same work as the base class
        //var formattedPaths = this.Format(mappingSpec._entityValue);
        var rawValue = mappingSpec._entityValue ? mappingSpec._entityValue : mappingSpec.EntityValue;
        _this.ExtractTargetPaths(rawValue);
        var instancePath = _this.InstancePath.split(',');
        _this.CharacteristicValueID = instancePath[instancePath.length - 1];
        _this.CharacteristicUseID = instancePath[instancePath.length - 2];
        _this.CharacteristicUseSchemaElementGuid = _this.SchemaElementPath.split(',')[0].toLowerCase();
        return _this;
    }
    return ConfiguredValueMappingTarget;
}(MappingTarget));
module.exports = ConfiguredValueMappingTarget;

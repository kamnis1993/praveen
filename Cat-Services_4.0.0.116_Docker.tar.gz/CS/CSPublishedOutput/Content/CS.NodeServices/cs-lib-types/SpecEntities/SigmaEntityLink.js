"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that represents a relation between 2 items in a candidate
 * (Note : This class is a direct representation of the class from the spec / database, i.e. its a spec entity. hence why it is called SigmaCandidateRelation and not LinkEntity)
 */
var SigmaEntityLink = /** @class */ (function (_super) {
    __extends(SigmaEntityLink, _super);
    /**
     * Create a new EntityRelation, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [productSpec] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function SigmaEntityLink(spec, errorContext) {
        var _this = _super.call(this, spec, errorContext) || this;
        if (!spec) {
            return _this;
        }
        _this.IsUnique = Utilities.ParseAsBoolean(spec.IsUnique, false);
        _this.IsRequired = Utilities.ParseAsBoolean(spec.IsRequired, false);
        _this.IsMulti = Utilities.ParseAsBoolean(spec.IsMulti, false);
        _this.Source = Utilities.ValueOrDefault(spec.Source, undefined);
        _this.Target = Utilities.ValueOrDefault(spec.Target, undefined);
        _this.EvaluateInCommercialScope = Utilities.ParseAsBoolean(spec.EvaluateInCommercialScope, false);
        _this.TargetIsDependent = Utilities.ParseAsBoolean(spec.TargetIsDependent, false);
        if (Utilities.IsDefined(spec.CommPhases)) {
            _this.CommPhases = [];
            Utilities.asArray(spec.CommPhases).forEach(function (phase) {
                _this.CommPhases.push(phase.CSCode);
            });
        }
        if (Utilities.IsDefined(spec.TechPhases)) {
            _this.TechPhases = [];
            Utilities.asArray(spec.TechPhases).forEach(function (phase) {
                _this.TechPhases.push(phase.CSCode);
            });
        }
        return _this;
    }
    return SigmaEntityLink;
}(SpecEntityBase));
module.exports = SigmaEntityLink;

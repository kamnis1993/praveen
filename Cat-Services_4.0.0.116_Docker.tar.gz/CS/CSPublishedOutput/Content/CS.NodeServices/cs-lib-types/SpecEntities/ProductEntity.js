"use strict";
/// <reference types="node" />
/// <reference types="lodash" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CharacteristicUseEntity = require("./CharacteristicUseEntity");
var ChildGroupCardinalityRule = require("./ChildGroupCardinalityRule");
var CompatibilityRule = require("./CompatibilityRule");
var ConfiguredValueEntity = require("./ConfiguredValueEntity");
var EntityLimit = require("./EntityLimit");
var IndexedProductEntity = require("./IndexedProductEntity");
var LaunchEntity = require("./LaunchEntity");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var MappingRule = require("./MappingRule");
var ProductRelation = require("./ProductRelation");
var Rate = require("./Rate");
var SigmaEntityLink = require("./SigmaEntityLink");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Represents a Product within the Product Specification
 */
var ProductEntity = /** @class */ (function (_super) {
    __extends(ProductEntity, _super);
    /**
     * Create a new Product SpecEntity.
     * Passing a spec (typically the output of ProductSpecificationDal) will hydrate this object only, no children.
     * To hydrate the full use the static CreateFromSpec() method
     *
     * @param {any} [productSpec] Optional. If supplied, the non-array values on the new object will be hydrated from it.
     *                                      Usually output of ProductSpecificationDal
     * @param {boolean} [omitMappingRules] Optional. If supplied then the mapping rules are not add to the product entity
     *                                          Used for when we map the candidate template from the spec, because we don't require mapping rules
     * @param {CSErrorContext} [errorContext] Optional. If supplied, errors CS and BadData errors will be added
     *
     * @constructor
     */
    function ProductEntity(productSpec, omitMappingRules, errorContext) {
        var _this = _super.call(this, productSpec, errorContext) || this;
        _this._indexedProductEntities = [];
        _this.Product_To_Product = [];
        _this.AllProductRelations = [];
        _this.MappingRules = [];
        _this.CharacteristicUses = [];
        _this.ConfiguredValues = [];
        _this.EntityLimits = [];
        _this.CompatibilityRules = [];
        _this.Rates = [];
        if (!productSpec) {
            return _this;
        }
        _this.PopulateProductToProductRelations(productSpec);
        _this.Min_Cust_Portfolio_Instances = Utilities.ValueOrDefault(productSpec.Min_Cust_Portfolio_Instances, undefined);
        _this.Max_Cust_Portfolio_Instances = Utilities.ValueOrDefault(productSpec.Max_Cust_Portfolio_Instances, undefined);
        _this.IsForCustomService = Utilities.ValueOrDefault(productSpec.IsForCustomService, false);
        _this.IsExcludedCharge = (Utilities.IsDefined(productSpec._meta) ? (Utilities.IsDefined(productSpec._meta.IsExcludedCharge)) ? (productSpec._meta.IsExcludedCharge) : (false) : false);
        _this.IsExcludedCost = (Utilities.IsDefined(productSpec._meta) ? (Utilities.IsDefined(productSpec._meta.IsExcludedCost)) ? (productSpec._meta.IsExcludedCost) : (false) : false);
        _this.IsExcludedDiscount = (Utilities.IsDefined(productSpec._meta) ? (Utilities.IsDefined(productSpec._meta.IsExcludedDiscount)) ? (productSpec._meta.IsExcludedDiscount) : (false) : false);
        _this.ChargePeriodicity = (Utilities.IsDefined(productSpec.Charge_Periodicity)) ? (new SpecEntityBase(productSpec.Charge_Periodicity)) : (undefined);
        _this.DiscountClass = (Utilities.IsDefined(productSpec.Discount_Class)) ? (new SpecEntityBase(productSpec.Discount_Class)) : (undefined);
        _this.UnitOfMeasure = Utilities.ValueOrDefault(productSpec.Unit_Of_Measure, undefined);
        _this.CostDetails = Utilities.ValueOrDefault(productSpec.CostDetails, []);
        _this.ChargeDetails = Utilities.ValueOrDefault(productSpec.ChargeDetails, []);
        _this.ChargeAdjustments = Utilities.ValueOrDefault(productSpec.Rates, []);
        _this.PopulateEntityLinks(productSpec.SigmaEntLinks);
        if (productSpec.TChild_Group_Cardinality_Rule) {
            _this.ChildGroupCardinalityRule = new ChildGroupCardinalityRule(productSpec.TChild_Group_Cardinality_Rule, errorContext);
        }
        Object.keys(productSpec).forEach(function (propertyName) {
            var productSpecValue = productSpec[propertyName];
            if (!LodashUtilities.IsPlainObject(productSpecValue) && !LodashUtilities.IsArray(productSpecValue)) {
                return;
            }
            var values = Utilities.asArray(productSpecValue);
            if (_this.ValueIsATypeOf(values, ['SMapRuleBase']) && !omitMappingRules) {
                _this.PopulateMappingRules(productSpec[propertyName]);
            }
            else if (_this.ValueIsATypeOf(values, ['SigmaCompatibilityRule'])) {
                _this.PopulateCompatibilityRules(productSpec[propertyName]);
            }
            else if (_this.ValueIsATypeOf(values, ['TCharUse', 'TConfigurable_Fact'])) {
                _this.PopulateCharacteristicUses(propertyName, productSpec[propertyName]);
            }
            else if (_this.ValueIsATypeOf(values, ['TDefinableCharacteristicValue'])) {
                _this.PopulateUserDefinedCharacteristicUses(propertyName, productSpec[propertyName]);
            }
            else if (_this.ValueIsATypeOf(values, ['TLookup_Limit', 'TTree_Leaf_Limit'])) {
                _this.PopulateEntityLimits(propertyName, productSpec[propertyName]);
            }
            else if (_this.ValueIsATypeOf(values, ['Non_Recurring_Rate', 'NonRecCostRate', 'NonRecCostBasedRate', 'Recurring_Rate', 'RecCostRate', 'RecCostBasedRate', 'Standalone_RC_Rate', 'Standalone_NRC_Rate', 'SimpleCBDRate'])) {
                _this.PopulateRates(propertyName, productSpec[propertyName]);
            }
            else if (propertyName === "EntityPathsRemoved") {
                _this.EntityPathsRemoved = values;
            }
            if (_this.HasBreakingErrors) {
                return;
            }
        });
        return _this;
    }
    Object.defineProperty(ProductEntity.prototype, "IsTechnical", {
        /**
         * Property (read only): IsTechnical whether the product is marked as a Technical Product in the current context
         * @returns {boolean}
         */
        get: function () {
            return Utilities.ParseAsBoolean(this.Meta.isTechnical, false);
        },
        enumerable: true,
        configurable: true
    });
    ProductEntity.FilterByHierarchy = function (source, pathPart) {
        var result = [];
        var keys = Object.keys(source);
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var values = Utilities.asArray(source[key]);
            values.forEach(function (v) {
                if (v && v._meta) {
                    var path = Utilities.IsDefined(v._meta.path) ? v._meta.path : v._meta.Path;
                    if (path && path.indexOf(pathPart) >= 0) {
                        result.push(v);
                    }
                }
            });
        }
        return result;
    };
    /**
     * Child of static factory method CreateFromSpec
     * @static
     * @param {any} relationSpec DescriptionOfParamA literal object representing the product
     * @returns {ProductRelation} An hydrated ProductRelation
     */
    ProductEntity.CreateProductRelation = function (relationSpec, errorContext) {
        var newProdRelation = new ProductRelation(relationSpec, errorContext);
        newProdRelation.Product = undefined;
        if (relationSpec !== undefined && relationSpec !== null) {
            var thing = LodashUtilities.First(ProductEntity.FilterByHierarchy(relationSpec, '/Launch_Entity'));
            if (thing) {
                newProdRelation.Product = new ProductEntity(thing, false, errorContext);
            }
        }
        if (Utilities.IsNotDefined(newProdRelation.Product)) {
            newProdRelation = undefined;
        }
        return newProdRelation;
    };
    /**
     * Find a product. Looks at the root and all children
     * @param {string} productEntityId the EntityID (Guid) of the product to look for. If undefined/null then return this.
     * @returns {ProductEntity} undefined if not found otherwise the Product
     */
    ProductEntity.prototype.FindProduct = function (productEntityId) {
        if (productEntityId === undefined || productEntityId === null) {
            return this;
        }
        var searchEntityId = productEntityId.toLowerCase();
        if (searchEntityId === this.Guid) {
            return this;
        }
        var findChild = function (parent) {
            var productFound = undefined;
            parent.AllProductRelations.some(function (prodRelation) {
                if (prodRelation.Product.Guid === searchEntityId) {
                    productFound = prodRelation.Product;
                    return true;
                }
                else {
                    productFound = findChild(prodRelation.Product);
                    return (productFound !== undefined);
                }
            });
            return productFound;
        };
        return findChild(this);
    };
    /**
     * Find the ProductEntity which has the specified Guid Path
     * @param {string} guidPath the Guid path to search for
     * @returns {ProductEntity} the ProductEntity found, undefined if path is not recognised
     */
    ProductEntity.prototype.FindProductWithGuidPath = function (guidPath) {
        if (guidPath === undefined || guidPath === null) {
            return undefined;
        }
        if (guidPath === this.Guid) {
            return this;
        }
        if (this._indexedProductEntities.length === 0) {
            this.CreateIndexedProductEntities();
        }
        var foundEntity = LodashUtilities.FindWithObject(this._indexedProductEntities, { GuidPath: guidPath.toLowerCase() });
        return foundEntity !== undefined && foundEntity !== null ? foundEntity.Product : undefined;
    };
    /**
     * Find the Product spec among its ProductRelations which matches the specified entityId
     * @param {string} childEntityId the entity Id to look for
     * @returns {Product} the found product spec, undefined if not found
     */
    ProductEntity.prototype.FindChildProductWithEntityId = function (childEntityId) {
        var relation = this.FindRelationWithChildOf(this.Guid, childEntityId);
        if (relation === undefined || relation === null) {
            return undefined;
        }
        return relation.Product;
    };
    /**
     * Find the relation of a parent which contains a specified child
     * @param {string} parentEntityId the EntityID (Guid) of the parent, undefined/null refers to this
     * @param {string} childEntityId the EntityID (Guid) of the child to look for
     * @returns {ProductRelation} the ProductRelationFound, otherwise undefined if not found
     */
    ProductEntity.prototype.FindRelationWithChildOf = function (parentEntityId, childEntityId) {
        var parentEntity = this.FindProduct(parentEntityId);
        if (parentEntity === undefined || parentEntity === null) {
            return undefined;
        }
        var relationFound = undefined;
        parentEntity.AllProductRelations.some(function (prodRelation) {
            if (prodRelation.Product.Guid.toLowerCase() === childEntityId.toLowerCase()) {
                relationFound = prodRelation;
                return true;
            }
            else {
                return false;
            }
        });
        return relationFound;
    };
    /**
     * Find the MappingRule with a specific Guid
     * @param {string} guidToLookFor The Guid to match
     * @returns {MappingRule} MappingRule found, or undefined if not found
     */
    ProductEntity.prototype.FindMappingRule = function (guidToLookFor) {
        var mappingRuleFound = undefined;
        this.MappingRules.some(function (mapping) {
            if (mapping.Guid === guidToLookFor) {
                mappingRuleFound = mapping;
                return true;
            }
            else {
                return false;
            }
        });
        return mappingRuleFound;
    };
    /**
     * Find a CharacteristicUse of the item given it's ID (i.e. guid)
     * @param {string} guidToLookFor the ID (i.e. guid) to look for
     * @returns {CharacteristicUseEntity} undefined if not found, otherwise the CharacteristicUse
     */
    ProductEntity.prototype.FindCharacteristicUse = function (guidToLookFor) {
        var charUseFound = undefined;
        this.CharacteristicUses.some(function (charUse) {
            if (charUse.Guid === guidToLookFor) {
                charUseFound = charUse;
                return true;
            }
            return false;
        });
        return charUseFound;
    };
    /**
     * Find a ConfiguredValue of the item given it's ID (i.e. guid)
     * @param {string} guidToLookFor the ID (i.e. guid) to look for
     * @returns {ConfiguredValue} undefined if not found, otherwise the ConfiguredValue
     */
    ProductEntity.prototype.FindConfiguredValue = function (guidToLookFor) {
        var valueFound = undefined;
        this.ConfiguredValues.some(function (value) {
            if (value.Guid === guidToLookFor) {
                valueFound = value;
                return true;
            }
            return false;
        });
        return valueFound;
    };
    /**
     * Populate the flattened indexed product entities
     * @param {IndexedProductEntity} parent the Parent entity
     */
    ProductEntity.prototype.CreateIndexedProductEntities = function () {
        var _this = this;
        var indexChildren = function (parent) {
            if (!parent.Product || parent.Product.AllProductRelations === undefined || parent.Product.AllProductRelations === null) {
                return;
            }
            parent.Product.AllProductRelations.forEach(function (reln) {
                if (reln.Product === undefined || reln.Product === null) {
                    return;
                }
                var idxChild = new IndexedProductEntity(parent.GuidPath, parent.BusinessIdPath, reln.Product);
                _this._indexedProductEntities.push(idxChild);
                indexChildren(idxChild);
            });
        };
        this._indexedProductEntities = [];
        indexChildren(new IndexedProductEntity('', this.BusinessID, this));
    };
    /**
    * Checks if the supplied values is of a specific type
    * @param {any[]} elementValues the values to check the type of
    * @param {Array<string>} elementTypes the types to match against
    * @param {boolean} compareBaseType? indicates if the base type of the value should be compared against the list of types
    * @returns {boolean} a boolean indicating if the supplied list of types contains the type of the supplied element value
    */
    ProductEntity.prototype.ValueIsATypeOf = function (elementValues, elementTypes, compareBaseType) {
        return elementValues.some(function (val) {
            if (Utilities.IsNotDefined(val._meta)) {
                return false;
            }
            var path = val._meta.path;
            return Utilities.PathContains(path, elementTypes, compareBaseType);
        });
    };
    /**
     * Populates the candidate relations on this product entity using the relations defined in the spec
     * @param {string} rawRelations The raw relations as defined in the spec
     */
    ProductEntity.prototype.PopulateEntityLinks = function (rawRelations) {
        var _this = this;
        var relations = Utilities.asArray(rawRelations).map(function (reln) {
            return new SigmaEntityLink(reln, _this._errorContext);
        });
        if (relations.length > 0) {
            this.LinkedEntities = relations;
        }
    };
    /**
     * Populates the entity limits on this Product Entity
     * @param {string} propertyName the name of the property that holds the entity limits on the spec
     * @param {any} propertyValue the value of the property with the name 'PropertyName' on the spec
     */
    ProductEntity.prototype.PopulateEntityLimits = function (propertyName, propertyValue) {
        var _this = this;
        var limits = Utilities.asArray(propertyValue).map(function (val) {
            return new EntityLimit(val, propertyName, _this._errorContext);
        });
        if (limits.length > 0) {
            this.EntityLimits = this.EntityLimits.concat(limits);
        }
    };
    /**
     * Populates the rates and rate attributes on this Product Entity
     * @param   {string} propertyName the name of the property that holds the rates on the spec
     * @param   {any} propertyValue the value of the property with the name 'Propertyname' on the spec
     */
    ProductEntity.prototype.PopulateRates = function (propertyName, propertyValue) {
        var _this = this;
        var rates = Utilities.asArray(propertyValue).map(function (entityRate) {
            var rate = new Rate(entityRate, _this._errorContext);
            var rateAttributeNames = Object.keys(entityRate).filter(function (key) {
                return _this.IsRateAttribute(key);
            });
            rateAttributeNames.forEach(function (rateAttributeName) {
                var rateAttribute = entityRate[rateAttributeName];
                if (Utilities.IsDefined(rateAttribute, true)) {
                    _this.PopulateRateAttributes(rate, rateAttributeName, rateAttribute);
                }
            });
            return rate;
        });
        if (rates.length > 0) {
            this.Rates = this.Rates.concat(rates);
        }
    };
    /**
     * Checks names of properties passed from a rate to identify if they are a rate attribute property
     * @param   {string} propertyName the name of the rate property
     * @returns {boolean} true if the property is a rate attribute, otherwise false
     */
    ProductEntity.prototype.IsRateAttribute = function (propertyName) {
        if (Utilities.IsNotDefined(propertyName)) {
            return false;
        }
        if (propertyName === "_meta" ||
            propertyName === "Start_Date" ||
            propertyName === "End_Date" ||
            propertyName === "Rate" ||
            propertyName === "Aggregate" ||
            propertyName === "Cost" ||
            propertyName === "CostRateType" ||
            propertyName === "PerUnit" ||
            propertyName === "Description" ||
            propertyName === "OrdOfExec" ||
            propertyName === "IsExclusive" ||
            propertyName === "ChgAdjst") {
            return false;
        }
        return true;
    };
    /**
     * Populates the udcs on this Product Entity
     * @param {string} propertyName the name of the property that holds the udcs on the spec
     * @param {any} propertyValue the value of the property with the name 'PropertyName' on the spec
     */
    ProductEntity.prototype.PopulateUserDefinedCharacteristicUses = function (propertyName, propertyValue) {
        var _this = this;
        var udcs = Utilities.asArray(propertyValue).map(function (val) {
            return new ConfiguredValueEntity(val, propertyName, _this.Guid, _this._errorContext);
        });
        if (udcs.length > 0) {
            this.ConfiguredValues = this.ConfiguredValues.concat(udcs);
        }
    };
    /**
    * Populates the char uses on this Product Entity
    * @param {string} propertyName the name of the property that holds the char uses on the spec
    * @param {any} propertyValue the value of the property with the name 'PropertyName' on the spec
    */
    ProductEntity.prototype.PopulateCharacteristicUses = function (propertyName, propertyValue) {
        var _this = this;
        var characteristicUses = Utilities.asArray(propertyValue).map(function (val) {
            return new CharacteristicUseEntity(val, propertyName, _this.Guid, _this._errorContext);
        });
        if (characteristicUses.length > 0) {
            this.CharacteristicUses = this.CharacteristicUses.concat(characteristicUses);
        }
    };
    /**
    * Populates the compatibility rules on this Product Entity
    * @param {any} rawCompatibilityRules the raw compatibility rules from the product spec
    */
    ProductEntity.prototype.PopulateCompatibilityRules = function (rawCompatibilityRules) {
        var _this = this;
        var compatibilityRules = Utilities.asArray(rawCompatibilityRules).map(function (val) {
            return new CompatibilityRule(val, _this._errorContext);
        });
        if (compatibilityRules.length > 0) {
            this.CompatibilityRules = this.CompatibilityRules.concat(compatibilityRules);
        }
    };
    /**
     * Populates the mapping rules on this product entity using the mapping rules defined on the supplied product spec
     * @param {any} productSpec the spec that contains the mapping rules
     */
    ProductEntity.prototype.PopulateMappingRules = function (rawMappingRules) {
        var _this = this;
        var mappingRules = Utilities.asArray(rawMappingRules).map(function (val) {
            return new MappingRule(val, _this._errorContext);
        });
        if (mappingRules.length > 0) {
            this.MappingRules = this.MappingRules.concat(mappingRules);
        }
    };
    /**
     * Populates the Product_To_Product relations on this product entity using the relations on the supplied product spec
     * @param {any} productSpec the product spec to use to populate the relations on this product entity
     */
    ProductEntity.prototype.PopulateProductToProductRelations = function (productSpec) {
        var _this = this;
        if (productSpec === undefined || productSpec === null) {
            return;
        }
        this.AllProductRelations = [];
        var relationTypes = ProductEntity.FilterByHierarchy(productSpec, '/Relation_Entity');
        relationTypes.forEach(function (rel) {
            var newRelation = ProductEntity.CreateProductRelation(rel, _this._errorContext);
            if (Utilities.IsDefined(newRelation)) {
                _this.AllProductRelations.push(newRelation);
            }
        });
        this.Product_To_Product = this.AllProductRelations.filter(function (r) {
            return r.Type.indexOf('Product_Relation') >= 0;
        });
    };
    /**
     * Populates rate attribute data for a rate
     * @param {Rate} rate the rate to which rate attributes need to be attached
     * @param {string} propertyName the name of the property that holds the rate attribute details on the spec
     * @param {any} propertyValue the value of the property with the name 'Propertyname' on the spec
     */
    ProductEntity.prototype.PopulateRateAttributes = function (rate, propertyName, propertyValue) {
        if (Utilities.IsNotDefined(rate.RateAttributes)) {
            rate.RateAttributes = {};
        }
        var values = Utilities.asArray(propertyValue);
        if (!rate.RateAttributes[propertyName]) {
            rate.RateAttributes[propertyName] = [];
        }
        values.forEach(function (value) {
            var rateAttributeValueID = Utilities.GetDeepValue(value, "_meta.ID");
            if (Utilities.IsDefined(rateAttributeValueID)) {
                rate.RateAttributes[propertyName].push(rateAttributeValueID);
            }
            else {
                rate.RateAttributes[propertyName].push(value);
            }
        });
    };
    return ProductEntity;
}(LaunchEntity));
module.exports = ProductEntity;

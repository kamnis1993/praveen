"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadData = require("../../cs-lib-constants/BadDataTypes");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
var MappingTarget = /** @class */ (function (_super) {
    __extends(MappingTarget, _super);
    /**
     * Create a new Mapping Target.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [mappingSpec] Optional. An object literal to hydrate the Mapping Target from
     */
    function MappingTarget(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        /**
         * The array of strings for the instance GUID's
         */
        _this._instanceGuids = [];
        if (!mappingSpec) {
            return _this;
        }
        _this.Guid = Utilities.ValueOrDefault(mappingSpec.Guid, undefined, true);
        if (mappingSpec._entityValue) { // some kind of loop back happened
            _this.ExtractTargetPaths(mappingSpec._entityValue);
        }
        else {
            _this.ExtractTargetPaths(_this.FirstStringValueIn([mappingSpec.EntityValue, mappingSpec.SourceElement, mappingSpec.Target, mappingSpec]));
        }
        return _this;
    }
    MappingTarget.prototype.FirstStringValueIn = function (vals) {
        for (var i = 0; i < vals.length; i++) {
            if (typeof vals[i] === "string") {
                return vals[i];
            }
        }
        this.RaiseBadDataError(ErrorCode.BadData.InvalidMappingTarget, undefined, BadData.MappingRule, { Target: vals });
    };
    Object.defineProperty(MappingTarget.prototype, "InstanceGuids", {
        /**
         * Gets the array of instance Guids for this target
         *
         */
        get: function () { return this._instanceGuids; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MappingTarget.prototype, "SchemaElementGuids", {
        /**
         * Gets the schema element path as an array
         */
        get: function () { return this._schemaElementPathAsArray; },
        enumerable: true,
        configurable: true
    });
    /**
         * Gets the array of instance Guids for this target
         *
         */
    MappingTarget.prototype.GetInstanceGuids = function () {
        return this._instanceGuids;
    };
    Object.defineProperty(MappingTarget.prototype, "EntityPathEndPoint", {
        /**
         * Property (read-only): The Guid at the end of the EntityPath
         * @returns {string} the Guid of the last component of the EntityPath
         */
        get: function () {
            if (Utilities.IsNotDefined(this._entityPathAsArray, true)) {
                return '';
            }
            return this._entityPathAsArray[this._entityPathAsArray.length - 1];
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Whether or not the supplied comma separated path meets this Targets path
     * @param {string} path comma separated path (guids) to check against the target
     * @returns {boolean} True if the path is valid
     */
    MappingTarget.prototype.EntityPathIsResolvedBy = function (path) {
        return Utilities.StringEndsWith(path, this.EntityPath);
    };
    Object.defineProperty(MappingTarget.prototype, "ElementPathEndPoint", {
        /**
         * Property (read-only): The Guid at the end of the ElementPath
         * @returns {string} the Guid of the last component of the ElementPath
         */
        get: function () {
            if (Utilities.IsNotDefined(this._elementPathAsArray, true)) {
                return '';
            }
            return this._elementPathAsArray[this._elementPathAsArray.length - 1];
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Whether the EntityElement contains the given value (guid)
     * @param {string} value the value (guid) to look for
     * @returns {boolean} true if value is in the EntityElement
     */
    MappingTarget.prototype.ValuePathContains = function (value) {
        if (Utilities.IsNotDefined(this.InstancePath, true)) {
            return false;
        }
        return (this.InstancePath.indexOf(value) !== -1);
    };
    /**
     * Extract Entity and Element paths from the EntityValue from the SPEC
     * @param {any} entityValue the Action.Target.EntityValue as supplied from the spec
     */
    MappingTarget.prototype.ExtractTargetPaths = function (entityValue) {
        this._entityValue = Utilities.ValueOrDefault(entityValue, undefined, true);
        if (Utilities.IsNotDefined(this._entityValue)) {
            return;
        }
        // This assumes the element paths contains SchemaElementGuids. If the Spec DAL is updated update this accordingly
        var pathParts = this._entityValue.split('|').map(function (a) {
            return a.split(',').filter(function (b) { return b.length > 1; });
        });
        if (Utilities.IsNotDefined(pathParts) || pathParts.length !== 2) {
            this.RaiseBadDataError(ErrorCode.BadData.InvalidMappingTarget, this.Guid, BadData.MappingRule, { Target: entityValue });
            return;
        }
        this._entityPathAsArray = pathParts[0];
        this._elementPathAsArray = pathParts[1];
        this.EntityPath = pathParts[0].join(',');
        this.InstancePath = pathParts[1].filter(function (part, index) { return index % 2 !== 0; }).join(',');
        this._schemaElementPathAsArray = pathParts[1].filter(function (part, index) { return index % 2 === 0; });
        this.SchemaElementPath = this._schemaElementPathAsArray.join(',');
        if (this.InstancePath) {
            this._instanceGuids = this.InstancePath.split(',');
        }
    };
    return MappingTarget;
}(SpecEntityBase));
module.exports = MappingTarget;

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadDataTypes = require("../../cs-lib-constants/BadDataTypes");
var ChargeAdjustment = require("./ChargeAdjustment");
var CostRateType = require("./CostRateType");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var RateTypes = require("../../cs-lib-constants/RateTypes");
var SpecEntityBase = require("./SpecEntityBase");
var TargetedCharge = require("./TargetedCharge");
var TargetedCost = require("./TargetedCost");
var UnitPricingRate = require("./UnitPricingRate");
var Utilities = require("../../cs-lib-utilities/Utilities");
var Rate = /** @class */ (function (_super) {
    __extends(Rate, _super);
    function Rate(rateSpec, errorContext) {
        var _this = _super.call(this, rateSpec, errorContext) || this;
        _this.StartDate = undefined;
        _this.EndDate = undefined;
        _this.Aggregate = undefined;
        _this.CostRateType = undefined;
        _this.RateType = undefined;
        _this.DiscountDescription = undefined;
        _this.TargetedCosts = undefined;
        _this.TargetedCharges = undefined;
        _this.ChargeAdjustments = undefined;
        _this.OrderOfExecution = undefined;
        _this.IsExclusive = undefined;
        if (Utilities.IsNotDefined(rateSpec)) {
            return _this;
        }
        // Unit based pricing introduces tables of rates based on unit quantity. Need to convert
        // rate to an array before parsing.
        var rateValues = Utilities.asArray(rateSpec.Rate);
        _this.ParseRateValue(rateValues);
        if (_this.HasBreakingErrors) {
            return _this;
        }
        _this.StartDate = Utilities.ParseDateFromString(rateSpec.Start_Date, true);
        _this.EndDate = Utilities.ParseDateFromString(rateSpec.End_Date, true);
        _this.RateAttributes = Utilities.ValueOrDefault(rateSpec.RateAttributes, {});
        _this.PerUnit = Utilities.ParseAsBoolean(rateSpec.PerUnit, undefined);
        // The following properties are exclusive to cost-based charges
        _this.Aggregate = Utilities.ParseAsBoolean(rateSpec.Aggregate, false);
        _this.CostRateType = Utilities.IsDefined(rateSpec.CostRateType) ? new CostRateType(rateSpec.CostRateType) : undefined;
        _this.TargetedCosts = _this.ParseTargetedCosts(rateSpec.Cost);
        _this.DiscountDescription = Utilities.ValueOrDefault(rateSpec.Description, undefined);
        // charge based discount properties
        _this.TargetedCharges = _this.ParseTargetedCharges(rateSpec.ChgAdjst);
        _this.ChargeAdjustments = _this.ParseChargeAdjustments(rateSpec.ChgAdjst);
        _this.OrderOfExecution = rateSpec.OrdOfExec;
        _this.IsExclusive = rateSpec.IsExclusive;
        return _this;
    }
    /**
     * Parses a rate value from specification, whether the rate is a string or a complex object
     * @param {string} input The rate to parse
     * @returns {number}
     */
    Rate.prototype.ParseRateValue = function (input) {
        var _this = this;
        if (Utilities.IsNotDefined(input, true)) {
            this.Rate = 0;
            return;
        }
        var isComplexRate = Utilities.IsDefined(input[0]._meta, true);
        if (!isComplexRate) {
            this.RateType = RateTypes.Simple;
            var parsedOutput = parseFloat(input);
            if (!isNaN(parsedOutput)) {
                this.Rate = parsedOutput;
            }
            else {
                this.RaiseBadDataError(ErrorCode.BadData.InvalidRate, undefined, BadDataTypes.InvalidProperty);
                return undefined;
            }
        }
        else {
            // is this a tiered or threshold rate?
            var isTieredRate = (input[0]._meta.path.toLowerCase() === "stierband");
            this.UnitPricingRates = [];
            this.RateType = isTieredRate ? RateTypes.Tiered : RateTypes.Threshold;
            input.forEach(function (specRate) {
                _this.UnitPricingRates.push(new UnitPricingRate(specRate, _this.RateType, _this._errorContext));
            });
        }
    };
    /**
     * Parses a targeted cost from the specification
     * @param {any} input The targeted cost to parse
     * @returns {TargetedCost[]}
     */
    Rate.prototype.ParseTargetedCosts = function (input) {
        if (Utilities.IsNotDefined(input)) {
            return undefined;
        }
        var targetedCosts = [];
        var inputCosts = Utilities.asArray(input);
        inputCosts.forEach(function (inputCost) {
            targetedCosts.push(new TargetedCost(inputCost));
        });
        return targetedCosts;
    };
    /**
     * Parses a targeted charge from the specification
     * @param {any} input The targeted charge to parse
     * @returns {TargetedCharge[]}
     */
    Rate.prototype.ParseTargetedCharges = function (input) {
        if (Utilities.IsNotDefined(input)) {
            return undefined;
        }
        var targetedCharges = [];
        var inputCharges = Utilities.asArray(input);
        inputCharges.forEach(function (inputcharge) {
            targetedCharges.push(new TargetedCharge(inputcharge));
        });
        return targetedCharges;
    };
    /**
     * Parses a charge adjustment from the specification
     * @param {any} input The targeted charge to parse
     * @returns {ChargeAdjustment[]}
     */
    Rate.prototype.ParseChargeAdjustments = function (input) {
        if (Utilities.IsNotDefined(input)) {
            return undefined;
        }
        var chargeAdjustments = [];
        var inputAdjustments = Utilities.asArray(input);
        inputAdjustments.forEach(function (inputAdjustment) {
            chargeAdjustments.push(new ChargeAdjustment(inputAdjustment));
        });
        return chargeAdjustments;
    };
    return Rate;
}(SpecEntityBase));
module.exports = Rate;

"use strict";
/// <reference types="node" />
/**
 * A class which is used to help
 */
var IndexedProductEntity = /** @class */ (function () {
    function IndexedProductEntity(parentGuidPath, parentBusinessIdPath, product) {
        // S-08718 thrown error needs handling //
        if (!product) {
            throw new Error("Product not supplied when indexing paths"); // ValidErrorThrow //
        }
        if (!product.Guid) {
            throw new Error("Guid missing from product"); // ValidErrorThrow //
        }
        if (!product.BusinessID) {
            throw new Error("BusinessID missing from product"); // ValidErrorThrow //
        }
        this.GuidPath = this.MakePath(parentGuidPath, product.Guid);
        this.BusinessIdPath = this.MakePath(parentBusinessIdPath, product.BusinessID);
        this.Product = product;
    }
    IndexedProductEntity.prototype.MakePath = function (parent, child) {
        return parent.length > 0 ? parent.toLowerCase() + ',' + child.toLowerCase() : child.toLowerCase();
    };
    return IndexedProductEntity;
}());
module.exports = IndexedProductEntity;

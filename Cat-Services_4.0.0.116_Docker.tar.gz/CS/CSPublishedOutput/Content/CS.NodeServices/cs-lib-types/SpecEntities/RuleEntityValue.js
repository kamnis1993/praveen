"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadDataTypes = require("../../cs-lib-constants/BadDataTypes");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/*
 * Class describes a rule that points at an entity value
 */
var RuleEntityValue = /** @class */ (function (_super) {
    __extends(RuleEntityValue, _super);
    /**
     * Creates a new instance of a rule entity
     * @param {RuleEntityValue} ruleEntityValue the object to use to populate this one
     */
    function RuleEntityValue(entityValue, errorContext) {
        var _this = _super.call(this, entityValue, errorContext) || this;
        _this.ExtractTargetPaths(entityValue);
        _this.Scope = Utilities.ValueOrDefault(entityValue.Scope, undefined);
        return _this;
    }
    /**
     * Extract Entity and Element paths from the EntityValue from the SPEC
     * @param {any} entityValue the Action.Target.EntityValue as supplied from the spec
     */
    RuleEntityValue.prototype.ExtractTargetPaths = function (entityValue) {
        this.EntityValue = entityValue;
        if (entityValue === undefined || entityValue === null) {
            this.EntityPath = undefined;
            this.InstancePath = undefined;
            this.SchemaElementPath = undefined;
            return;
        }
        var pathParts = entityValue.split('|').map(function (a) {
            return a.split(',').filter(function (b) { return b.length > 1; });
        });
        if (Utilities.IsNotDefined(pathParts) || pathParts.length !== 2) {
            this.RaiseBadDataError(ErrorCode.BadData.InvalidMappingTarget, undefined, BadDataTypes.MappingRule, { Target: entityValue });
        }
        this.EntityPath = pathParts[0].join(',').toLowerCase();
        this.InstancePath = pathParts[1].filter(function (part, index) { return index % 2 !== 0; }).join(',').toLowerCase();
        this.SchemaElementPath = pathParts[1].filter(function (part, index) { return index % 2 === 0; }).join(',').toLowerCase();
        // Find the Value and UseIDs
        var instancePathParts = this.InstancePath.split(',');
        if (instancePathParts.length > 1) {
            this.ValueId = instancePathParts.pop();
            this.UseId = instancePathParts.pop();
        }
        else {
            this.UseId = instancePathParts.pop();
            this.ValueId = undefined;
        }
    };
    return RuleEntityValue;
}(SpecEntityBase));
module.exports = RuleEntityValue;

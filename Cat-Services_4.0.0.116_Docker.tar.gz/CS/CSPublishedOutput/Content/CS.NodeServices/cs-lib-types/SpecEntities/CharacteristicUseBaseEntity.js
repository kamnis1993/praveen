"use strict";
/// <reference path="../CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../../cs-lib-utilities/Utilities");
var SpecEntityBase = require("./SpecEntityBase");
/**
 * The base class for a characteristic use entities
 */
var CharacteristicUseBaseEntity = /** @class */ (function (_super) {
    __extends(CharacteristicUseBaseEntity, _super);
    /**
     * Create a new CharacteristicUseEntity.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [spec] Optional. An object literal to hydrate the CharacteristicUseEntity from
     * @param {string} [parentProductGuid] Optional The Guid of the parent product.
     */
    function CharacteristicUseBaseEntity(spec, useAreaName, parentProductGuid, errorContext) {
        var _this = _super.call(this, spec, errorContext) || this;
        if (!spec) {
            return _this;
        }
        _this._parentProductGuid = Utilities.ValueOrDefault(parentProductGuid, undefined, true);
        _this._specJson = Utilities.ValueOrDefault(spec, undefined);
        _this.UseID = spec._meta.ID;
        _this.UseAreaName = Utilities.ValueOrDefault(useAreaName, undefined);
        var characteristicUseInfo = _this.GetCharacteristicInfo(spec);
        _this.CharacteristicID = characteristicUseInfo.CharacteristicId;
        _this.CharacteristicName = characteristicUseInfo.CharacteristicName;
        _this.Min_Occurs = Utilities.ValueOrDefault(spec.Min_Occurs, undefined);
        _this.Max_Occurs = Utilities.ValueOrDefault(spec.Max_Occurs, undefined);
        if (Utilities.IsDefined(spec.CommPhases)) {
            _this.CommPhases = [];
            Utilities.asArray(spec.CommPhases).forEach(function (phase) {
                _this.CommPhases.push(phase.CSCode);
            });
        }
        if (Utilities.IsDefined(spec.TechPhases)) {
            _this.TechPhases = [];
            Utilities.asArray(spec.TechPhases).forEach(function (phase) {
                _this.TechPhases.push(phase.CSCode);
            });
        }
        return _this;
    }
    Object.defineProperty(CharacteristicUseBaseEntity.prototype, "Specification", {
        /**
         * Returns the original specification that this entity was built from
         * Read only
         */
        get: function () { return this._specJson; },
        enumerable: true,
        configurable: true
    });
    /**
     * Gets the characteristic use info.
     * @param {any} charUseSpec the spec of the characteristic use info
     * @returns {CsTypes.CharacteristicUseInfo}
     */
    CharacteristicUseBaseEntity.prototype.GetCharacteristicInfo = function (charUseSpec) {
        var characteristicUseInfo = {
            UseArea: null, CharacteristicId: null, CharacteristicName: null, CharacteristicUseId: charUseSpec._meta.ID
        };
        var charValues = Utilities.asArray(charUseSpec.Characteristic_CharValue);
        var baseType = this.GetPathPart(-1);
        if (charValues.length > 0) {
            charValues.some(function (charValue) {
                if (charValue.Characteristic && charValue.Characteristic._meta) {
                    characteristicUseInfo.CharacteristicName = charValue.Characteristic.Name;
                    characteristicUseInfo.CharacteristicId = charValue.Characteristic._meta.ID.toLowerCase();
                    return true;
                }
                else {
                    return false;
                }
            });
        }
        else {
            if (baseType === 'TConfigurable_Fact') {
                characteristicUseInfo.CharacteristicId = this.Meta.ID.toLowerCase();
                characteristicUseInfo.CharacteristicName = this.Name;
            }
            else if (baseType === 'TDefinableCharacteristicValue') {
                characteristicUseInfo.CharacteristicName = charUseSpec.Characteristic.Name;
                characteristicUseInfo.CharacteristicId = charUseSpec.Characteristic._meta.ID.toLowerCase();
            }
        }
        return characteristicUseInfo;
    };
    return CharacteristicUseBaseEntity;
}(SpecEntityBase));
module.exports = CharacteristicUseBaseEntity;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RuleScope = require("../../cs-lib-constants/RuleScope");
var SpecEntityBase = require("./SpecEntityBase");
var SpecificationGuids = require("../../cs-lib-constants/SpecificationGuids");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Entity representing scope
 */
var SpecEntityScope = /** @class */ (function (_super) {
    __extends(SpecEntityScope, _super);
    /**
     * Create a new SpecEntityScope.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [specEntityScope] Optional. An object literal to hydrate the SpecEntityScope from
     */
    function SpecEntityScope(specEntityScope, errorContext) {
        var _this = _super.call(this, specEntityScope, errorContext) || this;
        if (!specEntityScope) {
            return _this;
        }
        return _this;
    }
    Object.defineProperty(SpecEntityScope.prototype, "Type", {
        /**
         * (ReadOnly) Get the scope
         * @returns {ScopeType}
         */
        get: function () {
            if (!Utilities.IsDefined(this.Guid)) {
                return RuleScope.Child;
            }
            if (this.Guid.toLowerCase() === SpecificationGuids.Mapping.Scope.Child) {
                return RuleScope.Child;
            }
            if (this.Guid.toLowerCase() === SpecificationGuids.Mapping.Scope.ProductCandidate) {
                return RuleScope.ProductCandidate;
            }
            if (this.Guid.toLowerCase() === SpecificationGuids.Mapping.Scope.Portfolio) {
                return RuleScope.Portfolio;
            }
            return RuleScope.Child;
        },
        enumerable: true,
        configurable: true
    });
    return SpecEntityScope;
}(SpecEntityBase));
module.exports = SpecEntityScope;

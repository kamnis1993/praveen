"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadDataTypes = require("../../cs-lib-constants/BadDataTypes");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var RateTypes = require("../../cs-lib-constants/RateTypes");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Defines a generic container for unit based pricing rates
 */
var UnitPricingRate = /** @class */ (function (_super) {
    __extends(UnitPricingRate, _super);
    function UnitPricingRate(unitPricingRate, unitPricingType, errorContext) {
        var _this = _super.call(this, unitPricingRate, errorContext) || this;
        if (Utilities.IsNotDefined(unitPricingType)) {
            _this.RaiseBadDataError(ErrorCode.BadData.InvalidRate, undefined, BadDataTypes.InvalidProperty);
        }
        if (_this.HasBreakingErrors) {
            return _this;
        }
        // Tiered and threshold rate types use different specification names for their threshold value
        switch (unitPricingType) {
            case RateTypes.Tiered:
                _this.ThresholdValue = Utilities.IsDefined(unitPricingRate.UnitsLessOrEqualTo, true) ? _this.ParseValue(unitPricingRate.UnitsLessOrEqualTo) : undefined;
                break;
            case RateTypes.Threshold:
                _this.ThresholdValue = _this.ParseValue(unitPricingRate.UnitsGreaterOrEqualTo);
                break;
            default:
                break;
        }
        _this.UnitRate = _this.ParseValue(unitPricingRate.UnitRate);
        return _this;
    }
    /**
     * Takes in a string value and returns a number or raises an error
     * @param   {string} input the value to parse
     */
    UnitPricingRate.prototype.ParseValue = function (input) {
        if (Utilities.IsNotDefined(input, true)) {
            return 0;
        }
        var parsedOutput = parseFloat(input);
        if (!isNaN(parsedOutput)) {
            return parsedOutput;
        }
        else {
            this.RaiseBadDataError(ErrorCode.BadData.InvalidRate, undefined, BadDataTypes.InvalidProperty);
            return undefined;
        }
    };
    return UnitPricingRate;
}(SpecEntityBase));
module.exports = UnitPricingRate;

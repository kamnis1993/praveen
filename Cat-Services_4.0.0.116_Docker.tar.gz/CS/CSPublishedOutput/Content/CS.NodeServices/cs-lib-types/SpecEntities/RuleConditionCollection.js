"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var EntityLinkValue = require("./EntityLinkValue");
var SpecEntityScope = require("./SpecEntityScope");
var Utilities = require("../../cs-lib-utilities/Utilities");
var RuleEntityValue = require("./RuleEntityValue");
var RuleEntity = require("./RuleEntity");
var RuleEntityValueMatch = require("./RuleEntityValueMatch");
var SpecEntityBase = require("./SpecEntityBase");
var RuleConditionCollection = /** @class */ (function (_super) {
    __extends(RuleConditionCollection, _super);
    /**
     * Create a new RuleCondition.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param ruleConditions {any} Optional. An object literal to hydrate the RuleCondition from
     */
    function RuleConditionCollection(ruleConditions, errorContext) {
        var _this = _super.call(this, ruleConditions, errorContext) || this;
        _this.Exists = [];
        _this.NotExists = [];
        _this.ExistsValue = [];
        _this.NotExistsValue = [];
        _this.ExistsOrdActItem = [];
        _this.NotExistsOrdActItem = [];
        _this.ExistsEntityLink = [];
        _this.NotExistsEntityLink = [];
        _this.NoValueExists = [];
        _this.UDCMatchesValue = [];
        if (!ruleConditions) {
            return _this;
        }
        var existsConditions = Utilities.asArray(ruleConditions.Exists);
        var notExistsConditions = Utilities.asArray(ruleConditions.NotExists);
        var existsValueConditions = Utilities.asArray(ruleConditions.ExistsValue);
        var notExistsValueConditions = Utilities.asArray(ruleConditions.NotExistsValue);
        var existsEntityWithOrderAction = Utilities.asArray(ruleConditions.ExistsOrdActItem);
        var notExistsEntityWithOrderAction = Utilities.asArray(ruleConditions.NotExistsOrdActItem);
        var existsEntityLink = Utilities.asArray(ruleConditions.ExistsEntityLink);
        var notExistsEntityLink = Utilities.asArray(ruleConditions.NotExistsEntityLink);
        var noValueExistsConditions = Utilities.asArray(ruleConditions.NoValueExists);
        var udcMatchesValue = Utilities.asArray(ruleConditions.UDCMatchesValue);
        _this.Scope = new SpecEntityScope(ruleConditions.Scope);
        for (var c = 0; c < existsConditions.length; c++) {
            if (Utilities.IsDefined(existsConditions[c])) {
                _this.Exists.push(new RuleEntity(existsConditions[c], errorContext));
            }
        }
        for (var c = 0; c < notExistsConditions.length; c++) {
            if (Utilities.IsDefined(notExistsConditions[c])) {
                _this.NotExists.push(new RuleEntity(notExistsConditions[c], errorContext));
            }
        }
        for (var c = 0; c < existsValueConditions.length; c++) {
            if (Utilities.IsDefined(existsValueConditions[c])) {
                _this.ExistsValue.push(new RuleEntityValue(existsValueConditions[c].EntityValue, errorContext));
            }
        }
        for (var c = 0; c < notExistsValueConditions.length; c++) {
            if (Utilities.IsDefined(notExistsValueConditions[c])) {
                _this.NotExistsValue.push(new RuleEntityValue(notExistsValueConditions[c].EntityValue, errorContext));
            }
        }
        for (var c = 0; c < noValueExistsConditions.length; c++) {
            if (Utilities.IsDefined(noValueExistsConditions[c])) {
                _this.NoValueExists.push(new RuleEntityValue(noValueExistsConditions[c].EntityValueElement, errorContext));
            }
        }
        for (var c = 0; c < existsEntityWithOrderAction.length; c++) {
            if (Utilities.IsDefined(existsEntityWithOrderAction[c])) {
                _this.ExistsOrdActItem.push(new RuleEntity(existsEntityWithOrderAction[c], errorContext));
            }
        }
        for (var c = 0; c < notExistsEntityWithOrderAction.length; c++) {
            if (Utilities.IsDefined(notExistsEntityWithOrderAction[c])) {
                _this.NotExistsOrdActItem.push(new RuleEntity(notExistsEntityWithOrderAction[c], errorContext));
            }
        }
        for (var c = 0; c < existsEntityLink.length; c++) {
            if (Utilities.IsDefined(existsEntityLink[c])) {
                _this.ExistsEntityLink.push(new EntityLinkValue(existsEntityLink[c], errorContext));
            }
        }
        for (var c = 0; c < notExistsEntityLink.length; c++) {
            if (Utilities.IsDefined(notExistsEntityLink[c])) {
                _this.NotExistsEntityLink.push(new EntityLinkValue(notExistsEntityLink[c], errorContext));
            }
        }
        for (var c = 0; c < udcMatchesValue.length; c++) {
            if (Utilities.IsDefined(udcMatchesValue[c])) {
                _this.UDCMatchesValue.push(new RuleEntityValueMatch(udcMatchesValue[c], errorContext));
            }
        }
        return _this;
    }
    return RuleConditionCollection;
}(SpecEntityBase));
module.exports = RuleConditionCollection;

"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../../cs-lib-utilities/Utilities");
var SpecEntityBase = require("./SpecEntityBase");
var MappingAction = require("./MappingAction");
var RuleConditionCollection = require("./RuleConditionCollection");
var MappingTriggerEvent = require("./MappingTriggerEvent");
var MappingRule = /** @class */ (function (_super) {
    __extends(MappingRule, _super);
    /**
     * Create a new MappingRule.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [mappingSpec] Optional. An object literal to hydrate the MappingRule from
     * @param {string} [parentProductGuid] Optional The Guid of the parent product.
     */
    function MappingRule(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        _this.StartDate = undefined;
        _this.EndDate = undefined;
        if (!mappingSpec) {
            return _this;
        }
        _this.Sequence = Utilities.ParseAsNumber(mappingSpec.Sequence, 1);
        _this.StartDate = Utilities.ParseDateFromString(mappingSpec.StartDate);
        _this.EndDate = Utilities.ParseDateFromString(mappingSpec.EndDate);
        // Unpack TriggerEvents
        _this.TriggerEvents = Utilities.ConvertToArrayOf(mappingSpec.TriggerEvents, function (item) {
            return new MappingTriggerEvent(item);
        });
        // Unpack Conditions
        _this.Conditions = new RuleConditionCollection(mappingSpec.Conditions, errorContext);
        // Unpack Actions
        _this.Actions = Utilities.ConvertToArrayOf(mappingSpec.Actions, function (item) {
            return new MappingAction(item, errorContext);
        });
        // Unpack Actions
        _this.FalseActions = Utilities.ConvertToArrayOf(mappingSpec.FalseActions, function (item) {
            return new MappingAction(item, errorContext);
        });
        return _this;
    }
    /**
     * Checks to see if any of the rule's TriggerEvents are of the specified type
     * @param {MappingTriggerType} triggerType the trigger type to search for
     * @returns {boolean} True if there is a TriggerEvent of the same type
     */
    MappingRule.prototype.ContainsTriggerType = function (triggerType) {
        if (this.TriggerEvents === undefined || this.TriggerEvents.length === 0) {
            return false;
        }
        return this.TriggerEvents.some(function (trigger) {
            return (trigger.Type === triggerType);
        });
    };
    /**
     * Whether the mapping rule meets the date criteria
     * @param {Date} orderDate the date on the order
     * @returns {boolean} True if it meets the date criteria
     */
    MappingRule.prototype.DateCriteriaIsMet = function (orderDate) {
        if (orderDate === undefined || orderDate === null) {
            return false;
        }
        // Try and work with what has been passed, in case it is not a Date
        var testDate = undefined;
        if ((orderDate instanceof Date)) {
            testDate = orderDate;
        }
        else if (typeof orderDate === 'number') {
            var numDate = orderDate;
            testDate = new Date(numDate);
        }
        else if (typeof orderDate === 'string') {
            testDate = Utilities.ParseDateFromString(orderDate.toString());
        }
        var meetsStartCriteria = (this.StartDate === undefined || this.StartDate === null) || testDate.getTime() >= this.StartDate.getTime();
        var meetsEndCriteria = (this.EndDate === undefined || this.EndDate === null) || testDate.getTime() <= this.EndDate.getTime();
        return (meetsStartCriteria && meetsEndCriteria);
    };
    return MappingRule;
}(SpecEntityBase));
module.exports = MappingRule;

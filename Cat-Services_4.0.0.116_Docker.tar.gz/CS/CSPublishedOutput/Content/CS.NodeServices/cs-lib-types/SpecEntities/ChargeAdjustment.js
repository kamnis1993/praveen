"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Represents a ChargeAdjustment in the product specification
 */
var ChargeAdjustment = /** @class */ (function (_super) {
    __extends(ChargeAdjustment, _super);
    /**
     * Creates a new ChargeAdjustment SpecEntity, hydrating from output of ProductSpecificationDal if specified
     * @param {any} [chargeAdjustment] Optional. If supplied, hydrate object from spec. Usually output of ProductSpecificationDal
     * @constructor
     */
    function ChargeAdjustment(chargeAdjustment) {
        var _this = _super.call(this, chargeAdjustment) || this;
        _this.AdjustmentGuid = Utilities.ValueOrDefault(chargeAdjustment._meta.ID, undefined);
        _this.AdjustmentType = Utilities.ValueOrDefault(chargeAdjustment.AdjType.Name, undefined);
        _this.ExactType = Utilities.ValueOrDefault(chargeAdjustment._meta.name, undefined);
        _this.Amount = Utilities.ValueOrDefault(chargeAdjustment.Amount, undefined);
        _this.MostExpensiveFirst = Utilities.ValueOrDefault(chargeAdjustment.ExpFirst, undefined);
        _this.MaximumAllowedToTarget = Utilities.ValueOrDefault(chargeAdjustment.MaxToTgt, undefined);
        _this.MinimumTargetsRequired = Utilities.ValueOrDefault(chargeAdjustment.MinTgtReqd, undefined);
        _this.Description = Utilities.ValueOrDefault(chargeAdjustment.Description, undefined);
        return _this;
    }
    return ChargeAdjustment;
}(SpecEntityBase));
module.exports = ChargeAdjustment;

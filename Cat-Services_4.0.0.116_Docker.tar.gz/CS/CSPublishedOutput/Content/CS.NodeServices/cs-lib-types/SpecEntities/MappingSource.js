"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MappingTarget = require("./MappingTarget");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
var RuleConditionCollection = require("./RuleConditionCollection");
/**
 * Class that defines a mapping source
 */
var MappingSource = /** @class */ (function (_super) {
    __extends(MappingSource, _super);
    /**
     * Initalizes a new instance of the MappingSource class.
     * @param {any} mappingSpec? The mapping spec to read
     */
    function MappingSource(mappingSpec, errorContext) {
        var _this = _super.call(this, mappingSpec, errorContext) || this;
        if (!mappingSpec) {
            return _this;
        }
        _this.SourceElement = new MappingTarget(mappingSpec, errorContext);
        if (_this.HasBreakingErrors) {
            return _this;
        }
        if (!mappingSpec.State) {
            _this.SourceStates = null; // if states are empty, all are false. If not supplied, all are true.
        }
        else {
            _this.SourceStates = Utilities.asArray(mappingSpec.State).map(function (value) { return new SpecEntityBase(value, errorContext); });
        }
        _this.SourceConditions = new RuleConditionCollection(mappingSpec, errorContext);
        return _this;
    }
    return MappingSource;
}(SpecEntityBase));
module.exports = MappingSource;

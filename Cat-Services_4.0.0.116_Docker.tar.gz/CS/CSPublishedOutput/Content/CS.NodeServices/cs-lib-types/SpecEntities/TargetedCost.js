"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var EntityLinkValue = require("./EntityLinkValue");
var SpecEntityBase = require("./SpecEntityBase");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
* Entity representing a cost based charge targeted cost.
* Used to hold costing attributes during compilation in order to calculate prices
* at the end of compilation when all required pricing info has been collected.
*/
var TargetedCost = /** @class */ (function (_super) {
    __extends(TargetedCost, _super);
    function TargetedCost(targetedCost) {
        var _this = _super.call(this, targetedCost) || this;
        _this.CostEntity = Utilities.ValueOrDefault(targetedCost.CostEntity, undefined);
        _this.EntityLink = Utilities.IsDefined(targetedCost.EntityLink) ? new EntityLinkValue(targetedCost) : undefined;
        return _this;
    }
    return TargetedCost;
}(SpecEntityBase));
module.exports = TargetedCost;

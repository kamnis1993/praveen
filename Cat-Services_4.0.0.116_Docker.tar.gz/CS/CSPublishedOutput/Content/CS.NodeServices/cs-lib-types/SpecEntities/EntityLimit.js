"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../../cs-lib-utilities/Utilities");
var SpecEntityBase = require("./SpecEntityBase");
/**
 * Represents a CharacteristicUse in the Spec
 */
var EntityLimit = /** @class */ (function (_super) {
    __extends(EntityLimit, _super);
    /**
     * Create a new CharacteristicUseEntity.
     * If a object literal (usually from ProductSpecificationDal) is specified, hydrate from it
     * @param {any} [charUseSpec] Optional. An object literal to hydrate the CharacteristicUseEntity from
     */
    function EntityLimit(entitySpec, limitName, errorContext) {
        var _this = _super.call(this, entitySpec, errorContext) || this;
        _this.LimitName = Utilities.ValueOrDefault(limitName, undefined);
        _this._specJson = Utilities.ValueOrDefault(entitySpec, undefined);
        return _this;
    }
    Object.defineProperty(EntityLimit.prototype, "Specification", {
        /**
         * Returns the original specification that this entity was built from
         * Read only
         */
        get: function () { return this._specJson; },
        enumerable: true,
        configurable: true
    });
    return EntityLimit;
}(SpecEntityBase));
module.exports = EntityLimit;

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../cs-lib-utilities/Utilities");
var CsValidationError = require("./CsValidationError");
/**
 * The internal representation of a bad data Error.
 */
var CsBadDataError = /** @class */ (function (_super) {
    __extends(CsBadDataError, _super);
    function CsBadDataError(errorId, errorCode, entityId, badDataType, messageParameters, sourceEntityId, targetEntityId, errorCategory) {
        var _this = _super.call(this, errorId, errorCode, undefined, entityId, messageParameters) || this;
        _this.BadDataType = badDataType;
        _this.SourceEntityId = Utilities.ValueOrDefault(sourceEntityId, undefined);
        _this.TargetEntityId = Utilities.ValueOrDefault(targetEntityId, undefined);
        return _this;
    }
    return CsBadDataError;
}(CsValidationError));
module.exports = CsBadDataError;

"use strict";
/**
 * Class holds trace event data for diagnostic services
 */
var TraceEvent = /** @class */ (function () {
    function TraceEvent() {
    }
    return TraceEvent;
}());
module.exports = TraceEvent;

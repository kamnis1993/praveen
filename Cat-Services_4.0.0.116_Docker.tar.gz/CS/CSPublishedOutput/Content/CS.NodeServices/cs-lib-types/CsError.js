"use strict";
var CsError = /** @class */ (function () {
    /**
     * Creates a new instance of the CsError class
     * @param {string} message The error message
     * @param {number} statusCode The HTTP status code for the error
     * @param {any} substitutions The substitutions for the error for the translations
     */
    function CsError(statusCode, message, substitutions) {
        this.statusCode = statusCode;
        this.message = message;
        this.substitutions = substitutions;
    }
    return CsError;
}());
module.exports = CsError;

"use strict";
var CsSchemaContext = /** @class */ (function () {
    function CsSchemaContext() {
    }
    return CsSchemaContext;
}());
module.exports = CsSchemaContext;

"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts"/>
var MergedActions = require("../../cs-lib-constants/MergedActions");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityQueries = require("./OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../../cs-lib-utilities/Utilities");
var Logger = require("../../cs-logging/Logger");
/**
 * Class allowing use of entity links to perform actions on an orderfolio
 */
var OrderfolioLinkedEntityActions = /** @class */ (function () {
    function OrderfolioLinkedEntityActions() {
    }
    /**
     * Applies entity link actions to the orderfolio
     * @param   {CsTypes.DecomposeContext} decomposeContext the decompose context containing items to apply entity links against
     */
    OrderfolioLinkedEntityActions.ApplyEntityLinks = function (decomposeContext) {
        if (!decomposeContext.LinkedEntities) {
            return;
        }
        this.ApplyLinkDependencies(decomposeContext);
        this.RemoveLinksTargetingDeletedEntities(decomposeContext);
    };
    /**
     * Identifies deleted source entities and cascades the delete action to linked targets
     * @param   {CsTypes.DecomposeContext} decomposeContext the decompose context containing items to apply delete cascades to
     */
    OrderfolioLinkedEntityActions.ApplyLinkDependencies = function (decomposeContext) {
        var _this = this;
        var dependentTargetLinks = OrderfolioLinkedEntityQueries.GetTargetIsDependentLinks(decomposeContext.LinkedEntities);
        dependentTargetLinks.forEach(function (dependentLink) {
            var sourceEntity = decomposeContext.Orderfolio[dependentLink.Source.Key][dependentLink.Source.Index];
            if (sourceEntity.Action !== OrderActions.Delete) {
                return;
            }
            var targetEntity = decomposeContext.Orderfolio[dependentLink.Target.Key][dependentLink.Target.Index];
            targetEntity.Action = OrderActions.Delete;
            // TODO: Is this cascade deleting all it's children?
            OrderfolioLinkedEntityActions.UpdateActionHierarchyForOrderfolioItem(decomposeContext, dependentLink.Target);
            // Remove any links which target this target entity
            _this.DeleteLinksToDeletedTarget(decomposeContext, targetEntity);
            // TODO: This should also mark all links that the targetEntity is the source for as deleted.
            // TODO: If there are any dependent links which the targetEntity is the source for, the targets of them should be deleted
            //       i.e. cascade delete along link pathways
        });
    };
    /**
     * Identifies Deleted OrderfolioItems in a Decompose Context and ensures any entity links to those items are also deleted
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context whose OrderfolioItems need checking
     */
    OrderfolioLinkedEntityActions.RemoveLinksTargetingDeletedEntities = function (decomposeContext) {
        var _this = this;
        if (Utilities.IsNotDefined(decomposeContext.LinkedEntities)) {
            return;
        }
        // Get all orderfolioItems which are marked as deleted
        var deletedItems = OrderfolioQueries.GetOrderfolioItemsByAction(decomposeContext, OrderActions.Delete);
        // Remove any links targeting them
        deletedItems.forEach(function (deletedOrderfolioItem) {
            _this.DeleteLinksToDeletedTarget(decomposeContext, deletedOrderfolioItem);
        });
    };
    /**
     * Delete all entity links which target an OrderfolioItem which is marked as Deleted
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context containing the orderfolioItem
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item which is marked as deleted
     */
    OrderfolioLinkedEntityActions.DeleteLinksToDeletedTarget = function (decomposeContext, orderfolioItem) {
        // Check we have a QueryableLinkedEntities in the decompose context or that the orderfolio item is marked as deleted
        if (Utilities.IsNotDefined(decomposeContext.LinkedEntities) || orderfolioItem.Action !== OrderActions.Delete) {
            return;
        }
        // Get list of Links which target the orderfolio item
        var linksToTarget = OrderfolioLinkedEntityQueries.GetByTarget(decomposeContext.LinkedEntities, orderfolioItem.CompoundKey, true);
        // Mark them as deleted and ensure hierarchy is updated appropriately
        linksToTarget.forEach(function (link) {
            link.LinkAction = MergedActions.DeleteExisting;
            OrderfolioQueries.EnsureActionHierarchyByLookup(decomposeContext, link.Source);
            Logger.debug(50, "Mapping Rule", "Deleting Entity links of deleted entity: " + link.PortfolioItemID, { SubType: "DeleteLinksToDeletedTarget", EntityLink: link });
        });
    };
    OrderfolioLinkedEntityActions.UpdateActionHierarchyForOrderfolioItem = function (decomposeContext, orderfolioItemLookup) {
        var orderfolioItemKey = OrderfolioQueries.GetOrderfolioItemKey(orderfolioItemLookup);
        var parentLookup = decomposeContext.ChildToParentTable[orderfolioItemKey];
        if (Utilities.IsNotDefined(parentLookup)) {
            return;
        }
        OrderfolioQueries.EnsureActionHierarchyByLookup(decomposeContext, parentLookup);
    };
    return OrderfolioLinkedEntityActions;
}());
module.exports = OrderfolioLinkedEntityActions;

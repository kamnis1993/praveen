"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts"/>
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../../cs-lib-constants/MergedActions");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a customer portfolio
 */
var OrderfolioLinkedEntityQueries = /** @class */ (function () {
    function OrderfolioLinkedEntityQueries() {
    }
    /**
     * Gets the SourceToTargetEntityLinks that match the orderfolio item lookup
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} source The source orderfolio item lookup
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetBySource = function (flatEntityLinks, source) {
        var _this = this;
        return flatEntityLinks.filter(function (link) {
            return OrderfolioQueries.CompareOrderfolioItemLookup(source, link.Source) && _this.IncludeLink(link, true);
        });
    };
    /**
     * Gets the SourceToTargetEntityLinks by source and link type ID
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} source The source orderfolio item lookup
     * @param {string} linkTypeId The link type ID
     * @param {boolean} excludeDeleted Whether to exclude deleted entities from the results
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetBySourceAndLinkType = function (flatEntityLinks, source, linkTypeId, excludeDeleted) {
        var _this = this;
        if (excludeDeleted === void 0) { excludeDeleted = false; }
        return flatEntityLinks.filter(function (link) {
            return link.LinkTypeID === linkTypeId
                && OrderfolioQueries.CompareOrderfolioItemLookup(source, link.Source)
                && _this.IncludeLink(link, excludeDeleted);
        });
    };
    /**
     * Gets the SourceToTargetEntityLinks as defined by an EntityLink
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.EntityLink} searchForLink The EntityLink which drives the search
     * @param {boolean} excludeDeleted Whether to exclude deleted entities from the results
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetByEntityLink = function (flatEntityLinks, searchForLink, excludeDeleted) {
        var _this = this;
        if (excludeDeleted === void 0) { excludeDeleted = false; }
        return flatEntityLinks.filter(function (link) {
            return link.LinkTypeID === searchForLink.Id
                && link.ExpectedSource === searchForLink.Source
                && link.ExpectedTarget === searchForLink.Target
                && _this.IncludeLink(link, excludeDeleted);
        });
    };
    /**
     * Gets all of the links that violate the IsMulti rule for an orderfolio item
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} source The source orderfolio item lookup
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetInvalidMultiLinks = function (flatEntityLinks, source) {
        var _this = this;
        var multiLinks = flatEntityLinks.filter(function (link) {
            return !link.IsMulti
                && OrderfolioQueries.CompareOrderfolioItemLookup(source, link.Source)
                && _this.IncludeLink(link, true);
        });
        var invalidMultiLinks = [];
        var linkGroups = LodashUtilities.GroupByCallback(multiLinks, function (link) {
            return link.Source.Key + "|" + link.Source.Index + "|" + link.LinkTypeID;
        });
        Object.keys(linkGroups).forEach(function (key) {
            if (linkGroups[key].length > 1) {
                invalidMultiLinks = invalidMultiLinks.concat(linkGroups[key][0]);
            }
        });
        return invalidMultiLinks;
    };
    /**
     * Gets the links that have an invalid target according to the specification, for an orderfolio item
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} source The source orderfolio item lookup
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetInvalidTargetLinks = function (flatEntityLinks, source) {
        var _this = this;
        return flatEntityLinks.filter(function (link) {
            return OrderfolioQueries.CompareOrderfolioItemLookup(source, link.Source)
                && (_this.IncludeLink(link, true)
                    && link.ExpectedTarget !== link.Target.Key);
        });
    };
    /**
     * Get the links that are marked as unique for an orderfolio item lookup
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} source The source orderfolio item lookup
     */
    OrderfolioLinkedEntityQueries.GetUniqueLinks = function (flatEntityLinks, source) {
        var _this = this;
        return flatEntityLinks.filter(function (link) {
            return OrderfolioQueries.CompareOrderfolioItemLookup(source, link.Source)
                && link.IsUnique
                && _this.IncludeLink(link, true);
        });
    };
    /**
     * Get the links that are marked as having dependent targets
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     */
    OrderfolioLinkedEntityQueries.GetTargetIsDependentLinks = function (flatEntityLinks) {
        return flatEntityLinks.filter(function (link) {
            return link.TargetIsDependent;
        });
    };
    /**
     * Gets the SourceToTargetEntityLinks where the Target matches the orderfolio item lookup
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} targetLookup The target orderfolio item lookup
     * @param {boolean} [excludeDeleted] Optional, Whether to exclude deleted entities from the results, defaults to false
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetByTarget = function (flatEntityLinks, targetLookup, excludeDeleted) {
        var _this = this;
        if (excludeDeleted === void 0) { excludeDeleted = false; }
        return flatEntityLinks.filter(function (link) {
            return OrderfolioQueries.CompareOrderfolioItemLookup(targetLookup, link.Target) && _this.IncludeLink(link, excludeDeleted);
        });
    };
    /**
     * Gets the SourceToTargetEntityLinks by target and link type ID
     * @param {Array<CsTypes.SourceToTargetEntityLink>} The entity links to check
     * @param {CsTypes.OrderfolioItemLookup} targetLookup The target orderfolio item lookup
     * @param {string} linkTypeId The link type ID
     * @param {boolean} excludeDeleted Whether to exclude deleted entities from the results
     * @returns {CsTypes.SourceToTargetEntityLink[]}
     */
    OrderfolioLinkedEntityQueries.GetByTargetAndLinkType = function (flatEntityLinks, targetLookup, linkTypeId, excludeDeleted) {
        var _this = this;
        if (excludeDeleted === void 0) { excludeDeleted = false; }
        return flatEntityLinks.filter(function (link) {
            return link.LinkTypeID === linkTypeId
                && OrderfolioQueries.CompareOrderfolioItemLookup(targetLookup, link.Target)
                && _this.IncludeLink(link, excludeDeleted);
        });
    };
    /**
     * Given an instance of an EntityLink - ie between one OrderfolioItem and another,
     * collect the OrderfolioItemLookup (as a string for Dictionary access) of the Source, Target and all their children.
     * (If the Target of a mapping action is in the collection, then any source that is also in the collection can see it)
     * @param {CsTypes.SourceToTargetEntityLink} link the EntityLink instance which defines Source and Target OrderfolioItem instances
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context in which the Link resides
     * @return {CsTypes.EntityLinkSourceTargetDescendents} collections of descendent OrderfolioItemLookup in Dictionary key string format
     */
    OrderfolioLinkedEntityQueries.GetLinkedOrderfolioItemCollection = function (link, decomposeContext) {
        // Helper function: determines if OrderItem is marked as Deleted
        var isMarkedAsDeleted = function (itemLookup) {
            var items = decomposeContext.Orderfolio[itemLookup.Key.toString()];
            if (Utilities.IsNotDefined(items, true) || items.length <= itemLookup.Index) {
                return true;
            }
            return items[itemLookup.Index].Action === OrderActions.Delete;
        };
        // Recursive routine to get all descendents of an item including oneself
        var getAllDescendents = function (parent) {
            // If item is marked as Deleted, ignore it and all descendents
            if (isMarkedAsDeleted(parent)) {
                return [];
            }
            var parentKey = OrderfolioQueries.GetOrderfolioItemKey(parent);
            var descendents = [parentKey];
            // Add child descendents to collection and return
            var children = decomposeContext.ParentToChildTable[parentKey];
            if (Utilities.IsDefined(children, true)) {
                children.forEach(function (child) { descendents.push.apply(descendents, getAllDescendents(child)); });
            }
            return descendents;
        };
        // Get all Source and Target OrderfolioItem Descendents for the Link
        var descendentCollections = {
            SourceDescendents: LodashUtilities.Uniq(getAllDescendents(link.Source)),
            TargetDescendents: LodashUtilities.Uniq(getAllDescendents(link.Target))
        };
        return descendentCollections;
    };
    /**
     * Indicates whether we include the link
     * @param {CsTypes.SourceToTargetEntityLink} link The link to check
     * @param {boolean} excludeDeleted Indicates if we are excluding deleted links
     * @returns {boolean}
     */
    OrderfolioLinkedEntityQueries.IncludeLink = function (link, excludeDeleted) {
        var isLinkDeleted = function (selectedLink) {
            var isDeleted = (selectedLink.LinkAction === MergedActions.DeleteExisting || selectedLink.LinkAction === MergedActions.DeleteMissing);
            return Utilities.IsDefined(selectedLink.LinkAction) && isDeleted;
        };
        var linkIsDeleted = isLinkDeleted(link);
        var includeLink = !(excludeDeleted && linkIsDeleted);
        return includeLink && !link.IsInvalid;
    };
    return OrderfolioLinkedEntityQueries;
}());
module.exports = OrderfolioLinkedEntityQueries;

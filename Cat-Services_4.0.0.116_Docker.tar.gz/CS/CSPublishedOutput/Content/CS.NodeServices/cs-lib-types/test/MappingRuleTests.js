"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var MappingRule = require("../SpecEntities/MappingRule");
describe("When an object is passed to a mapping rule constructor", function () {
    var mappingRuleContents = fs.readFileSync('cs-lib-types/test/data/inputs/MappingRule.json', { encoding: 'utf8' });
    var mappingRuleData = JSON.parse(mappingRuleContents);
    var mappingRule = new MappingRule(mappingRuleData);
    it("the mapping rule parses the sequence as a number", function (done) {
        chai.expect(mappingRule).to.not.be.undefined;
        chai.expect(mappingRule.Sequence).to.not.be.undefined;
        chai.expect(typeof mappingRule.Sequence).to.equal("number");
        chai.expect(mappingRule.Sequence).to.equal(2);
        done();
    });
    it("the mapping actions parse the sequence as a number", function (done) {
        chai.expect(mappingRule.Actions).to.not.be.undefined;
        chai.expect(mappingRule.Actions.length).to.equal(1);
        var mappingAction = mappingRule.Actions[0];
        chai.expect(mappingAction).to.not.be.undefined;
        chai.expect(mappingAction.Sequence).to.not.be.undefined;
        chai.expect(typeof mappingAction.Sequence).to.equal("number");
        chai.expect(mappingAction.Sequence).to.equal(1);
        done();
    });
});

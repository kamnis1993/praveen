"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var chai = require("chai");
var ProductEntity = require("../SpecEntities/ProductEntity");
describe('ProductEntity Tests', function () {
    describe('CreateFromSpec: Loading from literal object', function () {
        it('should hydrate the literal object into a ProductEntity object without Mapping Rules', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/ProductEntitySpec.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                chai.expect(productSpec.Meta.ID).to.equal('f92f2f90-9ce5-4bb9-bf47-2aa956cacf04');
                chai.expect(productSpec.Product_To_Product.length).to.equal(2);
                // A child
                var childProduct = productSpec.FindChildProductWithEntityId('d1e9bf0b-fd63-48fb-9d69-07064b01b442');
                chai.expect(childProduct).to.be.not.null;
                chai.expect(childProduct.Product_To_Product.length).to.equal(2);
                // Mapping Rules should be empty array
                chai.expect(productSpec.MappingRules instanceof Array).to.be.true;
                chai.expect(productSpec.MappingRules.length).to.be.equal(0);
                done();
            });
        });
        it('should hydrate a large literal object with Mapping Rules', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/LargeProductEntitySpecWithMappings.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                chai.expect(productSpec.Meta.ID).to.equal('b239f455-9c8d-4829-aa5d-d37457e29b1c');
                chai.expect(productSpec.Product_To_Product.length).to.equal(4);
                // A child
                var childProduct = productSpec.FindChildProductWithEntityId('69179d71-46f5-4ba4-8bd9-ec33e9096d3a');
                chai.expect(childProduct).to.be.not.null;
                chai.expect(childProduct.Product_To_Product.length).to.equal(2);
                // There should be 16 Mapping Rules
                chai.expect(productSpec.MappingRules instanceof Array).to.be.true;
                chai.expect(productSpec.MappingRules.length).to.be.equal(10);
                done();
            });
        });
    });
    describe('FindChildProductWithEntityId:', function () {
        it('should return the correct ProductEntity when given a valid Id', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/ProductEntitySpec.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                var childProduct = productSpec.FindChildProductWithEntityId('d1e9bf0b-fd63-48fb-9d69-07064b01b442');
                chai.expect(childProduct).to.be.not.null;
                chai.expect(childProduct.Meta.ID).to.equal('d1e9bf0b-fd63-48fb-9d69-07064b01b442');
                chai.expect(childProduct.Product_To_Product.length).to.equal(2);
                done();
            });
        });
        it('should return undefined if an unknown Id is passed', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/ProductEntitySpec.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                var childProduct = productSpec.FindChildProductWithEntityId('UnknownId');
                chai.expect(childProduct).to.be.undefined;
                done();
            });
        });
    });
    describe('IsTechnical:', function () {
        it('should return false if "isTechnical" is not in the Products meta data', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/ProductEntitySpec.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                chai.expect(productSpec.IsTechnical).to.be.false;
                done();
            });
        });
        it('should return the value of "isTechnical" in the _meta section if it is present in the source literal', function (done) {
            fs.readFile('cs-lib-types/test/data/inputs/ProductEntitySpec.json', { encoding: 'utf-8' }, function (error, fileContents) {
                var inputProductSpec = JSON.parse(fileContents);
                var productSpec = new ProductEntity(inputProductSpec);
                var childA = productSpec.FindChildProductWithEntityId('d1e9bf0b-fd63-48fb-9d69-07064b01b442');
                chai.expect(childA).to.be.not.null;
                chai.expect(childA.IsTechnical).to.be.true;
                var childB = childA.FindChildProductWithEntityId('6467adb4-66e5-4215-9a02-788c6506576f');
                chai.expect(childB).to.be.not.null;
                chai.expect(childB.IsTechnical).to.be.true;
                done();
            });
        });
    });
});

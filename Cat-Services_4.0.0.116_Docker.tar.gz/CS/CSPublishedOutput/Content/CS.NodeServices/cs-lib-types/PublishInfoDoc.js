"use strict";
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Document object which holds information associated with a published data import
 */
var PublishInfoDoc = /** @class */ (function () {
    /**
     * Create a new PublishInfo document, revive from JSON or literal if supplied.
     * @param {any} [fromDoc] either an object or json string to initialise from
     * @constructor
     */
    function PublishInfoDoc(fromDoc) {
        /**
         * MongoDb document _id. Only one in any database, _id is always 'Current'
         */
        // ReSharper disable once InconsistentNaming
        this._id = 'Current';
        /**
         * Correlation Id of th ePublished data. (Guid)
         */
        this.CorrelationId = '00000000-0000-0000-0000-000000000000';
        /**
         * The context the the data was published as.
         */
        this.ContextType = 'No Data';
        /**
         * Name of the context the data was published as
         */
        this.ContextName = 'No data is available.';
        /**
         * Date & time that the publish was valid
         */
        this.DateTime = new Date(0);
        /**
         *  Any changeset that the published data is restricted to. (Guid)
         *  An empty Guid represents no changeset.
         */
        this.ChangesetItemGuid = '00000000-0000-0000-0000-000000000000';
        /**
         * The date the publish set was imported
         */
        this.DateImported = new Date();
        /**
         * Guid that uniquely identifies an import
         */
        this.UniqueImportId = 'NotSet';
        var self = this;
        // If an initialiser is specified, revive from it
        if (fromDoc) {
            if (fromDoc instanceof Object) {
                if (fromDoc.ChangesetItemGuid) {
                    self.ChangesetItemGuid = fromDoc.ChangesetItemGuid;
                }
                if (fromDoc.ContextName) {
                    self.ContextName = fromDoc.ContextName;
                }
                if (fromDoc.DateTime) {
                    self.DateTime = fromDoc.DateTime;
                }
                if (fromDoc.ContextType) {
                    self.ContextType = fromDoc.ContextType;
                }
                if (fromDoc.CorrelationId) {
                    self.CorrelationId = fromDoc.CorrelationId;
                }
                if (fromDoc.DateImported) {
                    self.DateImported = fromDoc.DateImported;
                }
                if (Utilities.IsDefined(fromDoc.UniqueImportId)) {
                    self.UniqueImportId = fromDoc.UniqueImportId;
                }
            }
            else if (typeof fromDoc === 'string') {
                try {
                    JSON.parse(fromDoc, function (k, v) {
                        if (k !== "") {
                            return v;
                        }
                        self._id = v._id;
                        self.ChangesetItemGuid = v.ChangesetItemGuid;
                        self.ContextName = v.ContextName;
                        self.DateTime = v.DateTime;
                        self.ContextType = v.ContextType;
                        self.CorrelationId = v.CorrelationId;
                        self.DateImported = v.DateImported;
                        return self;
                    });
                }
                catch (err) {
                    // Ignore SyntaxError from invalid json
                }
            }
        }
        self._id = 'Current';
    }
    return PublishInfoDoc;
}());
module.exports = PublishInfoDoc;

"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ExistsDataTarget = require("./BusinessEntities/ExistsDataTarget");
var CompatibilityErrorEntityLinkDetails = require("./BusinessEntities/CompatibilityErrorEntityLinkDetails");
var CompatibilityErrorEntToEntConditionDetails = require("./BusinessEntities/CompatibilityErrorEntToEntConditionDetails");
var CompatibilityErrorEntToStaticConditionDetails = require("./BusinessEntities/CompatibilityErrorEntToStaticConditionDetails");
var CompatibilityErrorEntToUDCConditionDetails = require("./BusinessEntities/CompatibilityErrorEntToUDCConditionDetails");
var CompatibilityErrorExistsDataConditionDetails = require("./BusinessEntities/CompatibilityErrorExistsDataConditionDetails");
var CompatibilityErrorItemActionDetails = require("./BusinessEntities/CompatibilityErrorItemActionDetails");
var CompatibilityErrorValueDetails = require("./BusinessEntities/CompatibilityErrorValueDetails");
var CsValidationError = require("./CsValidationError");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * The internal representation of a compatibility Error.
 * This will be converted to a CompatibilityError before inserting into the OrderCandidateResponse
 */
var CsCompatibilityError = /** @class */ (function (_super) {
    __extends(CsCompatibilityError, _super);
    function CsCompatibilityError(errorId, compatibilityRule, errorCode, orderfolioItem, decomposeContext, phaseCode, parentEntityID, parentEntityUniqueCode) {
        var _this = _super.call(this, errorId, errorCode, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId) || this;
        var conditions = compatibilityRule.Conditions;
        _this.RuleID = compatibilityRule.ID;
        _this.RuleScope = compatibilityRule.RuleScope;
        _this.Message = compatibilityRule.ErrorMessage;
        _this.IsWarning = compatibilityRule.IsWarning;
        _this.PhaseCodes = phaseCode;
        if (Utilities.IsDefined(parentEntityID) && Utilities.IsDefined(parentEntityUniqueCode)) {
            _this.MessageParameters = { ParentID: parentEntityID, ParentUniqueCode: parentEntityUniqueCode };
        }
        _this.Exists = _this.BuildPathsForEntityConditions(conditions.Exists, decomposeContext);
        _this.NotExists = _this.BuildPathsForEntityConditions(compatibilityRule.Conditions.NotExists, decomposeContext);
        var existsValueCreator = function (entityPath, elementPath) { return new CompatibilityErrorValueDetails(entityPath, elementPath); };
        _this.ExistsValue = _this.BuildPathsForValueConditions(conditions.ExistsValue, existsValueCreator);
        _this.NotExistsValue = _this.BuildPathsForValueConditions(conditions.NotExistsValue, existsValueCreator);
        _this.NoValueExists = _this.BuildPathsForValueConditions(conditions.NoValueExists, existsValueCreator);
        _this.UdcMatchesValue = _this.BuildPathsForValueConditions(conditions.UDCMatchesValue, existsValueCreator);
        var existsEntityLinkCreator = function (entityPath, linkTypeID) { return new CompatibilityErrorEntityLinkDetails(entityPath, linkTypeID); };
        _this.ExistsEntityLink = _this.BuildPathsForValueConditions(conditions.ExistsEntityLink, existsEntityLinkCreator);
        _this.NotExistsEntityLink = _this.BuildPathsForValueConditions(conditions.NotExistsEntityLink, existsEntityLinkCreator);
        _this.ExistsOrdActItem = _this.BuildPathsForEntityItemActionConditions(conditions.ExistsOrdActItem, decomposeContext);
        _this.NotExistsOrdActItem = _this.BuildPathsForEntityItemActionConditions(conditions.NotExistsOrdActItem, decomposeContext);
        // Dr Who conditions
        _this.ExistsData = _this.BuildPathsForDataCondition(conditions.ExistsData);
        _this.NotExistsData = _this.BuildPathsForDataCondition(conditions.NotExistsData);
        // Count Duckula conditions
        _this.EntToEnt = _this.BuildEntToEntCountConditions(conditions.EntToEnt);
        _this.EntToStatic = _this.BuildEntToStaticCountConditions(conditions.EntToStatic);
        _this.EntToUDC = _this.BuildEntToUDCCountConditions(conditions.EntToUDC);
        return _this;
    }
    /**
     * Builds the GUID path from the business ID path
     * @param {CsTypes.Condition[]} collection The list of entity conditions
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose contexts
     * @returns {string[]}
     */
    CsCompatibilityError.prototype.BuildPathsForEntityConditions = function (collection, decomposeContext) {
        var _this = this;
        var guidPaths = [];
        collection.forEach(function (condition) {
            for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                var targetPathItem = condition.TargetPaths[targetPath];
                var guidPath = _this.ConvertBusinessPathToGuidPath(targetPathItem, decomposeContext);
                guidPaths.push(guidPath);
            }
        });
        return guidPaths;
    };
    /**
     * Builds the compatibility rule errors for the item action conditions
     * @param {CsTypes.Condition[]} collection The paths to use
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {Array<CompatibilityErrorItemActionDetails>}
     */
    CsCompatibilityError.prototype.BuildPathsForEntityItemActionConditions = function (collection, decomposeContext) {
        var _this = this;
        var itemActionCollection = [];
        collection.forEach(function (condition) {
            for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                var targetPathItem = condition.TargetPaths[targetPath];
                var guidPath = _this.ConvertBusinessPathToGuidPath(targetPathItem, decomposeContext);
                itemActionCollection.push(new CompatibilityErrorItemActionDetails(guidPath, targetPathItem.Action));
            }
        });
        return itemActionCollection;
    };
    /**
     * Builds the compatibility rule errors for the value conditions
     * @param {CsTypes.Condition[]} collection The paths to use
     * @param {(a: string, b: string) => T} generator The function that creates the object of the correct type
     * @returns {Array<T>}
     */
    CsCompatibilityError.prototype.BuildPathsForValueConditions = function (collection, generator) {
        var detailCollection = [];
        collection.forEach(function (condition) {
            for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                var targetPathItem = condition.TargetPaths[targetPath];
                var isInstance = false;
                var entityGuidPath = targetPathItem.RawValue.split("|")[0].split(",").filter(function (val) { return Utilities.IsDefined(val, true); });
                var elementGuids = targetPathItem.RawValue.split("|")[1].split(",").filter(function (val) { return Utilities.IsDefined(val, true); });
                var elementGuidPath = [];
                if (Utilities.IsDefined(targetPathItem.ElementPath)) {
                    detailCollection.push(generator(entityGuidPath[0], targetPathItem.ElementPath.substring(0, targetPathItem.ElementPath.length - 1)));
                }
                else {
                    elementGuids.forEach(function (elementGuid) {
                        if (isInstance) {
                            elementGuidPath.push(elementGuid);
                        }
                        else {
                            //var elementPath = path.ElementPath;
                            var schemaElementName = "";
                            //this._globalCache.GetSchemaElementName(elementGuid);
                            if (!schemaElementName || schemaElementName.length < 1) {
                                schemaElementName = "UNKNOWN_ELEMENT";
                            }
                            elementGuidPath.push(schemaElementName);
                        }
                        isInstance = !isInstance;
                    });
                    detailCollection.push(generator(entityGuidPath.join(","), elementGuidPath.join("/")));
                }
            }
        });
        return detailCollection;
    };
    /**
     * Builds the details for both ExistsData and NotExistsData
     * @param {CsTypes.Condition[]} collection
     * @returns {Array<CompatibilityErrorExistsDataConditionDetails>}
     */
    CsCompatibilityError.prototype.BuildPathsForDataCondition = function (collection) {
        var detailCollection = [];
        collection.forEach(function (condition) {
            var current = new CompatibilityErrorExistsDataConditionDetails(condition.MatchAny);
            condition.TargetPaths.forEach(function (targetPath) {
                current.Targets.push(new ExistsDataTarget(targetPath.EntityPath, targetPath.ElementPath, targetPath.Action));
            });
            detailCollection.push(current);
        });
        return detailCollection;
    };
    /**
     * Builds the EntityToEntity condition details
     * @param {CsTypes.Condition[]} countCondition
     * @returns {Array<CompatibilityErrorEntToEntConditionDetails>}
     */
    CsCompatibilityError.prototype.BuildEntToEntCountConditions = function (countCondition) {
        var detailCollection = [];
        countCondition.forEach(function (condition) {
            // get the appropriate left hand side and right hand side entity paths
            // we need to order these correctly for the output
            var lhsTargetPaths = condition.TargetPaths.filter(function (targetPath) {
                return Utilities.IsDefined(targetPath.LeftHandSide);
            });
            var lhsEntityPaths = [];
            lhsTargetPaths.forEach(function (targetPath) {
                lhsEntityPaths.push(targetPath.EntityPath);
            });
            var rhsTargetPaths = condition.TargetPaths.filter(function (targetPath) {
                return Utilities.IsNotDefined(targetPath.LeftHandSide);
            });
            var rhsEntityPaths = [];
            rhsTargetPaths.forEach(function (targetPath) {
                rhsEntityPaths.push(targetPath.EntityPath);
            });
            detailCollection.push(new CompatibilityErrorEntToEntConditionDetails(lhsEntityPaths, condition.Comparer, rhsEntityPaths));
        });
        return detailCollection;
    };
    /**
     * Buils the EntityToStaticValue condition details
     * @param {CsTypes.Condition[]} countCondition
     * @returns {Array<CompatibilityErrorEntToStaticConditionDetails>}
     */
    CsCompatibilityError.prototype.BuildEntToStaticCountConditions = function (countCondition) {
        var detailCollection = [];
        countCondition.forEach(function (condition) {
            var entityPaths = [];
            condition.TargetPaths.forEach(function (targetPath) {
                entityPaths.push(targetPath.EntityPath);
            });
            detailCollection.push(new CompatibilityErrorEntToStaticConditionDetails(entityPaths, condition.Comparer, condition.Value));
        });
        return detailCollection;
    };
    /**
     * Builds the EntityToUDCValue count condition details
     * @param {CsTypes.Condition[]} countCondition
     * @returns {Array<CompatibilityErrorEntToUDCConditionDetails>}
     */
    CsCompatibilityError.prototype.BuildEntToUDCCountConditions = function (countCondition) {
        var detailCollection = [];
        countCondition.forEach(function (condition) {
            var lhsTargetPaths = condition.TargetPaths.filter(function (targetPath) {
                return Utilities.IsDefined(targetPath.LeftHandSide);
            });
            var lhsEntityPaths = [];
            lhsTargetPaths.forEach(function (targetPath) {
                lhsEntityPaths.push(targetPath.EntityPath);
            });
            var udcTargetPath = condition.TargetPaths.find(function (targetPath) {
                return Utilities.IsNotDefined(targetPath.LeftHandSide);
            });
            detailCollection.push(new CompatibilityErrorEntToUDCConditionDetails(lhsEntityPaths, condition.Comparer, udcTargetPath.EntityPath, udcTargetPath.ElementPath));
        });
        return detailCollection;
    };
    /**
     * Converts a business ID path to a GUID path
     * @param {CsTypes.Condition} path The path to convert
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    CsCompatibilityError.prototype.ConvertBusinessPathToGuidPath = function (path, decomposeContext) {
        var businessIDs = path.RawValue.split(',');
        var guidPath = businessIDs.map(function (businessID) {
            return decomposeContext.CompiledSpec.BusinessIdToGuidLookup[businessID];
        });
        return guidPath.join(',');
    };
    return CsCompatibilityError;
}(CsValidationError));
module.exports = CsCompatibilityError;

"use strict";
var CombinedCharacteristicUses = /** @class */ (function () {
    function CombinedCharacteristicUses() {
        this.OrderItemCharacteristicUses = [];
        this.PortfolioItemCharacteristicUses = [];
    }
    return CombinedCharacteristicUses;
}());
module.exports = CombinedCharacteristicUses;

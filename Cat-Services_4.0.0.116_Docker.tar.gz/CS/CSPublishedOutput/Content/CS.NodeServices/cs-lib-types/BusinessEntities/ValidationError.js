"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a Validation error
 * @type   {[type]}
 */
var ValidationError = /** @class */ (function () {
    /**
     * Creates a new instance of a Validation Error
     * @param   {string}   entityUniqueCode   The unique ID of the entity from the Order Candidate
     * @param   {string}   errorCode          The error Code
     * @param   {string}   message            The message that describes this error
     * @param   {string}   childID            The ID of the child entity that is in error
     * @param   {string}   entityID           The ID, from the catalog, of the entity in question
     */
    function ValidationError(entityUniqueCode, errorCode, message, contextParameters, entityID, childID, extraInfo, xsiType, phaseCodes) {
        var _this = this;
        this.EntityUniqueCode = Utilities.ValueOrDefault(entityUniqueCode, undefined);
        this.ErrorCode = Utilities.ValueOrDefault(errorCode, undefined);
        this.Message = Utilities.ValueOrDefault(message, undefined);
        this.EntityID = Utilities.ValueOrDefault(entityID, undefined);
        this.ChildID = Utilities.ValueOrDefault(childID, undefined);
        this.ExtraInfo = Utilities.ValueOrDefault(extraInfo, undefined);
        this.XsiType = Utilities.ValueOrDefault(xsiType, undefined);
        this.PhaseCodes = Utilities.ValueOrDefault(phaseCodes, undefined);
        this.ContextParameters = [];
        this.AddValidationContextParameters();
        var parameters = Utilities.asArray(contextParameters);
        parameters.forEach(function (parameter) {
            _this.ContextParameters.push(parameter);
        });
    }
    /**
     * Adds the properties of the validation error to the context parameters
     */
    ValidationError.prototype.AddValidationContextParameters = function () {
        // Need separate ValueOrDefault, because if a property is undefined then we need to set it to empty string for the context parameters
        // However for the properties on the object, it can be undefined, if this changes this can probably be revisited
        this.ContextParameters.push({ Name: "EntityUniqueCode", Value: Utilities.ValueOrDefault(this.EntityUniqueCode, '') });
        this.ContextParameters.push({ Name: "ErrorCode", Value: Utilities.ValueOrDefault(this.ErrorCode, '') });
        this.ContextParameters.push({ Name: "EntityID", Value: Utilities.ValueOrDefault(this.EntityID, '') });
        this.ContextParameters.push({ Name: "ChildID", Value: Utilities.ValueOrDefault(this.ChildID, '') });
        this.ContextParameters.push({ Name: "ExtraInfo", Value: Utilities.ValueOrDefault(this.ExtraInfo, '') });
        this.ContextParameters.push({ Name: "XsiType", Value: Utilities.ValueOrDefault(this.XsiType, '') });
    };
    return ValidationError;
}());
module.exports = ValidationError;

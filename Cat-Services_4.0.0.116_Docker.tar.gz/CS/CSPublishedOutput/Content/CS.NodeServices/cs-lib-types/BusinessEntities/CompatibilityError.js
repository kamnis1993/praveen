"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * Class describes a Validation error
 * @type   {[type]}
 */
var CompatibilityError = /** @class */ (function () {
    /**
     * Creates a new instance of a CompatibilityError Error
     * @param   {string}          ruleID             The ID of the compatibility rule that triggered this compatibility error
     * @param   {string}          ruleScope          The scope of the compatibility rule that triggered this Compatibility error
     * @param   {string}          entityUniqueCode   The unique ID of the entity from the Order Candidate
     * @param   {string}          errorCode          The error Code
     * @param   {string}          message            The message that describes this error
     * @param   {string}          entityID           The ID, from the catalog, of the entity in question
     * @param   {Array<string>}   exists             The Exists conditions that were present on the compatibility rule that triggered this compatibility error
     * @param   {Array<string>}   notExists          The NotExists conditions that were present on the compatibility rule that triggered this compatibility error
     * @param   {Array<string>}   existsValue        The ExistsValue conditions that were present on the compatibility rule that triggered this compatibility error
     * @param   {Array<string>}   notExistsValue     The NotExistsValue conditions that were present on the compatibility rule that triggered this compatibility error
     */
    function CompatibilityError(csCompatibilityError) {
        this.RuleID = csCompatibilityError.RuleID;
        this.RuleScope = csCompatibilityError.RuleScope;
        this.EntityUniqueCode = csCompatibilityError.EntityUniqueCode;
        this.ErrorCode = csCompatibilityError.ErrorCode;
        this.Message = csCompatibilityError.Message;
        this.EntityID = csCompatibilityError.EntityId;
        this.ContextParameters = [];
        this.Exists = csCompatibilityError.Exists;
        this.NotExists = csCompatibilityError.NotExists;
        this.ExistsValue = csCompatibilityError.ExistsValue;
        this.NotExistsValue = csCompatibilityError.NotExistsValue;
        this.NoValueExists = csCompatibilityError.NoValueExists;
        this.ExistsEntityLink = csCompatibilityError.ExistsEntityLink;
        this.NotExistsEntityLink = csCompatibilityError.NotExistsEntityLink;
        this.ExistsOrdActItem = csCompatibilityError.ExistsOrdActItem;
        this.NotExistsOrdActItem = csCompatibilityError.NotExistsOrdActItem;
        this.UdcMatchesValue = csCompatibilityError.UdcMatchesValue;
        this.ExistsData = csCompatibilityError.ExistsData;
        this.NotExistsData = csCompatibilityError.NotExistsData;
        this.EntToEntCount = csCompatibilityError.EntToEnt;
        this.EntToStaticCount = csCompatibilityError.EntToStatic;
        this.EntToUDCCount = csCompatibilityError.EntToUDC;
        this.PhaseCodes = csCompatibilityError.PhaseCodes;
        this.IsWarning = csCompatibilityError.IsWarning;
    }
    return CompatibilityError;
}());
module.exports = CompatibilityError;

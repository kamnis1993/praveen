"use strict";
/**
 * Class that represents a matched pair of reassign to reassigned items in an order candidate request
 */
var ReassignPair = /** @class */ (function () {
    function ReassignPair(entityId, portfolioItemID, reassignItem, reassignedItem) {
        this.EntityID = entityId;
        this.PortfolioItemID = portfolioItemID;
        this.ReassignItem = reassignItem;
        this.ReassignedItem = reassignedItem;
    }
    return ReassignPair;
}());
module.exports = ReassignPair;

"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class for storing request-centric rate information
 */
var RateDetail = /** @class */ (function () {
    /**
     * Creates a new instance of the Rate Detail object
     * @param rateDetail The object to use to instantiate this one
     */
    function RateDetail(rateDetail) {
        this.RateIdOverride = Utilities.ValueOrDefault(rateDetail.RateIdOverride, null);
        this.ValueOverride = Utilities.ValueOrDefault(rateDetail.ValueOverride, null);
        this.RateActivationDate = Utilities.ValueOrDefault(rateDetail.RateActivationDate, null);
    }
    return RateDetail;
}());
module.exports = RateDetail;

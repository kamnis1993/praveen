"use strict";
var AffectedPortfolioItem = require("./AffectedPortfolioItem");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a customer portfolio
 */
var AffectedCustomerPortfolio = /** @class */ (function () {
    /**
     * Creates a new instance of the AffectedCustomerPortfolio object
     * @param portfolio The portfolio object to use to instantiate this one
     */
    function AffectedCustomerPortfolio(affectedCustomerPortfolio) {
        /**
         * Holds a reference to all the affected items in the customers portfolio
         */
        this.AffectedPortfolioItems = [];
        if (!affectedCustomerPortfolio) {
            this.AffectedPortfolioItems = [];
            return;
        }
        if (affectedCustomerPortfolio.AffectedPortfolioItems) {
            var portfolioItemsArray = Utilities.asArray(affectedCustomerPortfolio.AffectedPortfolioItems);
            for (var c = 0; c < portfolioItemsArray.length; c++) {
                var affectedPortfolioItem = portfolioItemsArray[c];
                this.AffectedPortfolioItems.push(new AffectedPortfolioItem(affectedPortfolioItem));
            }
        }
    }
    /**
     * Removes any portfolio items that are marked for deletion
     */
    AffectedCustomerPortfolio.prototype.RemoveInternalData = function () {
        this.AffectedPortfolioItems = this.AffectedPortfolioItems.filter(function (portfolioItem) {
            //remove any items that are marked for delete or do not have an item action against them.
            //if an item does not have an item action against it then it means it has been unaffected by
            //the decompose process and therefore should not be present in the affected portfolio
            if ((portfolioItem.ItemAction === undefined) || (portfolioItem.ItemAction === OrderActions.Delete)) {
                return false;
            }
            // Tidy up the internals of the portfolio Item tree
            portfolioItem.RemoveInternalData();
            return true;
        });
    };
    return AffectedCustomerPortfolio;
}());
module.exports = AffectedCustomerPortfolio;

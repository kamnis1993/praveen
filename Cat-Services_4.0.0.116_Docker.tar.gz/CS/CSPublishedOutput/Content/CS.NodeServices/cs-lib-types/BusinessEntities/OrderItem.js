"use strict";
/// <reference path="../CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ItemBase = require("./ItemBase");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Describes an item that forms part of an order
 */
var OrderItem = /** @class */ (function (_super) {
    __extends(OrderItem, _super);
    /**
     * Creates a new instance of the order item object
     * @param {IOrderItem} orderItem The object to use to instantiate this one
     * @param {OrderItem} parent the OrderItem that this is a child of. undefined if no parent
     * @param {boolean} isForProductCandidate whether this Order Item is being created for a ProductCandidate - default action to Add
     * @param {CsTypes.Dictionary<CsTypes.OrderItemLookup>} orderItemLookup The OrderItem lookup that tracks all the order items in the tree
     */
    function OrderItem(orderItem, parent, isForProductCandidate, orderItemLookup) {
        if (isForProductCandidate === void 0) { isForProductCandidate = false; }
        var _this = _super.call(this, orderItem) || this;
        /**
         * Flag that indicates if this is new for customer
         * This is for internal use only, required for CPQ 1.x
         */
        _this._IsNewForCustomer = undefined;
        /**
         * The child items that form part of
         */
        _this.ChildOrderItems = [];
        if (!orderItem) {
            _this.PortfolioItemID = Utilities.CreateID();
            return _this;
        }
        // Default item action is add if one is not provided, as per the schema
        if (Utilities.IsNotDefined(orderItem.ItemAction, true)) {
            _this.ItemAction = OrderActions.Add;
        }
        if (isForProductCandidate) {
            // For product candidate, ID is nothing but PortfolioItemID
            _this.PortfolioItemID = Utilities.ValueOrDefault(orderItem.ID, undefined);
            if (Utilities.IsDefined(orderItem._IsNewForCustomer)) {
                _this._IsNewForCustomer = Utilities.ValueOrDefault(orderItem._IsNewForCustomer, undefined);
                // If flag is a boolean, compare to `true`, else if a string, check against "true" -- otherwise it's false.
                // this is because it's being supplied as both boolean and string depending on source.
                var isNew = (orderItem._IsNewForCustomer === true || (orderItem._IsNewForCustomer.toLowerCase && orderItem._IsNewForCustomer.toLowerCase() === "true"));
                _this.ItemAction = (isNew) ? OrderActions.Add : OrderActions.Update;
            }
            else {
                // Default to Add if no IsNewForCustomer
                _this.ItemAction = OrderActions.Add;
            }
        }
        else {
            // For all other cases, extract PortfolioItemID
            _this.PortfolioItemID = Utilities.ValueOrDefault(orderItem.PortfolioItemID, undefined);
        }
        _this.ChangeType = Utilities.ValueOrDefault(orderItem.ChangeType, undefined, true);
        _this.DecomposeGenID = Utilities.ValueOrDefault(orderItem.DecomposeGenID, undefined);
        _this.UnitQuantity = Utilities.ValueOrDefault(orderItem.UnitQuantity, undefined);
        _this.AddToOrderItemLookup(_this, parent, orderItemLookup);
        var childOrderItemsArray = Utilities.asArray(orderItem.ChildOrderItems);
        childOrderItemsArray.forEach(function (child) {
            var childOrderItem = new OrderItem(child, _this, isForProductCandidate, orderItemLookup);
            _this.ChildOrderItems.push(childOrderItem);
        });
        return _this;
    }
    /**
     * Add a new child order item.
     * The add will be aborted if the child has the same ID as this OrderItem or
     * if the ID already exists in the ChildOrderItems
     * @param {OrderItem} childItem The OrderItem to add to the ChildOrderitems
     */
    OrderItem.prototype.AddChildOrderItem = function (childItem) {
        if (this.ID === childItem.ID) {
            // S-08718 thrown error needs handling //
            throw new Error('Order cannot include a child with an ID the same as itself'); // ValidErrorThrow //
        }
        if (this.ChildOrderItems === undefined) {
            this.ChildOrderItems = [];
        }
        if (this.IsIdUnique(childItem.ID)) {
            this.ChildOrderItems.push(childItem);
        }
        else {
            // S-08718 thrown error needs handling //
            throw new Error('Order cannot include duplicate IDs'); // ValidErrorThrow //
        }
    };
    /**
     * Whether Id is unique within an OrderItem
     * @param {string} id The ID to test
     * @returns {boolean} True if it is unique in the OrderItem, otherwise false
     */
    OrderItem.prototype.IsIdUnique = function (id) {
        if (id === this.ID) {
            return false;
        }
        return !(this.ChildOrderItems.some(function (child) { return id === child.ID; }));
    };
    /**
     *
     * @param {OrderItem} orderItem The order item to add to the lookup
     * @param {IOrderItem} parent The parent of the order item being added to the lookup
     * @param {CsTypes.Dictionary<IOrderItemLookup>} orderItemLookup The order item lookup
     */
    OrderItem.prototype.AddToOrderItemLookup = function (orderItem, parent, orderItemLookup) {
        if (Utilities.IsNotDefined(orderItemLookup) || Utilities.IsNotDefined(orderItem.ID, true)) {
            return;
        }
        var parentOrderId = (Utilities.IsDefined(parent)) ? (parent.ID) : (undefined);
        orderItemLookup[orderItem.ID] = { ParentOrderItemId: parentOrderId, OrderItem: orderItem };
    };
    return OrderItem;
}(ItemBase));
module.exports = OrderItem;

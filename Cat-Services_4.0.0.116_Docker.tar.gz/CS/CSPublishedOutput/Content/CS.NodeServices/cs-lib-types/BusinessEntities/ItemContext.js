"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Describes a characteristic and its value
 * @type   {Context}
 */
var ItemContext = /** @class */ (function () {
    /**
     * Creates a new instance of the context object
     * @param   {IItemContext}   context   The context object to use to populate this one
     */
    function ItemContext(itemContext) {
        /**
         * The name of the characteristic
         * @type   {string}
         */
        this.Characteristic = null;
        /**
         * The value of the characteristic
         * @type   {string}
         */
        this.Value = null;
        if (!itemContext) {
            return;
        }
        this.Characteristic = Utilities.ValueOrDefault(itemContext.Characteristic, undefined);
        itemContext.Value = Utilities.asArray(itemContext.Value);
        this.Value = itemContext.Value;
    }
    return ItemContext;
}());
module.exports = ItemContext;

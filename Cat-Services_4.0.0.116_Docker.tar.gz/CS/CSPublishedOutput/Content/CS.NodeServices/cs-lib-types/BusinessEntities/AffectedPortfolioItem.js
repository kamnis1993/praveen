"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../../cs-lib-utilities/Utilities");
var PortfolioItem = require("./PortfolioItem");
/**
 * Class describes an item in a portfolio
 */
var AffectedPortfolioItem = /** @class */ (function (_super) {
    __extends(AffectedPortfolioItem, _super);
    /**
     * Creates a new instance of a portfolio item
     * @param portfolioItem the portfolio item to use to populate this one
     */
    function AffectedPortfolioItem(affectedPortfolioItem) {
        var _this = _super.call(this, affectedPortfolioItem) || this;
        _this.ChildEntities = [];
        _this.NotAvailable = undefined;
        if (Utilities.IsNotDefined(affectedPortfolioItem)) {
            return _this;
        }
        if (Utilities.IsDefined(affectedPortfolioItem.ChildEntities)) {
            var childEntityArray = Utilities.asArray(affectedPortfolioItem.ChildEntities);
            childEntityArray.forEach(function (childEntity) {
                _this.ChildEntities.push(new AffectedPortfolioItem(childEntity));
            });
        }
        _this.NotAvailable = Utilities.ValueOrDefault(affectedPortfolioItem.NotAvailable, undefined);
        return _this;
    }
    return AffectedPortfolioItem;
}(PortfolioItem));
module.exports = AffectedPortfolioItem;

"use strict";
var CombinedUserDefinedCharacteristicUses = /** @class */ (function () {
    function CombinedUserDefinedCharacteristicUses() {
        this.OrderItemUDCs = [];
        this.PortfolioItemUdcs = [];
    }
    return CombinedUserDefinedCharacteristicUses;
}());
module.exports = CombinedUserDefinedCharacteristicUses;

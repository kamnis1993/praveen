"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes an EntityToEntity condition on a compatibility rule error
 * @type   {[type]}
 */
var CompatibilityErrorEntToEntConditionDetails = /** @class */ (function () {
    function CompatibilityErrorEntToEntConditionDetails(lhsEntityPaths, comparer, rhsEntityPaths) {
        this.PrimaryEntities = Utilities.ValueOrDefault(lhsEntityPaths, undefined);
        this.Comparer = Utilities.ValueOrDefault(comparer, undefined);
        this.SecondaryEntities = Utilities.ValueOrDefault(rhsEntityPaths, undefined);
    }
    return CompatibilityErrorEntToEntConditionDetails;
}());
module.exports = CompatibilityErrorEntToEntConditionDetails;

"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderCandidate = require("./OrderCandidate");
var CustomerPortfolio = require("./CustomerPortfolio");
/**
 * Describes the object that will be received from users of Cat Services when calling order related methods
 */
var OrderCandidateRequest = /** @class */ (function () {
    /**
     * Creates a new instance of the OrderCandidateRequest object
     * @param orderCandidateRequest The object to use to populate this one
     */
    function OrderCandidateRequest(orderCandidateRequest) {
        /**
         * The activation date for this order
         * @type   {Date}
         */
        this.ActivationDate = undefined;
        if (Utilities.IsNotDefined(orderCandidateRequest)) {
            this.ActivationDate = new Date(Date.now());
            this.DecomposeID = Utilities.GenerateGuid();
            this.CustomerPortfolio = new CustomerPortfolio();
            this.OrderCandidate = new OrderCandidate();
            return;
        }
        this.ID = Utilities.ValueOrDefault(orderCandidateRequest.ID, undefined);
        this.DecomposeID = Utilities.ValueOrDefault(orderCandidateRequest.DecomposeID, Utilities.GenerateGuid());
        this.CustomerPortfolio = Utilities.IsDefined(orderCandidateRequest.CustomerPortfolio) ? new CustomerPortfolio(orderCandidateRequest.CustomerPortfolio) : undefined;
        this.OrderCandidate = Utilities.IsDefined(orderCandidateRequest.OrderCandidate) ? new OrderCandidate(orderCandidateRequest.OrderCandidate) : undefined;
        if (typeof orderCandidateRequest.ActivationDate === 'string') {
            this.ActivationDate = Utilities.ParseDateFromString(orderCandidateRequest.ActivationDate);
        }
        else {
            this.ActivationDate = Utilities.IsDefined(orderCandidateRequest.ActivationDate) ? orderCandidateRequest.ActivationDate : undefined;
        }
    }
    /**
     * Removes any parameters that are for internal use only
     */
    OrderCandidateRequest.prototype.RemoveInternalData = function () {
        this.OrderCandidate.RemoveInternalData();
        this.CustomerPortfolio.RemoveInternalData();
    };
    return OrderCandidateRequest;
}());
module.exports = OrderCandidateRequest;

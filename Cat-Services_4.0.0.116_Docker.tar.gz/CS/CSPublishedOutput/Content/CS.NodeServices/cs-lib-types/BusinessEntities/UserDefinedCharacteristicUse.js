"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CharacteristicUseBase = require("./CharacteristicUseBase");
/**
 * Describes a characteristic that has a value that is defined by the user at order time
 */
var UserDefinedCharacteristicUse = /** @class */ (function (_super) {
    __extends(UserDefinedCharacteristicUse, _super);
    /**
     * Creates a new instance of the user DefinedCharacteristic Use object
     * @param userDefinedCharacteristicUse The value to use to populate this one
     */
    function UserDefinedCharacteristicUse(userDefinedCharacteristicUse) {
        return _super.call(this, userDefinedCharacteristicUse) || this;
    }
    /**
     * Adds the supplied value to the list of values on this user defined characteristic use
     * @param {UserDefinedCharacteristicValue} value DescriptionOfParam
     */
    UserDefinedCharacteristicUse.prototype.AddValue = function (value) {
        var exists = this.Value.some(function (existingCharValue) {
            return existingCharValue.Value === value.Value && existingCharValue.Action === value.Action;
        });
        if (!exists) {
            this.Value.push(value);
        }
    };
    /**
     * Gets the value with the supplied value text
     * @param {string} valueText The value to retrieve
     * @returns {UserDefinedCharacteristicUse} The UserDefinedCharvalue
     */
    UserDefinedCharacteristicUse.prototype.GetValue = function (valueText) {
        for (var c = 0; c < this.Value.length; c++) {
            var userDefinedValue = this.Value[c];
            if (userDefinedValue.Value === valueText) {
                return userDefinedValue;
            }
        }
        return null;
    };
    return UserDefinedCharacteristicUse;
}(CharacteristicUseBase));
module.exports = UserDefinedCharacteristicUse;

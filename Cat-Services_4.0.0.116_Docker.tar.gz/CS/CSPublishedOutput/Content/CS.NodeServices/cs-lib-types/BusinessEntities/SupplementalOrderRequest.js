"use strict";
/// <reference path="../CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderCandidate = require("./OrderCandidate");
var OrderCandidateRequest = require("./OrderCandidateRequest");
/**
 * Class that defines the supplemental order request
 */
var SupplementalOrderRequest = /** @class */ (function (_super) {
    __extends(SupplementalOrderRequest, _super);
    /**
     * Creates a new instance of the SupplementalOrderRequest object
     * @param supplementalOrderRequest The object to use to populate this one
     */
    function SupplementalOrderRequest(supplementalOrderRequest) {
        var _this = _super.call(this, supplementalOrderRequest) || this;
        if (!supplementalOrderRequest) {
            return _this;
        }
        _this.OriginalRequestID = Utilities.ValueOrDefault(supplementalOrderRequest.OriginalRequestID, undefined);
        // Its easier to treat this as an order candidate, so we can inherit from OrderCandidateRequest
        _this.OrderCandidate = new OrderCandidate(supplementalOrderRequest.InflightOrder);
        return _this;
    }
    return SupplementalOrderRequest;
}(OrderCandidateRequest));
module.exports = SupplementalOrderRequest;

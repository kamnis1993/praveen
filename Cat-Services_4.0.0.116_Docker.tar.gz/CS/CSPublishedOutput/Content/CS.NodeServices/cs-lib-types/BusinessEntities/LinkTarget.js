"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
/**
 * Describes a link to an item in the customers portfolio
 * @type   {OrderLinkTarget}
 */
var LinkTarget = /** @class */ (function () {
    /**
     * Creates a new instance of a link to portfolio item
     * @param {ILinkTarget} link the object to use to populate this one
     */
    function LinkTarget(link) {
        this.PortfolioItemID = Utilities.ValueOrDefault(link.PortfolioItemID, undefined);
        this.Action = Utilities.ValueOrDefault(link.Action, OrderActions.Add, true);
        this.ChangeType = Utilities.ValueOrDefault(link.ChangeType, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(link.ItemSource, undefined);
        this.DecomposeGenID = Utilities.ValueOrDefault(link.DecomposeGenID, undefined);
    }
    return LinkTarget;
}());
module.exports = LinkTarget;

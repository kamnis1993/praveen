"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that represents a bad data error
 */
var BadDataError = /** @class */ (function () {
    /**
     *
     * @param {string} errorCode The error code
     * @param {string} errorType The error type
     * @param {string} message The error message
     * @param {string} entityId The entity ID
     * @param {string} sourceEntityId The source entity ID
     * @param {string} targetEntityId The target entity ID
     * @param {string} extraInfo The extra info
     */
    function BadDataError(errorCode, errorType, message, entityId, contextParameters, sourceEntityId, targetEntityId, extraInfo) {
        var _this = this;
        this.ErrorCode = errorCode;
        this.Type = errorType;
        this.Message = message;
        this.EntityId = entityId;
        this.SourceEntityId = sourceEntityId;
        this.TargetEntityId = targetEntityId;
        this.ExtraInfo = extraInfo;
        this.ContextParameters = [];
        var parameters = Utilities.asArray(contextParameters);
        parameters.forEach(function (parameter) {
            _this.ContextParameters.push(parameter);
        });
    }
    return BadDataError;
}());
module.exports = BadDataError;

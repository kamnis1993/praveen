"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes item action details on a compatibility error
 * @type   {[type]}
 */
var CompatibilityErrorItemActionDetails = /** @class */ (function () {
    function CompatibilityErrorItemActionDetails(entityPath, itemAction) {
        this.EntityPath = Utilities.ValueOrDefault(entityPath, undefined);
        this.ItemAction = Utilities.ValueOrDefault(itemAction, undefined);
    }
    return CompatibilityErrorItemActionDetails;
}());
module.exports = CompatibilityErrorItemActionDetails;

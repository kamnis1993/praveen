"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
/*
 * Base class from which characteristic values should derive.
 */
var CharacteristicValueBase = /** @class */ (function () {
    /**
     * Creates a new instance of the CharacteristicUseBase object
     * @param {ICharacteristicUseBase} characteristicUseBase The object to use to populate this one
     */
    function CharacteristicValueBase(characteristicValueBase) {
        if (!characteristicValueBase) {
            return;
        }
        this.ValueDetail = Utilities.ValueOrDefault(characteristicValueBase.ValueDetail, undefined);
        this.Action = Utilities.ValueOrDefault(characteristicValueBase.Action, OrderActions.Add, true);
        this.NotAvailable = Utilities.ValueOrDefault(characteristicValueBase.NotAvailable, undefined);
        this.ChangeType = Utilities.ValueOrDefault(characteristicValueBase.ChangeType, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(characteristicValueBase.ItemSource, undefined);
    }
    return CharacteristicValueBase;
}());
module.exports = CharacteristicValueBase;

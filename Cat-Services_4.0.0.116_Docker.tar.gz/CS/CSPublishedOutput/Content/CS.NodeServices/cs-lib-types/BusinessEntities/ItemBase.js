"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var EntityLink = require("./EntityLink");
var UserDefinedCharacteristicUse = require("./UserDefinedCharacteristicUse");
var CharacteristicUse = require("./CharacteristicUse");
var RateAttribute = require("./RateAttribute");
/**
 * Class Describes the information regarding an item in catalog services
 * @type   {ItemBase}
 */
var ItemBase = /** @class */ (function () {
    /**
     * Creates a new instance of the item base class
     * @param   {IItemBase}   itemBase   The itemBase object to use to populate this one
     */
    function ItemBase(itemBase) {
        /**
         * The list of Entity links for this entity
         */
        this.LinkedEntities = [];
        /**
         * The RateAttributes for this item
         */
        this.RateAttributes = [];
        /**
        * The Characteristics used on this item
        */
        this.CharacteristicUses = [];
        /**
         * The configured vales used on this item
         */
        this.ConfiguredValues = [];
        /**
         * The Applicable discounts for this item
         */
        this.ApplicableDiscount = [];
        if (!itemBase) {
            return;
        }
        this.ID = Utilities.ValueOrDefault(itemBase.ID, undefined);
        this.EntityID = Utilities.ValueOrDefault(itemBase.EntityID, undefined, true);
        this.ItemAction = Utilities.ValueOrDefault(itemBase.ItemAction, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(itemBase.ItemSource, undefined);
        this.RateDetail = Utilities.ValueOrDefault(itemBase.RateDetail, undefined);
        var packArray = function (src, func) {
            var items = Utilities.asArray(src);
            var outp = [];
            for (var c = 0; c < items.length; c++) {
                var item = func(items[c]);
                outp.push(item);
            }
            return outp;
        };
        if (itemBase.LinkedEntities) {
            this.LinkedEntities = packArray(itemBase.LinkedEntities, function (i) { return new EntityLink(i); });
        }
        if (itemBase.RateAttributes) {
            this.RateAttributes = packArray(itemBase.RateAttributes, function (i) { return new RateAttribute(i); });
        }
        if (itemBase.CharacteristicUses) {
            this.CharacteristicUses = packArray(itemBase.CharacteristicUses, function (i) { return new CharacteristicUse(i); });
        }
        if (itemBase.ConfiguredValues) {
            this.ConfiguredValues = packArray(itemBase.ConfiguredValues, function (i) { return new UserDefinedCharacteristicUse(i); });
        }
    }
    /**
     * Adds the supplied characteristic use to the collection of characteristic uses (if it does not exists already)
     * @param {CharacteristicUse} characteristicUse The characteristic use to add
     */
    ItemBase.prototype.AddCharacteristicUse = function (characteristicUse) {
        var exists = this.CharacteristicUses.some(function (existingCharUse) {
            if (existingCharUse.UseArea !== characteristicUse.UseArea) {
                return false;
            }
            if (existingCharUse.CharacteristicID !== characteristicUse.CharacteristicID) {
                return false;
            }
            return true;
        });
        if (!exists) {
            this.CharacteristicUses.push(characteristicUse);
        }
    };
    /**
     * Gets the characteristic use object that has the supplied useArea and CharacteristicID
     * @param {string} useArea UseArea The useArea of the CharacteristicUse
     * @param {string} characteristicID The ID of the characteristic that the values in thsi use area point at
     * @returns {CharacteristicUse} The characteristic use
     */
    ItemBase.prototype.GetCharacteristicUse = function (useArea, characteristicID) {
        for (var c = 0; c < this.CharacteristicUses.length; c++) {
            var characteristicUse = this.CharacteristicUses[c];
            if (characteristicUse.UseArea !== useArea) {
                continue;
            }
            if (characteristicUse.CharacteristicID === characteristicID) {
                return characteristicUse;
            }
        }
        return null;
    };
    /**
     * Deletes the supplied characteristic Use from the collection of characteristic Uses
     * @param {CharacteristicUse} characteristicUse The char use to be deleted
     */
    ItemBase.prototype.DeleteCharacteristicUse = function (characteristicUse) {
        for (var c = 0; c < this.CharacteristicUses.length; c++) {
            if (this.CharacteristicUses[c] !== characteristicUse) {
                continue;
            }
            this.CharacteristicUses.splice(c, 1);
            return;
        }
    };
    /**
    * Gets the configured value object that has the supplied useArea and CharacteristicID
    * @param {string} useArea UseArea The useArea of the configured value
    * @param {string} characteristicID The ID of the configured value that the values in this configured value point at
    * @returns {ConfiguredValue} The characteristic use
    */
    ItemBase.prototype.GetConfiguredValue = function (useArea, characteristicID) {
        for (var c = 0; c < this.ConfiguredValues.length; c++) {
            var configuredValue = this.ConfiguredValues[c];
            if (configuredValue.UseArea !== useArea) {
                continue;
            }
            if (configuredValue.CharacteristicID === characteristicID) {
                return configuredValue;
            }
        }
        return null;
    };
    /**
     * Removes internal only data
     * @param {boolean} removeItemsMarkedForDeletion indicates if we are to remove items marked with a delete action
     */
    ItemBase.prototype.RemoveInternalData = function (removeItemsMarkedForDeletion) {
        this.ItemAction = undefined;
        if (removeItemsMarkedForDeletion) {
            this.RemoveRateAttributesMarkedForDeletion();
            this.RemoveCharacteristicsMarkedForDeletion();
        }
    };
    /**
    * Removes any rate attributes that are marked for deletion
    */
    ItemBase.prototype.RemoveRateAttributesMarkedForDeletion = function () {
        for (var c = 0; c < this.RateAttributes.length; c++) {
            var rateAttribute = this.RateAttributes[c];
            if (rateAttribute.Action) {
                if (rateAttribute.Action === OrderActions.Delete) {
                    this.RateAttributes.splice(c, 1);
                    c -= 1;
                }
            }
        }
    };
    /**
     * Removes any characteristics that are marked for deletion
     */
    ItemBase.prototype.RemoveCharacteristicsMarkedForDeletion = function () {
        for (var z = 0; z < 2; z++) {
            var collection = z === 0 ? this.CharacteristicUses : this.ConfiguredValues;
            for (var c = 0; c < collection.length; c++) {
                var charUse = collection[c];
                if (charUse.Action === OrderActions.Delete) {
                    collection.splice(c, 1);
                    c -= 1;
                    continue;
                }
                for (var i = 0; i < charUse.Value.length; i++) {
                    if (charUse.Value[i].Action !== OrderActions.Delete) {
                        continue;
                    }
                    charUse.Value.splice(i, 1);
                    i -= 1;
                    if (charUse.Value.length === 0) {
                        collection.splice(c, 1);
                        c -= 1;
                    }
                }
            }
        }
    };
    return ItemBase;
}());
module.exports = ItemBase;

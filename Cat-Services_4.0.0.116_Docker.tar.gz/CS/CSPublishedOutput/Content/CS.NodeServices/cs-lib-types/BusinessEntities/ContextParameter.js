"use strict";
/**
 * Class that represents a context parameter
 */
var ContextParameter = /** @class */ (function () {
    function ContextParameter(name, value) {
        this.Name = name;
        this.Value = value;
    }
    return ContextParameter;
}());
module.exports = ContextParameter;

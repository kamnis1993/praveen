"use strict";
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var OrderActions = require("../../cs-lib-constants/OrderActions");
var Utilities = require("../../cs-lib-utilities/Utilities");
var ItemBase = require("./ItemBase");
/**
 * Class describes an item in a portfolio
 */
var PortfolioItem = /** @class */ (function (_super) {
    __extends(PortfolioItem, _super);
    /**
     * Creates a new instance of a portfolio item
     * @param portfolioItem the portfolio item to use to populate this one
     */
    function PortfolioItem(portfolioItem) {
        var _this = _super.call(this, portfolioItem) || this;
        /**
         * The child entities of this portfolio item
         */
        _this.ChildEntities = [];
        /**
         * Flag that indicates if this is new for customer
         * This is for internal use only, required for CPQ 1.x
         */
        _this._IsNewForCustomer = undefined;
        if (!portfolioItem) {
            return _this;
        }
        _this._IsNewForCustomer = Utilities.ValueOrDefault(portfolioItem._IsNewForCustomer, undefined);
        if (Utilities.IsDefined(portfolioItem.ChildEntities, true)) {
            Utilities.asArray(portfolioItem.ChildEntities).forEach(function (childEntity) {
                _this.ChildEntities.push(new PortfolioItem(childEntity));
            });
        }
        return _this;
    }
    /**
    * Removes any parameters that are for internal use only
    *  - Children marked for deletion
    *  - ItemAction element
    *  - Action element
    */
    PortfolioItem.prototype.RemoveInternalData = function () {
        this.ItemAction = undefined;
        this.RemoveRateAttributesMarkedForDeletion();
        this.RemoveCharacteristicsMarkedForDeletion();
        this.ChildEntities = this.ChildEntities.filter(function (childItem) {
            return childItem.ItemAction !== OrderActions.Delete;
        });
        // Recurse down child entities
        this.ChildEntities.forEach(function (childItem) {
            childItem.RemoveInternalData();
        });
    };
    /**
   * Removes any rate attributes that are marked for deletion
   */
    PortfolioItem.prototype.RemoveRateAttributesMarkedForDeletion = function () {
        this.RateAttributes = this.RateAttributes.filter(function (rateAttr) {
            return Utilities.IsNotDefined(rateAttr.Action) || rateAttr.Action !== OrderActions.Delete;
        });
    };
    /**
     * Removes any characteristics that are marked for deletion
     */
    PortfolioItem.prototype.RemoveCharacteristicsMarkedForDeletion = function () {
        this.CharacteristicUses = this.FilterCharacteristicDeletes(this.CharacteristicUses);
        this.ConfiguredValues = this.FilterCharacteristicDeletes(this.ConfiguredValues);
    };
    /**
     * Filters out CharacteristicUse or ConfiguredValues which are marked as Delete
     * Remove all values marked as Delete, and if there are no values afterwards then
     * also remove the Characteristic Container (i.e. CharacteristicUse or ConfiguredValue)
     * @param  charCollection [description]
     * @return                [description]
     */
    PortfolioItem.prototype.FilterCharacteristicDeletes = function (charCollection) {
        return charCollection.filter(function (charUse) {
            if (charUse.Action === OrderActions.Delete) {
                return false;
            }
            charUse.Value = charUse.Value.filter(function (charValue) {
                if (charValue.Action === OrderActions.Delete) {
                    return false;
                }
                charValue.Action = undefined;
                return true;
            });
            return charUse.Value.length > 0 || Utilities.IsDefined(charUse.NotAvailable, true);
        });
    };
    return PortfolioItem;
}(ItemBase));
module.exports = PortfolioItem;

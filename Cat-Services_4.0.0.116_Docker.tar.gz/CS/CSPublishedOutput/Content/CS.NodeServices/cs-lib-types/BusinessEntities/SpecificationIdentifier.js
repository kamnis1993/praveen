"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a specification identifier
 * This structure holds parameters required to search for a specification
 */
var SpecificationIdentifier = /** @class */ (function () {
    /**
     * Creates a new instance of type SpecificationIdentifier
     * @param {string] id - The id of the product to retrieve
     * @param {ProductSpecIdType} idType - The type of the id being supplied, either entity guid or business id
     * @param {BoundaryCondition} boundaryCondition - Indicates whether the specification is technical or commercial
     * @param {string} contractId (optional) - specifies a Framework Contracts negotiated specification
     * @param {Date} filterDate (optional) - The filter date
     */
    function SpecificationIdentifier(id, idType, boundaryCondition, contractId, filterDate) {
        this.Id = id;
        this.IdType = idType;
        this.BoundaryCondition = boundaryCondition;
        this.ContractId = Utilities.IsDefined(contractId, true) ? contractId : null;
        this.FilterDate = Utilities.IsDefined(filterDate, true) ? filterDate : null;
    }
    /**
    * Checks if the specification identifier has a valid contractId
    */
    SpecificationIdentifier.prototype.HasContractId = function () {
        return Utilities.IsDefined(this.ContractId, true);
    };
    /**
    * Checks if the specification identifier has a valid product id
    */
    SpecificationIdentifier.prototype.HasValidId = function () {
        return Utilities.IsValidId(this.Id, this.IdType);
    };
    return SpecificationIdentifier;
}());
module.exports = SpecificationIdentifier;

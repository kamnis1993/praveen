"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describing the entity or data container being targetted by an ExistsData/NotExistsData rule condition
 */
var ExistsDataTarget = /** @class */ (function () {
    function ExistsDataTarget(entityPath, elementPath, action) {
        this.EntityPath = Utilities.ValueOrDefault(entityPath, undefined);
        this.ElementPath = Utilities.ValueOrDefault(elementPath, undefined);
        this.Action = Utilities.ValueOrDefault(action, undefined);
    }
    return ExistsDataTarget;
}());
module.exports = ExistsDataTarget;

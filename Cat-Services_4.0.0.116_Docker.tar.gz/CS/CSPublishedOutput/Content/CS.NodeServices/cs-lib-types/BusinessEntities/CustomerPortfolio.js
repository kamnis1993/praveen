"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var RootPortfolioItem = require("./RootPortfolioItem");
/**
 * Class describes a customer portfolio
 */
var CustomerPortfolio = /** @class */ (function () {
    /**
     * Creates a new instance of the portfolio object
     * @param portfolio The portfolio object to use to instantiate this one
     */
    function CustomerPortfolio(customerPortfolio) {
        /**
         * Holds a reference to all the items in the customers portfolio
         */
        this.PortfolioItems = [];
        /**
         * The contextual parameters
         * This is for internal use only, required for CPQ 1.x
         *
         */
        this.ContextualParameters = [];
        if (!customerPortfolio) {
            return;
        }
        if (customerPortfolio.PortfolioItems) {
            var portfolioItemsArray = Utilities.asArray(customerPortfolio.PortfolioItems);
            for (var c = 0; c < portfolioItemsArray.length; c++) {
                var portfolioItem = portfolioItemsArray[c];
                this.PortfolioItems.push(new RootPortfolioItem(portfolioItem));
            }
        }
        this.ContextualParameters = Utilities.asArray(customerPortfolio.ContextualParameters);
    }
    /**
     * Removes the process context from PortfolioItems and contents
     */
    CustomerPortfolio.prototype.RemoveInternalData = function () {
        this.PortfolioItems.forEach(function (portfolioItem) {
            portfolioItem.RemoveInternalData();
        });
    };
    return CustomerPortfolio;
}());
module.exports = CustomerPortfolio;

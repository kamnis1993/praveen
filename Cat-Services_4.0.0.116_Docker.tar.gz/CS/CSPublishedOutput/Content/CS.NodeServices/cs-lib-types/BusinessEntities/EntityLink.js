"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var LinkTarget = require("./LinkTarget");
var OrderActions = require("../../cs-lib-constants/OrderActions");
/**
 * Describes a Linked Entity
 * @type   {OrderEntityLink}
 */
var EntityLink = /** @class */ (function () {
    /**
     * Creates a new instance of the context object
     * @param   {IEntityLink}   relatedEntity   The relatedEntity to use to populate this one
     */
    function EntityLink(entityLink) {
        /**
         * A list of all the portfolio items that this EntityLink targets
         */
        this.Links = [];
        if (!entityLink) {
            return;
        }
        this.LinkTypeID = Utilities.ValueOrDefault(entityLink.LinkTypeID, undefined, true);
        this.Action = Utilities.ValueOrDefault(entityLink.Action, OrderActions.Modify, true);
        this.ChangeType = Utilities.ValueOrDefault(entityLink.ChangeType, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(entityLink.ItemSource, undefined);
        var links = Utilities.asArray(entityLink.Links);
        for (var c = 0; c < links.length; c++) {
            this.Links.push(new LinkTarget(links[c]));
        }
    }
    return EntityLink;
}());
module.exports = EntityLink;

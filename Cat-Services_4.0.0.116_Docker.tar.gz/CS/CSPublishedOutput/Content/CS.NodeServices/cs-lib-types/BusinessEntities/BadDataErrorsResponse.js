"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * The bad data errors response
 */
var BadDataErrorsResponse = /** @class */ (function () {
    /**
     * Creates a new bad data error instance
     * @param {number} statusCode The status code
     * @param {string} title The title
     * @param {BadDataError[]} badDataErrors The bad data errors
     */
    function BadDataErrorsResponse(statusCode, title, badDataErrors) {
        var _this = this;
        this.StatusCode = statusCode;
        this.Title = title;
        this.BadDataErrors = [];
        var errors = Utilities.asArray(badDataErrors);
        if (Utilities.IsNotDefined(errors, true)) {
            return;
        }
        errors.forEach(function (badDataError) {
            _this.BadDataErrors.push(badDataError);
        });
    }
    return BadDataErrorsResponse;
}());
module.exports = BadDataErrorsResponse;

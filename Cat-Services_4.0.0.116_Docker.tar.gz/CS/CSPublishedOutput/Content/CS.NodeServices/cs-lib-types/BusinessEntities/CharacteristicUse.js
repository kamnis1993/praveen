"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var OrderActions = require("../../cs-lib-constants/OrderActions");
var CharacteristicUseBase = require("./CharacteristicUseBase");
/**
 * Object describes the use of a characteristic
 * @type   {CharacteristicUse}
 */
var CharacteristicUse = /** @class */ (function (_super) {
    __extends(CharacteristicUse, _super);
    /**
     * Creates a new instance of the CharacteristicUse object
     * @param {ICharacteristicUse} characteristicUse The object to use to populate this one
     */
    function CharacteristicUse(characteristicUse) {
        return _super.call(this, characteristicUse) || this;
    }
    /**
     * Adds the supplied characteristic value to the list of values for this char use (if it does not already exist)
     * @param {CharacteristicValue} value DescriptionOfParam
     */
    CharacteristicUse.prototype.AddValue = function (value) {
        var exists = this.Value.some(function (existingCharValue) {
            if (existingCharValue.Action && existingCharValue.Action === OrderActions.Delete) {
                return false;
            }
            return existingCharValue.ValueID === value.ValueID;
        });
        if (!exists) {
            this.Value.push(value);
        }
    };
    /**
     * Deletes a value from the list of values for this characteristic use
     * @param {string} valueID the valueid of the value to delete
     */
    CharacteristicUse.prototype.DeleteValue = function (valueID) {
        for (var c = 0; c < this.Value.length; c++) {
            var charValue = this.Value[c];
            if (charValue.ValueID === valueID) {
                this.Value.splice(c, 1);
                return;
            }
        }
    };
    /**
     * Gets the characteristic value with the supplied valueID
     * @param {string} valueID The ID of the value to retrieve
     * @returns {CharacteristicValue} The characteristic value
     */
    CharacteristicUse.prototype.GetValue = function (valueID) {
        for (var c = 0; c < this.Value.length; c++) {
            var charValue = this.Value[c];
            if (charValue.ValueID === valueID) {
                return charValue;
            }
        }
        return null;
    };
    return CharacteristicUse;
}(CharacteristicUseBase));
module.exports = CharacteristicUse;

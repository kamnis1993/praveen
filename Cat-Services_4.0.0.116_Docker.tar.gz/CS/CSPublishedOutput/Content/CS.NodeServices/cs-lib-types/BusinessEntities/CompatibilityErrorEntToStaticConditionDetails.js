"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes an EntityToStaticValue condiiton on a compatibility rule error
 * @type   {[type]}
 */
var CompatibilityErrorEntToStaticConditionDetails = /** @class */ (function () {
    function CompatibilityErrorEntToStaticConditionDetails(entityPaths, comparer, value) {
        this.EntityPaths = Utilities.ValueOrDefault(entityPaths, undefined);
        this.Comparer = Utilities.ValueOrDefault(comparer, undefined);
        this.StaticValue = Utilities.ValueOrDefault(value, undefined);
    }
    return CompatibilityErrorEntToStaticConditionDetails;
}());
module.exports = CompatibilityErrorEntToStaticConditionDetails;

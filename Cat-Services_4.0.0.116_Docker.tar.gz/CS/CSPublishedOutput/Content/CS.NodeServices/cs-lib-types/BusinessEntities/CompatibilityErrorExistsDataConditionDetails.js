"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes an ExistData or NotExistsData condition on a compatibility rule error
 * @type   {[type]}
 */
var CompatibilityErrorExistsDataConditionDetails = /** @class */ (function () {
    function CompatibilityErrorExistsDataConditionDetails(matchAny) {
        this.MatchAny = Utilities.ValueOrDefault(matchAny, undefined);
        this.Targets = [];
    }
    return CompatibilityErrorExistsDataConditionDetails;
}());
module.exports = CompatibilityErrorExistsDataConditionDetails;

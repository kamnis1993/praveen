"use strict";
/// <reference path="../CompiledTypes/CsTypes.d.ts" />
var ItemContext = require("./ItemContext");
var Customer = require("./Customer");
var OrderItem = require("./OrderItem");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Describes an order candidate
 */
var OrderCandidate = /** @class */ (function () {
    /**
     * Creates a new instance of the OrderCandidate object
     * @param order The raw order object to use to create this instance
     */
    function OrderCandidate(orderCandidate) {
        /**
         * Any context that accompanies this order
         * @type   {Array<ContextItem>}
         */
        this.OrderContext = [];
        /**
         * Holds a reference to the list of order items that form this order
         */
        this.OrderItems = [];
        this.OrderContext = [];
        this.OrderItems = [];
        this._orderItemLookup = {};
        if (!orderCandidate) {
            return;
        }
        this.OrderID = Utilities.ValueOrDefault(orderCandidate.OrderID, undefined);
        if (orderCandidate.Customer) {
            this.Customer = new Customer(orderCandidate.Customer);
        }
        if (orderCandidate.OrderContext) {
            var orderContextArray = Utilities.asArray(orderCandidate.OrderContext);
            for (var c = 0; c < orderContextArray.length; c++) {
                var itemContext = new ItemContext(orderContextArray[c]);
                this.OrderContext.push(itemContext);
            }
        }
        if (orderCandidate.OrderItems) {
            var orderItemArray = Utilities.asArray(orderCandidate.OrderItems);
            for (var i = 0; i < orderItemArray.length; i++) {
                var orderItem = orderItemArray[i];
                this.OrderItems.push(new OrderItem(orderItem, null, false, this._orderItemLookup));
            }
        }
        if (orderCandidate.Limits) {
            this.Limits = Utilities.asArray(orderCandidate.Limits);
        }
    }
    Object.defineProperty(OrderCandidate.prototype, "OrderItemLookup", {
        /**
         * Gets the order item lookup
         * @returns {CsTypes.Dictionary<IOrderItemLookup>}
         */
        get: function () {
            return this._orderItemLookup;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Removes any parameters that are for internal use only
     */
    OrderCandidate.prototype.RemoveInternalData = function () {
        this._orderItemLookup = undefined;
    };
    return OrderCandidate;
}());
module.exports = OrderCandidate;

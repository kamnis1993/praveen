"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes entity link on a compatibility rule error
 * @type   {[type]}
 */
var CompatibilityErrorEntityLinkDetails = /** @class */ (function () {
    function CompatibilityErrorEntityLinkDetails(entityPath, linkTypeID) {
        this.EntityPath = Utilities.ValueOrDefault(entityPath, undefined);
        this.LinkTypeID = Utilities.ValueOrDefault(linkTypeID, undefined);
    }
    return CompatibilityErrorEntityLinkDetails;
}());
module.exports = CompatibilityErrorEntityLinkDetails;

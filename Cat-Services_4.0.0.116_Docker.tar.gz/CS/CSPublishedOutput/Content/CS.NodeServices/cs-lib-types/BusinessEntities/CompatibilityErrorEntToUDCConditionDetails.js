"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes an EntityToUDC condition on a compatibility rule error
 * @type   {[type]}
 */
var CompatibilityErrorEntToUDCConditionDetails = /** @class */ (function () {
    function CompatibilityErrorEntToUDCConditionDetails(entityPaths, comparer, udcEntityPath, udcElementPath) {
        this.EntityPaths = Utilities.ValueOrDefault(entityPaths, undefined);
        this.Comparer = Utilities.ValueOrDefault(comparer, undefined);
        this.UDCEntityPath = Utilities.ValueOrDefault(udcEntityPath, undefined);
        this.UDCElementPath = Utilities.ValueOrDefault(udcElementPath, undefined);
    }
    return CompatibilityErrorEntToUDCConditionDetails;
}());
module.exports = CompatibilityErrorEntToUDCConditionDetails;

"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Object describes a customer
 * @type   {Customer}
 */
var Customer = /** @class */ (function () {
    /**
     * Creates a new instance of the customer objects
     * @param   {ICustomer}  customer The object to use to populate this one
     */
    function Customer(customer) {
        if (!customer) {
            return;
        }
        this.ID = Utilities.ValueOrDefault(customer.ID, undefined);
    }
    return Customer;
}());
module.exports = Customer;

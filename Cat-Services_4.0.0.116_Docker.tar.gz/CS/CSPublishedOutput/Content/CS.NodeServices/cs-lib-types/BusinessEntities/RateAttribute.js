"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
/**
 * Class describes a RateAttribute object
 */
var RateAttribute = /** @class */ (function () {
    /**
     * Creates a new instance of the Rate Attribute object
     * @param rateAttribute The object to use to instantiate this one
     */
    function RateAttribute(rateAttribute) {
        /**
         * The action to be carried out against this rate attribute
         */
        this.Action = OrderActions.Add;
        this.Name = rateAttribute.Name;
        this.Value = rateAttribute.Value;
        this.Action = Utilities.ValueOrDefault(rateAttribute.Action, OrderActions.Add, true);
        this.ChangeType = Utilities.ValueOrDefault(rateAttribute.ChangeType, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(rateAttribute.ItemSource, undefined);
    }
    return RateAttribute;
}());
module.exports = RateAttribute;

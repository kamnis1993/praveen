"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var CharacteristicValue = require("./CharacteristicValue");
var UserDefinedCharacteristicValue = require("./UserDefinedCharacteristicValue");
/*
 * Base class from which characteristic uses should derive.
 * Note: Configured Values are just another type of characteristic use in EPM and therefore also derive from here . (We have called them configured values in cat services for some reason)
 */
var CharacteristicUseBase = /** @class */ (function () {
    /**
     * Creates a new instance of the CharacteristicUseBase object
     * @param {ICharacteristicUseBase} characteristicUseBase The object to use to populate this one
     */
    function CharacteristicUseBase(characteristicUseBase) {
        var _this = this;
        /**
         * The values associated with this characteristic use
         */
        this.Value = [];
        if (!characteristicUseBase) {
            return;
        }
        this.UseArea = Utilities.ValueOrDefault(characteristicUseBase.UseArea, undefined);
        this.CharacteristicID = Utilities.ValueOrDefault(characteristicUseBase.CharacteristicID, undefined, true);
        this.UseID = Utilities.ValueOrDefault(characteristicUseBase.UseID, undefined, true);
        this.Action = Utilities.ValueOrDefault(characteristicUseBase.Action, OrderActions.Modify, true);
        this.NotAvailable = Utilities.ValueOrDefault(characteristicUseBase.NotAvailable, undefined);
        this.ChangeType = Utilities.ValueOrDefault(characteristicUseBase.ChangeType, undefined, true);
        this.ItemSource = Utilities.ValueOrDefault(characteristicUseBase.ItemSource, undefined);
        Utilities.asArray(characteristicUseBase.Value).forEach(function (charValue) {
            var CharValueType = (Utilities.IsDefined(charValue.ValueID)) ? CharacteristicValue : UserDefinedCharacteristicValue;
            _this.Value.push(new CharValueType(charValue));
        });
    }
    /**
     * Removes any parameters that are for internal use only
     */
    CharacteristicUseBase.prototype.RemoveInternalData = function () {
        for (var c = 0; c < this.Value.length; c++) {
            var charValue = this.Value[c];
            if (charValue.Action === OrderActions.Delete) {
                this.Value.splice(c, 1);
                c -= 1;
            }
        }
    };
    /**
     * Marks all the value of this char use with the supplied action
     * @param {string} action The action to mark the values with
     */
    CharacteristicUseBase.prototype.MarkAllValueActionsAs = function (action) {
        for (var c = 0; c < this.Value.length; c++) {
            this.Value[c].Action = action;
        }
    };
    /**
    * ABSTRACT
    * Adds the supplied characteristic value to the list of values for this char use (if it does not already exist)
    * @param {CharacteristicValue} value DescriptionOfParam
    */
    CharacteristicUseBase.prototype.AddValue = function (value) { return; };
    /**
     * ABSTRACT
     * Gets the characteristic value with the supplied valueID
     * @param {string} identifier The ID of the value to retrieve
     * @returns {any} The retrieved value
     */
    CharacteristicUseBase.prototype.GetValue = function (identifier) { return; };
    return CharacteristicUseBase;
}());
module.exports = CharacteristicUseBase;

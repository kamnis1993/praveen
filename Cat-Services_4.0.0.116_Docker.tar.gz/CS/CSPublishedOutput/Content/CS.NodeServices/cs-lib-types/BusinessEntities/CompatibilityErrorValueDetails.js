"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes value element details on a compatibility error
 * @type   {[type]}
 */
var CompatibilityErrorValueDetails = /** @class */ (function () {
    function CompatibilityErrorValueDetails(entityPath, elementPath) {
        this.EntityPath = Utilities.ValueOrDefault(entityPath, undefined);
        this.ElementPath = Utilities.ValueOrDefault(elementPath, undefined);
    }
    return CompatibilityErrorValueDetails;
}());
module.exports = CompatibilityErrorValueDetails;

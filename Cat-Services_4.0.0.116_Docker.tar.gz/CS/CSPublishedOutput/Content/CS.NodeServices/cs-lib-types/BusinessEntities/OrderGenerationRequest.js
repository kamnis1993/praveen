"use strict";
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var Utilities = require("../../cs-lib-utilities/Utilities");
var ProductCandidate = require("../CPQ-BusinessEntities/ProductCandidate");
/**
 * Describes the object that is received when the user wishes to create an order from 2 product candidates
 */
var OrderGenerationRequest = /** @class */ (function () {
    /**
     * Creates a new instance of the OrderGenerationRequest object
     * @param orderGenerationRequest The object to use to populate this one
     */
    function OrderGenerationRequest(orderGenerationRequest) {
        if (!orderGenerationRequest) {
            return;
        }
        this.OldCandidate = orderGenerationRequest.OldCandidate ? new ProductCandidate(ConverterUtils.OrderPluralize(orderGenerationRequest.OldCandidate)) : null;
        this.NewCandidate = orderGenerationRequest.NewCandidate ? new ProductCandidate(ConverterUtils.OrderPluralize(orderGenerationRequest.NewCandidate)) : null;
        if (typeof orderGenerationRequest.ActivationDate === 'string') {
            this.ActivationDate = Utilities.ParseDateFromString(orderGenerationRequest.ActivationDate);
        }
        else {
            this.ActivationDate = Utilities.IsDefined(orderGenerationRequest.ActivationDate) ? orderGenerationRequest.ActivationDate : undefined;
        }
    }
    return OrderGenerationRequest;
}());
module.exports = OrderGenerationRequest;

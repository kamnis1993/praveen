"use strict";
/**
 * Class that holds a result set from the ReassignPairsBuilder class.
 */
var ReassignPairsResult = /** @class */ (function () {
    function ReassignPairsResult() {
        this.ReassignPairs = new Array();
        this.ReassignItems = new Array();
        this.ReassignedItems = new Array();
    }
    return ReassignPairsResult;
}());
module.exports = ReassignPairsResult;

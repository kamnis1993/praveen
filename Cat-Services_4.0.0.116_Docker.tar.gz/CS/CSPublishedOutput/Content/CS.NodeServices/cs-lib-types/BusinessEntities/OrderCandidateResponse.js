"use strict";
var AffectedCustomerPortfolio = require("./AffectedCustomerPortfolio");
var OrderCandidate = require("./OrderCandidate");
var Utilities = require("../../cs-lib-utilities/Utilities");
var ValidationError = require("./ValidationError");
/**
 * Describes the object that will be sent from Cat Services when calling order related methods
 */
var OrderCandidateResponse = /** @class */ (function () {
    /**
     * Creates a new instance of the orderCandidateResponse object
     * @param orderCandidateResponse The object to use to populate this one
     */
    function OrderCandidateResponse(orderCandidateResponse) {
        /**
         * Any validation errors that occurred during the operation
         * @type   {Array<ValidationError>}
         */
        this.ValidationErrors = [];
        if (!orderCandidateResponse) {
            this.CustomerPortfolio = new AffectedCustomerPortfolio();
            this.OrderCandidate = new OrderCandidate();
            this.ValidationErrors = [];
            return;
        }
        this.RequestID = Utilities.ValueOrDefault(orderCandidateResponse.RequestID, undefined);
        this.OriginalRequestID = Utilities.ValueOrDefault(orderCandidateResponse.OriginalRequestID, undefined);
        this.DecomposeID = Utilities.ValueOrDefault(orderCandidateResponse.DecomposeID, undefined);
        if (orderCandidateResponse.CustomerPortfolio) {
            this.CustomerPortfolio = new AffectedCustomerPortfolio(orderCandidateResponse.CustomerPortfolio);
        }
        if (orderCandidateResponse.OrderCandidate) {
            this.OrderCandidate = new OrderCandidate(orderCandidateResponse.OrderCandidate);
        }
        if (orderCandidateResponse.ValidationErrors) {
            var errorsArray = Utilities.asArray(orderCandidateResponse.ValidationErrors);
            for (var c = 0; c < errorsArray.length; c++) {
                var valError = errorsArray[c];
                this.ValidationErrors.push(new ValidationError(valError.EntityUniqueCode, valError.ErrorCode, valError.Message, valError.EntityID, valError.ChildID));
            }
        }
    }
    Object.defineProperty(OrderCandidateResponse.prototype, "HasErrors", {
        /**
         * Read-only property: indicates if this response contains any errors or not
         */
        get: function () {
            return this.ValidationErrors.length > 0;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Removes any parameters that are for internal use only
     */
    OrderCandidateResponse.prototype.RemoveInternalData = function () {
        this.OrderCandidate.RemoveInternalData();
        this.CustomerPortfolio.RemoveInternalData();
    };
    /**
     * Check if ValidationErrors contains an error which matches the properties specified in matchError
     * @param {any} matchError a literal object containing the properties to match
     * @returns {boolean} True if a match is found
     */
    OrderCandidateResponse.prototype.HasErrorMatching = function (matchError) {
        return this.ValidationErrors.some(matchError);
    };
    return OrderCandidateResponse;
}());
module.exports = OrderCandidateResponse;

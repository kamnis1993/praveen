"use strict";
/**
 * Class holds the information about diagnostic services and placeholder for all trace events logged in node side
 */
var CsContext = /** @class */ (function () {
    function CsContext() {
    }
    return CsContext;
}());
var CsSchemaContext = /** @class */ (function () {
    function CsSchemaContext() {
    }
    return CsSchemaContext;
}());
module.exports = CsContext;

"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * The internal representation of a Validation Error.
 * This will be converted to a ValidationError before inserting into the OrderCandidateResponse
 */
var CsValidationError = /** @class */ (function () {
    function CsValidationError(errorId, errorCode, entityUniqueCode, entityId, messageParameters, childUniqueCode, childId, extraInfo, xsiType, isSevere, phaseCodes) {
        this.ErrorId = errorId;
        this.ErrorCode = errorCode;
        this.EntityUniqueCode = Utilities.IsDefined(entityUniqueCode, true) ? entityUniqueCode : "Not Found";
        this.EntityId = entityId;
        this.MessageParameters = Utilities.ValueOrDefault(messageParameters, {});
        this.ChildUniqueCode = Utilities.ValueOrDefault(childUniqueCode, undefined);
        this.ChildId = Utilities.ValueOrDefault(childId, undefined);
        this.ExtraInfo = Utilities.ValueOrDefault(extraInfo, undefined);
        this.XsiType = Utilities.ValueOrDefault(xsiType, undefined);
        this.IsSevere = Utilities.ValueOrDefault(isSevere, false);
        this.PhaseCodes = Utilities.ValueOrDefault(phaseCodes, undefined);
    }
    return CsValidationError;
}());
module.exports = CsValidationError;

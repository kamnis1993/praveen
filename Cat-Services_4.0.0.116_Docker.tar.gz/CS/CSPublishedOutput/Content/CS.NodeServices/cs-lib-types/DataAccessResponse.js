"use strict";
/**
 * The response object that is returned from a product specification data access operation
 */
var DataAccessResponse = /** @class */ (function () {
    function DataAccessResponse() {
    }
    return DataAccessResponse;
}());
module.exports = DataAccessResponse;

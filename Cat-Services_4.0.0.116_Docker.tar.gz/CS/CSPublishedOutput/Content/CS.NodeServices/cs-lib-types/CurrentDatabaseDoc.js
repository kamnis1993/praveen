"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PublishInfoDoc = require("./PublishInfoDoc");
var DataStoreStatus = require("../cs-lib-constants/DataStoreStatus");
/**
 * Document object which holds information associated with a published data import
 */
var CurrentDatabaseDoc = /** @class */ (function (_super) {
    __extends(CurrentDatabaseDoc, _super);
    /**
     * Create a new CurrentDatabaseDoc object, revive from JSON if supplied.
     * @param {any} [fromDoc] either an object or json string to initialise from
     * @constructor
     */
    function CurrentDatabaseDoc(fromDoc) {
        var _this = _super.call(this, fromDoc) || this;
        /**
         * The name of the database
         */
        _this.DatabaseName = '';
        /** Name or file location that was the source for the most recent import */
        _this.DataSource = '';
        /**
         * The current status of a publish
         */
        _this.Status = DataStoreStatus.Unknown;
        var self = _this;
        // If an initialiser is specified, revive from it
        if (fromDoc) {
            if (fromDoc instanceof Object) {
                if (fromDoc.DatabaseName) {
                    self.DatabaseName = fromDoc.DatabaseName;
                }
                if (fromDoc.DataSource) {
                    self.DataSource = fromDoc.DataSource;
                }
                if (fromDoc.Status) {
                    self.Status = fromDoc.Status;
                }
            }
            else if (typeof (fromDoc) === 'string') {
                try {
                    JSON.parse(fromDoc, function (k, v) {
                        if (k !== "") {
                            return v;
                        }
                        self.DatabaseName = v.DatabaseName;
                        self.DataSource = v.DataSource;
                        self.Status = v.Status;
                        return self;
                    });
                }
                catch (err) {
                    // Ignore SyntaxError from invalid json
                }
            }
        }
        // There is usually only ever one, default to "CurrentDb"
        self._id = 'CurrentDb';
        return _this;
    }
    return CurrentDatabaseDoc;
}(PublishInfoDoc));
module.exports = CurrentDatabaseDoc;

"use strict";
/// <reference types="node" />
/**
 * A class representing the External Product Specification which simulates the CPQ 1.7 version.
 * A bit of a HACK to get XmlOuputFormatter to set the root item correctly
 */
var ExternalProductSpecification = /** @class */ (function () {
    /**
     * @constructor
     * Adds an element with the same name as the _meta name
     * @param {any} source The source
     */
    function ExternalProductSpecification(source, rootProductName) {
        this[rootProductName] = source;
        this['_xmlns:xsi'] = 'http://www.w3.org/2001/XMLSchema-instance';
    }
    return ExternalProductSpecification;
}());
module.exports = ExternalProductSpecification;

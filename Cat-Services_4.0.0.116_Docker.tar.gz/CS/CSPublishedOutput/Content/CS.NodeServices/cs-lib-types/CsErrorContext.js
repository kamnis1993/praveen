"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BadDataError = require("./BusinessEntities/BadDataError");
var BadDataErrorsResponse = require("./BusinessEntities/BadDataErrorsResponse");
var CsBadDataError = require("./CsBadDataError");
var CsError = require("./CsError");
var CsCompatibilityError = require("./CsCompatibilityError");
var CompatibilityError = require("./BusinessEntities/CompatibilityError");
var CsValidationError = require("./CsValidationError");
var ContextParameter = require("./BusinessEntities/ContextParameter");
var DataAccessResult = require("./Enums/DataAccessResult");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var Utilities = require("../cs-lib-utilities/Utilities");
var ValidationError = require("./BusinessEntities/ValidationError");
/**
 * A class which encapsulates the error context of a decompose request
 */
var CsErrorContext = /** @class */ (function () {
    /**
     * @constructor
     * @param {boolean} includeExtraInfo? (default: false) whether the ExtraInfo should be included in ValidationError
     */
    function CsErrorContext(options) {
        this._options = options || {};
        this._includeExtraInfo = true; // Utilities.ParseAsBoolean(this._options.IncludeExtraErrorInfo, false);
        this._truncateErrorCodes = true; // Utilities.ParseAsBoolean(this._options.TruncateErrorCode, false);
        this._badDataStatusCode = 500; //Utilities.ParseAsNumber(this._options.BadDataStatusCode, 500);
        this._validationErrors = {};
        this._compatibilityErrors = {};
        this._badDataErrors = {};
        this._processError = undefined;
        this._errorCode = ErrorCode;
    }
    Object.defineProperty(CsErrorContext.prototype, "ProcessError", {
        /**
         * (ReadOnly) Any error raised due to a problem with the system (i.e. not validation)
         */
        get: function () {
            return this._processError;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CsErrorContext.prototype, "HasProcessError", {
        /**
         * (ReadOnly) An error with the system has been raised.
         */
        get: function () {
            return (Utilities.IsDefined(this._processError));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CsErrorContext.prototype, "HasBadDataError", {
        /*
         * Has Bad Data Error
         * @param {CsErrorContext} Checking for the existence of bad data error
         * @returns {boolean}
         */
        get: function () {
            return (Object.keys(this._badDataErrors).length > 0);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CsErrorContext.prototype, "HasBreakingErrors", {
        get: function () {
            return (this.HasProcessError || this.HasBadDataError || this.HasSevereValidationError);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CsErrorContext.prototype, "HasSevereValidationError", {
        /**
         * (ReadOnly) Returns true if a severe validation error has been raised
         */
        get: function () {
            for (var key in this._validationErrors) {
                if (this._validationErrors[key].IsSevere) {
                    return true;
                }
            }
            return false;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Create a CsError, remember it and return it
     * @param {number} statusCode the HTTP status code for the error
     * @param {string} errorCode the error code, see cs-lib-constants/ValidationErrorCode.ts
     * @param {any} [messageParameters] any parameters required by the message translation
     * @returns {CsError} the CsError raised
     */
    CsErrorContext.prototype.RaiseCsError = function (statusCode, errorDescriptor, messageParameters) {
        Logger.error(errorDescriptor.Code + " : " + errorDescriptor.Message, messageParameters);
        this._processError = new CsError(statusCode, errorDescriptor.Code, messageParameters);
        this._processError.message = this.GetErrorMessageFromConstants(errorDescriptor.Code, messageParameters);
        this._processError.errorCode = errorDescriptor.Code;
        return this._processError;
    };
    /**
     * Raises a CsError for the data access result provided
     * @param {DataAccessResult} result The data access result
     * @param {string} entityId? The entity ID
     * @returns {CsError}
     */
    CsErrorContext.prototype.RaiseCsErrorForDataAccessResult = function (result, entityId) {
        switch (result) {
            case DataAccessResult.Successful:
                return undefined;
            case DataAccessResult.DatastoreNotAvailable:
                return this.RaiseCsError(500, ErrorCode.Find.DatastoreNotAvailable, null);
            case DataAccessResult.NoProductSpecificationFound:
                return this.RaiseCsError(404, ErrorCode.Find.NotFound, null);
            case DataAccessResult.NoProductIdSupplied:
                return this.RaiseCsError(400, ErrorCode.Find.BadID, null);
            case DataAccessResult.BadData:
                return undefined;
            default:
                return this.RaiseCsError(500, ErrorCode.Find.UnknownError, { EntityId: entityId });
        }
    };
    /**
     * Add a CsError to the context
     */
    CsErrorContext.prototype.AddCsError = function (error) {
        this._processError = error;
    };
    /**
     * Raises a compatibility error
     * @param {CsTypes.CompatibilityRule} rule The rule to raise an error for
     * @param {string} errorCode The error code
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.PhaseCodes} Phase error Codes of Compatibility rule
     * @param {string} Entity(container of Compatibility rule)'s Parent Entity ID
     * @param {string} Entity(container of Compatibility rule)'s Parent Entity unique code
     * @ returns {string}
     */
    CsErrorContext.prototype.RaiseCompatibilityError = function (rule, errorDescriptor, orderfolioItem, decomposeContext, phaseCodes, parentEntityID, parentEntityUniqueCode) {
        var errorId = Utilities.GenerateGuid();
        this._compatibilityErrors[errorId] = new CsCompatibilityError(errorId, rule, errorDescriptor.Code, orderfolioItem, decomposeContext, phaseCodes, parentEntityID, parentEntityUniqueCode);
        return errorId;
    };
    /**
     * Raises a bad data error
     * @param   {string} errorCode The error code
     * @param   {string} entityId The Entity ID of the Bad Data
     * @param   {string} badDataType The category of bad data
     * @param   {any}   messageParameters any parameters required by the message translation
     * @param   {string} sourceEntityId The source entity ID, if any
     * @param   {string} targetEntityId The target entity ID, if any
     * @returns {string}
     */
    CsErrorContext.prototype.RaiseBadDataError = function (errorDescriptor, entityId, badDataType, messageParameters, sourceEntityId, targetEntityId) {
        var errorId = Utilities.GenerateGuid();
        this._badDataErrors[errorId] = new CsBadDataError(errorId, errorDescriptor.Code, entityId, badDataType, messageParameters, sourceEntityId, targetEntityId);
        return errorId;
    };
    /**
     * Adds bad data errors
     * @param {CsBadDataError[]} badDataErrors The bad data errors to add
     */
    CsErrorContext.prototype.AddBadDataErrors = function (badDataErrors) {
        var _this = this;
        badDataErrors.forEach(function (err) {
            _this._badDataErrors[err.ErrorId] = err;
        });
    };
    /**
     * Raise a severe validation error
     * @param {string} errorCode the error code, see cs-lib-constants/ValidationErrorCode.ts
     * @param {string} entityUniqueCode the ID of the entity which raised the error (PortfolioItemID or OrderItemID)
     * @param {string} entityId the entities guid
     * @param {any} [messageParameters] any parameters required by the message translation
     * @param {string} [extraInfo] any extra information to be added to the error, mainly for development purposes
     * @param {string} [xsiType] The Xsi type of the element that has been violated
     * @returns {string} the errorId assigned to the Error
     */
    CsErrorContext.prototype.RaiseSevereValidationError = function (errorDescriptor, entityUniqueCode, entityId, messageParameters, extraInfo, xsiType) {
        return this.RaiseValidationErrorWithChildInfo(errorDescriptor, entityUniqueCode, entityId, null, null, messageParameters, extraInfo, xsiType, true, undefined);
    };
    /**
     * Raise a validation error
     * @param {string} errorCode the error code, see cs-lib-constants/ValidationErrorCode.ts
     * @param {string} entityUniqueCode the ID of the entity which raised the error (PortfolioItemID or OrderItemID)
     * @param {string} entityId the entities guid
     * @param {any} [messageParameters] any parameters required by the message translation
     * @param {string} [extraInfo] any extra information to be added to the error, mainly for development purposes
     * @param {string} [xsiType] The Xsi type of the element that has been violated
     * @returns {string} the errorId assigned to the Error
     */
    CsErrorContext.prototype.RaiseValidationError = function (errorDescriptor, entityUniqueCode, entityId, messageParameters, extraInfo, xsiType, phaseCodes) {
        return this.RaiseValidationErrorWithChildInfo(errorDescriptor, entityUniqueCode, entityId, null, null, messageParameters, extraInfo, xsiType, false, phaseCodes);
    };
    /**
     * Raise a validation error which includes child information
     * @param {string} errorCode the error code, see cs-lib-constants/ValidationErrorCode.ts
     * @param {string} entityUniqueCode the ID of the entity which raised the error (PortfolioItemID or OrderItemID)
     * @param {string} entityId the entities guid
     * @param {string} childUniqueCode the ID of the child entity which raised the error (PortfolioItemID or OrderItemID)
     * @param {string} childId the child entities guid
     * @param {any} [messageParameters] any parameters required by the message translation
     * @param {string} [extraInfo] any extra information to be added to the error, mainly for development purposes
     * @param {string} [xsiType] The Xsi type of the element that has been violated
     * @param {boolean} [isSevere] flag to determine if the validation error is severe and prevent further processing
     * @returns {string} the errorId assigned to the Error
     */
    CsErrorContext.prototype.RaiseValidationErrorWithChildInfo = function (errorDescriptor, entityUniqueCode, entityId, childUniqueCode, childId, messageParameters, extraInfo, xsiType, isSevere, phaseCodes) {
        var errorId = Utilities.GenerateGuid();
        this._validationErrors[errorId] = new CsValidationError(errorId, errorDescriptor.Code, entityUniqueCode, entityId, messageParameters, childUniqueCode, childId, extraInfo, xsiType, isSevere, phaseCodes);
        return errorId;
    };
    /**
     * Set a set of properties on an existing validation error
     * @param {string} errorId the Id of the error to update
     * @param {any} newInfo an object containing the properties to update
     * @returns {string} the errorid
     */
    CsErrorContext.prototype.UpdateValidationError = function (errorId, newInfo) {
        if (Utilities.IsNotDefined(errorId) || Utilities.IsNotDefined(newInfo)) {
            return errorId;
        }
        var error = this._validationErrors[errorId];
        if (Utilities.IsNotDefined(error)) {
            return errorId;
        }
        Object.keys(newInfo).forEach(function (key) {
            error[key] = newInfo[key];
        });
        return errorId;
    };
    /**
     * Creates an array of ValidationErrors from all errors raised to date
     * The returned array is suitable for inclusion in the OrderCandidateResponse
     * @param {DecomposeGenIdController} decomposeController (Optional) The decompose controller
     * @returns {Array<ValidationError>}
     */
    CsErrorContext.prototype.GetValidationErrorsForResponse = function (decomposeController) {
        var _this = this;
        var valErrors = [];
        Object.keys(this._validationErrors).forEach(function (valErrorId) {
            var error = _this._validationErrors[valErrorId];
            var contextParameters = _this.BuildContextParametersResponse(error);
            var extraInfo = _this._includeExtraInfo ? error.ExtraInfo : undefined;
            _this.MapError(error, contextParameters, decomposeController);
            var valError = new ValidationError(error.EntityUniqueCode, _this.TruncateErrorCode(error.ErrorCode), _this.ComposeErrorMessage(error), contextParameters, error.EntityId, error.ChildId, extraInfo, error.XsiType, error.PhaseCodes);
            valError.ContextParameters.push({ Name: "ChildUniqueCode", Value: Utilities.ValueOrDefault(error.ChildUniqueCode, '') });
            valError.ChildUniqueCode = error.ChildUniqueCode;
            valErrors.push(valError);
        });
        Object.keys(this._compatibilityErrors).forEach(function (compatErrorId) {
            var compError = _this._compatibilityErrors[compatErrorId];
            var compatibilityError = new CompatibilityError(compError);
            compatibilityError.ErrorCode = _this.TruncateErrorCode(compError.ErrorCode);
            // Build context parameter for the parent information
            compatibilityError.ContextParameters = _this.BuildContextParametersResponse(compError);
            valErrors.push(compatibilityError);
        });
        return valErrors;
    };
    /**
     * Gets the bad data errors response for this CsErrorContext
     * @returns {BadDataErrorsResponse}
     */
    CsErrorContext.prototype.GetBadDataErrorsResponse = function () {
        var _this = this;
        var badDataErrors = [];
        var csBadDataErrors = this.GetBadDataErrors();
        csBadDataErrors.forEach(function (error) {
            var message = _this._i18N.translate(error.ErrorCode, error.MessageParameters);
            var contextParameters = _this.BuildContextParametersResponse(error);
            var errorCode = _this.TruncateErrorCode(error.ErrorCode);
            var badDataError = new BadDataError(errorCode, error.BadDataType, message, error.EntityId, contextParameters, error.SourceEntityId, error.TargetEntityId, error.ExtraInfo);
            badDataErrors.push(badDataError);
        });
        var badDataErrorsResponse = new BadDataErrorsResponse(this._badDataStatusCode, 'Inconsistencies in Catalog Services Data', badDataErrors);
        //Allow the status code to be specified to a different status code rather than the defaulted 500
        if (Utilities.IsDefined(this._badDataStatusCode)) {
            if (Utilities.IsNumeric(this._badDataStatusCode) && this._badDataStatusCode !== 500) {
                badDataErrorsResponse.StatusCode = this._badDataStatusCode;
            }
        }
        return badDataErrorsResponse;
    };
    /**
     * Returns all of the values in the badDataErrors dictionary
     * @returns {Array<CsBadDataError>}
     */
    CsErrorContext.prototype.GetBadDataErrors = function () {
        return LodashUtilities.Values(this._badDataErrors);
    };
    /**
     * Gets the specification errors for this CsErrorContext
     * @returns {ISpecificationError}
     */
    CsErrorContext.prototype.GetSpecificationErrors = function () {
        var specificationError = {
            ProcessError: this._processError,
            BadDataErrors: this.GetBadDataErrors()
        };
        return specificationError;
    };
    /**
     * Merges the current CsErrorContext with the one passed in
     * @param {CsErrorContext} toBeMerged The CsErrorContext to merge with
     */
    CsErrorContext.prototype.Merge = function (toBeMerged) {
        var _this = this;
        if (Utilities.IsNotDefined(toBeMerged)) {
            return;
        }
        var badDataErrors = toBeMerged.GetBadDataErrors();
        badDataErrors.forEach(function (badDataError) {
            _this._badDataErrors[badDataError.ErrorId] = badDataError;
        });
    };
    /**
     * Compose the error message for a CsValidationError
     * If a translator has not been defined, then returns the index into the translation file
     * @param {CsValidationError} error the error object to create the message for
     * @returns {string} the translated string, or the index to the translated string if the trans
     */
    CsErrorContext.prototype.ComposeErrorMessage = function (error) {
        var translatedMessage;
        if (Utilities.IsNotDefined(this._i18N) || Utilities.IsNotDefined(this._i18N.translate)) {
            translatedMessage = this.GetErrorMessageFromConstants(error.ErrorCode, error.MessageParameters);
        }
        else {
            translatedMessage = this._i18N.translate(error.ErrorCode, error.MessageParameters);
        }
        if (Utilities.IsDefined(translatedMessage)) {
            translatedMessage = translatedMessage.trim();
        }
        return translatedMessage;
    };
    CsErrorContext.prototype.GetErrorMessageFromConstants = function (errorCode, messageParameters) {
        var errorCodes = this._errorCode;
        var splitErrorCode = errorCode.split(".");
        var message = "";
        Object.keys(this._errorCode).forEach(function (key) {
            var errorGroup = errorCodes[key];
            if (errorGroup[splitErrorCode[1]] !== undefined) {
                switch (splitErrorCode.length) {
                    case 2: {
                        message = errorGroup[splitErrorCode[1]].Message;
                        break;
                    }
                    case 3: {
                        if (errorGroup[splitErrorCode[1]][splitErrorCode[2]] !== undefined) {
                            message = errorGroup[splitErrorCode[1]][splitErrorCode[2]].Message;
                        }
                        break;
                    }
                    case 4: {
                        if (errorGroup[splitErrorCode[1]][splitErrorCode[2]][splitErrorCode[3]]) {
                            message = errorGroup[splitErrorCode[1]][splitErrorCode[2]][splitErrorCode[3]].Message;
                        }
                        break;
                    }
                    default: {
                        return errorCode;
                    }
                }
            }
        });
        // If we cant find message at this point then lets just return the error code for now
        if (message === "") {
            return errorCode;
        }
        // Replace all wildcards in the error message with message parameters
        if (Utilities.IsDefined(messageParameters) && message.indexOf("__") >= 0) {
            for (var key in messageParameters) {
                if (messageParameters.hasOwnProperty(key)) {
                    message = message.replace("__" + key + "__", messageParameters[key]);
                }
            }
        }
        return message;
    };
    /**
     * Builds the context parameters for the bad data errors response
     * @param {CsValidationError} csValidationError
     * @returns {ContextParameter[]}
     */
    CsErrorContext.prototype.BuildContextParametersResponse = function (csValidationError) {
        var contextParameters = [];
        Object.keys(csValidationError.MessageParameters).forEach(function (key) {
            var messageParameterValue = csValidationError.MessageParameters[key];
            if (Utilities.IsNotDefined(messageParameterValue)) {
                return;
            }
            contextParameters.push(new ContextParameter(key, messageParameterValue));
        });
        return contextParameters;
    };
    /**
     * Maps the ID's in a validation error and its context parameters
     * @param  {CsValidationError}        error               The validation error
     * @param  {ContextParameter[]}       contextParameters   The context parameters
     * @param  {DecomposeGenIdController} decomposeController The decompose controller to do the mapping
     */
    CsErrorContext.prototype.MapError = function (error, contextParameters, decomposeController) {
        if (Utilities.IsNotDefined(decomposeController)) {
            return;
        }
        error.EntityUniqueCode = decomposeController.MapId(error.EntityUniqueCode);
        error.ChildUniqueCode = decomposeController.MapId(error.ChildUniqueCode);
        contextParameters.forEach(function (contextParameter) {
            switch (contextParameter.Name.toLowerCase()) {
                // These are the currently used context parameters that would need to be re-mapped
                // This list may need to be updated at a later stage if more are added
                case "orderitemid":
                case "portfolioitemid":
                case "entityuniquecode":
                case "childuniquecode":
                    contextParameter.Value = decomposeController.MapId(contextParameter.Value);
                    break;
                default:
                    break;
            }
        });
    };
    /**
     * Truncate the error code, if set to true remove error category from the error code.
     * @param  {errorCode} The error code
     */
    CsErrorContext.prototype.TruncateErrorCode = function (errorCode) {
        if (Utilities.IsDefined(errorCode, true)) {
            var truncatedError = errorCode.substring(errorCode.indexOf(".") + 1, errorCode.length);
            return truncatedError;
        }
        return errorCode;
    };
    return CsErrorContext;
}());
module.exports = CsErrorContext;

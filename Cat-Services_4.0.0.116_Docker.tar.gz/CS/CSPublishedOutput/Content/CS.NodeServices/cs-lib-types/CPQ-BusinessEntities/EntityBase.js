"use strict";
var EntityLink = require("../BusinessEntities/EntityLink");
var Utilities = require("../../cs-lib-utilities/Utilities");
var RateAttribute = require("../BusinessEntities/RateAttribute");
var CharacteristicUse = require("../BusinessEntities/CharacteristicUse");
var ConfiguredValueUse = require("./ConfiguredValueUse");
var Rate = require("./Pricing/Rate");
var EntityBase = /** @class */ (function () {
    /**
     * Creates a new instance of the EntityBase object
     * @param entityBase The entityBase object to use to populate this one
     * @param recursiveNew Recursively initializes the child entities
     */
    function EntityBase(entityBase, recursiveNew) {
        var _this = this;
        /**
         *The child entities associated with the candidate
         */
        this.ChildEntities = [];
        /**
         * Holds a reference to the characteristics of the product
         */
        this.CharacteristicUses = [];
        /**
         * Holds a reference to the rating attributes of the product
         */
        this.RateAttributes = [];
        /**
         * Holds a reference to any configured values on the product
         */
        this.ConfiguredValues = [];
        /**
         * Holds a reference to the list of entities that this entity links to
         */
        this.LinkedEntities = [];
        if (!entityBase) {
            return;
        }
        this.ID = Utilities.ValueOrDefault(entityBase.ID, null);
        this.EntityID = Utilities.ValueOrDefault(entityBase.EntityID, null, true);
        this._IsNewForCustomer = entityBase._IsNewForCustomer;
        this.Rate = new Rate(entityBase.Rate);
        this.ChargeNotProvided = Utilities.ValueOrDefault(entityBase.ChargeNotProvided, []);
        this.UnitQuantity = Utilities.ValueOrDefault(entityBase.UnitQuantity, undefined);
        if (entityBase.CharacteristicUses) {
            var characteristicUses = Utilities.asArray(entityBase.CharacteristicUses);
            characteristicUses.forEach(function (characteristicUse) { _this.CharacteristicUses.push(new CharacteristicUse(characteristicUse)); });
        }
        if (entityBase.RateAttributes) {
            var rateAttributes = Utilities.asArray(entityBase.RateAttributes);
            rateAttributes.forEach(function (ratingAttribute) { _this.RateAttributes.push(new RateAttribute(ratingAttribute)); });
        }
        if (entityBase.ConfiguredValues) {
            var configuredValues = Utilities.asArray(entityBase.ConfiguredValues);
            configuredValues.forEach(function (configuredValue) { _this.ConfiguredValues.push(new ConfiguredValueUse(configuredValue)); });
        }
        if (entityBase.LinkedEntities) {
            var linkedEntities = Utilities.asArray(entityBase.LinkedEntities);
            linkedEntities.forEach(function (linkedEntity) { _this.LinkedEntities.push(new EntityLink(linkedEntity)); });
        }
        if (entityBase.ChildEntities && recursiveNew) {
            // Typescript can't handle recursive inheritance, so we need to use a function to recursively create children
            var childEntities = Utilities.asArray(entityBase.ChildEntities);
            childEntities.forEach(function (childEntity) { _this.ChildEntities.push(recursiveNew(childEntity)); });
        }
    }
    return EntityBase;
}());
module.exports = EntityBase;

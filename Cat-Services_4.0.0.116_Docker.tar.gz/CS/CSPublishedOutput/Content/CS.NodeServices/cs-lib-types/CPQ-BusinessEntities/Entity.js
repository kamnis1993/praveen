"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var EntityBase = require("./EntityBase");
/**
 * Class describes an Entity for a product candidate
 */
var Entity = /** @class */ (function (_super) {
    __extends(Entity, _super);
    /**
     * Creates a new instance of the Entity object
     * @param {IEntity} entity? The entity used to populate this one
     */
    function Entity(entity) {
        var _this = _super.call(this, entity, function (i) { return new Entity(i); }) || this;
        /**
         * Indicates if technical children should be included in this candidate
         */
        _this._IncludeTechnicalChildren = true;
        if (!entity) {
            return _this;
        }
        if (entity._IncludeTechnicalChildren !== undefined) {
            _this._IncludeTechnicalChildren = entity._IncludeTechnicalChildren;
        }
        return _this;
    }
    /**
     * Removes any data on this object that is considered internal only
     */
    Entity.prototype.RemoveInternalData = function () {
        for (var c = 0; c < this.CharacteristicUses.length; c++) {
            this.CharacteristicUses[c].RemoveInternalData();
        }
        for (var c = 0; c < this.ChildEntities.length; c++) {
            this.ChildEntities[c].RemoveInternalData();
        }
    };
    return Entity;
}(EntityBase));
module.exports = Entity;

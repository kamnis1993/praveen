"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a configured value use
 */
var ConfiguredValueUse = /** @class */ (function () {
    /**
     * Creates a new isntance of ConfiguredValueUse
     * @param {IConfiguredValueUse} configuredValueUse? The configured value use used to create this one
     */
    function ConfiguredValueUse(configuredValueUse) {
        var _this = this;
        /**
         * The configured value
         */
        this.Value = [];
        if (!configuredValueUse) {
            return;
        }
        this.UseID = configuredValueUse.UseID;
        this.CharacteristicID = configuredValueUse.CharacteristicID;
        this.UseArea = configuredValueUse.UseArea;
        if (configuredValueUse.Value) {
            var configuredValues = Utilities.asArray(configuredValueUse.Value);
            configuredValues.forEach(function (configuredValue) { _this.Value.push(configuredValue); });
        }
    }
    return ConfiguredValueUse;
}());
module.exports = ConfiguredValueUse;

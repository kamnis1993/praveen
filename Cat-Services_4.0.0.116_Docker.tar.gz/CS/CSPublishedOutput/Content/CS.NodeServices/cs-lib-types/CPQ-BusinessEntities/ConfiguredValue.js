"use strict";
/**
 * Class describes a configured value
 */
var ConfiguredValue = /** @class */ (function () {
    /**
     * Creates a new instance of configured value
     * @param {IConfiguredValue} configuredValue? The configured value used to populate this one
     */
    function ConfiguredValue(configuredValue) {
        if (!configuredValue) {
            return;
        }
        this.Value = configuredValue.Value;
        this.ValueDetail = configuredValue.ValueDetail;
    }
    return ConfiguredValue;
}());
module.exports = ConfiguredValue;

"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var ChargeNotProvided = /** @class */ (function () {
    function ChargeNotProvided(chargeNotProvided) {
        this.ChargeGuid = Utilities.ValueOrDefault(chargeNotProvided.ChargeGuid, undefined);
        this.Description = Utilities.ValueOrDefault(chargeNotProvided.Description, undefined);
    }
    return ChargeNotProvided;
}());
module.exports = ChargeNotProvided;

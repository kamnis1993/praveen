"use strict";
/**
 * Class describes a Contextual Parameter
 */
var ContextualParameter = /** @class */ (function () {
    /**
     * Creates a new instance of the ContextualParameter object
     * @param {IContextualParameter} contextualParameter The contextual parameter
     */
    function ContextualParameter(contextualParameter) {
        if (!contextualParameter) {
            return;
        }
        this.Value = contextualParameter.Value;
    }
    return ContextualParameter;
}());
module.exports = ContextualParameter;

"use strict";
var ProductCandidate = require("./ProductCandidate");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that describes a product candidate request
 */
var ProductCandidateRequest = /** @class */ (function () {
    /**
     * constructor
     * @param {IProductCandidateRequest} productCandidateRequest The product candidate request
     */
    function ProductCandidateRequest(productCandidateRequest) {
        /**
        * The list of contextual parameters
        */
        this.ContextualParameters = [];
        if (Utilities.IsNotDefined(productCandidateRequest)) {
            this.CreationDate = new Date(Date.now());
            this.ContextualParameters = [];
            this.ProductCandidate = new ProductCandidate();
            return;
        }
        this.CreationDate = Utilities.IsValidDate(productCandidateRequest.CreationDate) ? productCandidateRequest.CreationDate : undefined;
        this.ContextualParameters = Utilities.asArray(productCandidateRequest.ContextualParameters);
        this.ProductCandidate = Utilities.IsDefined(productCandidateRequest.ProductCandidate) ? new ProductCandidate(productCandidateRequest.ProductCandidate) : undefined;
    }
    return ProductCandidateRequest;
}());
module.exports = ProductCandidateRequest;

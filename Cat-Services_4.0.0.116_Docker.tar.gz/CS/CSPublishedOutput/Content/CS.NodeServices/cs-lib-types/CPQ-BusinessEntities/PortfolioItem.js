"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var ProductCandidate = require("./ProductCandidate");
/**
 * Class describes a Product Candidate that forms part of a portfolio item
 */
var PortfolioItem = /** @class */ (function () {
    /**
     * Creates a new instance of the ProductCandidate object
     * @param productCandidate The productCandidate object to use to populate this one
     */
    function PortfolioItem(portfolioItem) {
        if (Utilities.IsNotDefined(portfolioItem)) {
            return;
        }
        this._ID = Utilities.ValueOrDefault(portfolioItem._ID, undefined);
        this.CreationDate = Utilities.ValueOrDefault(portfolioItem.CreationDate, undefined);
        this.ProductCandidate = Utilities.IsDefined(portfolioItem.ProductCandidate) ? new ProductCandidate(portfolioItem.ProductCandidate) : undefined;
    }
    return PortfolioItem;
}());
module.exports = PortfolioItem;

"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var ContextualParameter = require("../CPQ-BusinessEntities/ContextualParameter");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var PortfolioItem = require("../CPQ-BusinessEntities/PortfolioItem");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class describes a Portfolio Candidate
 */
var PortfolioCandidate = /** @class */ (function () {
    /**
     * Creates a new instance of the PortfolioCandidate object
     * @param portfolioCandidate The IPortfolioCandidate object to use to populate this one
     */
    function PortfolioCandidate(portfolioCandidate) {
        var _this = this;
        this.HasErrors = false;
        this.PortfolioItems = [];
        this.ContextualParameters = [];
        if (Utilities.IsNotDefined(portfolioCandidate)) {
            return;
        }
        var portfolioItems = Utilities.asArray(portfolioCandidate.PortfolioItems);
        portfolioItems.forEach(function (p) {
            var newPortfolio = new PortfolioItem(p);
            if (Utilities.IsNotDefined(newPortfolio.CreationDate)) {
                _this.HasErrors = true;
                _this.ErrorDescriptor = ErrorCode.Validation.PortfolioCandidate.InvalidDate;
            }
            _this.PortfolioItems.push(newPortfolio);
        });
        if (this.PortfolioItems.length === 0) {
            this.HasErrors = true;
            this.ErrorDescriptor = ErrorCode.Validation.PortfolioCandidate.NoPortfolioSupplied;
        }
        if (Utilities.IsDefined(portfolioCandidate.ContextualParameters)) {
            portfolioCandidate.ContextualParameters.forEach(function (c) {
                _this.ContextualParameters.push(new ContextualParameter(c));
            });
        }
    }
    Object.defineProperty(PortfolioCandidate.prototype, "IsEmpty", {
        get: function () {
            return this.PortfolioItems.length === 0;
        },
        enumerable: true,
        configurable: true
    });
    return PortfolioCandidate;
}());
module.exports = PortfolioCandidate;

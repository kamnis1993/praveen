"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that represents a Discount Class
 */
var DiscountClass = /** @class */ (function () {
    function DiscountClass(discountClass) {
        if (Utilities.IsNotDefined(discountClass)) {
            return;
        }
        this._ID = Utilities.ValueOrDefault(discountClass._ID, undefined, true);
        this.Name = Utilities.ValueOrDefault(discountClass.Name, undefined);
        this.Description = Utilities.ValueOrDefault(discountClass.Description, undefined);
    }
    return DiscountClass;
}());
module.exports = DiscountClass;

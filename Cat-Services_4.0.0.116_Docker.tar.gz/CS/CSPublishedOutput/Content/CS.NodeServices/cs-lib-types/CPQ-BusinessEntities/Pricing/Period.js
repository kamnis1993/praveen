"use strict";
/**
 * Class that represents a period
 */
var Period = /** @class */ (function () {
    function Period(name, minumumTotal, finalTotal, adjustmentTotal, originalTotal) {
        this.Name = name;
        this.MinimumTotal = minumumTotal;
        this.FinalTotal = finalTotal;
        this.AdjustmentTotal = adjustmentTotal;
        this.OriginalTotal = originalTotal;
    }
    return Period;
}());
module.exports = Period;

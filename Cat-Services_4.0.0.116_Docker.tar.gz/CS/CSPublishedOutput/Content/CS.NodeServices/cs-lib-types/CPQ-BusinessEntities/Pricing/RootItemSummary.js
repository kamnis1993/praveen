"use strict";
var Summary = require("./Summary");
var Utilities = require("../../../cs-lib-utilities/Utilities");
/**
 * Class describes a root item summar for pricing
 */
var RootItemSummary = /** @class */ (function () {
    function RootItemSummary(entityUniqueCode) {
        this.EntityUniqueCode = Utilities.ValueOrDefault(entityUniqueCode, undefined);
        this.ItemSummary = new Summary();
    }
    return RootItemSummary;
}());
module.exports = RootItemSummary;

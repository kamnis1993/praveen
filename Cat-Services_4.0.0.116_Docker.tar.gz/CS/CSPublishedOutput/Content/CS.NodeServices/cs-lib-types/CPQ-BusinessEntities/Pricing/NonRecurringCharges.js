"use strict";
/**
 * Class that represents a non recurring charge
 */
var NonRecurringCharges = /** @class */ (function () {
    function NonRecurringCharges() {
        this.MinimumTotal = 0;
        this.FinalTotal = 0;
        this.AdjustmentTotal = 0;
        this.OriginalTotal = 0;
    }
    return NonRecurringCharges;
}());
module.exports = NonRecurringCharges;

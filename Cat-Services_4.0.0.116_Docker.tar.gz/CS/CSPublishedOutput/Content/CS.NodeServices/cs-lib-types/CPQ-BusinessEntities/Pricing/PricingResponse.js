"use strict";
var Utilities = require("../../../cs-lib-utilities/Utilities");
var PricingResponse = /** @class */ (function () {
    function PricingResponse(pricingResponse) {
        if (Utilities.IsNotDefined(pricingResponse)) {
            return;
        }
        this.Pricing = pricingResponse.Pricing;
    }
    return PricingResponse;
}());
module.exports = PricingResponse;

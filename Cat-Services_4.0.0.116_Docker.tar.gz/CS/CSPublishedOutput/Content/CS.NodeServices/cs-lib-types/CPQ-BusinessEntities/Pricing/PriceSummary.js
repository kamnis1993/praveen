"use strict";
var Summary = require("./Summary");
/**
 * Class describes a Price Summary for pricing
 */
var PriceSummary = /** @class */ (function () {
    function PriceSummary() {
        this.RootItemSummary = [];
        this.GrandSummary = new Summary();
    }
    return PriceSummary;
}());
module.exports = PriceSummary;

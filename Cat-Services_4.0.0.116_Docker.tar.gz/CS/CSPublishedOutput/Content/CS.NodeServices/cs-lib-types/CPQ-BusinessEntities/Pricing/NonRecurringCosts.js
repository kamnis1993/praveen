"use strict";
/**
 * Class that represents a non recurring cost
 */
var NonRecurringCosts = /** @class */ (function () {
    function NonRecurringCosts() {
        this.MinimumTotal = 0;
        this.FinalTotal = 0;
    }
    return NonRecurringCosts;
}());
module.exports = NonRecurringCosts;

"use strict";
var Utilities = require("../../../cs-lib-utilities/Utilities");
/**
 * Class describes a Product Candidate that forms part of a portfolio item
 */
var IgnoredCharge = /** @class */ (function () {
    /**
     * Creates a new instance of the ProductCandidate object
     * @param productCandidate The productCandidate object to use to populate this one
     */
    function IgnoredCharge(ignoredCharge) {
        if (Utilities.IsNotDefined(ignoredCharge)) {
            return;
        }
        this.ID = Utilities.ValueOrDefault(ignoredCharge.ID, undefined, true);
        this.Reason = Utilities.ValueOrDefault(ignoredCharge.Reason, undefined);
        this.ReasonDetails = Utilities.ValueOrDefault(ignoredCharge.ReasonDetails, undefined);
    }
    return IgnoredCharge;
}());
module.exports = IgnoredCharge;

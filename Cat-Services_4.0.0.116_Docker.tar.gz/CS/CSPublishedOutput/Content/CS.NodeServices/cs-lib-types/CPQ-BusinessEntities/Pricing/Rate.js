"use strict";
var Utilities = require("../../../cs-lib-utilities/Utilities");
var Rate = /** @class */ (function () {
    function Rate(rate) {
        /**
         * The rating attributes
         */
        this.RatingAttributes = [];
        if (Utilities.IsNotDefined(rate)) {
            return;
        }
        this.ID = Utilities.ValueOrDefault(rate.ID, undefined, true);
        this.Type = Utilities.ValueOrDefault(rate.Type, undefined);
        this.Start_Date = Utilities.ValueOrDefault(rate.Start_Date, undefined);
        this.End_Date = Utilities.ValueOrDefault(rate.End_Date, undefined);
        this.Value = Utilities.ValueOrDefault(rate.Value, undefined);
    }
    return Rate;
}());
module.exports = Rate;

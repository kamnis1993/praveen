"use strict";
/**
 * Class that represents recurring costs
 */
var RecurringCosts = /** @class */ (function () {
    function RecurringCosts() {
        this.Periods = [];
    }
    return RecurringCosts;
}());
module.exports = RecurringCosts;

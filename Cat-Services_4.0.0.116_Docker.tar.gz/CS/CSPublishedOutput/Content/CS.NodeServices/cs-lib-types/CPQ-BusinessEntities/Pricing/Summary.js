"use strict";
var NonRecurringCharges = require("./NonRecurringCharges");
var NonRecurringCosts = require("./NonRecurringCosts");
var RecurringCharges = require("./RecurringCharges");
var RecurringCosts = require("./RecurringCosts");
/**
 * Class describes a Summary of the summing of charges
 */
var Summary = /** @class */ (function () {
    function Summary() {
        this.RecurringCharges = new RecurringCharges();
        this.NonRecurringCharges = new NonRecurringCharges();
        this.IgnoredCharges = [];
        this.RecurringCosts = new RecurringCosts();
        this.NonRecurringCosts = new NonRecurringCosts();
        this.IgnoredCosts = [];
        this.IgnoredDiscounts = [];
    }
    return Summary;
}());
module.exports = Summary;

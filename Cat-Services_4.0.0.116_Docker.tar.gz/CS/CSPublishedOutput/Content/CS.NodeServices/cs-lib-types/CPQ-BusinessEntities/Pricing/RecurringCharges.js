"use strict";
/**
 * Class that represents recurring charges
 */
var RecurringCharges = /** @class */ (function () {
    function RecurringCharges() {
        this.Periods = [];
    }
    return RecurringCharges;
}());
module.exports = RecurringCharges;

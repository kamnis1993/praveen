"use strict";
var ProductCandidate = require("./ProductCandidate");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that describes a product candidate request
 */
var ProductCandidateResponse = /** @class */ (function () {
    /**
     * Creates a new instance of the product candidate response object
     * @param {IProductCandidateRequest} productCandidateResponse the object to use to populate this one
     */
    function ProductCandidateResponse(productCandidateResponse) {
        /**
        * Any validation errors on this candidate response
        */
        this.ValidationErrors = [];
        /**
        * The list of contextual parameters
        */
        this.ContextualParameters = [];
        if (!productCandidateResponse) {
            return;
        }
        this.CreationDate = productCandidateResponse.CreationDate;
        this.ContextualParameters = Utilities.asArray(productCandidateResponse.ContextualParameters);
        this.ProductCandidate = new ProductCandidate(productCandidateResponse.ProductCandidate);
        this.ValidationErrors = productCandidateResponse.ValidationErrors;
    }
    /**
     * Removes any data on this object that is considered internal only
     */
    ProductCandidateResponse.prototype.RemoveInternalData = function () {
        for (var c = 0; c < this.ProductCandidate.CharacteristicUses.length; c++) {
            this.ProductCandidate.CharacteristicUses[c].RemoveInternalData();
        }
        for (var c = 0; c < this.ProductCandidate.ChildEntities.length; c++) {
            this.ProductCandidate.ChildEntities[c].RemoveInternalData();
        }
    };
    return ProductCandidateResponse;
}());
module.exports = ProductCandidateResponse;

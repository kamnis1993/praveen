"use strict";
/// <reference types="node" />
var MappingTriggerType;
(function (MappingTriggerType) {
    MappingTriggerType[MappingTriggerType["Unknown"] = 0] = "Unknown";
    MappingTriggerType[MappingTriggerType["Decompose"] = 1] = "Decompose";
    MappingTriggerType[MappingTriggerType["CommercialDecompose"] = 2] = "CommercialDecompose";
})(MappingTriggerType || (MappingTriggerType = {}));
module.exports = MappingTriggerType;

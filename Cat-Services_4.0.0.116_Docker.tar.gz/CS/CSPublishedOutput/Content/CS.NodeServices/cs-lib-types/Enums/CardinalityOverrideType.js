"use strict";
/// <reference types="node" />
/**
 * Defines the type of cardinality override
 */
var CardinalityOverrideType;
(function (CardinalityOverrideType) {
    CardinalityOverrideType[CardinalityOverrideType["Relational"] = 0] = "Relational";
    CardinalityOverrideType[CardinalityOverrideType["Group"] = 1] = "Group";
})(CardinalityOverrideType || (CardinalityOverrideType = {}));
module.exports = CardinalityOverrideType;

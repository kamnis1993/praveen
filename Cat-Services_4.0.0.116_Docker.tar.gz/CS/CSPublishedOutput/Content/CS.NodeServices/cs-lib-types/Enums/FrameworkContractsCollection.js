"use strict";
/**
 * Enum containing the Framework Contracts Collection names
 */
var FrameworkContractsCollection;
(function (FrameworkContractsCollection) {
    FrameworkContractsCollection[FrameworkContractsCollection["TechnicalSpecs"] = 0] = "TechnicalSpecs";
    FrameworkContractsCollection[FrameworkContractsCollection["CommercialSpecs"] = 1] = "CommercialSpecs";
    FrameworkContractsCollection[FrameworkContractsCollection["CompiledSpecs"] = 2] = "CompiledSpecs";
})(FrameworkContractsCollection || (FrameworkContractsCollection = {}));
module.exports = FrameworkContractsCollection;

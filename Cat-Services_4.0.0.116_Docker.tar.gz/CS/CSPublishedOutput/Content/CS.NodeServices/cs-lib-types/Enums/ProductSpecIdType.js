"use strict";
/**
 * Enum containing the different Ids that can be used to identify a product specification
 */
var ProductSpecIdType;
(function (ProductSpecIdType) {
    ProductSpecIdType[ProductSpecIdType["Guid"] = 0] = "Guid";
    ProductSpecIdType[ProductSpecIdType["BusinessId"] = 1] = "BusinessId";
})(ProductSpecIdType || (ProductSpecIdType = {}));
module.exports = ProductSpecIdType;

"use strict";
/**
 * TODO: Specifies the boundaries that can exist on a Product Specification
 */
var BoundaryCondition;
(function (BoundaryCondition) {
    BoundaryCondition[BoundaryCondition["Technical"] = 0] = "Technical";
    BoundaryCondition[BoundaryCondition["Commercial"] = 1] = "Commercial";
})(BoundaryCondition || (BoundaryCondition = {}));
module.exports = BoundaryCondition;

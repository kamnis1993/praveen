"use strict";
/// <reference types="node" />
var DataImportStatus;
(function (DataImportStatus) {
    DataImportStatus[DataImportStatus["Pending"] = 0] = "Pending";
    DataImportStatus[DataImportStatus["Started"] = 1] = "Started";
    DataImportStatus[DataImportStatus["Successful"] = 2] = "Successful";
    DataImportStatus[DataImportStatus["Failed"] = 3] = "Failed";
})(DataImportStatus || (DataImportStatus = {}));
module.exports = DataImportStatus;

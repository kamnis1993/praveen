"use strict";
/*
 * The available collections on an order candidate request
 */
var OrderCandidateRequestCollection;
(function (OrderCandidateRequestCollection) {
    OrderCandidateRequestCollection[OrderCandidateRequestCollection["PortfolioItems"] = 0] = "PortfolioItems";
    OrderCandidateRequestCollection[OrderCandidateRequestCollection["OrderItems"] = 1] = "OrderItems";
})(OrderCandidateRequestCollection || (OrderCandidateRequestCollection = {}));
module.exports = OrderCandidateRequestCollection;

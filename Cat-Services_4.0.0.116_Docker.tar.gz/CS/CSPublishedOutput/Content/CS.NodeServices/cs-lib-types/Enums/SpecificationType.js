"use strict";
/**
 * Enum containing the different types of product specification
 */
var SpecificationType;
(function (SpecificationType) {
    SpecificationType[SpecificationType["External"] = 0] = "External";
    SpecificationType[SpecificationType["Internal"] = 1] = "Internal";
    SpecificationType[SpecificationType["Compiled"] = 2] = "Compiled";
})(SpecificationType || (SpecificationType = {}));
module.exports = SpecificationType;

"use strict";
/// <reference types='node'/>
var RequestType;
(function (RequestType) {
    RequestType[RequestType["Unset"] = 0] = "Unset";
    RequestType[RequestType["ProductCandidate"] = 1] = "ProductCandidate";
    RequestType[RequestType["OrderCandidate"] = 2] = "OrderCandidate";
    RequestType[RequestType["OrderGeneration"] = 3] = "OrderGeneration";
    RequestType[RequestType["PortfolioCandidate"] = 4] = "PortfolioCandidate";
})(RequestType || (RequestType = {}));
module.exports = RequestType;

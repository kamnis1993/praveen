"use strict";
/// <reference types="node" />
var DbStatus;
(function (DbStatus) {
    DbStatus[DbStatus["Initialising"] = 0] = "Initialising";
    DbStatus[DbStatus["ServerNotFound"] = 1] = "ServerNotFound";
    DbStatus[DbStatus["Connected"] = 2] = "Connected";
    DbStatus[DbStatus["Disconnected"] = 3] = "Disconnected";
})(DbStatus || (DbStatus = {}));
module.exports = DbStatus;

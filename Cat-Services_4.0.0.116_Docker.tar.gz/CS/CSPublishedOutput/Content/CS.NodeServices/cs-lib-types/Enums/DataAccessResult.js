"use strict";
/**
 * Enum contains failure codes related to data access
 */
var DataAccessResult;
(function (DataAccessResult) {
    DataAccessResult[DataAccessResult["Successful"] = 0] = "Successful";
    DataAccessResult[DataAccessResult["DatastoreNotAvailable"] = 1] = "DatastoreNotAvailable";
    DataAccessResult[DataAccessResult["NoProductIdSupplied"] = 2] = "NoProductIdSupplied";
    DataAccessResult[DataAccessResult["NoProductSpecificationFound"] = 3] = "NoProductSpecificationFound";
    DataAccessResult[DataAccessResult["BadData"] = 4] = "BadData";
})(DataAccessResult || (DataAccessResult = {}));
module.exports = DataAccessResult;

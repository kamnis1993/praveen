"use strict";
/**
 * The list of possible ItemSource values or prefixes
 */
var ItemSources = {
    // The order item was inthe original order but did not have an ItemSource set
    Original: 'Original',
    // the item has been inferred from the product specification
    Decompose: "Decompose:",
    // The item already existed when the request was made, but did not have an item source set
    Existing: "Existing:"
};
module.exports = ItemSources;

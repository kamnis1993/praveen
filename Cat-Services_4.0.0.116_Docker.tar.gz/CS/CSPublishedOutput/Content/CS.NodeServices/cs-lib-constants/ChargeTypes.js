"use strict";
/**
 * The list of Charge Types
 */
var ChargeTypes = {
    /** Recurring Charge Type */
    RecurringCharge: 'RecurringCharge',
    /** Non Recurring Charge Type */
    NonRecurringCharge: 'NonRecurringCharge',
    /** Recurring Cost-Based Charge Type */
    RecurringCostBasedCharge: "RecurringCostBasedCharge",
    /** Non Recurring Cost-Based Charge Type */
    NonRecurringCostBasedCharge: "NonRecurringCostBasedCharge",
    /** Standalone Recurring Charge Type */
    StandaloneRecurringCharge: 'StandaloneRecurringCharge',
    /** Standalone Non-Recurring Charge Type */
    StandaloneNonRecurringCharge: 'StandaloneNonRecurringCharge',
    /** Event Charge Type */
    EventCharge: 'EventCharge'
};
module.exports = ChargeTypes;

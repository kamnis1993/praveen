"use strict";
/**
 * The types of rate with respect to the way they are applied per unit
 */
var RateTypes = {
    /* The rate applied to a charge, irrespective of any quantity listed on the charge */
    Simple: "Simple",
    /* The rate applied to a charge, based on the quantity listed on the charge. Exclusive, only one rate per unit can be applied */
    Threshold: "Threshold",
    /* The rate applied to a charge, based on the quantity listed on the charge. Non-exclusive, the rate per unit may differ depending on the total quantity */
    Tiered: "Tiered"
};
module.exports = RateTypes;

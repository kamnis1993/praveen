"use strict";
/**
 * The list of adjustment types
 * At time of writing there are only simple discounts
 * This may be expanded in the future
 * e.g. to UnitBased discounts
 */
var AdjustmentTypes = {
    Flat: 'Flat',
    Percentage: 'Percentage',
    Absolute: 'Absolute'
};
module.exports = AdjustmentTypes;

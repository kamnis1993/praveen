"use strict";
/**
 * The list of pricing response types
 */
var PricingResponseTypes = {
    /* Order candidate pricing response */
    OrderCandidate: 'OrderCandidate',
    /* Product candidate pricing response */
    ProductCandidate: 'ProductCandidate'
};
module.exports = PricingResponseTypes;

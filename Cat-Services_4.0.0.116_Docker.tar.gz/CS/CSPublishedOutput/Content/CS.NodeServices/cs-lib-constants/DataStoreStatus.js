"use strict";
/**
 * The list of data store statuses
 */
var DataStoreStatus = {
    Starting: "Starting",
    Active: "Active",
    UpdatingData: "UpdatingData",
    UnableToStartServices: "UnableToStartServices",
    RefreshRequired: "RefreshRequired",
    Unknown: "Unknown"
};
module.exports = DataStoreStatus;

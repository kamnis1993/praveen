"use strict";
/**
 * The list of phase code types
 */
var PhaseCodeTypes = {
    GroupCardinality: "GroupCardinality",
    CompatibilityRule: "CompatibilityRule",
    CharacteristicsUse: "CharacteristicsUse",
    ConfiguredValue: "ConfiguredValue",
    EntityLinks: "EntityLinks",
    RelationCardinality: "RelationCardinality"
};
module.exports = PhaseCodeTypes;

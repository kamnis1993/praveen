"use strict";
/**
 * The list of possible actions that can be performed against an order item
 */
var IgnoredReasonTypes = {
    // Additional; charge
    AdditionalCharge: "Additional Charge",
    // Charge excluded
    ChargeExcluded: "Charge Excluded",
    // Expired charge
    ExpiredCharge: "Out of date Charge",
    // No entity link to charge
    NoEntityLinkToCharge: "No EntityLink to Charge",
    // No cost rate
    MissingCostRate: "Cost Rate Missing",
    // No valid cost provided
    NoValidCostProvided: "No valid cost provided",
    // No rates on charge
    NoRateOnCharge: "No rates on charge",
    // No rates on cost
    NoRateOnCost: "No rates on cost",
    // No valid rates
    NoValidRate: "No valid rates",
    // Multiple ambiguous rates
    MultipleAmbiguousRates: "Multiple ambiguous rates",
    // Outdated costs
    ExpiredCost: "Out of date Cost",
    // Cost Excluded
    CostExcluded: "Cost Excluded",
    // AmbiguousRates on Costs
    AmbiguousRates: "Cost ambiguous rates",
    // No unit rate supplied on charge or cost
    AmbiguousUnitQuantity: "No unit rate provided in request",
    // Incorrectly defined rate details
    InvalidRateOverride: "Rate overrides must include both a valid rate guid and value override",
    // Rate override cannot coexist with rate attributes
    RateAttributeAmbiguity: "Rate overrides cannot be used in conjunction with rate attributes in the request",
    // RateActivationDate is passed in but is an invalid value
    InvalidRateActivationDate: "RateActivationDate value is not a valid date",
    // Discount reasons
    DiscountExcluded: "Discount Excluded",
    ExpiredDiscount: "Out of date discount",
    NoEntityLinksToDiscount: "No EntityLink to Discount",
    AmbiguousDiscountRate: "Discount ambiguous rate",
    MissingChargeRate: "Charge Rate Missing",
    NoRateOnDiscount: "No rates on discount",
    NoValidChargeProvided: "No valid charge provided"
};
module.exports = IgnoredReasonTypes;

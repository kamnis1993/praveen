"use strict";
var CacheKeys = {
    Specification: "SPEC",
    CompiledSpecification: "COMPSPEC",
    DescendantInstanceIds: "DI"
};
module.exports = CacheKeys;

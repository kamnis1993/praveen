"use strict";
/**
 * The list of activities which may be performed as part of a decompose request
 */
var DecomposeActivities = {
    Inference: "Inference",
    Mapping: "Mapping"
};
module.exports = DecomposeActivities;

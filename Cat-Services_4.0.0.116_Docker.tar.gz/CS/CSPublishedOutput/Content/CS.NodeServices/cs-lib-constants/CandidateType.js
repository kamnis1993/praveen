"use strict";
/**
 * The list of input candidate types
 */
var CandidateType = {
    Order: 'Order',
    Product: 'Product',
    Portfolio: 'Portfolio'
};
module.exports = CandidateType;

"use strict";
/**
 * The list of SpecificationGuids
 */
var SpecificationGuids = {
    Mapping: {
        TriggerEvents: {
            /** Decompose trigger event */
            Decompose: "5d070dca-ac17-4d6c-b007-346576c65719",
            /** Commercial decompose trigger event */
            CommercialDecompose: "a20d9f45-0b23-4512-8e24-7d423cc40b8f",
            /** No matching value for trigger event */
            Unknown: "Unknown"
        },
        Scope: {
            /** Child scope */
            Child: "2ae094e5-be58-45c5-88c3-1f9471bcaab6",
            /** Product candidate scope */
            ProductCandidate: "c2bb02e0-a1b4-4732-8fd3-ec8a68172a66",
            /** Portfolio scope */
            Portfolio: "e1ee77d6-7d0c-46c2-af0c-212f3094f45e",
            /** No matching value for scope */
            Unknown: "Unknown"
        },
        SourceTargetState: {
            /** ADD */
            Add: "454471fb-1a74-49cf-b186-b6aa4629b7f8",
            /** UPDATE */
            Update: "1b0c072d-d36b-442b-8f71-1a4d51948142",
            /** DELETE */
            Delete: "ed6c80fb-1a0e-4c04-b186-70d85bd6452c",
            /** NOCHANGE */
            NoChange: "f7d99993-f0b2-4440-8a41-3a3206b4000a",
            /** REASSIGNED */
            Reassigned: "e26b862b-f94f-45c8-9d82-383cddcf95c8",
            /** REASSIGNEDUPDATE */
            ReassignedUpdate: "612b820e-8e17-4a78-9eeb-1d81de1b76aa"
        }
    },
    Pricing: {
        CostRateType: {
            /** Flat markup type */
            Flat: "601fbc9d-a199-4f96-bf34-ed5180f90a25",
            /** Percentage markup type */
            Percentage: "0e4b02eb-7a29-4946-abf4-b173d9da1fa2"
        }
    }
};
module.exports = SpecificationGuids;

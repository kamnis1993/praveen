"use strict";
/**
 * The list of possible types of conditions for Mapping Rules and Compatibility Rules
 */
var RuleConditionType = {
    Entity: 'Entity',
    Value: 'Value',
    ItemAction: 'ItemAction',
    EntityLink: 'EntityLink',
    NoValueExists: 'NoValueExists',
    UDCMatchesValue: 'UDCMatchesValue',
    ItemValueAction: 'ItemValueAction',
    EntToEnt: 'EntToEnt',
    EntToStatic: 'EntToStatic',
    EntToUDC: 'EntToUDC',
    ExistsData: 'ExistsData',
    NotExistsData: 'NotExistsData'
};
module.exports = RuleConditionType;

"use strict";
/**
 * The list of Cost Types
 */
var CostTypes = {
    /** Recurring Cost Type */
    RecurringCost: 'RecurringCost',
    /** Non Recurring Cost Type */
    NonRecurringCost: 'NonRecurringCost',
    /** Standalone Recurring Cost Type */
    StandaloneRecurringCost: 'StandaloneRecurringCost',
    /** Standalone Non-Recurring Cost Type */
    StandaloneNonRecurringCost: 'StandaloneNonRecurringCost'
};
module.exports = CostTypes;

"use strict";
/**
 * The list of delimiters used in catalog services
 */
var Delimiters = {
    /**
     * Delimiter used for DecomposeGenID
     */
    DecomposeGeneration: '#~',
    OrderfolioKey: '-'
};
module.exports = Delimiters;

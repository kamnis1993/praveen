"use strict";
/**
 * The list of possible ways an item can be created through decompose
 */
var DecomposeGeneratedTypes = {
    /**
     * Item was generated through Inference
     */
    Inference: 'INF',
    /**
     * Item was generated through Mapping
     */
    Mapping: 'MAP',
    /**
     * Entity Link was generated through Create Missing EL
     */
    EntityLinkMapping: "ELMAP",
    /**
     * Entity was generated through Create Missing EL
     */
    EntityLinkChildMapping: 'ELMAPCHILD',
    /**
     * Item has been generated to affect an existing portfolio item
     */
    Existing: 'EXIST'
};
module.exports = DecomposeGeneratedTypes;

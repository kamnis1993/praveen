"use strict";
var LogLevel;
(function (LogLevel) {
    /** show no messages */
    LogLevel[LogLevel["None"] = 0] = "None";
    // warn, error etc go between
    /** Diagnostic level information */
    LogLevel[LogLevel["Info"] = 100] = "Info";
})(LogLevel || (LogLevel = {}));
module.exports = LogLevel;

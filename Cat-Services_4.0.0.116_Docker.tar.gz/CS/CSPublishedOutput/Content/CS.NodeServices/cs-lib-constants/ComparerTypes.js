"use strict";
/**
 * The list of Math signs known in Catalog as Comparer
 */
var ComparerTypes = {
    Equals: '=',
    NotEquals: '!=',
    LessThan: "<",
    GreaterThan: ">",
    LessThanOrEqualTo: '<=',
    GreaterThanOrEqualTo: '>='
};
module.exports = ComparerTypes;

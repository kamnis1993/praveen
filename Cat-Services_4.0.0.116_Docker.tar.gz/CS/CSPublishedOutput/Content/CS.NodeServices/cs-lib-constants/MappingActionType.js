"use strict";
/**
 * The list of possible actions that can be performed by Mapping
 */
var MappingActionType = {
    SetConfigValue: 'smap_setconfigvalue',
    CopyConfigValue: 'smap_copyconfigvalue',
    CopyConfigValueMapped: 'smap_copyconfigvaluemapped',
    SetLiteralValue: 'smap_setliteralvalue',
    CopyUDCValue: 'smap_copyudcvalue',
    CreateEntity: 'smap_createentity',
    SetUDCToSpecValue: 'smap_setudctospecvalue',
    SetUDCToSpecValueMapped: 'smap_setudctospecvaluemapped',
    CopyConfValToRA: 'smap_copyconfvaltora',
    DeleteConfigValue: 'smap_deleteconfigvalue',
    DeleteConfigUse: 'smap_deleteconfiguse',
    DeleteEntity: 'smap_deleteentity',
    SetRAValue: 'smap_setravalue',
    SetRAtoLiteral: 'smap_setratoliteral',
    CopyConfValToRAMapped: 'smap_copyconfvaltoramapped',
    DeleteRAValue: 'smap_deleteravalue',
    CreateRelatedEntity: 'smap_createrelatedentity',
    DeleteRelatedEntity: 'smap_deleterelatedentity',
    CreateMissingEntityLink: 'smap_createmissel'
};
module.exports = MappingActionType;

"use strict";
/**
 * The list of possible markup types for a cost based charge
 */
var MarkupTypes = {
    /** Flat markup type */
    Flat: "Flat",
    /** Percentage markup type */
    Percentage: "Percentage"
};
module.exports = MarkupTypes;

"use strict";
/**
 * The list of the table names (MongoDb collections)
 */
var DbTableNames = {
    // Imported database
    Instances: 'Instances',
    InstancesCache: 'InstancesCache',
    Relationships: 'Relationships',
    RelationshipsCache: 'RelationshipsCache',
    ValueContexts: 'ValueContexts',
    ChargeAdjustments: 'ChargeAdjustments',
    CostAdjustments: 'CostAdjustments',
    DiscountAdjustments: 'DiscountAdjustments',
    SchemaElements: 'SchemaElements',
    Schemas: 'Schemas',
    BusinessIdToGuidLookups: "BusinessIdToGuidLookups",
    TechnicalBoundaries: 'TechnicalBoundaries',
    // Main database
    CurrentDatabase: 'CurrentDatabase',
    Status: 'Status',
    FrameworkContracts: 'FrameworkContracts'
};
module.exports = DbTableNames;

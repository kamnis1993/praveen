"use strict";
/**
 * The list of possible actions that can be performed against an order item
 */
var OrderActions = {
    // A new entity or value is being inserted
    Add: "add",
    // An entity is unchanged but one of it's children or values have been changed
    Update: "update",
    // An entity or value has been removed
    Delete: "delete",
    // An entity or value is being moved from one parent entity to another
    Reassign: "reassign",
    // An entity or value has being moved from one parent entity to another
    Reassigned: "reassigned",
    // An entity or value has being moved from one parent entity to another with an update to one or more of it's immediate children
    ReassignedUpdate: "reassignedupdate",
    // Modify & Replace only apply to ConfiguredValues and CharacteristicUses
    // A set of values is being modified with a set of add/delete
    Modify: "modify",
    // A set of values is being removed and replaced with a set of adds
    Replace: "replace",
    // An item in a set is not affected by any action
    NoChange: "nochange",
    // Order action for when
    Invalid: "invalid"
};
module.exports = OrderActions;

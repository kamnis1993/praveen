"use strict";
/**
 * The list of events
 */
var EventConstants = {
    // The name of the event when the database is switched
    DatabaseSwitched: "databaseSwitched",
    // The name of the event when the technical boundaries are updated
    TechnicalBoundariesUpdated: "technicalBoundariesUpdated",
    // The name of the event when the global cache is updated
    GlobalCacheUpdated: "GlobalCacheUpdated"
};
module.exports = EventConstants;

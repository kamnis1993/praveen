"use strict";
/**
 * The list of Rule scopes
 */
var RuleScope = {
    /** Portfolio scoped rule */
    Portfolio: 'Portfolio',
    /** Child scoped rule */
    Child: 'Child',
    /** Product Candidate scoped rule */
    ProductCandidate: 'ProductCandidate'
};
module.exports = RuleScope;

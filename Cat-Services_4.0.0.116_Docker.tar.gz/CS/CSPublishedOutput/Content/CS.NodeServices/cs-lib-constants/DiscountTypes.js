"use strict";
/**
 * The list of DiscountTypes
 */
var DiscountTypes = {
    /** Event Discount Type */
    ProductEventDiscount: 'Product Event Discount',
    /** Non Event Discount Type */
    ProductNonEventDiscount: 'Product Non Event Discount'
};
module.exports = DiscountTypes;

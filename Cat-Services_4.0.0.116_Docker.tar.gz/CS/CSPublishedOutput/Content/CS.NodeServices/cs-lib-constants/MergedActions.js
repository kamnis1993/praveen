"use strict";
var MergedActions = {
    DeleteExisting: "DeleteExisting",
    AddExisting: "AddExisting",
    SkipExisting: "SkipExisting",
    DeleteMissing: "DeleteMissing",
    AddMissing: "AddMissing",
    UpdateExisting: "UpdateExisting"
};
module.exports = MergedActions;

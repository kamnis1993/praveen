"use strict";
/**
 * The list of work item states defining which state that the management server is on for a particular work item
 * when doing a data refresh
 */
var WorkItemState = {
    /** Invalid state, don't use */
    Unknown: "Unknown",
    /** No work in progress */
    Idle: "Idle",
    /** Work item is being processed */
    Working: "Working",
    /** Work item completed successfully */
    Complete: "Complete",
    /** The related work item could not be completed. It should be unassigned and re-issued later */
    Failed: "Failed",
    /** Work item is scheduled for later, or waiting for a worker to become available */
    Pending: "Pending"
};
module.exports = WorkItemState;

"use strict";
/**
 * The list of HTTP header constants
 */
var HttpHeaderConstants = {
    /**
     * The response version
     */
    ResponseVersion: 'ResponseVersion'
};
module.exports = HttpHeaderConstants;

"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Import in translation.json
 */
var ImportErrorCode = {
    ExpectedTargetField: {
        Code: "Import.ExpectedTargetField",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Expected an object in the request body with a 'target' field",
        MessageV1: "Expected an object in the request body with a 'target' field",
        Description: "This error will be raised when the source folder is invalid"
    },
    IncompleteDataSetToImport: {
        Code: "Import.IncompleteDataSetToImport",
        StatusCode: "500",
        ContextParameters: [{ Name: "ErrorMessage", Type: "string", Description: "The inner error message" }],
        Message: "Incomplete import data set: { message: __ErrorMessage__}",
        MessageV1: "Incomplete import data set: { message: __ErrorMessage__}",
        Description: "This error will be raised when importing an incomplete data set in mongo"
    },
    InProgress: {
        Code: "Import.InProgress",
        StatusCode: "400",
        ContextParameters: [],
        Message: "There is currently another import running, please wait until it has finished",
        MessageV1: "There is currently another import running, please wait until it has finished",
        Description: "This error will be raised when trying to import when another import is already in progress"
    },
    ManagementConnectionFailed: {
        Code: "Import.ManagementConnectionFailed",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ErrorMessage", Type: "string", Description: "The error message returned from the connection attempt to Management" }
        ],
        Message: "Failed to connect to Management Server: { message: __ErrorMessage__}",
        MessageV1: "Failed to connect to management server: __ErrorMessage__",
        Description: "This error will be raised when the management server returned an error"
    },
    InvalidConfiguration: {
        Code: "Import.InvalidConfiguration",
        StatusCode: "500",
        ContextParameters: [
            { Name: "Settings", Type: "string", Description: "The settings that are being provided" }
        ],
        Message: "Import configuration incomplete. Data Refresh failed",
        MessageV1: "The following settings are required:  '__Settings__'",
        Description: "This error will be raised when management server configuration settings are invalid"
    },
    CertificateLookupFailed: {
        Code: "Import.CertificateLookupFailed",
        StatusCode: "500",
        ContextParameters: [
            { Name: "Thumbprint", Type: "string", Description: "The certificate thumbprint provided" }
        ],
        Message: "No certificate found using provided thumbprint",
        MessageV1: "Failed to retrieve certificate with thumbprint '__Thumbprint__'",
        Description: "This error will be raised when a valid security certificate could not be retrieved"
    },
    TechnicalBoundaryImportFailed: {
        Code: "Import.TechnicalBoundaryImportFailed",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The technical boundary import request is invalid",
        MessageV1: "The technical boundary import request is invalid",
        Description: "This error will be raised when the technical boundary import request is invalid"
    }
};
module.exports = ImportErrorCode;

"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from SupplementalOrder in translation.json
 */
var SupplementalOrderErrorCode = {
    InvalidSupplementalOrderRequest: {
        MissingProperty: {
            Code: "SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty",
            StatusCode: "400",
            ContextParameters: [
                { Name: "Item", Type: "string", Description: "The type of item in the request which has the missing property" },
                { Name: "Property", Type: "string", Description: "The property which is missing" }
            ],
            Message: "A mandatory property is missing from the Supplemental Order Request: { Item: __Item__, Property: __Property__ }",
            MessageV1: "Missing Property: The property __Property__ on the __Item__ must be specified",
            Description: "A property which is mandatory in a Supplemental Order Request is missing. The request cannot be processed."
        },
        DuplicatedSupplementalOrderID: {
            Code: "SupplementalOrder.InvalidSupplementalOrderRequest.DuplicatedSupplementalOrderID",
            StatusCode: "200",
            ContextParameters: [
                { Name: "Item", Type: "string", Description: "The type of item in the request which has a duplicated ID" }
            ],
            Message: "The Supplemental Order Request has contains a duplicated ID",
            MessageV1: "The request contains a duplicated supplemental order item ID. Item Type: __Item__",
            Description: "A duplicated ID has been found in the Supplemental Order Request. The ID's of all items within a Supplemental Order Request must be unique."
        },
        DuplicatedOrderItemID: {
            Code: "SupplementalOrder.InvalidSupplementalOrderRequest.DuplicatedOrderItemID",
            StatusCode: "200",
            ContextParameters: [
                { Name: "Item", Type: "string", Description: "The type of item in the request which has a duplicated OrderItem ID" },
                { Name: "OrderItemID", Type: "string", Description: "The duplicated OrderItemID" }
            ],
            Message: "The Supplemental Order Request contains an Order Item ID, which is already targeted by other Supplemental Order instructions",
            MessageV1: "The request contains an order item ID '__OrderItemID__' that is targeted by more than one supplemental order item",
            Description: "Different instructions within the SupplementalOrder section of a Supplemental Order Request cannot refer to the same OrderItem in the Inflight Order. " +
                "The EntityUniqueCode holds the ID of the supplemental order instruction which has the duplicate OrderItem ID."
        },
        MissingRequest: {
            Code: "SupplementalOrder.InvalidSupplementalOrderRequest.MissingRequest",
            StatusCode: "400",
            ContextParameters: [],
            Message: "Invalid or missing Supplemental Order Request",
            MessageV1: "Invalid Supplemental Order Request",
            Description: "A body of the request sent to the SupplementalOrder endpoint is either invalid or missing."
        }
    },
    ParentOrderItemDoesNotExist: {
        Code: "SupplementalOrder.ParentOrderItemDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "CreateOrderItemID", Type: "string", Description: "The ID of the CreateOrderItem which contains the duplicate ID" },
            { Name: "ParentOrderItemID", Type: "string", Description: "The ParentOrderItemID which does not exist in the order" }
        ],
        Message: "The CreateOrderItem contains a ParentOrderItemID which does not exist in the order",
        MessageV1: "The CreateOrderItem __CreateOrderItemID__ contains a parent order item with ID '__ParentOrderItemID__' which does not exist",
        Description: "A CreateOrderItem within the Supplemental Order CreateInstructionSet defines an ID for the parent order item which does not exist in the Inflight order."
    },
    OrderItemIDAlreadyExists: {
        Code: "SupplementalOrder.OrderItemIDAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "CreateOrderItemID", Type: "string", Description: "The ID of the CreateOrderItem which contains the duplicate ID" }
        ],
        Message: "The CreateOrderItem contains an OrderItem with an ID which already exists",
        MessageV1: "The CreateOrderItem with ID '__CreateOrderItemID__' already exists",
        Description: "A CreateOrderItem within the CreateInstructionSet of the Supplemental Order contains an OrderItem with an ID (shown in EntityUniqueCode) which already exists in the Inflight order. All ID's within an order must be unique."
    },
    OrderItemDoesNotExist: {
        Code: "SupplementalOrder.OrderItemDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "InstructionType", Type: "string", Description: "The instruction type, either Amend or Cancel" },
            { Name: "InstructionID", Type: "string", Description: "The ID of the item within the Instruction Set." },
            { Name: "OrderItemID", Type: "string", Description: "The OrderItemID which does not exist in the order" }
        ],
        Message: "An instruction set contains an OrderItem with an ID which does not exist in the order",
        MessageV1: "An order item with ID '__OrderItemID__' does not exist",
        Description: "The Supplemental Order has either an Amend or a Cancel Instruction set which references an OrderItemID that does not exist in the Inflight Order"
    },
    UnrecognisedChangeTypeOnProperty: {
        Code: "SupplementalOrder.UnrecognisedChangeTypeOnProperty",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "Property", Type: "string", Description: "The type of property which has the invalid ChangeType" },
            { Name: "ChangeType", Type: "string", Description: "The invalid ChangeType which was found in the Supplemental Order" },
            { Name: "PropertyIdentification", Type: "string", Description: "Information which helps identify the exact property containing the invalid change type" }
        ],
        Message: "A ChangeType defined on a property in the Supplemental Order is invalid.",
        MessageV1: "The change type '__ChangeType__' is not supported on a property please specify either Cancel, Create or Amend",
        Description: "A ChangeType has been defined on a property which is part of an AmendOrderItem in a Supplemental Order and that ChangeType is not supported. Change Types can only be either Create, Amend or Cancel"
    },
    UnrecognisedChangeTypeOnValue: {
        Code: "SupplementalOrder.UnrecognisedChangeTypeOnValue",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "PropertyValue", Type: "string", Description: "The type of property value which has the invalid ChangeType, for example: CharacteristicUse.Value" },
            { Name: "ChangeType", Type: "string", Description: "The invalid ChangeType which was found in the Supplemental Order" },
            { Name: "ValueIdentification", Type: "string", Description: "Information which helps identify the exact value containing the invalid change type" }
        ],
        Message: "A ChangeType defined on a property value in the Supplemental Order is invalid.",
        MessageV1: "The change type '__ChangeType__' is not supported on a value please specify either Cancel or Create",
        Description: "A ChangeType has been defined on a property value which is part of an AmendOrderItem in a Supplemental Order, and that ChangeType is not supported. Change Types can only be either Create, Amend or Cancel"
    },
    CharacteristicAlreadyExists: {
        Code: "SupplementalOrder.CharacteristicAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "Property", Type: "string", Description: "Whether a CharacteristicUse or ConfiguredValue" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" }
        ],
        Message: "Attempted to Create a CharacteristicUse or ConfiguredValue which already exists",
        MessageV1: "The characteristic with use area '__UseArea__' and characteristic ID '__CharacteristicID__' already exists",
        Description: "A Supplemental Order has a Create instruction for a CharacteristicUse or ConfiguredValue and a property with the same UseArea and CharacteristicID already exists in the Inflight Order. " +
            "The Create will be part of an AmendOrderItem."
    },
    CharacteristicDoesNotExist: {
        Code: "SupplementalOrder.CharacteristicDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "Property", Type: "string", Description: "Whether a CharacteristicUse or ConfiguredValue" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" }
        ],
        Message: "Attempted to Amend or Cancel a CharacteristicUse which does not exist",
        MessageV1: "The characteristic with use area '__UseArea__' and characteristic ID '__CharacteristicID__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for a CharacteristicUse or ConfiguredValue which does not exist in the Inflight Order. The Amend or Cancel instruction will be part of an AmendOrderItem."
    },
    CharacteristicValueAlreadyExists: {
        Code: "SupplementalOrder.CharacteristicValueAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" },
            { Name: "ValueID", Type: "string", Description: "The ValueID of the existing value" }
        ],
        Message: "Attempted to Create a Value on a CharacteristicUse which already exists",
        MessageV1: "The characteristic value with use area '__UseArea__', characteristic ID '__CharacteristicID__' and value ID '__ValueID__' already exists",
        Description: "A Supplemental Order has a Create instruction for a Value on a CharacteristicUse and a Value with the specified ValueID already exists on that CharacteristicUse in the Inflight Order. " +
            "The Create instruction will be part of an AmendOrderItem."
    },
    CharacteristicValueDoesNotExist: {
        Code: "SupplementalOrder.CharacteristicValueDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" },
            { Name: "ValueID", Type: "string", Description: "The ValueID of the non-existing value" }
        ],
        Message: "Attempted to Amend or Cancel a Value on a CharacteristicUse which does not exist",
        MessageV1: "The characteristic value with use area '__UseArea__', characteristic ID '__CharacteristicID__' and value ID '__ValueID__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for a Value on a CharacteristicUse and a Value with the specified ValueID does not exist in the Inflight Order. " +
            "The Amend or Cancel instruction will be part of an AmendOrderItem."
    },
    RateAttributeAlreadyExists: {
        Code: "SupplementalOrder.RateAttributeAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "RateAttributeName", Type: "string", Description: "The Name of the already existing RateAttribute" }
        ],
        Message: "Attempted to Create a RateAttribute which already exists",
        MessageV1: "The rate attribute with name '__RateAttributeName__' already exists",
        Description: "A Supplemental Order has a Create instruction for a RateAttribute and a Rate Attribute with an identical Name already exists in the Inflight Order. The Create instruction will be part of an AmendOrderItem."
    },
    RateAttributeDoesNotExist: {
        Code: "SupplementalOrder.RateAttributeDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "RateAttributeName", Type: "string", Description: "The Name of the already existing RateAttribute" }
        ],
        Message: "Attempted to Amend or Cancel a RateAttribute which does not exist",
        MessageV1: "The rate attribute with name '__RateAttributeName__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for a RateAttribute which does not exist in the Inflight Order. The Amend or Cancel instruction will be part of an AmendOrderItem."
    },
    UserDefinedCharacteristicValueAlreadyExists: {
        Code: "SupplementalOrder.UserDefinedCharacteristicValueAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" },
            { Name: "Value", Type: "string", Description: "The Value which already exists" }
        ],
        Message: "Attempted to Create a Value on a ConfiguredValue which already exists",
        MessageV1: "The user defined characteristic value with use area '__UseArea__', characteristic ID '__CharacteristicID__' and value '__Value__' already exists",
        Description: "A Supplemental Order has a Create instruction for a Value on a ConfiguredValue and an identical Value already exists on that ConfiguredValue in the Inflight Order. The Create instruction will be part of an AmendOrderItem."
    },
    UserDefinedCharacteristicValueDoesNotExist: {
        Code: "SupplementalOrder.UserDefinedCharacteristicValueDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "UseArea", Type: "string", Description: "The UseArea of the CharacteristicUse" },
            { Name: "CharacteristicID", Type: "string", Description: "The CharacteristicID of the CharacteristicUse" },
            { Name: "Value", Type: "string", Description: "The Value which does not exists" }
        ],
        Message: "Attempted to Amend or Cancel a Value on a ConfiguredValue which does not exist",
        MessageV1: "The user defined characteristic value with use area '__UseArea__', characteristic ID '__CharacteristicID__' and value '__Value__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for a Value on a ConfiguredValue and that Value does not exist in the Inflight Order. The Amend or Cancel instruction will be part of an AmendOrderItem."
    },
    LinkedEntityAlreadyExists: {
        Code: "SupplementalOrder.LinkedEntityAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "LinkTypeID", Type: "string", Description: "The ID of the LinkedEntity which contains the Link" }
        ],
        Message: "The linked entity with specified LinkTypeID already exists",
        MessageV1: "The linked entity with link type ID '__LinkTypeID__' already exists",
        Description: "A Supplemental Order has a Create instruction for a LinkedEntity and a LinkedEntity with that LinkTypeID already exists in the Inflight Order. The Create will be part of an AmendOrderItem."
    },
    LinkedEntityDoesNotExist: {
        Code: "SupplementalOrder.LinkedEntityDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "LinkTypeID", Type: "string", Description: "The ID of the LinkedEntity which contains the Link" }
        ],
        Message: "The linked entity with specified LinkTypeID does not exist",
        MessageV1: "The linked entity with link type ID '__LinkTypeID__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for a LinkedEntity which does not exist in the Inflight Order. The Amend or Cancel instruction will be part of an AmendOrderItem."
    },
    LinkAlreadyExists: {
        Code: "SupplementalOrder.LinkAlreadyExists",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "LinkTypeID", Type: "string", Description: "The ID of the LinkedEntity which contains the Link" },
            { Name: "PortfolioItemID", Type: "string", Description: "The ID of the PortfolioItem the Link connects to" }
        ],
        Message: "The AmendOrderItem contains a Create instruction for a LinkedEntity Link which already exists",
        MessageV1: "The linked entity with link type ID '__LinkTypeID__' and portfolio item ID '__PortfolioItemID__' exists",
        Description: "A Supplemental Order has a Create instruction for a Link of a LinkedEntity and a Link with the specified PortfolioItemID already exists on that LinkedEntity in the Inflight Order. " +
            "The Create instruction will be part of an AmendOrderItem."
    },
    LinkDoesNotExist: {
        Code: "SupplementalOrder.LinkDoesNotExist",
        StatusCode: "200",
        ContextParameters: [
            { Name: "AmendOrderItemID", Type: "string", Description: "The ID of the AmendOrderItem within the Supplemental Order" },
            { Name: "LinkTypeID", Type: "string", Description: "The ID of the LinkedEntity which contains the Link" },
            { Name: "PortfolioItemID", Type: "string", Description: "The ID of the PortfolioItem the Link connects to" }
        ],
        Message: "The AmendOrderItem contains an Amend or Cancel instruction for a LinkedEntity Link which does not exist",
        MessageV1: "The linked entity with link type ID '__LinkTypeID__' and portfolio item ID '__PortfolioItemID__' does not exist",
        Description: "A Supplemental Order has an Amend or Cancel instruction for the Link of a LinkedEntity and that Link does not exist in the Inflight Order. The Amend or Cancel instruction will be part of an AmendOrderItem."
    }
};
module.exports = SupplementalOrderErrorCode;

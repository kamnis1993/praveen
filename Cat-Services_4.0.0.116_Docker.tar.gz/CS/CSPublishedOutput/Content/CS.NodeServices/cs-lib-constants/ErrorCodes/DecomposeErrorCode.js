"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Decompose in translation.json
 */
var DecomposeErrorCode = {
    InvalidOrderCandidate: {
        Code: "Decompose.InvalidOrderCandidate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The OrderCandidate used in the request to decompose is empty",
        MessageV1: "A correct OrderCandidateRequest structure is expected",
        Description: "This error is raised when the OrderCandidateRequest is not populated with a value. Please provide a valid OrderCandidateRequest"
    },
    InvalidProductCandidate: {
        Code: "Decompose.InvalidProductCandidate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The ProductCandidate used in the request to decompose is empty",
        MessageV1: "A correct ProductCandidateRequest structure is expected",
        Description: "This error is raised when the ProductCandidateRequest is not populated with a value. Please provide a valid ProductCandidateRequest"
    },
    InvalidPortfolioCandidate: {
        Code: "Decompose.InvalidPortfolioCandidate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The PortfolioCandidate used in the request to decompose is empty",
        MessageV1: "A correct PortfolioCandidateRequest structure is expected",
        Description: "This error is raised when the PortfolioCandidateRequest does not have a valid structure. Please provide a valid PortfolioCandidateRequest structure, such as 'application/json'"
    },
    InvalidCandidate: {
        Code: "Decompose.InvalidCandidate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The body of the request in the request to decompose is invalid",
        MessageV1: "An InvalidCandidate structure",
        Description: "This error is raised when the body of the request is not valid. Please provide a request with a valid body"
    }
};
module.exports = DecomposeErrorCode;

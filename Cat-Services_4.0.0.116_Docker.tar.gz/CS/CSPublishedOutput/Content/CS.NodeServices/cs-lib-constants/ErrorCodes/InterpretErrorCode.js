"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Interpret in translation.json
 */
var InterpretErrorCode = {
    CannotModifyRootItem: {
        Code: "Interpret.CannotModifyRootItem",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The root items in both candidates do not match",
        MessageV1: "The root items in both candidates are not equal. You cannot change the root item in a candidate with an order item.",
        Description: "This error is raised when different root items are used in the old and new candidates for a request to generate an order. The new root item must match the original"
    }
};
module.exports = InterpretErrorCode;

"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Manage in translation.json
 */
var ManageErrorCode = {
    FailedToSetTechnicalBoundary: {
        Code: "Manage.FailedToSetTechnicalBoundary",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ErrorMessage", Type: "string", Description: "Error message returned from database" }
        ],
        Message: "Failed to import the Technical Boundary",
        MessageV1: "Failed to import technical boundary data : __ErrorMessage__",
        Description: "This error is raised when an attempt to import the technical boundary from the database has failed"
    },
    FailedToRetrieveCrashLog: {
        Code: "Manage.FailedToRetrieveCrashLog",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Unable to retrieve crash log from server",
        MessageV1: "Unable to retrieve crash log from server",
        Description: "This error is raised when an attempt to retrieve the crash log from the server has failed"
    },
    FailedToDeleteCrashLog: {
        Code: "Manage.FailedToDeleteCrashLog",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Unable to delete crash log",
        MessageV1: "Unable to delete crash log",
        Description: "This error is raised when an attempt to delete the crash log from the server has failed"
    }
};
module.exports = ManageErrorCode;

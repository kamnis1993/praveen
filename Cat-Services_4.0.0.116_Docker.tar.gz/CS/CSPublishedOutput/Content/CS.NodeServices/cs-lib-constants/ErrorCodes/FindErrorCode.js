"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Find in translation.json
 */
var FindErrorCode = {
    UnknownError: {
        Code: "Find.UnknownError",
        StatusCode: "500",
        ContextParameters: [
            { Name: "EntityID", Type: "string", Description: "The unique entityID that is invalid or missing" }
        ],
        Message: "An Unknown error occurred when attempting to find the specification",
        MessageV1: "An Unknown error occurred when attempting to find the specification for the entity with Id : __EntityID__",
        Description: "This error will be rasied when an EntityID is either invalid or missing and it cannot be found in the specification"
    },
    NotFound: {
        Code: "Find.NotFound",
        StatusCode: "404",
        ContextParameters: [],
        Message: "Product Specification cannot be found",
        MessageV1: "Not Found",
        Description: "This error will be raised when Catalog Services cannot find the product Specification"
    },
    DatastoreNotAvailable: {
        Code: "Find.DatastoreNotAvailable",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Datastore not available",
        MessageV1: "Datastore not available",
        Description: "This error will be raised when the provided datastore or compiled specification cannot be found"
    },
    BadID: {
        Code: "Find.BadID",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The supplied entity id is invalid",
        MessageV1: "The supplied entity id is invalid",
        Description: "This error will be raised when the input entityID is invalid"
    },
    CommercialSpecificationNotAvailable: {
        Code: "Find.CommercialSpecificationNotAvailable",
        StatusCode: "400",
        ContextParameters: [],
        Message: "No commercial specification available",
        MessageV1: "No commercial specification available",
        Description: "This error will be raised when the commerical specification cannot be found"
    },
    RootElementOutOfDateRange: {
        Code: "Find.RootElementOutOfDateRange",
        StatusCode: "409",
        ContextParameters: [],
        Message: "The root element is out of date for the available date specified in the query",
        MessageV1: "The root element is out of date for the available date specified in the query",
        Description: "This error will be raised when the provided available date is not within the root entity's date range"
    },
    BadRequest: {
        Code: "Find.BadRequest",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Bad Request",
        MessageV1: "Bad Request",
        Description: "This error will be raised when no request body is provided"
    },
    BadQueryDate: {
        Code: "Find.BadQueryDate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Cannot find requested date",
        MessageV1: "Cannot find requested date",
        Description: "This error will be raised when the specification date is invalid or missing"
    },
    BadAvailableDate: {
        Code: "Find.BadAvailableDate",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Available date cannot be found",
        MessageV1: "Available date cannot be found",
        Description: "This error will be raised when the available date is inccorect or missing"
    }
};
module.exports = FindErrorCode;

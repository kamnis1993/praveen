"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from FrameworkContracts in translation.json
 */
var FrameworkContractsErrorCode = {
    DisabledMessage: {
        Code: "FrameworkContracts.DisabledMessage",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Framework Contracts is not enabled",
        MessageV1: "Framework Contracts is not enabled",
        Description: "This error will occur when FrameworkContracts is not enabled"
    },
    RequestNotDefined: {
        Code: "FrameworkContracts.RequestNotDefined",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Request is not defined",
        MessageV1: "Request is not defined",
        Description: "This error will occur when the Negotiated Specification schema is invalid"
    },
    MissingContractID: {
        Code: "FrameworkContracts.MissingContractID",
        StatusCode: "400",
        ContextParameters: [],
        Message: "ContractId must be included in the request",
        MessageV1: "ContractId must be included in the request",
        Description: "This error will occur when the contract ID is missing in the negotiated specification"
    },
    MissingGuid: {
        Code: "FrameworkContracts.MissingGuid",
        StatusCode: "400",
        ContextParameters: [],
        Message: "EntityGuid must be included in the request",
        MessageV1: "EntityGuid must be included in the request",
        Description: "This error will occur when the specification ID is missing from the request"
    },
    MissingBusinessID: {
        Code: "FrameworkContracts.MissingBusinessID",
        StatusCode: "400",
        ContextParameters: [],
        Message: "BusinessID must be included in the request",
        MessageV1: "BusinessID must be included in the request",
        Description: "This error will occur when the Business ID is missing from the request"
    },
    InvalidSpec: {
        Code: "FrameworkContracts.InvalidSpec",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Negotiated Specification is missing or invalid",
        MessageV1: "Negotiated Specification is missing or invalid",
        Description: "This error will occur when the negotiated specification is missing or invalid"
    },
    UnableToFindNegotiatedSpec: {
        Code: "FrameworkContracts.UnableToFindNegotiatedSpec",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Unable to find the requested Negotiated Specification",
        MessageV1: "Unable to find the requested Negotiated Specification",
        Description: "This error will occur when a negotiated specification is found but is invalid"
    },
    UnableToFindStandardSpec: {
        Code: "FrameworkContracts.UnableToFindStandardSpec",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Unable to find the Standard Specification that matches the imported Negotiated Specification",
        MessageV1: "Unable to find the Standard Specification that matches the imported Negotiated Specification",
        Description: "This error will occur when the specification could not be retrieved"
    },
    ImportFailure: {
        Code: "FrameworkContracts.ImportFailure",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ImportErr", Type: "string", Description: "The contract is invalid or missing" }
        ],
        Message: "Negotiated Specification was not imported successfully: { ErrorMessage: __ImportErr__}",
        MessageV1: "Failed to import Negotiated Specification: __ImportErr__",
        Description: "This error will occur when the framework contract imported has failed due to it being invalid or missing"
    },
    SpecificationNotCreated: {
        Code: "FrameworkContracts.SpecificationNotCreated",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Negotiated Specification was not successfully created",
        MessageV1: "egotiated Specification was not successfully created",
        Description: "This error will occur when the specification is either incorrectly created or missing"
    },
    MissingPublishDate: {
        Code: "FrameworkContracts.MissingPublishDate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "PublishDate must be included in the request",
        MessageV1: "PublishDate must be included in the request",
        Description: "This error will occur when the Publish date is missing from the request"
    },
    InvalidPublishDate: {
        Code: "FrameworkContracts.InvalidPublishDate",
        StatusCode: "undefined",
        ContextParameters: [],
        Message: "PublishDate must be a valid date",
        MessageV1: "PublishDate must be a valid date",
        Description: "This error will occur when the start date in the specification header is not valid"
    },
    InvalidEndDate: {
        Code: "FrameworkContracts.InvalidEndDate",
        StatusCode: "400",
        ContextParameters: [],
        Message: "EndDate must be a valid date",
        MessageV1: "EndDate must be a valid date",
        Description: "This error will occur when the end date in the specification header is not valid"
    },
    InvalidImportRequest: {
        Code: "FrameworkContracts.InvalidImportRequest",
        StatusCode: "400",
        ContextParameters: [
            { Name: "ImportSpecErr", Type: "string", Description: "The imported negotiated specification" }
        ],
        Message: "Invalid Import request: { ImportError: __ImportSpecErr__}",
        MessageV1: "Invalid import request: __ImportSpecErr__",
        Description: "This error will occur when the import request is invalid due to invalid or missing headers in the negotiated specification"
    },
    InvalidContractID: {
        Code: "FrameworkContracts.InvalidContractID",
        StatusCode: "400",
        ContextParameters: [],
        Message: "ContractId must be a string value",
        MessageV1: "ContractId must be a string value",
        Description: "This error will occur when the Contract ID is passed through with anything but a string value"
    },
    InvalidGuid: {
        Code: "FrameworkContracts.InvalidGuid",
        StatusCode: "400",
        ContextParameters: [],
        Message: "EntityGuid must be a string value",
        MessageV1: "EntityGuid must be a string value",
        Description: "This error will occur when the request ID is passed through with anything but a string value"
    },
    InvalidBusinessID: {
        Code: "FrameworkContracts.InvalidBusinessID",
        StatusCode: "400",
        ContextParameters: [],
        Message: "BusinessID must be a string value",
        MessageV1: "BusinessID must be a string value",
        Description: "This error will occur when the Business ID is passed through with anything but a string value"
    },
    InvalidContractVersion: {
        Code: "FrameworkContracts.InvalidContractVersion",
        StatusCode: "400",
        ContextParameters: [],
        Message: "ContractVersion must be a string value",
        MessageV1: "ContractVersion must be a string value",
        Description: "This error will occur when the Contract Version is passed through with anything but a string value"
    },
    InvalidSpecificationHash: {
        Code: "FrameworkContracts.InvalidSpecificationHash",
        StatusCode: "400",
        ContextParameters: [],
        Message: "SpecificationHash must be a string value",
        MessageV1: "SpecificationHash must be a string value",
        Description: "This error will occur when the specification hash is passed through with anything but a string value"
    },
    BusinessIDMismatch: {
        Code: "FrameworkContracts.BusinessIDMismatch",
        StatusCode: "400",
        ContextParameters: [],
        Message: "BusinessID does not match the standard spec",
        MessageV1: "BusinessID does not match the standard spec",
        Description: "This error will occur when the business ID does not match the standard specification"
    }
};
module.exports = FrameworkContractsErrorCode;

"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from DataAccess in translation.json
 */
var DataAccessErrorCode = {
    DalFactoryError: {
        Code: "DataAccess.DalFactoryError",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ErrorMessage", Type: "any", Description: "Supplies given error message" }
        ],
        Message: "There is a problem accessing the Database: { ErrorMessage: __ErrorMessage__ }",
        MessageV1: "There is a problem accessing the Database : __ErrorMessage__",
        Description: "This error message is shown when there is an issue connecting to the database"
    }
};
module.exports = DataAccessErrorCode;

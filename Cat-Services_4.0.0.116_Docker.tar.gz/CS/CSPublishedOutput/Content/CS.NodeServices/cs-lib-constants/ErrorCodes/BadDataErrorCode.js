"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from BadData in translation.json
 */
var BadDataErrorCode = {
    MissingEntityID: {
        Code: "BadData.MissingEntityID",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The Entity is missing an EntityID which is a required field",
        MessageV1: "The Entity is missing an EntityID which is a required field",
        Description: "This error occurs when an entity in the specification is missing an Entity ID, which is a required value"
    },
    MissingCharUseID: {
        Code: "BadData.MissingCharUseID",
        StatusCode: "500",
        ContextParameters: [
            { Name: "CharacteristicID", Type: "string", Description: "The unique identifier of the characteristic use" },
            { Name: "EntityID", Type: "string", Description: "The Guid of the entity" },
            { Name: "EntityUniqueCode", Type: "string", Description: "The order or portfolio ID of the entity" }
        ],
        Message: "The Characteristic is missing required field UseID",
        MessageV1: "The Characteristic is missing required field UseID",
        Description: "This error occurs if a characteristic use or user defined characteristic is missing its characteristic ID"
    },
    MissingValueID: {
        Code: "BadData.MissingValueID",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The Characteristic is missing required field ValueID",
        MessageV1: "The Characteristic is missing required field ValueID",
        Description: "This error occurs when a characteristic value is missing its value ID"
    },
    InvalidMappingSourceType: {
        Code: "BadData.InvalidMappingSourceType",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The Mapping Action Source is not a type that is supported, supported types are: TCharUse and TConfigurable_Fact",
        MessageV1: "The Mapping Action Source is not a type that is supported, supported types are: TCharUse and TConfigurable_Fact",
        Description: "This error occurs when the mapping action source is not an element of the expected type"
    },
    MissingProductEntity: {
        Code: "BadData.MissingProductEntity",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Failed to build a list of compatibility rules. Product Entity is missing",
        MessageV1: "Failed to build a list of compatibility rules. Product Entity is missing",
        Description: "This error occurs when trying to retrieve compatibility rules and Catalog Services could not recognise an entity"
    },
    InvalidFurtherScopePath: {
        Code: "BadData.InvalidFurtherScopePath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Cannot find path to entity defined by Further Scope",
        MessageV1: "Cannot find path to entity defined by Further Scope",
        Description: "This error occurs when a further scope was defined on a compatibility rule, but the target defined by the scope could not be found"
    },
    InvalidEntityBusinessIDPath: {
        Code: "BadData.InvalidEntityBusinessIDPath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Cannot find entity with the business ID path specified",
        MessageV1: "Cannot find entity with the business ID path specified",
        Description: "This error occurs when Catalog Services could not identify where the compatibility rule was defined using the provided business ID"
    },
    MissingRootPath: {
        Code: "BadData.MissingRootPath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "GUID for the Root path is missing on the product entity",
        MessageV1: "GUID for the Root path is missing on the product entity",
        Description: "This error occurs when the root on which the entity is defined could not be found"
    },
    AmbiguousRootPath: {
        Code: "BadData.AmbiguousRootPath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "PathId is longer than expected",
        MessageV1: "PathId is longer than expected",
        Description: "This error occurs when Catalog Services cannot uniquely identify the root on which the entity is defined"
    },
    MissingEntityPath: {
        Code: "BadData.MissingEntityPath",
        StatusCode: "500",
        ContextParameters: [
            { Name: "BasePath", Type: "string", Description: "The base entity path" },
            { Name: "PathToTarget", Type: "string", Description: "The path to the target entity" }
        ],
        Message: "Cannot not find the entity in the specification for the specified target path",
        MessageV1: "Cannot not find the entity in the specification for the specified target path",
        Description: "This error occurs when a targeted entity cannot be found at the target location"
    },
    UnrecognisedMergeAction: {
        Code: "BadData.UnrecognisedMergeAction",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Merge action is not recognised or is invalid",
        MessageV1: "Merge action is not recognised or is invalid",
        Description: "This error occurs when Catalog Services was not able to resolve an ItemAction on an entity successfully"
    },
    InvalidCompiledSpec: {
        Code: "BadData.InvalidCompiledSpec",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Compiled spec could not be built",
        MessageV1: "Compiled spec could not be built",
        Description: "This error occurs when there was a problem retrieving the specification for the decompose request"
    },
    InvalidMappingTarget: {
        Code: "BadData.InvalidMappingTarget",
        StatusCode: "500",
        ContextParameters: [
            { Name: "Target", Type: "string", Description: "The path to the mapping action target" }
        ],
        Message: "Mapping action target could not find a valid path",
        MessageV1: "Mapping action target could not find a valid path",
        Description: "This error occurs when a mapping action could not find the target entity in the specification"
    },
    InvalidRate: {
        Code: "BadData.InvalidRate",
        StatusCode: "500",
        ContextParameters: [],
        Message: "Rate could not be recognised as a numeric value",
        MessageV1: "Rate could not be recognised as a numeric value",
        Description: "This error occurs when a rate in the specification has a value which could not be recognised as a number"
    },
    MissingMappingTarget: {
        Code: "BadData.MissingMappingTarget",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ActionName", Type: "string", Description: "The mapping action" },
            { Name: "MappingRuleName", Type: "string", Description: "The mapping rule" }
        ],
        Message: "The Mapping Action is missing required field Target",
        MessageV1: "The Mapping Action is missing required field Target",
        Description: "This error occurs when a mapping action expects a target but no target was provided"
    },
    MissingRateStartDate: {
        Code: "BadData.MissingRateStartDate",
        StatusCode: "500",
        ContextParameters: [
            { Name: "RateID", Type: "string", Description: "The unique identifier of the rate" },
            { Name: "ChargeID", Type: "string", Description: "The unique identifier of the charge" }
        ],
        Message: "No start date present on rate",
        MessageV1: "Missing Rate: no start date present on rate '__RateID__' for charge '__ChargeID__'",
        Description: "This error occurs when a rate does not have a start date"
    },
    InvalidChargePath: {
        Code: "BadData.InvalidChargePath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The entity was not recognised as a charge",
        MessageV1: "The entity was not recognised as a charge",
        Description: "This error occurs when a charge is expected, but the entity found could not be recognised as a charge"
    },
    InvalidSchemaGuid: {
        Code: "BadData.InvalidSchemaGuid",
        StatusCode: "500",
        ContextParameters: [
            { Name: "Guid", Type: "string", Description: "The unique identifier of the source element" }
        ],
        Message: "Cannot find schema guid specified",
        MessageV1: "Cannot find schema guid specified",
        Description: "This error occurs when a mapping action tries to find a mapping source entity, but the entity could not be found due to an invalid entity ID"
    },
    UnsupportedChargeType: {
        Code: "BadData.UnsupportedChargeType",
        StatusCode: "500",
        ContextParameters: [
            { Name: "ChargeType", Type: "string", Description: "The charge type" }
        ],
        Message: "Unrecognised charge type",
        MessageV1: "Unrecognised charge type",
        Description: "This error occurs when a charge entity cannot be processed because the type of charge is not recognised by Catalog Services"
    },
    ReferencedChargeNotFound: {
        Code: "BadData.ReferencedChargeNotFound",
        StatusCode: "500",
        ContextParameters: [
            { Name: "RateID", Type: "string", Description: "The ID of the rate" },
            { Name: "ChargePath", Type: "string", Description: "The business ID path of the targeted charge" }
        ],
        Message: "Charge referenced by discount was not found in specification",
        MessageV1: "Charge referenced by discount was not found in specification",
        Description: "This error occurs when a charge based discount targets a charge which was not found in the specification"
    },
    MissingChargeLinkID: {
        Code: "BadData.MissingChargeLinkID",
        StatusCode: "500",
        ContextParameters: [
            { Name: "Entity", Type: "string", Description: "The entity that should contain the ChargeLinkID" }
        ],
        Message: "Missing ChargeLinkID property",
        MessageV1: "Missing ChargeLinkID property",
        Description: "This error occurs when a charge based discount is missing a ChargeLinkID"
    },
    InvalidEntityLinkTarget: {
        Code: "BadData.InvalidEntityLinkTarget",
        StatusCode: "500",
        ContextParameters: [
            { Name: "LinkValue", Type: "string", Description: "The path to the entity link target" }
        ],
        Message: "The Mapping Rule Action has an entity link with a target path which is invalid",
        MessageV1: "The Mapping Rule Action has an entity link with a target path which is invalid",
        Description: "This error occurs when a Mapping Action has an entity link with a target which is not valid"
    },
    InvalidCostPath: {
        Code: "BadData.InvalidCostPath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The entity was not recognised as a cost",
        MessageV1: "The entity was not recognised as a cost",
        Description: "This error occurs when a cost is expected, but the entity found could not be recognised as a cost"
    },
    UnsupportedCostType: {
        Code: "BadData.UnsupportedCostType",
        StatusCode: "500",
        ContextParameters: [
            { Name: "CostType", Type: "string", Description: "The cost type" }
        ],
        Message: "Unrecognised cost type",
        MessageV1: "Unrecognised cost type",
        Description: "This error occurs when a cost entity cannot be processed because the type of cost is not recognised by Catalog Services"
    },
    UnsupportedCostRateType: {
        Code: "BadData.UnsupportedCostRateType",
        StatusCode: "500",
        ContextParameters: [
            { Name: "CostRateType", Type: "string", Description: "The cost rate (markup) type" }
        ],
        Message: "Unrecognised cost rate type",
        MessageV1: "Unrecognised cost rate type",
        Description: "This error occurs when a rate contains a cost rate type which is not recognised or supported by Catalog Services"
    },
    ReferencedCostNotFound: {
        Code: "BadData.ReferencedCostNotFound",
        StatusCode: "500",
        ContextParameters: [
            { Name: "RateID", Type: "string", Description: "The ID of the rate" },
            { Name: "CostPath", Type: "string", Description: "The business ID path of the targeted cost" }
        ],
        Message: "Cost referenced by charge was not found in specification",
        MessageV1: "Cost referenced by charge was not found in specification",
        Description: "This error occurs when a cost based charge rate targets a cost which was not found in the specification"
    },
    InvalidDiscountPath: {
        Code: "BadData.InvalidDiscountPath",
        StatusCode: "500",
        ContextParameters: [],
        Message: "The entity was not recognised as a discount",
        MessageV1: "The entity was not recognised as a discount",
        Description: "This error occurs when a discount is expected, but the entity found could not be recognised as a cost"
    },
    UnsupportedDiscountType: {
        Code: "BadData.UnsupportedDiscountType",
        StatusCode: "500",
        ContextParameters: [
            { Name: "DiscountType", Type: "string", Description: "The discount type" }
        ],
        Message: "Unrecognised discount type",
        MessageV1: "Unrecognised discount type",
        Description: "This error occurs when a discount entity cannot be processed because the type of discount is not recognised by Catalog Services"
    },
    ReferencedEntityLinkNotFound: {
        Code: "BadData.ReferencedEntityLinkNotFound",
        StatusCode: "500",
        ContextParameters: [
            { Name: "RateID", Type: "string", Description: "The ID of the rate" },
            { Name: "EntityLinkID", Type: "string", Description: "The ID of the entity link" }
        ],
        Message: "Entity link referenced by charge was not found in specification",
        MessageV1: "Entity link referenced by charge was not found in specification",
        Description: "This error occurs when a cost based charge rate targets an entity link which was not found in the specification"
    },
    MissingRegex: {
        Code: "BadData.MissingRegex",
        StatusCode: "500",
        ContextParameters: [
            { Name: "EntityValue", Type: "string", Description: "The entity value" },
            { Name: "EntityPath", Type: "string", Description: "The entity path" },
            { Name: "InstancePath", Type: "string", Description: "The instance path" },
            { Name: "SchemaElementPath", Type: "string", Description: "The schema element path" },
            { Name: "UseId", Type: "string", Description: "The use id" }
        ],
        Message: "No regular expression provided",
        Messagev1: "No regular expression provided",
        Description: "This error occurs when regular expression is not provided in UDC Matches Values conditions"
    },
    MultipleUDCValue: {
        Code: "BadData.MultipleUDCValue",
        StatusCode: "500",
        ContextParameters: [
            { Name: "EntityValue", Type: "string", Description: "The entity value" },
            { Name: "EntityPath", Type: "string", Description: "The entity path" },
            { Name: "InstancePath", Type: "string", Description: "The instance path" },
            { Name: "SchemaElementPath", Type: "string", Description: "The schema element path" },
            { Name: "UseId", Type: "string", Description: "The use id" }
        ],
        Message: "Cannot Find a unique UDC Value to Use with the Condition",
        MessageV1: "Cannot Find a unique UDC Value to Use with the Condition",
        Description: "This error occurs when Multiple UDC Values have been provided without a valid further scope"
    }
};
module.exports = BadDataErrorCode;

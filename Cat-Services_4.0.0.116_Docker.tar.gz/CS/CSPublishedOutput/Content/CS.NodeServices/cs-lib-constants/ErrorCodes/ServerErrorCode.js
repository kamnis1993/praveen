"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Server in translation.json
 */
var ServerErrorCode = {
    UnsupportedContentEncoding: {
        Code: "Server.UnsupportedContentEncoding",
        StatusCode: "undefined",
        ContextParameters: [],
        Message: "The Content Encoding supplied in the request header is not supported by this application",
        MessageV1: "The Content Encoding supplied in the request header is not supported by this application",
        Description: "This Error is raised when the supplied Content Encoding is invalid and/or not supported by catalog services. Content-type in the header should be “application/xml” or “application/json"
    },
    DataValidation: {
        TestInProgress: {
            Code: "Server.DataValidation.TestInProgress",
            StatusCode: "400",
            ContextParameters: [],
            Message: "A data validation test is already in progress, please wait until it has finished",
            MessageV1: "A data validation test is already in progress, please wait until it has finished",
            Description: "The error is raised when a data validation test is already in progress and therefore another cannot be carried out until the current process has been completed"
        }
    }
};
module.exports = ServerErrorCode;

"use strict";
/// <reference path  = "../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/**
 * A list of possible Error codes coming from Validation in translation.json
 */
var ValidationErrorCode = {
    ActionNotAllowed: {
        Code: "Validation.ActionNotAllowed",
        StatusCode: "200",
        ContextParameters: [
            { Name: "Action", Type: "string", Description: "The Action specified in the request" },
            { Name: "DateMessage", Type: "string", Description: "The message describing why the date is invalid for the requested spec" }
        ],
        Message: "Action cannot be applied due to invalid date",
        MessageV1: "Cannot '__Action__' an entity __DateMessage__",
        Description: "When an action is requested on an order item or portfolio item, " +
            "and the ActivationDate on the order falls outside the Available or Effective date range of that item as defined in the catalog specification"
    },
    EntityOutOfDate: {
        Code: "Validation.EntityOutOfDate",
        StatusCode: "200",
        ContextParameters: [
            { Name: "DateMessage", Type: "string", Description: "The message describing why the date is invalid for the requested spec" }
        ],
        Message: "Entity with invalid date may not be included in an order or portfolio",
        MessageV1: "It is not valid to have this entity in an order or portfolio __DateMessage__",
        Description: "This validation message is raised when an order item or portfolio item is included in a request, but the ActivationDate falls outside the Available or Effective date range of that item, as defined in the catalog specification"
    },
    CharacteristicOutOfRange: {
        Code: "Validation.CharacteristicOutOfRange",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The cardinality set on a grouping structure is violated, because the product candidate structure is either missing required characteristic uses or has too many characteristic uses",
        MessageV1: "The cardinality set on a grouping structure is violated, because the product candidate structure is either missing required characteristic uses or has too many characteristic uses",
        Description: "This validation message is raised when the cardinality set on a grouping structure is violated, because the product candidate structure is either missing required characteristic uses or has too many characteristic uses"
    },
    DuplicateID: {
        Code: "Validation.DuplicateID",
        StatusCode: "200",
        ContextParameters: [],
        Message: "An ID has been duplicated in the request. All ID's must be unique across the whole request, both order and portfolio items",
        MessageV1: "An ID has been duplicated in the request. All ID's must be unique across the whole request, both order and portfolio items",
        Description: "This validation message is raised when the same unique order item or portfolio item ID is used multiple times in the same request"
    },
    DuplicatePortfolioItemID: {
        Code: "Validation.DuplicatePortfolioItemID",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The Portfolio Item ID is referenced by more than one Order Item",
        MessageV1: "The Portfolio Item ID is referenced by more than one Order Item",
        Description: "This validation message is raised when the same unique PortfolioItemID appears multiple times in the same request"
    },
    ExcludedChargeFound: {
        Code: "Validation.ExcludedChargeFound",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The charge is not applicable for this order",
        MessageV1: "The charge is not applicable for this order",
        Description: "This validation message is raised if an OrderCandidate request contains an excluded charge"
    },
    GroupCardinalityNotSatisfied: {
        Code: "Validation.GroupCardinalityNotSatisfied",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The cardinality set on a grouping structure is violated, because the product candidate structure is either missing required child items or has too many child items",
        MessageV1: "The cardinality set on a grouping structure is violated, because the product candidate structure is either missing required child items or has too many child items",
        Description: "This validation message is raised when a portfolio item in a product candidate request has too few or too many child items, breaking the cardinality"
    },
    InvalidConfiguredValue: {
        Code: "Validation.InvalidConfiguredValue",
        StatusCode: "200",
        ContextParameters: [
            { Name: "RequestMessage", Type: "string", Description: "The value provided in the request" },
            { Name: "ErrorMessage", Type: "string", Description: "The regular expression error message" },
            { Name: "CharacteristicName", Type: "string", Description: "The name of the characteristic provided in the catalog specification" },
            { Name: "RegularExpression", Type: "string", Description: "The regular expression in the provided in the catalog specification" }
        ],
        Message: "Invalid use of regular expression on the characteristic use",
        MessageV1: "__ErrorMessage__",
        Description: "This validation message is raised if a supplied characteristic use value does not match the associated regular expression, as defined on the characteristic use in the catalog specification"
    },
    InvalidCharacteristicUse: {
        Code: "Validation.InvalidCharacteristicUse",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The entity in the structure is invalid, because it contains a characteristic use that is not in the specification",
        MessageV1: "The entity in the structure is invalid, because it contains a characteristic use that is not in the specification",
        Description: "This validation message is raised when a request entity contains a characteristic use that does not exist in the catalog specification"
    },
    InvalidCharacteristicValue: {
        Code: "Validation.InvalidCharacteristicValue",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The entity in the structure is invalid, because it contains a characteristic value that is not in the specification",
        MessageV1: "The entity in the structure is invalid, because it contains a characteristic value that is not in the specification",
        Description: "This validation message is raised when a request entity contains a characteristic use value that does not exist in the catalog specification"
    },
    OutOfDateCharacteristicUse: {
        Code: "Validation.OutOfDateCharacteristicUse",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The entity in the structure is invalid, because it contains a characteristic use that is not available on the given activation date",
        MessageV1: "The entity in the structure is invalid, because it contains a characteristic use that is not available on the given activation date",
        Description: "This validation message is raised when a request entity contains a characteristic use is not available on the given activation date"
    },
    OutOfDateCharacteristicValue: {
        Code: "Validation.OutOfDateCharacteristicValue",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The entity in the structure is invalid, because it contains a characteristic value that is not available on the given activation date",
        MessageV1: "The entity in the structure is invalid, because it contains a characteristic value that is not available on the given activation date",
        Description: "This validation message is raised when a request entity contains a characteristic use value that is not available on the given activation date"
    },
    InvalidCustomerPortfolio: {
        Code: "Validation.InvalidCustomerPortfolio",
        StatusCode: "200",
        ContextParameters: [
            { Name: "ErrorMessage", Type: "string", Description: "The error message provided by the compatibility rule" }
        ],
        Message: "Compatibility Rule failed",
        MessageV1: "__ErrorMessage__",
        Description: "This validation message is raised when a requested portfolio item does not meet the requirements of a compatibility rule."
    },
    LimitNotSatisfied: {
        Code: "Validation.LimitNotSatisfied",
        StatusCode: "200",
        ContextParameters: [],
        Message: "Entity not valid for limit",
        MessageV1: "Entity not valid for limit",
        Description: "A limit value is supplied for an item in the order request which does not meet the Relation, Lookup Tree or Lookup Item limits defined in the catalog specification; " +
            "or when a limit value is not supplied for a SpecItemLookup or SpecItemTree that is required by the catalog specification"
    },
    PortfolioCardinalityError: {
        Code: "Validation.PortfolioCardinalityError",
        StatusCode: "200",
        ContextParameters: [
            { Name: "ActualNumber", Type: "string", Description: "Actual number of items supplied in the request" },
            { Name: "Min", Type: "string", Description: "The minimum cardinality" },
            { Name: "Max", Type: "string", Description: "The maximim cardinality" }
        ],
        Message: "Portfolio Cardinality for this entity has been violated",
        MessageV1: "Portfolio Cardinality for this entity has been violated. __ActualNumber__ instances were supplied and portfolio must contain a minimum of __Min__ and a maximum of __Max__",
        Description: "This validation message is raised when the requested portfolio contains an item that breaks the cardinality rules, as defined for that item by the catalog specification"
    },
    InvalidStructure: {
        Code: "Validation.InvalidStructure",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Root Order item structure is invalid",
        MessageV1: "Root Order item structure is invalid",
        Description: "This error is raised when a request contains no order or portfolio items"
    },
    MissingParentAction: {
        Code: "Validation.MissingParentAction",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Could not identify an action for this entity or its parents",
        MessageV1: "Could not identify an action for this entity or its parents",
        Description: "This error is raised when a request contains a root order item that has no action defined against it. The root item requires an Action such as 'add', 'update' or 'delete'"
    },
    MissingOrderfolioItem: {
        Code: "Validation.MissingOrderfolioItem",
        StatusCode: "400",
        ContextParameters: [],
        Message: "Cannot find an order or portfolio item",
        MessageV1: "Cannot find an order or portfolio item",
        Description: "This error is raised when a request references an order item or portfolio item that is not found within the request"
    },
    UnableToCommerciallyValidateCandidateWithTechnicalRoot: {
        Code: "Validation.UnableToCommerciallyValidateCandidateWithTechnicalRoot",
        StatusCode: "",
        ContextParameters: [],
        Message: "Validation not possible: commercial validation requested on a technical entity",
        MessageV1: "Validation not possible: commercial validation requested on a technical entity",
        Description: "This error is raised when attempting a commercial validation on a request that has a root order item or root portfolio item lying below the technical boundary"
    },
    InvalidOrderGenerationRequest: {
        Code: "Validation.InvalidOrderGenerationRequest",
        StatusCode: "400",
        ContextParameters: [],
        Message: "The supplied request is invalid. Old candidate and New candidate must be supplied",
        MessageV1: "The supplied request is invalid. Old candidate and New candidate must be supplied.",
        Description: "This error is raised when a request is made to generate an order, where the request is missing the old product candidate, or a new product candidate, or both"
    },
    InvalidRootOrderItemSource: {
        Code: "Validation.InvalidRootOrderItemSource",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The root order item cannot have an Item Source of Decompose",
        MessageV1: "The root order item cannot have an Item Source of Decompose",
        Description: "This validation message is raised when the root order item in a request has been created by the decompose process"
    },
    InvalidUserDefinedCharacteristicType: {
        Code: "Validation.InvalidUserDefinedCharacteristicType",
        StatusCode: "200",
        ContextParameters: [
            { Name: "UserDefinedCharacteristicTypeProvided", Type: "any", Description: "Typed User Defined Characteristic value provided" },
            { Name: "UserDefinedCharacteristicTypeExpected", Type: "any", Description: "Typed User Defined Characteristic value expected" }
        ],
        Message: "The User Defined Characteristic provided is not of the expected type",
        MessageV1: "An invalid User Defined Characteristic type, '__UserDefinedCharacteristicTypeProvided__' has been used where type '__UserDefinedCharacteristicTypeExpected__' is expected",
        Description: "This validation message is raised when a User Defined Characteristic of an incorrect type has been provided. e.g. expecting a data of type 'string' and data of type 'integer' is being supplied"
    },
    InvalidUserDefinedCharacteristicDateType: {
        Code: "Validation.InvalidUserDefinedCharacteristicDateType",
        StatusCode: "200",
        ContextParameters: [
            { Name: "UserDefinedCharacteristicTypeProvided", Type: "any", Description: "Typed User Defined Characteristic value provided" }
        ],
        Message: "The User Defined Characteristic provided is not a valid date or time",
        MessageV1: "An invalid User Defined Characteristic type, '__UserDefinedCharacteristicTypeProvided__' is not a valid date or time",
        Description: "This validation message is raised when a User Defined Characteristic does not match the format required by a date or time. i.e. YYYY-MM-DD, YYMMDD, hh:mm, hh:mm:ss, hhmm, hhmmss or YY-MM-DDThh:mm:ss"
    },
    InvalidUserDefinedCharacteristicNumberType: {
        Code: "Validation.InvalidUserDefinedCharacteristicNumberType",
        StatusCode: "400",
        ContextParameters: [
            { Name: "UserDefinedCharacteristicTypeProvided", Type: "any", Description: "Typed User Defined Characteristic value provided" }
        ],
        Message: "The User Defined Characteristic provided is not a valid Number",
        MessageV1: "An invalid User Defined Characteristic type, '__UserDefinedCharacteristicTypeProvided__' is not a valid Number",
        Description: "This validation message is raised when a User Defined Characteristic does not match the format required for a Number."
    },
    OrderNotApplicableToPortfolio: {
        NoChangeOnRoot: {
            Code: "Validation.OrderNotApplicableToPortfolio.NoChangeOnRoot",
            StatusCode: "200",
            ContextParameters: [],
            Message: "The Order is not applicable to the specified Portfolio",
            MessageV1: "The Order is not applicable to the specified Portfolio",
            Description: "This validation message is raised if a root order item has an item action of 'no change'"
        },
        PortfolioItemMissing: {
            Code: "Validation.OrderNotApplicableToPortfolio.PortfolioItemMissing",
            StatusCode: "400",
            ContextParameters: [
                { Name: "OrderItemID", Type: "string", Description: "The Id of the order item associated with this error" },
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" }
            ],
            Message: "The order item tried to act on a portfolio item that does not exist in the portfolio: { OrderItemID: __OrderItemID__, PortfolioItemID: __PortfolioItemID__}",
            MessageV1: "The order with item ID '__OrderItemID__' tried to act on a portfolio item that does not exists in the portfolio. The id of the portfolio item was : '__PortfolioItemID__'",
            Description: "The error is raised when an item in the order tries to reference a portfolio item that is not included in the portfolio"
        },
        OrderPortfolioItemIDMissing: {
            Code: "Validation.OrderNotApplicableToPortfolio.OrderPortfolioItemIDMissing",
            StatusCode: "400",
            ContextParameters: [
                { Name: "OrderItemID", Type: "string", Description: "The Id of the order item associated with this error" }
            ],
            Message: "The order item must have a portfolio item ID if the order does not have an action of Add: { OrderItemID: __OrderItemID__}",
            MessageV1: "The order with item ID '__OrderItemID__' must have a portfolio item ID if the order action is not add",
            Description: "This error is raised when attempting to 'update' or 'delete' an item, and that item does not have a PorfolioItemID identifying the portfolio item it is attempting to modify"
        },
        PortfolioItemIDMissing: {
            Code: "Validation.OrderNotApplicableToPortfolio.PortfolioItemIDMissing",
            StatusCode: "400",
            ContextParameters: [],
            Message: "The order is invalid because there is an existing portfolio item without an ID",
            MessageV1: "The order is invalid because there is an existing portfolio item without an ID",
            Description: "This error is raised when a request is made containing a portfolio item that is missing an ID"
        },
        AttemptToAddDuplicateItem: {
            Code: "Validation.OrderNotApplicableToPortfolio.AttemptToAddDuplicateItem",
            StatusCode: "400",
            ContextParameters: [
                { Name: "OrderItemID", Type: "string", Description: "The Id of the order item associated with this error" }
            ],
            Message: "The order item tried to add a duplicate item which has an EntityID and PortfolioItemID identical to an existing PortfolioItem: { OrderItemID: __OrderItemID__}",
            MessageV1: "OrderNotApplicableToPortfolio: The OrderItem with ID '__OrderItemID__' tried to add a duplicate item which has an EntityID and PortfolioItemID identical to an existing PortfolioItem",
            Description: "This error is raised when a OrderCandidate request contains entity with action 'add', but that exact entity already exists in the portfolio"
        },
        NoOrderEntityIDSupplied: {
            Code: "Validation.OrderNotApplicableToPortfolio.NoOrderEntityIDSupplied",
            StatusCode: "400",
            ContextParameters: [
                { Name: "OrderItemID", Type: "string", Description: "The Id of the order item associated with this error" }
            ],
            Message: "The order item is missing the required EntityID field: { OrderItemID: __OrderItemID__}",
            MessageV1: "The order item with ID '__OrderItemID__' is missing the required EntityID field.",
            Description: "This error is raised when a request is submitted containing an order item that does not contain an EntityID"
        },
        NoPortfolioEntityIDSupplied: {
            Code: "Validation.OrderNotApplicableToPortfolio.NoPortfolioEntityIDSupplied",
            StatusCode: "400",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" }
            ],
            Message: "The portfolio item is missing the required EntityID field: { PortfolioItemID: __PortfolioItemID__}",
            MessageV1: "The portfolio item with ID '__PortfolioItemID__' is missing the required EntityID field.",
            Description: "This error is raised when a request is submitted containing a portfolio item that does not contain an EntityID"
        },
        EntityIDDoesNotMatch: {
            Code: "Validation.OrderNotApplicableToPortfolio.EntityIDDoesNotMatch",
            StatusCode: "400",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" },
                { Name: "EntityID", Type: "string", Description: "The EntityId of the portfolio item associated with this error" }
            ],
            Message: "The order item does not match the entity ID of the corresponding portfolio item: { PortfolioItemID: __PortfolioItemID__, EntityID: __EntityID__}",
            MessageV1: "The order item with ID '__PortfolioItemID__' does not match the entity ID '__EntityID__' of the corresponding portfolio item",
            Description: "This error is raised for an OrderCandidate request where a portfolio item and order item have the same item ID but their EntityID's do not match"
        }
    },
    OrderRequestInvalid: {
        MissingProperty: {
            Code: "Validation.OrderRequestInvalid.MissingProperty",
            StatusCode: "400",
            ContextParameters: [
                { Name: "Property", Type: "string", Description: "The name of the missing property" },
                { Name: "Item", Type: "string", Description: "The entity item associated with the missing property" }
            ],
            Message: "The property must be specified: { Property: __Property__, Item: __Item__}",
            MessageV1: "Missing Property: The property __Property__ on the __Item__ must be specified",
            Description: "This error is raised when a required property is missing from the order request"
        },
        MissingOrInvalidActivationDate: {
            Code: "Validation.OrderRequestInvalid.MissingOrInvalidActivationDate",
            StatusCode: "400",
            ContextParameters: [],
            Message: "Invalid or missing activation date. Please supply as an ISO-8601 date",
            MessageV1: "Invalid or missing activation date. Please supply as an ISO-8601 date",
            Description: "This error is raised when the ActivationDate is missing from the order request"
        },
        InvalidCharacteristicUse: {
            Code: "Validation.OrderRequestInvalid.InvalidCharacteristicUse",
            StatusCode: "400",
            ContextParameters: [
                { Name: "EntityUniqueCode", Type: "string", Description: "The Id of the entity to which the missing characteristic use relates" },
                { Name: "CharacteristicID", Type: "string", Description: "The Id of the characteristic use entity that is missing from the specification" }
            ],
            Message: "Characteristic ID cannot be found in the specification: { EntityUniqueCode: __EntityUniqueCode__, CharacteristicID: __CharacteristicID__}",
            MessageV1: "InvalidCharacteristicUse: Item '__EntityUniqueCode__' contains a Characteristic with an ID of '__CharacteristicID__' that is not in the specification",
            Description: "This error will be raised when a user defined characteristic use is referenced in an order request, but is not found in the associated catalog specification"
        },
        MissingOrderCandidate: {
            Code: "Validation.OrderRequestInvalid.MissingOrderCandidate",
            StatusCode: "400",
            ContextParameters: [],
            Message: "The request did not supply a valid order candidate",
            MessageV1: "The request did not supply a valid order candidate",
            Description: "This error is raised when the OrderCandidate is missing from the order request"
        },
        MissingCustomerPortfolio: {
            Code: "Validation.OrderRequestInvalid.MissingCustomerPortfolio",
            StatusCode: "400",
            ContextParameters: [],
            Message: "The request did not supply a valid customer portfolio",
            MessageV1: "The request did not supply a valid customer portfolio",
            Description: "This error is raised when the CustomerPortfolio is missing from the order request"
        }
    },
    InvalidInputStructure: {
        Code: "Validation.InvalidInputStructure",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The input contained an invalid action hierarchy",
        MessageV1: "The input contained an invalid action hierarchy",
        Description: "The action specified for a child order item is invalid in relation to its parent item's action. e.g. An item marked with a 'delete' action cannot have a child item marked with an 'add' action"
    },
    RelationCardinalityNotSatisfied: {
        Code: "Validation.RelationCardinalityNotSatisfied",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The presence or absence of one or more child items violates the cardinality rules",
        MessageV1: "The presence or absence of one or more child items violates the cardinality rules",
        Description: "This validation message is raised when a request contains more than or less than the required child items specified for the parent item, as defined in the catalog specification; causing it to break cardinality rules"
    },
    UnexpectedChild: {
        Code: "Validation.UnexpectedChild",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The child entity found in the product candidate is not allowed according to the product specification",
        MessageV1: "The child entity found in the product candidate is not allowed according to the product specification",
        Description: "This validation message is raised if a product candidate contains child items that are not defined in the catalog specification, or for the specific level that they exist in the hierachy"
    },
    UnknownEntityID: {
        Code: "Validation.UnknownEntityID",
        StatusCode: "200",
        ContextParameters: [],
        Message: "The entity ID found in the order candidate does not exist in the database",
        MessageV1: "The entity ID found in the order candidate does not exist in the database",
        Description: "This validation message is raised if a requested entity is not found in the catalog services datastore"
    },
    MissingEntityLink: {
        Code: "Validation.MissingEntityLink",
        StatusCode: "200",
        ContextParameters: [
            { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeID of the entity link" }
        ],
        Message: "The entity in the structure is invalid, because it is missing required entity link",
        MessageV1: "The entity in the structure is invalid, because it is missing required entity link '__LinkTypeID__'",
        Description: "This validation message is raised if an entity link, required by an order item in the request, is missing from the request"
    },
    ProductCandidateRequestInvalid: {
        MissingOrInvalidCreationDate: {
            Code: "Validation.ProductCandidateRequestInvalid.MissingOrInvalidCreationDate",
            StatusCode: "400",
            ContextParameters: [],
            Message: "Invalid or missing creation date. Please supply as an ISO-8601 date",
            MessageV1: "Invalid or missing creation date. Please supply as an ISO-8601 date",
            Description: "This error is raised when the CreationDate is missing from the ProductCandidate in the request"
        },
        MissingProductCandidate: {
            Code: "Validation.ProductCandidateRequestInvalid.MissingProductCandidate",
            StatusCode: "400",
            ContextParameters: [],
            Message: "The request did not include a valid ProductCandidate",
            MessageV1: "The request did not supply a valid product candidate",
            Description: "This error is raised when the ProductCandidate is missing from the request or is invalid, e.g. it is missing the EntityID"
        }
    },
    InvalidEntityLink: {
        TargetNotFound: {
            Code: "Validation.InvalidEntityLink.TargetNotFound",
            StatusCode: "200",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" }
            ],
            Message: "A target entity with this Portfolio Item ID could not be found",
            MessageV1: "A target entity with ID '__PortfolioItemID__' could not be found",
            Description: "This validation message is raised when the PortfolioItemID specified in a requested entity link is missing from the portfolio"
        },
        InvalidTarget: {
            Code: "Validation.InvalidEntityLink.InvalidTarget",
            StatusCode: "200",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" },
                { Name: "EntityLinkID", Type: "string", Description: "The Id of the entity link item associated with this error" }
            ],
            Message: "This target entity is not valid for this entity link type.",
            MessageV1: "The target entity '__PortfolioItemID__' is not valid for an entity link of type '__EntityLinkID__'",
            Description: "This validation message is raised when the portfolio item associated with the requested entity link is not a valid target for the entity link type"
        },
        InvalidSource: {
            Code: "Validation.InvalidEntityLink.InvalidSource",
            StatusCode: "200",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" },
                { Name: "EntityLinkID", Type: "string", Description: "The Id of the entity link associated with this error" }
            ],
            Message: "The entity is not a valid source for this entity link",
            MessageV1: "The entity '__PortfolioItemID__' is not a valid source for the entity link of type '__EntityLinkID__'",
            Description: "This validation message is raised when the portfolio item associated with the requested entity link is not a valid source for the entity link"
        },
        IsUniqueViolated: {
            Code: "Validation.InvalidEntityLink.IsUniqueViolated",
            StatusCode: "200",
            ContextParameters: [
                { Name: "TargetID", Type: "string", Description: "The Id of the target entity in the portfolio" },
                { Name: "RelationID", Type: "string", Description: "The LinkTypeID of the entity link" },
                { Name: "ExistingSourceID", Type: "string", Description: "The Id of the source entity in the order" }
            ],
            Message: "The entity link must have unique targets",
            MessageV1: "A non-unique relation has been supplied, the target '__TargetID__' for relation '__RelationID__' is already related to '__ExistingSourceID__'",
            Description: "This validation message is raised when there are more than one possible target items in the portfolio for a requested entity link"
        },
        IsMultiViolated: {
            Code: "Validation.InvalidEntityLink.IsMultiViolated",
            StatusCode: "200",
            ContextParameters: [
                { Name: "RelationID", Type: "string", Description: "The LinkTypeID of the entity link" },
                { Name: "EntityUniqueCode", Type: "string", Description: "The Id of the the source entity in the order" }
            ],
            Message: "Relation cannot specify multiple targets",
            MessageV1: "The relation with ID '__RelationID__' on item '__EntityUniqueCode__' cannot specify multiple targets",
            Description: "This validation message is raised when an entity link is targeting multiple entities in the portfolio, but the entity link is not set to allow multiple targets in the catalog specification"
        },
        InvalidLinkTypeID: {
            Code: "Validation.InvalidEntityLink.InvalidLinkTypeID",
            StatusCode: "200",
            ContextParameters: [
                { Name: "PortfolioItemID", Type: "string", Description: "The Id of the portfolio item associated with this error" },
                { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeId of the entity link item associated with this error" }
            ],
            Message: "Entity contains an entity link that is not in the specification",
            MessageV1: "The entity '__PortfolioItemID__' contains an entity link '__LinkTypeID__' that is not in the specification",
            Description: "This validation message is raised when a request is referencing an entity link that does not exist in the catalog specification"
        },
        MissingPortfolioItemID: {
            Code: "Validation.InvalidEntityLink.MissingPortfolioItemID",
            StatusCode: "400",
            ContextParameters: [
                { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeId of the entity link item associated with this error" },
                { Name: "ItemType", Type: "string", Description: "Specifies that the entity link relates to either an order or portfolio item" },
                { Name: "EntityUniqueCode", Type: "string", Description: "The Id of the order or portfolio item associated with this error " }
            ],
            Message: "The portfolioItemID in invalid or missing on entity link: { LinkTypeID: __LinkTypeID__, ItemType: __ItemType__, EntityUniqueCode: __EntityUniqueCode__}",
            MessageV1: "The PortfolioItemID is invalid or missing on the entity link '__LinkTypeID__' on __ItemType__ '__EntityUniqueCode__'",
            Description: "This error is raised when the PortfolioItemID is missing from the portfolio item that the requested entity link is referencing"
        },
        OrderMissingPortfolioItemID: {
            Code: "Validation.InvalidEntityLink.OrderMissingPortfolioItemID",
            StatusCode: "200",
            ContextParameters: [],
            Message: "The PortfolioItemID is invalid or missing on the order and must be specified when using linked entities",
            MessageV1: "The PortfolioItemID is invalid or missing on the order and must be specified when using linked entities",
            Description: "This validation message is raised when the PortfolioItemID is missing from the order item that the requested entity link is referencing"
        }
    },
    PortfolioCandidate: {
        NoPortfolioSupplied: {
            Code: "Validation.PortfolioCandidate.NoPortfolioSupplied",
            StatusCode: "400",
            ContextParameters: [],
            Message: "No Portfolio supplied",
            MessageV1: "No Portfolio supplied",
            Description: "This error is raised when a portfolio candidate request has no portfolio items"
        },
        InvalidDate: {
            Code: "Validation.PortfolioCandidate.InvalidDate",
            StatusCode: "400",
            ContextParameters: [],
            Message: "CreationDate is missing from the portfolio item",
            MessageV1: "Invalid Date supplied",
            Description: "This error is raised when the portfolio item in a portfolio candidate request is missing the creation date, which is a required property"
        }
    },
    InvalidPropertyHierarchy: {
        OrderItemToCharacteristic: {
            Code: "Validation.InvalidPropertyHierarchy.OrderItemToCharacteristic",
            StatusCode: "200",
            ContextParameters: [
                { Name: "CharAction", Type: "string", Description: "The Action specified on the characteristic use" },
                { Name: "OrderItemAction", Type: "string", Description: "The Action specified on the order item" },
                { Name: "UseArea", Type: "string", Description: "The UseArea specified on the characteristic use" },
                { Name: "CharID", Type: "string", Description: "The Id of the characteristic use" }
            ],
            Message: "The characteristic cannot be modified due to an invalid order item action",
            MessageV1: "Cannot '__CharAction__' characteristic when order item action is '__OrderItemAction__', UseArea: '__UseArea__', CharacteristicID: '__CharID__'",
            Description: "This validation message is raised when a characteristic cannot be created or modified, because the order item action is not valid. e.g. If the item action is 'add' then the characteristic cannot be deleted"
        },
        CharacteristicToCharacteristicValue: {
            Code: "Validation.InvalidPropertyHierarchy.CharacteristicToCharacteristicValue",
            StatusCode: "200",
            ContextParameters: [
                { Name: "CharValueAction", Type: "string", Description: "The Action specified on the characteristic use value" },
                { Name: "CharAction", Type: "string", Description: "The Action specified on the characteristic use" },
                { Name: "UseArea", Type: "string", Description: "The UseArea specified on the characteristic use" },
                { Name: "CharID", Type: "string", Description: "The Id of the characteristic use" },
                { Name: "CharValue", Type: "string", Description: "The characteristic use Value" }
            ],
            Message: "The characteristic value has an invalid characteristic action",
            MessageV1: "Cannot '__charValueAction__' characteristic value when characteristic action is '__CharAction__', UseArea: '__UseArea__', CharacteristicID: '__CharID__', Value: '__CharValue__'",
            Description: "This validation message is raised when a characteristic value cannot be created or modified, because the characteristic action is not valid.  e.g. If the item action is 'add' then the characteristic value cannot be deleted"
        },
        OrderItemToCharacteristicValue: {
            Code: "Validation.InvalidPropertyHierarchy.OrderItemToCharacteristicValue",
            StatusCode: "200",
            ContextParameters: [
                { Name: "CharValueAction", Type: "string", Description: "The Action specified on the characteristic use value" },
                { Name: "OrderItemAction", Type: "string", Description: "The Action specified on the order item" },
                { Name: "UseArea", Type: "string", Description: "The UseArea specified on the characteristic use" },
                { Name: "CharID", Type: "string", Description: "The Id of the characteristic use" },
                { Name: "CharValue", Type: "string", Description: "The characteristic use Value" }
            ],
            Message: "The characteristic value has an invalid order item action",
            MessageV1: "Cannot '__charValueAction__' characteristic value when order item action is '__OrderItemAction__', UseArea: '__UseArea__', CharacteristicID: '__CharID__', Value: '__CharValue__'",
            Description: "A characteristic value cannot be created or modified, because the order item action is not valid. e.g. If an order item has an action of 'delete' then we cannot 'replace' a characteristic use"
        },
        OrderItemToRateAttribute: {
            Code: "Validation.InvalidPropertyHierarchy.OrderItemToRateAttribute",
            StatusCode: "200",
            ContextParameters: [
                { Name: "RateAction", Type: "string", Description: "The Action specified on the rate attribute" },
                { Name: "OrderItemAction", Type: "string", Description: "The Action specified on the order item" },
                { Name: "RateName", Type: "string", Description: "The rate attribute Name" },
                { Name: "RateValue", Type: "string", Description: "The rate attribute Value" }
            ],
            Message: "Rate attribute order item action is invalid",
            MessageV1: "Cannot '__rateAction__' rate attribute when order item action is '__OrderItemAction__', Name: '__RateName__', Value: '__RateValue__'",
            Description: "This validation message is raised when a rate attribute cannot be created or modified, because the order item action is not valid. e.g. If an order item has an action of 'add' then we cannot 'delete' a rate attribute"
        },
        OrderItemToEntityLink: {
            Code: "Validation.InvalidPropertyHierarchy.OrderItemToEntityLink",
            StatusCode: "200",
            ContextParameters: [
                { Name: "EntityLinkAction", Type: "string", Description: "The Action specified on the entity link" },
                { Name: "OrderItemAction", Type: "string", Description: "The Action specified on the order item" },
                { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeId specified on the entity link" }
            ],
            Message: "Entity Link order item action is invalid",
            MessageV1: "Cannot '__EntityLinkAction__' entity link when order item action is '__OrderItemAction__', LinkTypeID: '__LinkTypeID__'",
            Description: "This validation message is raised when a rate attribute cannot be modified, because the order item action is not valid. e.g. If an order item has an action of 'add' then we cannot 'delete' an entity link"
        },
        EntityLinkToLink: {
            Code: "Validation.InvalidPropertyHierarchy.EntityLinkToLink",
            StatusCode: "200",
            ContextParameters: [
                { Name: "LinkAction", Type: "string", Description: "The Action specified on the link target item" },
                { Name: "EntityLinkAction", Type: "string", Description: "The Action specified on the entity link" },
                { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeId specified on the entity link" },
                { Name: "PortfolioItemID", Type: "string", Description: "The PortFolioItemID of the link target item" }
            ],
            Message: "Entity link action is invalid",
            MessageV1: "Cannot '__linkAction__' link when entity link action is '__EntityLinkAction__', LinkTypeID: '__LinkTypeID__', PortfolioItemID: '__PortfolioItemID__'",
            Description: "This validation message is raised when a link cannot be created or modified, because the entity link action is not valid. e.g. If an entity link has an action of 'delete' then we cannot 'add' a link"
        },
        OrderItemToLink: {
            Code: "Validation.InvalidPropertyHierarchy.OrderItemToLink",
            StatusCode: "200",
            ContextParameters: [
                { Name: "LinkAction", Type: "string", Description: "The Action specified on the link target item" },
                { Name: "OrderItemAction", Type: "string", Description: "The action specified on the order item" },
                { Name: "LinkTypeID", Type: "string", Description: "The LinkTypeId specified on the entity link" },
                { Name: "PortfolioItemID", Type: "string", Description: "The PortFolioItemID of the link target item" }
            ],
            Message: "Link order item action is invalid",
            MessageV1: "Cannot '__linkAction__' link when order item action is '__OrderItemAction__', LinkTypeID: '__LinkTypeID__', PortfolioItemID: '__PortfolioItemID__'",
            Description: "This validation message is raised when a link cannot be created or modified, because the order action is not valid, e.g. If an order item has an action 'add' then we cannot 'delete' a link"
        }
    },
    InvalidRatingAttributes: {
        Code: "Validation.InvalidRatingAttributes",
        StatusCode: "200",
        ContextParameters: [
            { Name: "RatingAttributeName", Type: "string", Description: "The name of the rating attribute which has been provided multiple times" }
        ],
        Message: "A request may not contain rating attributes with duplicate names on the same entity",
        MessageV1: "A request may not contain rating attributes with duplicate names on the same entity, Name: __RatingAttributeName__",
        Description: "This validation message is raised when an entity has multiple rating attributes, and two or more share the same name"
    },
    InvalidReassignItemAction: {
        Code: "Validation.InvalidReassignItemAction",
        StatusCode: "200",
        ContextParameters: [
            { Name: "EntityID", Type: "string", Description: "The entity ID of the invalid item" },
            { Name: "ParentAction", Type: "string", Description: "The action type of the parent entity" },
            { Name: "ItemAction", Type: "string", Description: "The action type of the entity" }
        ],
        Message: "A request containing an item with action reassign cannot have a child with any action other than reassign",
        MessageV1: "A request containing an item with action reassign cannot have a child with any other action than reassign, EntityID: __EntityID__",
        Description: "This validation message is raised when an entity in an order candidate request has a parent with an ItemAction of reassign, " +
            "but its own action is something other than reassign."
    },
    InvalidReassignedItemAction: {
        Code: "Validation.InvalidReassignedItemAction",
        StatusCode: "200",
        ContextParameters: [
            { Name: "ParentAction", Type: "string", Description: "The action type of the parent entity" },
            { Name: "ItemAction", Type: "string", Description: "The action type of the entity" }
        ],
        Message: "A request containing an item with action reassigned can only contain a child with an action of reassigned, reassignedupdate, add or delete",
        MessageV1: "A request containing an item with action reassigned can only contain a child with an action of reassigned or reassignedupdate, add or delete, EntityID: __EntityID__",
        Description: "This validation message is raised when an entity in an order candidate request has a parent with an ItemAction of reassigned, " +
            "but its own action is something other than reassigned, reassignedupdate, add or delete."
    },
    InvalidReassignedUpdateItemAction: {
        Code: "Validation.InvalidReassignedUpdateItemAction",
        StatusCode: "200",
        ContextParameters: [
            { Name: "ParentAction", Type: "string", Description: "The action type of the parent entity" },
            { Name: "ItemAction", Type: "string", Description: "The action type of the entity" }
        ],
        Message: "A request containing an item with action reassignedUpdate can only contain a child with an action of reassignedUpdate, add or delete",
        MessageV1: "A request containing an item with action reassignedUpdate can only contain a child with an action of reassignedUpdate, add or delete, EntityID: __EntityID__",
        Description: "This validation message is raised when an entity in an order candidate request has a parent with an ItemAction of reassignedupdate, " +
            "but its own action is something other than reassignedupdate, add or delete."
    },
    MissingReassignItem: {
        Code: "Validation.MissingReassignItem",
        StatusCode: "200",
        ContextParameters: [],
        Message: "A request containing an item with action reassigned or reassignedupdate must have a matching reassign item when decompose processing is complete",
        MessageV1: "A request containing an item with action reassigned or reassignedupdate must have a matching reassign item when decompose processing is complete",
        Description: "This validation message is raised when a request containing reassigned items is returned without a matching pair of reassign/reassigned or reassign/reassignedupdate, " +
            "this can only occur due to an invalid request."
    },
    MissingReassignedItem: {
        Code: "Validation.MissingReassignedItem",
        StatusCode: "200",
        ContextParameters: [],
        Message: "A request containing an item with action reassign must have a matching reassigned, reassignedupdate or delete item when decompose processing is complete",
        MessageV1: "A request containing an item with action reassign must have a matching reassigned, reassignedupdate or delete item when decompose processing is complete",
        Description: "This validation message is raised when a request containing reassign items is returned without a matching pair of reassign/reassigned, reassign/reassignedupdate or reassign/delete items, " +
            "this can be due to mapping rules, cardinality rules or an internal error removing one of the items.  It can also occur if a reassign item in the request has been given the incorrect action."
    },
    ReassignItemMissingPortfolioItemId: {
        Code: "Validation.ReassignItemMissingPortfolioItemId",
        StatusCode: "200",
        ContextParameters: [
            { Name: "ItemAction", Type: "string", Description: "The ItemAction of order item" }
        ],
        Message: "Order Items with an action or reassign, reassigned or reassignedupdate must have a PortfolioItemId",
        MessageV1: "Order Items with an action or reassign, reassigned or reassignedupdate must have a PortfolioItemId",
        Description: "This validation message is raised when a request contains reassign, reassigned or reassignedUpdate order items without a PortfolioItemId."
    },
    ReassignItemDuplicatePortfolioItemId: {
        Code: "Validation.ReassignItemDuplicatePortfolioItemId",
        StatusCode: "200",
        ContextParameters: [],
        Message: "Multiple Order Items with an action of reassign cannot target the same PortfolioItemId",
        MessageV1: "Multiple Order Items with an action of reassign cannot target the same PortfolioItemId",
        Description: "This validation message is raised when a request contains multiple reassign order items that target the same PortfolioItemId."
    },
    ReassignedItemDuplicatePortfolioItemId: {
        Code: "Validation.ReassignedItemDuplicatePortfolioItemId",
        StatusCode: "200",
        ContextParameters: [],
        Message: "Multiple Order Items with an action of reassigned, reassignedUpdate or delete (under a reassignedupdate) cannot target the same PortfolioItemId",
        MessageV1: "Multiple Order Items with an action of reassigned, reassignedUpdate or delete (under a reassignedupdate) cannot target the same PortfolioItemId",
        Description: "This validation message is raised when a request contains multiple reassigned order items that target the same PortfolioItemId."
    },
    InvalidActionForType: {
        Code: "Validation.InvalidActionForType",
        StatusCode: "400",
        ContextParameters: [
            { Name: "Action", Type: "string", Description: "The Action specified in the request" },
            { Name: "CharacteristicID", Type: "string", Description: "The characteristic guid, if applicable" },
            { Name: "Value", Type: "string", Description: "The value or value guid, if applicable" }
        ],
        Message: "Action specified is not valid for this entity type",
        MessageV1: "Action '__Action__' is not valid for this type of entity, characteristic, or value",
        Description: "This validation message is raised when supplied with actions which cannot be implemented against certain types of entity, or are not valid action types."
    }
};
module.exports = ValidationErrorCode;

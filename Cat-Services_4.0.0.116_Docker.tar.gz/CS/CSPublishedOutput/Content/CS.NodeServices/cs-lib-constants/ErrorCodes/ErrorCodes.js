"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BadDataErrorCode = require("./BadDataErrorCode");
var DataAccessErrorCode = require("./DataAccessErrorCode");
var DecomposeErrorCode = require("./DecomposeErrorCode");
var FindErrorCode = require("./FindErrorCode");
var FrameworkContractsErrorCode = require("./FrameworkContractsErrorCode");
var ImportErrorCode = require("./ImportErrorCode");
var InterpretErrorCode = require("./InterpretErrorCode");
var ServerErrorCode = require("./ServerErrorCode");
var ManageErrorCode = require("./ManageErrorCode");
var SupplementalOrderErrorCode = require("./SupplementalOrderErrorCode");
var ValidationErrorCode = require("./ValidationErrorCode");
/**
 * This file is used as a master file to define all the Error Codes within the ErrorCodes directory.
 */
var ErrorCodes = {
    BadData: BadDataErrorCode,
    DataAccess: DataAccessErrorCode,
    Decompose: DecomposeErrorCode,
    Find: FindErrorCode,
    FrameworkContracts: FrameworkContractsErrorCode,
    Import: ImportErrorCode,
    Interpret: InterpretErrorCode,
    Server: ServerErrorCode,
    Manage: ManageErrorCode,
    SupplementalOrder: SupplementalOrderErrorCode,
    Validation: ValidationErrorCode
};
module.exports = ErrorCodes;

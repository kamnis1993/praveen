"use strict";
/**
 * The list of date statuses
 */
var DateStatus = {
    NotYetAvailable: "NotYetAvailable",
    NoLongerAvailable: "NoLongerAvailable",
    BeforeEffective: "BeforeEffectiveDate",
    AfterEffective: "AfterEffectiveDate",
    Available: "Available"
};
module.exports = DateStatus;

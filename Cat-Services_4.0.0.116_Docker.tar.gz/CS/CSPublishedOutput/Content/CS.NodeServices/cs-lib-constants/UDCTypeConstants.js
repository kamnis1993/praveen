"use strict";
/**
 * The list of guid constants for UDC data types
 */
var UDCTypeConstants = {
    String: "89899610-d70b-4c7e-be4e-8303d922b4d2",
    Boolean: "3ef52b86-487d-4b29-90c6-18cc55c3d87b",
    Integer: "8ca59a23-8fbd-42a1-aabf-12c86e3632fd",
    Decimal: "6c8dc724-040f-46d9-91b3-14373d428022",
    URI: "c9cc4056-6dc7-48df-8148-78213aba2b56",
    Date: "5863e7d8-683a-4982-93b5-6a0ed9ef4db6",
    Time: "8e85ff34-e4c1-4695-8fc2-42f7ddcf1311",
    DateTime: "4a095fb5-0abd-4473-a4b1-5de1b5335ec6"
    // Note that no data type guid exists for "NA"
};
module.exports = UDCTypeConstants;

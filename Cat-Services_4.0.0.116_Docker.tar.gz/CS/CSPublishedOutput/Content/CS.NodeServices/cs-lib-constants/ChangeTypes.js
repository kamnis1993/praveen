"use strict";
/**
 * The list of change types that an order item
 */
var ChangeTypes = {
    /**
     * Supplemental order created something on the in flight order
     */
    Create: "create",
    /**
     * Supplemental order did not change anything on the in flight order
     */
    NoChange: "nochange",
    /**
     * Supplemental order amended the in flight order
     */
    Amend: "amend",
    /**
     * Supplemental order cancelled this item
     */
    Cancel: "cancel"
};
module.exports = ChangeTypes;

"use strict";
var CompiledSpecificationConstants = {
    MissingEntityUuid: "-1"
};
module.exports = CompiledSpecificationConstants;

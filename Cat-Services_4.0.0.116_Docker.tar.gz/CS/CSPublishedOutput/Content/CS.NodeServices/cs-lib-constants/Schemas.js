"use strict";
/**
 * The list of Schema names, for use when defining routes
 * Names are pretty self-explanatory
 */
var Schemas = {
    ProductSpecification: 'ProductSpecification',
    OrderCandidate: 'OrderCandidateResponse',
    OrderCandidateVersion2: 'OrderCandidateResponse_V2',
    ProductCandidate: 'ProductCandidateResponse',
    SupplementalOrder: 'SupplementalOrderResponse',
    PricingOrderCandidate: 'OrderCandidatePricingResponse',
    PricingProductCandidate: 'ProductCandidatePricingResponse',
    InteractiveEndpoint: 'Interactive',
    Validation: 'FullCandidateValidateResponse',
    BadDataErrors: 'BadDataErrorsResponse'
};
module.exports = Schemas;

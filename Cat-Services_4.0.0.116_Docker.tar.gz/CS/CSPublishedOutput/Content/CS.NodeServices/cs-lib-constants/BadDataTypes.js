"use strict";
/**
 * The list of bad data error types
 */
var BadDataTypes = {
    /* Bad data in mapping rule */
    MappingRule: 'MappingRule',
    /* Bad data due to no entity found */
    NoEntityFound: 'NoEntityFound',
    /* Bad data due to no characteristic found */
    NoCharacteristicFound: 'NoCharacteristicFound',
    /* Bad data due to multiple schema element values found */
    MultipleValues: 'MultipleValues',
    /* Bad data due to missing required property*/
    MissingRequiredProperty: 'MissingRequiredProperty',
    /* Bad Data due to invalid property*/
    InvalidProperty: 'InvalidProperty',
    /* Bad Data due to unable to build spec */
    FatalBadData: "FatalBadData"
};
module.exports = BadDataTypes;

"use strict";
/**
 * The list of boundary conditions
 */
var BoundaryConditionConstants = {
    // The Technical boundary condition
    Technical: "technical",
    // The Commercial boundary condition
    Commercial: "commercial"
};
module.exports = BoundaryConditionConstants;

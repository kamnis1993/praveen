"use strict";
/// <reference types="node" />
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
var AmendOrderItemMerger = require("./AmendOrderItemMerger");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderItem = require("../cs-lib-types/BusinessEntities/OrderItem");
var SupplementalOrderBuilder = require("./SupplementalOrderBuilder");
var SupplementalOrderRequest = require("../cs-lib-types/BusinessEntities/SupplementalOrderRequest");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
/**
 * Class that applies a supplemental order to an existing decompose context
 */
var SupplementalOrderMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the SupplementalOrderMerger class
     * @param {CsErrorContext} errorContext The error context to use
     */
    function SupplementalOrderMerger(errorContext) {
        this._errorContext = errorContext;
        this._amendOrderItemMerger = new AmendOrderItemMerger(this._errorContext);
        this._idSet = {};
        this._orderItemIdSet = {};
    }
    /**
     * Merges a supplemental order and an in flight order together
     * @param {any} request The supplemental order request
     * @returns {SupplementalOrderRequest}
     */
    SupplementalOrderMerger.prototype.Merge = function (request) {
        var builder = new SupplementalOrderBuilder();
        var supplementalOrderRequest = new SupplementalOrderRequest(request);
        Logger.debug(0, "SupplementalOrder", "Starting To Process Supplemental Order Request", { InflightOrder: request.InflightOrder.OrderItem, SupplementalOrder: request.SupplementalOrder });
        supplementalOrderRequest.SupplementalOrder = builder.Build(request);
        if (Utilities.IsNotDefined(supplementalOrderRequest.SupplementalOrder)) {
            var validationContext = {
                Item: "SupplementalOrderRequest",
                Property: "SupplementalOrder"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return undefined;
        }
        if (Utilities.IsNotDefined(supplementalOrderRequest.ID, true)) {
            var validationContext = {
                Item: "SupplementalOrderRequest",
                Property: "ID"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return undefined;
        }
        if (Utilities.IsNotDefined(supplementalOrderRequest.OriginalRequestID, true)) {
            var validationContext = {
                Item: "SupplementalOrderRequest",
                Property: "OriginalRequestID"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return undefined;
        }
        // Store off the supplemental order ID, we don't use this yet but may do in the future
        // We need to output the OriginalRequestID out as the RequestID and use this ID in decompose
        supplementalOrderRequest.SupplementalOrderRequestID = supplementalOrderRequest.ID;
        supplementalOrderRequest.ID = supplementalOrderRequest.OriginalRequestID;
        // Order matters here, we need to do cancel first to make sure that none of the other supplemental order
        // items are affecting cancelled items
        // Same with amend, we need to make sure that we don't amend created items
        this.MergeCancel(supplementalOrderRequest);
        this.MergeAmend(supplementalOrderRequest);
        this.MergeCreate(supplementalOrderRequest);
        return supplementalOrderRequest;
    };
    /**
     * Merges the create block of a supplemental order request into the in flight order
     * @param {SupplementalOrderRequest} supplementalOrderRequest The supplemental order request
     */
    SupplementalOrderMerger.prototype.MergeCreate = function (supplementalOrderRequest) {
        var _this = this;
        var supplementalOrder = supplementalOrderRequest.SupplementalOrder;
        var orderCandidate = supplementalOrderRequest.OrderCandidate;
        if (Utilities.IsNotDefined(supplementalOrder.Create) || Utilities.IsNotDefined(supplementalOrder.Create.CreateOrderItems, true)) {
            return;
        }
        Logger.debug(2, "SupplementalOrder", "Processing create order items for inflight order");
        supplementalOrder.Create.CreateOrderItems.forEach(function (createOrderItem) {
            Logger.debug(3, "SupplementalOrder", "Processing Order Item with ID " + createOrderItem.ID, createOrderItem);
            if (!_this.IsValidSupplementalOrderItemId(createOrderItem, "CreateOrderItem")) {
                return;
            }
            _this.MergeCreateOrderItem(createOrderItem, orderCandidate);
        });
    };
    /**
     * Merges the cancel block of a supplemental order request into the inflight order
     * @param {SupplementalOrderRequest} supplementalOrderRequest The supplemental order request
     */
    SupplementalOrderMerger.prototype.MergeCancel = function (supplementalOrderRequest) {
        var _this = this;
        var supplementalOrder = supplementalOrderRequest.SupplementalOrder;
        var orderCandidate = supplementalOrderRequest.OrderCandidate;
        if (Utilities.IsNotDefined(supplementalOrder.Cancel) || Utilities.IsNotDefined(supplementalOrder.Cancel.CancelOrderItems, true)) {
            return;
        }
        supplementalOrder.Cancel.CancelOrderItems.forEach(function (cancelOrderItem) {
            Logger.debug(1, "SupplementalOrder", "Processing Cancel Item " + cancelOrderItem.ID + " into in flight order", cancelOrderItem);
            if (!_this.IsValidSupplementalOrderItemId(cancelOrderItem, "CancelOrderItem")) {
                return;
            }
            if (_this.CheckForDuplicatedOrderItemId(cancelOrderItem.OrderItemID, cancelOrderItem, "CancelOrderItem")) {
                Logger.debug(2, "SupplementalOrder", "Item already exist", cancelOrderItem.OrderItemID);
                return;
            }
            _this.MergeCancelOrderItem(cancelOrderItem, orderCandidate);
        });
    };
    /**
     * Merges the amend block of a supplemental order request into the in flight order
     * @param {SupplementalOrderRequest} supplementalOrderRequest The supplemental order request
     */
    SupplementalOrderMerger.prototype.MergeAmend = function (supplementalOrderRequest) {
        var _this = this;
        var supplementalOrder = supplementalOrderRequest.SupplementalOrder;
        if (Utilities.IsNotDefined(supplementalOrder.Amend) || Utilities.IsNotDefined(supplementalOrder.Amend.AmendOrderItems, true)) {
            return;
        }
        supplementalOrder.Amend.AmendOrderItems.forEach(function (amendOrderItem) {
            Logger.debug(1, "SupplementalOrder", "Processing Amend Item " + amendOrderItem.ID + " into in flight order", amendOrderItem);
            if (!_this.IsValidSupplementalOrderItemId(amendOrderItem, "AmendOrderItem")) {
                return;
            }
            if (_this.CheckForDuplicatedOrderItemId(amendOrderItem.OrderItemID, amendOrderItem, "AmendOrderItem")) {
                Logger.debug(2, "SupplementalOrder", "Item already exist", amendOrderItem.OrderItemID);
                return;
            }
            _this._amendOrderItemMerger.MergeAmendOrderItem(amendOrderItem, supplementalOrderRequest);
        });
    };
    /**
     * Merges a create order item into the in flight order
     * @param {CsTypes.OrderItem} createOrderItem The create order item
     * @param {OrderCandidate} orderCandidate The in flight order
     */
    SupplementalOrderMerger.prototype.MergeCreateOrderItem = function (createOrderItem, orderCandidate) {
        var _this = this;
        var orderItemLookup = orderCandidate.OrderItemLookup;
        if (Utilities.IsNotDefined(createOrderItem) || Utilities.IsNotDefined(createOrderItem.OrderItems, true)) {
            var validationContext = {
                Item: "CreateOrderItem",
                Property: "OrderItem"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return;
        }
        // Find any defined parent, do not do any work if the parent cannot be found
        var parentOrderItemLookup = undefined;
        if (Utilities.IsDefined(createOrderItem.ParentOrderItemID, true)) {
            parentOrderItemLookup = orderItemLookup[createOrderItem.ParentOrderItemID];
            if (Utilities.IsNotDefined(parentOrderItemLookup)) {
                // Parent specified does not exist
                var validationContext = {
                    CreateOrderItemID: createOrderItem.ID,
                    ParentOrderItemID: createOrderItem.ParentOrderItemID
                };
                this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.ParentOrderItemDoesNotExist, createOrderItem.ParentOrderItemID, undefined, validationContext);
                return;
            }
        }
        createOrderItem.OrderItems.forEach(function (orderItem) {
            Logger.debug(4, "SupplementalOrder", "Processing order item " + orderItem.ID, orderItem);
            if (Utilities.IsNotDefined(orderItem.ID, true)) {
                var validationContext = {
                    Item: "CreateOrderItem.OrderItem",
                    Property: "ID"
                };
                _this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
                return;
            }
            if (_this.CheckForDuplicatedOrderItemId(orderItem.ID, createOrderItem, "CreateOrderItem")) {
                Logger.debug(5, "SupplementalOrder", "Item already exist", orderItem.ID);
                return;
            }
            if (Utilities.IsDefined(orderItemLookup[orderItem.ID])) {
                var validationContext = {
                    CreateOrderItemID: createOrderItem.ID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.OrderItemIDAlreadyExists, orderItem.ID, orderItem.EntityID, validationContext);
                return;
            }
            // If parent is not defined this is a root level item
            if (Utilities.IsNotDefined(parentOrderItemLookup)) {
                Logger.debug(5, "SupplementalOrder", "Added order item at root level", orderItem.ID);
                orderCandidate.OrderItems.push(new OrderItem(orderItem));
            }
            else {
                parentOrderItemLookup.OrderItem.ChildOrderItems.push(new OrderItem(orderItem));
                Logger.debug(5, "SupplementalOrder", "Added order item as child order item of root", orderItem.ID);
            }
        });
    };
    /**
     * Merges a cancel order item into the in flight order
     * @param {CsTypes.CancelOrderItem} cancelOrderItem The cancel order item
     * @param {OrderCandidate} orderCandidate The in flight order
     * @param {Array<IOrderItemLookup>} cancelledItems The order items that have been cancelled
     */
    SupplementalOrderMerger.prototype.MergeCancelOrderItem = function (cancelOrderItem, orderCandidate) {
        var _this = this;
        var orderItemLookup = orderCandidate.OrderItemLookup;
        if (Utilities.IsNotDefined(cancelOrderItem.OrderItemID, true)) {
            var validationContext = {
                Item: "CancelOrderItem",
                Property: "OrderItemID"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return;
        }
        if (Utilities.IsNotDefined(orderItemLookup[cancelOrderItem.OrderItemID])) {
            var validationContext = {
                InstructionType: "Cancel",
                InstructionID: cancelOrderItem.ID,
                OrderItemID: cancelOrderItem.OrderItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.OrderItemDoesNotExist, cancelOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var orderItemEntry = orderItemLookup[cancelOrderItem.OrderItemID];
        var itemsToSearch = [];
        if (Utilities.IsNotDefined(orderItemEntry.ParentOrderItemId, true)) {
            itemsToSearch = orderCandidate.OrderItems;
        }
        else {
            var parent = orderItemLookup[orderItemEntry.ParentOrderItemId];
            itemsToSearch = parent.OrderItem.ChildOrderItems;
        }
        Logger.debug(4, "SupplementalOrder", "Removing OrderItem " + orderItemEntry.OrderItem.ID, function () { return _this.LogMappedContext(orderItemEntry, itemsToSearch); });
        var index = itemsToSearch.indexOf(orderItemEntry.OrderItem);
        itemsToSearch.splice(index, 1);
    };
    /**
    * Apply logging for mapped context
    * @param {CsTypes.OrderItemLookup} orderItemEntry order item in question
    * @param {CsTypes.IOrderItem[]} orderItems Inflight order items that will be affected
    */
    SupplementalOrderMerger.prototype.LogMappedContext = function (orderItemEntry, orderItems) {
        return {
            OrderItemToRemove: {
                ID: orderItemEntry.OrderItem.ID,
                EntityID: orderItemEntry.OrderItem.EntityID
            },
            AffectedOrderItems: {
                ParentOrderItem: orderItemEntry.ParentOrderItemId,
                IDs: LodashUtilities.Map(orderItems, function (orderItem) { return orderItem.ID; }),
                Entities: LodashUtilities.Map(orderItems, function (orderItem) { return orderItem.EntityID; })
            }
        };
    };
    /**
     * Checks the supplemental order item ID is provided and is not duplicated and raises a validation error if any issues are found
     * @param {CsTypes.BaseItem} baseItem The item to check
     * @param {string} baseItemName The name of the base items type
     * {boolean}
     */
    SupplementalOrderMerger.prototype.IsValidSupplementalOrderItemId = function (baseItem, baseItemType) {
        if (Utilities.IsNotDefined(baseItem.ID, true)) {
            var validationContext_1 = {
                Item: baseItemType,
                Property: "ID"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext_1);
            return false;
        }
        if (Utilities.IsNotDefined(this._idSet[baseItem.ID])) {
            this._idSet[baseItem.ID] = baseItem.ID;
            return true;
        }
        var validationContext = {
            Item: baseItemType
        };
        this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.DuplicatedSupplementalOrderID, baseItem.ID, undefined, validationContext);
        return false;
    };
    /**
     * Checks if we have already seen an supplemental order item that targets the order item ID provided and raises an error if any are found
     * @param  {string} orderItemId The order item to check
     * @param {CsTypes.BaseItem} baseItem The item that targets the order item
     * {boolean}
     */
    SupplementalOrderMerger.prototype.CheckForDuplicatedOrderItemId = function (orderItemId, baseItem, baseItemType) {
        if (Utilities.IsNotDefined(orderItemId, true)) {
            return false;
        }
        if (Utilities.IsNotDefined(this._orderItemIdSet[orderItemId])) {
            this._orderItemIdSet[orderItemId] = orderItemId;
            return false;
        }
        var validationContext = {
            Item: baseItemType,
            OrderItemID: orderItemId
        };
        this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.DuplicatedOrderItemID, baseItem.ID, undefined, validationContext);
        return true;
    };
    return SupplementalOrderMerger;
}());
module.exports = SupplementalOrderMerger;

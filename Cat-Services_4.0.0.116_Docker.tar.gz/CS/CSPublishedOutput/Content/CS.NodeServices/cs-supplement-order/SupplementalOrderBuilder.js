"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var Utilities = require("../cs-lib-utilities/Utilities");
var CharacteristicUse = require("../cs-lib-types/BusinessEntities/CharacteristicUse");
var EntityLink = require("../cs-lib-types/BusinessEntities/EntityLink");
var OrderItem = require("../cs-lib-types/BusinessEntities/OrderItem");
var RateAttribute = require("../cs-lib-types/BusinessEntities/RateAttribute");
var UserDefinedCharacteristicUse = require("../cs-lib-types/BusinessEntities/UserDefinedCharacteristicUse");
var Logger = require("../cs-logging/Logger");
/**
 * Class that builds a Supplemental Order from a request
 */
var SupplementalOrderBuilder = /** @class */ (function () {
    function SupplementalOrderBuilder() {
    }
    /**
     * Builds a supplemental order from a request input
     * @param {any} request The request input
     * @returns {CsTypes.SupplementalOrder}
     */
    SupplementalOrderBuilder.prototype.Build = function (request) {
        if (Utilities.IsNotDefined(request) || Utilities.IsNotDefined(request.SupplementalOrder)) {
            Logger.debug(1, "SupplementalOrder", "request or request's supplemental order is undefined ", request);
            return undefined;
        }
        var supplementalOrderInput = request.SupplementalOrder;
        var supplementalOrder = {
            Create: this.BuildCreate(supplementalOrderInput),
            Cancel: this.BuildCancel(supplementalOrderInput),
            Amend: this.BuildAmend(supplementalOrderInput)
        };
        Logger.debug(1, "SupplementalOrder", "Finished Bulding Supplemental Order ", supplementalOrder);
        return supplementalOrder;
    };
    /**
     * Builds a Cancel object
     * @param {CsTypes.SupplementalOrder} supplementalOrderInput The supplemental order
     * @returns {CsTypes.Cancel}
     */
    SupplementalOrderBuilder.prototype.BuildCancel = function (supplementalOrderInput) {
        var _this = this;
        if (Utilities.IsNotDefined(supplementalOrderInput.Cancel)) {
            return undefined;
        }
        var cancel = {
            CancelOrderItems: []
        };
        var cancelOrderItems = Utilities.asArray(supplementalOrderInput.Cancel.CancelOrderItems);
        cancelOrderItems.forEach(function (orderItem) {
            var cancelOrderItem = _this.BuildCancelOrderItem(orderItem);
            cancel.CancelOrderItems.push(cancelOrderItem);
        });
        return cancel;
    };
    /**
     * Builds a Create object
     * @param {CsTypes.SupplementalOrder} supplementalOrderInput The supplemental order
     * @returns {CsTypes.Create}
     */
    SupplementalOrderBuilder.prototype.BuildCreate = function (supplementalOrderInput) {
        var _this = this;
        if (Utilities.IsNotDefined(supplementalOrderInput.Create)) {
            return undefined;
        }
        var create = {
            CreateOrderItems: []
        };
        var createOrderItems = Utilities.asArray(supplementalOrderInput.Create.CreateOrderItems);
        createOrderItems.forEach(function (orderItem) {
            var createOrderItem = _this.BuildCreateOrderItem(orderItem);
            create.CreateOrderItems.push(createOrderItem);
        });
        return create;
    };
    /**
     * Builds an Amend object
     * @param {CsTypes.SupplementalOrder} supplementalOrderInput The supplemental order
     * @returns {CsTypes.Amend}
     */
    SupplementalOrderBuilder.prototype.BuildAmend = function (supplementalOrderInput) {
        var _this = this;
        if (Utilities.IsNotDefined(supplementalOrderInput.Amend)) {
            return undefined;
        }
        var amend = {
            AmendOrderItems: []
        };
        var amendOrderItems = Utilities.asArray(supplementalOrderInput.Amend.AmendOrderItems);
        amendOrderItems.forEach(function (orderItem) {
            var amendOrderItem = _this.BuildAmendOrderItem(orderItem);
            amend.AmendOrderItems.push(amendOrderItem);
        });
        return amend;
    };
    /**
     * Builds a CancelOrderItem object
     * @param {CsTypes.CancelOrderItem} canceOrderItemInput The input used to build the cancel order item
     * @returns {CsTypes.CancelOrderItem}
     */
    SupplementalOrderBuilder.prototype.BuildCancelOrderItem = function (canceOrderItemInput) {
        var cancelOrderItem = {
            ID: Utilities.ValueOrDefault(canceOrderItemInput.ID, undefined),
            OrderItemID: Utilities.ValueOrDefault(canceOrderItemInput.OrderItemID, undefined)
        };
        Logger.debug(1, "SupplementalOrder", "Starting To Build Cancel Item - " + cancelOrderItem.ID, cancelOrderItem);
        return cancelOrderItem;
    };
    /**
     * Builds a CreateOrderItem object
     * @param {CsTypes.CreateOrderItem} createOrderItemInput The input used to build the create order item
     * @returns {CsTypes.CreateOrderItem}
     */
    SupplementalOrderBuilder.prototype.BuildCreateOrderItem = function (createOrderItemInput) {
        var createOrderItem = {
            ID: Utilities.ValueOrDefault(createOrderItemInput.ID, undefined),
            ParentOrderItemID: Utilities.ValueOrDefault(createOrderItemInput.ParentOrderItemID, undefined),
            OrderItems: []
        };
        Logger.debug(1, "SupplementalOrder", "Starting To Build Create Item - " + createOrderItem.ID, createOrderItem);
        var orderItems = Utilities.asArray(createOrderItemInput.OrderItems);
        orderItems.forEach(function (orderItem) {
            createOrderItem.OrderItems.push(new OrderItem(orderItem));
        });
        return createOrderItem;
    };
    /**
     * Builds a AmendOrderItem object
     * @param {CsTypes.AmendOrderItem} amendOrderItemInput The input used to build the amend order item
     * @returns {CsTypes.AmendOrderItem}
     */
    SupplementalOrderBuilder.prototype.BuildAmendOrderItem = function (amendOrderItemInput) {
        var amendOrderItem = {
            ID: Utilities.ValueOrDefault(amendOrderItemInput.ID, undefined),
            OrderItemID: Utilities.ValueOrDefault(amendOrderItemInput.OrderItemID, undefined),
            ItemAction: Utilities.ValueOrDefault(amendOrderItemInput.ItemAction, undefined, true),
            ItemSource: Utilities.ValueOrDefault(amendOrderItemInput.ItemSource, undefined),
            CharacteristicUses: [],
            ConfiguredValues: [],
            LinkedEntities: [],
            RateAttributes: []
        };
        Logger.debug(1, "SupplementalOrder", "Starting To Build Amend Item - " + amendOrderItem.ID, amendOrderItem);
        Utilities.asArray(amendOrderItemInput.CharacteristicUses).forEach(function (charUse) {
            amendOrderItem.CharacteristicUses.push(new CharacteristicUse(charUse));
            Logger.debug(2, "SupplementalOrder", "Added CharacteristicUse to Amend Item", charUse);
        });
        Utilities.asArray(amendOrderItemInput.ConfiguredValues).forEach(function (confValue) {
            amendOrderItem.ConfiguredValues.push(new UserDefinedCharacteristicUse(confValue));
            Logger.debug(2, "SupplementalOrder", "Added ConfiguredValues to Amend Item", confValue);
        });
        Utilities.asArray(amendOrderItemInput.RateAttributes).forEach(function (rateAttribute) {
            amendOrderItem.RateAttributes.push(new RateAttribute(rateAttribute));
            Logger.debug(2, "SupplementalOrder", "Added RateAttributes to Amend Item", rateAttribute);
        });
        Utilities.asArray(amendOrderItemInput.LinkedEntities).forEach(function (linkedEntity) {
            amendOrderItem.LinkedEntities.push(new EntityLink(linkedEntity));
            Logger.debug(2, "SupplementalOrder", "Added LinkedEntities to Amend Item", linkedEntity);
        });
        return amendOrderItem;
    };
    return SupplementalOrderBuilder;
}());
module.exports = SupplementalOrderBuilder;

"use strict";
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
/// <reference types="node" />
var ChangeTypes = require("../cs-lib-constants/ChangeTypes");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Class responsible for merging entity links in an amend section of a supplemental order
 */
var AmendEntityLinkMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the AmendEntityLinkMerger class
     * @param {CsErrorContext} errorContext The error context
     */
    function AmendEntityLinkMerger(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Merges the entity links into the in flight order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendEntityLinkMerger.prototype.Merge = function (amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(amendOrderItem.LinkedEntities, true)) {
            return;
        }
        Logger.debug(2, "SupplementalOrder", "Processing entity links for inflight order");
        amendOrderItem.LinkedEntities.forEach(function (entityLink) {
            Logger.debug(3, "SupplementalOrder", "Processing CharacteristicUse with ID " + entityLink.LinkTypeID, entityLink);
            if (entityLink.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateEntityLink(entityLink, amendOrderItem, orderItem);
            }
            else if (entityLink.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelEntityLink(entityLink, amendOrderItem, orderItem);
            }
            else if (entityLink.ChangeType === ChangeTypes.Amend) {
                _this.MergeLinks(entityLink, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    Property: "LinkedEntity",
                    ChangeType: entityLink.ChangeType,
                    PropertyIdentification: "LinkTypeID: " + entityLink.LinkTypeID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnProperty, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Creates an entity link in the in flight order
     * @param {CsTypes.IEntityLink} entityLink The entity link to create
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to create the entity link on
     */
    AmendEntityLinkMerger.prototype.MergeCreateEntityLink = function (entityLink, amendOrderItem, orderItem) {
        var existingEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === entityLink.LinkTypeID; });
        if (Utilities.IsDefined(existingEntityLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkedEntityAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        orderItem.LinkedEntities.push(entityLink);
        Logger.debug(4, "SupplementalOrder", "Added Characteristic to orderItem", {
            LinkID: entityLink.LinkTypeID,
            OrderItemID: orderItem.ID,
            EntityID: orderItem.EntityID
        });
    };
    /**
     * Cancels an entity link from the in flight order
     * @param {CsTypes.IEntityLink} entityLink The entity link to cancel
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to cancel it from
     */
    AmendEntityLinkMerger.prototype.MergeCancelEntityLink = function (entityLink, amendOrderItem, orderItem) {
        var existingEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === entityLink.LinkTypeID; });
        if (Utilities.IsNotDefined(existingEntityLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkedEntityDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = orderItem.LinkedEntities.indexOf(existingEntityLink);
        orderItem.LinkedEntities.splice(index, 1);
        Logger.debug(4, "SupplementalOrder", "Removed Characteristic Use " + existingEntityLink.LinkTypeID + " from order item", {
            EntityLinkIDToRemove: existingEntityLink.LinkTypeID,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID
            }
        });
    };
    /**
     * Merges the links into the entity link on the order
     * @param {CsTypes.IEntityLink} entityLink The entity link on the order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendEntityLinkMerger.prototype.MergeLinks = function (entityLink, amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(entityLink.Links, true)) {
            return;
        }
        entityLink.Links.forEach(function (link) {
            Logger.debug(4, "SupplementalOrder", "Processing link target", link);
            if (link.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateLink(link, entityLink, amendOrderItem, orderItem);
            }
            else if (link.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelLink(link, entityLink, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    PropertyValue: "LinkedEntity.Link",
                    ChangeType: link.ChangeType,
                    ValueIdentification: "LinkTypeID: " + entityLink.LinkTypeID + ", PortfolioItemID: " + link.PortfolioItemID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnValue, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Merges a create link into the in flight order
     * @param {CsTypes.ILinkTarget} link The link to create
     * @param {CsTypes.IEntityLink} entityLink The entity link on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendEntityLinkMerger.prototype.MergeCreateLink = function (link, entityLink, amendOrderItem, orderItem) {
        var existingEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === entityLink.LinkTypeID; });
        if (Utilities.IsNotDefined(existingEntityLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkedEntityDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingLink = LodashUtilities.Find(existingEntityLink.Links, function (l) { return l.PortfolioItemID === link.PortfolioItemID; });
        if (Utilities.IsDefined(existingLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID,
                PortfolioItemID: link.PortfolioItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        existingEntityLink.Links.push(link);
        Logger.debug(5, "SupplementalOrder", "Added link value to characteristic use", {
            Link: link,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                LinkID: existingEntityLink.LinkTypeID
            }
        });
    };
    /**
     * Merges the cancelled link into the in flight order
     * @param {CsTypes.ILinkTarget} link The link to create
     * @param {CsTypes.IEntityLink} entityLink The entity link on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendEntityLinkMerger.prototype.MergeCancelLink = function (link, entityLink, amendOrderItem, orderItem) {
        var existingEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === entityLink.LinkTypeID; });
        if (Utilities.IsNotDefined(existingEntityLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkedEntityDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingLink = LodashUtilities.Find(existingEntityLink.Links, function (l) { return l.PortfolioItemID === link.PortfolioItemID; });
        if (Utilities.IsNotDefined(existingLink)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                LinkTypeID: entityLink.LinkTypeID,
                PortfolioItemID: link.PortfolioItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.LinkDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = existingEntityLink.Links.indexOf(existingLink);
        existingEntityLink.Links.splice(index, 1);
        Logger.debug(5, "SupplementalOrder", "Removed link from entity links", {
            LinkToRemove: existingLink,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                LinkID: existingEntityLink.LinkTypeID
            }
        });
    };
    return AmendEntityLinkMerger;
}());
module.exports = AmendEntityLinkMerger;

"use strict";
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
/// <reference types="node" />
var ChangeTypes = require("../cs-lib-constants/ChangeTypes");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Class responsible for merging rate attributes in an amend section of a supplemental order
 */
var AmendRateAttributeMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the AmendCharacteristicUseMerger class
     * @param {CsErrorContext} errorContext The error context
     */
    function AmendRateAttributeMerger(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Merges the rate attributes into the in flight order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param CsTypes.IOrderItem orderItem The order item
     */
    AmendRateAttributeMerger.prototype.Merge = function (amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(amendOrderItem.RateAttributes, true)) {
            return;
        }
        Logger.debug(2, "SupplementalOrder", "Processing rate attributes for inflight order");
        amendOrderItem.RateAttributes.forEach(function (rateAttribute) {
            Logger.debug(3, "SupplementalOrder", "Processing rate attribute - " + rateAttribute.Name, rateAttribute);
            if (rateAttribute.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateRateAttribute(rateAttribute, amendOrderItem, orderItem);
            }
            else if (rateAttribute.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelRateAttribute(rateAttribute, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    PropertyValue: "RateAttribute",
                    ChangeType: rateAttribute.ChangeType,
                    ValueIdentification: "Name: " + rateAttribute.Name + ", Value: " + rateAttribute.Value
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnValue, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Creates a rate attribute in the in flight order
     * @param {CsTypes.IOrderRateAttribute} rateAttribute The rate attribute to create
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to create the rate attribute on
     */
    AmendRateAttributeMerger.prototype.MergeCreateRateAttribute = function (rateAttribute, amendOrderItem, orderItem) {
        var existingRate = LodashUtilities.Find(orderItem.RateAttributes, function (r) { return r.Name === rateAttribute.Name; });
        if (Utilities.IsDefined(existingRate)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                RateAttributeName: rateAttribute.Name
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.RateAttributeAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        orderItem.RateAttributes.push(rateAttribute);
        Logger.debug(4, "SupplementalOrder", "Added rate attribute to orderItem", {
            RateAttributeName: rateAttribute.Name,
            OrderItemID: orderItem.ID,
            EntityID: orderItem.EntityID
        });
    };
    /**
     * Cancels a rate attribute from the in flight order
     * @param {CsTypes.IOrderRateAttribute} rateAttribute The rate attribute to cancel
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to cancel it from
     */
    AmendRateAttributeMerger.prototype.MergeCancelRateAttribute = function (rateAttribute, amendOrderItem, orderItem) {
        var existingRate = LodashUtilities.Find(orderItem.RateAttributes, function (r) { return r.Name === rateAttribute.Name; });
        if (Utilities.IsNotDefined(existingRate)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                RateAttributeName: rateAttribute.Name
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.RateAttributeDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = orderItem.RateAttributes.indexOf(existingRate);
        orderItem.RateAttributes.splice(index, 1);
        Logger.debug(4, "SupplementalOrder", "Removed rate attributes from order item", {
            RateAttributeToRemove: existingRate,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID
            }
        });
    };
    return AmendRateAttributeMerger;
}());
module.exports = AmendRateAttributeMerger;

"use strict";
/// <reference types="node" />
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var Decompose = require("../cs-decompose/Decompose");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var DecomposeGenIdController = require("./ReApplyDecompose/DecomposeGenIdController");
var DecomposeReverser = require("./ReApplyDecompose/DecomposeReverser");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var SupplementalOrderMerger = require("./SupplementalOrderMerger");
var SupplementalOrderRequest = require("../cs-lib-types/BusinessEntities/SupplementalOrderRequest");
var SupplementalOrderResponseBuilder = require("../cs-lib-composition/SupplementalOrderResponseBuilder");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
var SupplementalOrder = /** @class */ (function () {
    function SupplementalOrder() {
    }
    SupplementalOrder.prototype.ProcessSupplementalOrder = function (request, compiledSpecs, callback) {
        var _this = this;
        // Get the response's error context
        var errorContext = new CsErrorContext({});
        this.ValidateRequestBody(request, errorContext);
        if (errorContext.HasBreakingErrors) {
            return callback(this.GetError(errorContext), null);
        }
        var supplementalOrderMerger = new SupplementalOrderMerger(errorContext);
        var processedSupplementalOrderRequest = supplementalOrderMerger.Merge(request);
        if (errorContext.HasBreakingErrors) {
            return callback(this.GetError(errorContext), null);
        }
        Logger.debug(1, "SupplementalOrder", "Processed Supplemental Order Request", processedSupplementalOrderRequest.OrderCandidate.OrderItems);
        var expectedDecomposeItemSource = OrderfolioQueries.GetGeneratedItemSource(processedSupplementalOrderRequest.ID);
        // Reverse the decompose process, by removing all items with an Item Source of Decompose
        var decomposeController = new DecomposeGenIdController(errorContext, expectedDecomposeItemSource);
        var decomposeReverser = new DecomposeReverser(errorContext, decomposeController, expectedDecomposeItemSource);
        decomposeReverser.Execute(processedSupplementalOrderRequest);
        var decomposeContextBuilder = new DecomposeContextBuilder('technical', errorContext);
        var decompose = new Decompose();
        decomposeContextBuilder.BuildFromOrderCandidateRequest(processedSupplementalOrderRequest, compiledSpecs, function (decomposeContexts) {
            if (errorContext.HasBreakingErrors) {
                return callback(_this.GetError(errorContext), null);
            }
            decompose.PerformInferrenceAndMapping(decomposeContexts, errorContext);
            if (errorContext.HasBreakingErrors) {
                return callback(_this.GetError(errorContext), null);
            }
            var originalSupplementalOrderRequest = new SupplementalOrderRequest(request);
            var builder = new SupplementalOrderResponseBuilder(originalSupplementalOrderRequest, processedSupplementalOrderRequest, decomposeController, errorContext);
            var orderCandidateResponse = builder.Build(decomposeContexts);
            return callback(null, ConverterUtils.OrderSingularize(orderCandidateResponse)); // SupplementalOrderResponse
        });
    };
    SupplementalOrder.prototype.GetError = function (errorContext) {
        if (errorContext.HasProcessError) {
            return errorContext.ProcessError;
        }
        if (errorContext.HasBadDataError) {
            return errorContext.GetBadDataErrorsResponse();
        }
    };
    /**
     * Confirms that the body of the request is valid.
     * @param {express.Request} requestBody The request body from the http request
     * @param {string} candidateType the type of CandidateType which is being decomposed
     * @param {CsErrorContext} errorContext The error context
     */
    SupplementalOrder.prototype.ValidateRequestBody = function (request, errorContext) {
        if (Utilities.IsNotDefined(request, true)) {
            errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingRequest, undefined);
            return;
        }
        if (Utilities.IsNotDefined(request.InflightOrder)) {
            var validationContext = {
                Item: "SupplementalOrderRequest",
                Property: "InflightOrder"
            };
            errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return;
        }
        return;
    };
    return SupplementalOrder;
}());
module.exports = SupplementalOrder;

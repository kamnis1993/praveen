"use strict";
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
/// <reference types="node" />
var ChangeTypes = require("../cs-lib-constants/ChangeTypes");
var CharacteristicQueries = require("../cs-lib-composition/CharacteristicQueries");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Class responsible for merging characteristics in an amend section of a supplemental order
 */
var AmendCharacteristicUseMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the AmendCharacteristicUseMerger class
     * @param {CsErrorContext} errorContext The error context
     */
    function AmendCharacteristicUseMerger(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Merges the characteristics into the in flight order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param CsTypes.IOrderItem orderItem The order item
     */
    AmendCharacteristicUseMerger.prototype.Merge = function (amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(amendOrderItem.CharacteristicUses, true)) {
            return;
        }
        Logger.debug(2, "SupplementalOrder", "Processing characteristics for inflight order");
        amendOrderItem.CharacteristicUses.forEach(function (charUse) {
            Logger.debug(3, "SupplementalOrder", "Processing CharacteristicUse with ID " + charUse.CharacteristicID, charUse);
            if (charUse.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateCharacteristic(charUse, amendOrderItem, orderItem);
            }
            else if (charUse.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelCharacteristic(charUse, amendOrderItem, orderItem);
            }
            else if (charUse.ChangeType === ChangeTypes.Amend) {
                _this.MergeCharacteristicValues(charUse, amendOrderItem, orderItem);
            }
            else {
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    Property: "CharacteristicUse",
                    ChangeType: charUse.ChangeType,
                    PropertyIdentification: "UseArea: " + charUse.UseArea + ", CharacteristicID: " + charUse.CharacteristicID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnProperty, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Creates a characteristic use in the in flight order
     * @param {CsTypes.IOrderCharacteristicUse} charUse The characteristic use to create
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to create the characteristic on
     */
    AmendCharacteristicUseMerger.prototype.MergeCreateCharacteristic = function (charUse, amendOrderItem, orderItem) {
        var existingCharUse = CharacteristicQueries.GetCharUseFromCollection(orderItem.CharacteristicUses, charUse.UseArea, charUse.CharacteristicID);
        if (Utilities.IsDefined(existingCharUse)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "CharacteristicUse",
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        orderItem.CharacteristicUses.push(charUse);
        Logger.debug(4, "SupplementalOrder", "Added Characteristic to orderItem", {
            CharacteristicUseID: charUse.CharacteristicID,
            OrderItemID: orderItem.ID,
            EntityID: orderItem.EntityID
        });
    };
    /**
     * Cancels a characteristic from the in flight order
     * @param {CsTypes.IOrderCharacteristicUse} charUse The characteristic to cancel
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to cancel it from
     */
    AmendCharacteristicUseMerger.prototype.MergeCancelCharacteristic = function (charUse, amendOrderItem, orderItem) {
        var existingCharUse = CharacteristicQueries.GetCharUseFromCollection(orderItem.CharacteristicUses, charUse.UseArea, charUse.CharacteristicID);
        if (Utilities.IsNotDefined(existingCharUse)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "CharacteristicUse",
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = orderItem.CharacteristicUses.indexOf(existingCharUse);
        orderItem.CharacteristicUses.splice(index, 1);
        Logger.debug(4, "SupplementalOrder", "Removed Characteristic Use " + existingCharUse.CharacteristicID + " from order item", {
            CharacteristicIDToRemove: existingCharUse.CharacteristicID,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID
            }
        });
    };
    /**
     * Merges the characteristic values into the characteristic use on the order
     * @param {CsTypes.IOrderCharacteristicUse} charUse The characteristic use from the order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendCharacteristicUseMerger.prototype.MergeCharacteristicValues = function (charUse, amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(charUse.Value, true)) {
            return;
        }
        charUse.Value.forEach(function (charValue) {
            Logger.debug(4, "SupplementalOrder", "Processing Characteristic Use Value - " + charValue.ValueID, charValue);
            if (charValue.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateCharacteristicValue(charValue, charUse, amendOrderItem, orderItem);
            }
            else if (charValue.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelCharacteristicValue(charValue, charUse, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    PropertyValue: "CharacteristicUse.Value",
                    ChangeType: charValue.ChangeType,
                    ValueIdentification: "UseArea: " + charUse.UseArea + ", CharacteristicID: " + charUse.CharacteristicID + ", ValueID: " + charValue.ValueID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnValue, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Merges a create characteristic value into the in flight order
     * @param {CsTypes.ICharacteristicValue} charValue The characteristic value to create
     * @param {CsTypes.IOrderCharacteristicUse} charUse The characteristic use on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendCharacteristicUseMerger.prototype.MergeCreateCharacteristicValue = function (charValue, charUse, amendOrderItem, orderItem) {
        var existingCharUse = CharacteristicQueries.GetCharUseFromCollection(orderItem.CharacteristicUses, charUse.UseArea, charUse.CharacteristicID);
        if (Utilities.IsNotDefined(existingCharUse)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "CharacteristicUse",
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingValue = CharacteristicQueries.GetCharValueFromCollection(existingCharUse.Value, charValue.ValueID);
        if (Utilities.IsDefined(existingValue)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID,
                ValueID: charValue.ValueID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicValueAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        existingCharUse.Value.push(charValue);
        Logger.debug(5, "SupplementalOrder", "Added characteristic value to characteristic use", {
            ValueID: charValue.ValueID,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                CharacteristicUse: existingCharUse.CharacteristicID
            }
        });
    };
    /**
     * Merges the cancelled characteristic values into the in flight order
     * @param {CsTypes.ICharacteristicValue} charValue The characteristic value to create
     * @param {CsTypes.IOrderCharacteristicUse} charUse The characteristic use on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendCharacteristicUseMerger.prototype.MergeCancelCharacteristicValue = function (charValue, charUse, amendOrderItem, orderItem) {
        var existingCharUse = CharacteristicQueries.GetCharUseFromCollection(orderItem.CharacteristicUses, charUse.UseArea, charUse.CharacteristicID);
        if (Utilities.IsNotDefined(existingCharUse)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "CharacteristicUse",
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingValue = CharacteristicQueries.GetCharValueFromCollection(existingCharUse.Value, charValue.ValueID);
        if (Utilities.IsNotDefined(existingValue)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                UseArea: charUse.UseArea,
                CharacteristicID: charUse.CharacteristicID,
                ValueID: charValue.ValueID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicValueDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = existingCharUse.Value.indexOf(existingValue);
        existingCharUse.Value.splice(index, 1);
        Logger.debug(5, "SupplementalOrder", "Removed Characteristic Use value " + existingValue.ValueID + " from order item", {
            CharValueIDToRemove: existingValue.ValueID,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                CharacteristicID: existingCharUse.CharacteristicID
            }
        });
    };
    return AmendCharacteristicUseMerger;
}());
module.exports = AmendCharacteristicUseMerger;

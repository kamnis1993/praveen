"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ActivityBase = require("./ActivityBase");
var Delimiters = require("../../cs-lib-constants/Delimiters");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * A helper class to support mapping of items modified by mapping rules when decomposing or reversing a decompose
 */
var MappingActivityMap = /** @class */ (function (_super) {
    __extends(MappingActivityMap, _super);
    function MappingActivityMap() {
        return _super.call(this) || this;
    }
    /**
     * Builds a DecomposeGenIdentifier from a DecomposeGenID string
     * @param {string} decomposeGenId The DecomposeGenID string
     * @returns {CsTypes.DecomposeGenIdentifier}
     */
    MappingActivityMap.prototype.BuildDecomposeGenIdentifier = function (decomposeGenId) {
        if (Utilities.IsNotDefined(decomposeGenId, true)) {
            return undefined;
        }
        var parts = decomposeGenId.split(Delimiters.DecomposeGeneration);
        if (parts.length !== 4) {
            return undefined;
        }
        return { Type: parts[0], ParentID: parts[1], ActionID: parts[2], CardinalityIndex: parts[3], DecomposeGenID: decomposeGenId };
    };
    /**
    * Uses a generated decompose Id wrapper to construct a generated decompose Id
    * @param   {CsTypes.DecomposeGenIdentifier} id the generated decompose Id wrapper
    * @returns {string} the generated decompose Id
    */
    MappingActivityMap.prototype.ConstructDecomposeGenId = function (id) {
        if (Utilities.IsNotDefined(id.Type, true) || Utilities.IsNotDefined(id.ActionID, true) || Utilities.IsNotDefined(id.ParentID, true) || Utilities.IsNotDefined(id.CardinalityIndex, true)) {
            return undefined;
        }
        var parts = [id.Type, id.ParentID, id.ActionID, id.CardinalityIndex];
        var decomposeGenId = parts.join(Delimiters.DecomposeGeneration);
        return decomposeGenId;
    };
    return MappingActivityMap;
}(ActivityBase));
module.exports = MappingActivityMap;

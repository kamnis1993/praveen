"use strict";
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
/**
 * Class that reverses the Decompose process for an Order Candidate Request
 * If the Item Source is Decompose then the item will be removed
 * The following rules apply going bottom up at each level:
 * For entities it must have no properties or child items
 * For Properties it must have no values
 * For Values they get removed if the Item Source is decompose
 */
var DecomposeReverser = /** @class */ (function () {
    /**
     * Creates an instance of the DecomposeReverser class
     * @param {CsErrorContext} errorContext The error context
     */
    function DecomposeReverser(errorContext, decomposeController, expectedDecomposeItemSource) {
        this._errorContext = errorContext;
        this._decomposeController = decomposeController;
        this._expectedDecomposeItemSource = expectedDecomposeItemSource;
    }
    /**
     * Executes a method to remove all items from the order than have an Item Source of Decompose
     * @param {OrderCandidateRequest} request The order candidate request
     */
    DecomposeReverser.prototype.Execute = function (request) {
        var _this = this;
        if (Utilities.IsNotDefined(request.OrderCandidate)) {
            return;
        }
        request.OrderCandidate.OrderItems.forEach(function (rootOrderItem) {
            if (_this.IsItemSourceDecompose(rootOrderItem)) {
                _this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidRootOrderItemSource, rootOrderItem.ID, rootOrderItem.EntityID);
            }
            _this.RemoveOrderItems(rootOrderItem);
        });
    };
    /**
     * Removes order items with an item source of Decompose
     * @param {OrderItem} orderItem The order item
     */
    DecomposeReverser.prototype.RemoveOrderItems = function (orderItem) {
        var _this = this;
        orderItem.ChildOrderItems.forEach(function (childOrderItem) {
            _this.RemoveOrderItems(childOrderItem);
        });
        var getCharValues = function (charUse) { return charUse.Value; };
        var getUdcValues = function (udc) { return udc.Value; };
        var getLinks = function (entityLink) { return entityLink.Links; };
        var addLinkToMappingTable = function (link) {
            _this._decomposeController.AddEntityLink(link);
        };
        this.RemoveProperties(orderItem.CharacteristicUses, getCharValues);
        this.RemoveProperties(orderItem.ConfiguredValues, getUdcValues);
        this.RemoveProperties(orderItem.LinkedEntities, getLinks, addLinkToMappingTable);
        orderItem.RateAttributes = orderItem.RateAttributes.filter(function (rateAttribute) { return !_this.IsItemSourceDecompose(rateAttribute); });
        this.RemoveChildren(orderItem.ChildOrderItems);
    };
    /**
     * Removes children that have an Item Source of Decompose and have no properties
     * @param {Array<OrderItem>} childOrderItems The child order items
     */
    DecomposeReverser.prototype.RemoveChildren = function (childOrderItems) {
        for (var childIdx = childOrderItems.length - 1; childIdx >= 0; childIdx--) {
            var childOrderItem = childOrderItems[childIdx];
            // CS-3180: JB - If the childOrderItem has an action of delete, do not remove it from the OrderCandidate
            if (this.IsItemSourceDecompose(childOrderItem) && !this.HasProperties(childOrderItem) && childOrderItem.ItemAction !== OrderActions.Delete) {
                this._decomposeController.AddOrderItem(childOrderItem);
                childOrderItems.splice(childIdx, 1);
            }
        }
    };
    /**
     * Remove properties where all their values were created by decompose
     * @param {CsTypes.ItemSourceObject[]} properties The properties to check
     * @param {(property: CsTypes.ItemSourceObject) => CsTypes.ItemSourceObject[]} getValues Function to return the values for the properties
     * @param {(value: CsTypes.ItemSourceObject) => void} addValueToMappingTable Function that adds the value to the mapping table
     */
    DecomposeReverser.prototype.RemoveProperties = function (properties, getValues, addValueToMappingTable) {
        if (Utilities.IsNotDefined(properties, true)) {
            return;
        }
        for (var propertyIdx = properties.length - 1; propertyIdx >= 0; propertyIdx--) {
            var property = properties[propertyIdx];
            var values = getValues(property);
            this.RemoveValues(values, addValueToMappingTable);
            if (values.length === 0 && this.IsItemSourceDecompose(property)) {
                properties.splice(propertyIdx, 1);
            }
        }
    };
    /**
     * Removes all values that were created by decompose
     * @param {CsTypes.ItemSourceObject[]} values The values to check
     * @param {(value: CsTypes.ItemSourceObject) => void} addValueToMappingTable Function that adds the value to the mapping table
     */
    DecomposeReverser.prototype.RemoveValues = function (values, addValueToMappingTable) {
        if (Utilities.IsNotDefined(values, true)) {
            return;
        }
        for (var valueIdx = values.length - 1; valueIdx >= 0; valueIdx--) {
            var value = values[valueIdx];
            if (this.IsItemSourceDecompose(value)) {
                if (Utilities.IsDefined(addValueToMappingTable)) {
                    addValueToMappingTable(value);
                }
                values.splice(valueIdx, 1);
            }
        }
    };
    /**
     * Checks whether an order item has an properties or children
     * @param {OrderItem} orderItem The order item to check
     * @returns {boolean}
     */
    DecomposeReverser.prototype.HasProperties = function (orderItem) {
        return Utilities.IsDefined(orderItem.ChildOrderItems, true)
            || Utilities.IsDefined(orderItem.CharacteristicUses, true)
            || Utilities.IsDefined(orderItem.ConfiguredValues, true)
            || Utilities.IsDefined(orderItem.LinkedEntities, true)
            || Utilities.IsDefined(orderItem.RateAttributes, true);
    };
    /**
     * Checks whether an item has an Item Source of Decompose
     * @param {CsTypes.ItemSourceObject} itemSourceObject The item to check
     * @returns {boolean}
     */
    DecomposeReverser.prototype.IsItemSourceDecompose = function (itemSourceObject) {
        if (Utilities.IsNotDefined(itemSourceObject.ItemSource, true)) {
            return false;
        }
        return itemSourceObject.ItemSource === this._expectedDecomposeItemSource;
    };
    return DecomposeReverser;
}());
module.exports = DecomposeReverser;

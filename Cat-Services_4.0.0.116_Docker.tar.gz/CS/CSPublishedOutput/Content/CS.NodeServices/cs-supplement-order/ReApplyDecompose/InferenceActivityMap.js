"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ActivityBase = require("./ActivityBase");
var Delimiters = require("../../cs-lib-constants/Delimiters");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * A helper class to support mapping of inferred items when decomposing or reversing a decompose
 */
var InferenceActivityMap = /** @class */ (function (_super) {
    __extends(InferenceActivityMap, _super);
    function InferenceActivityMap() {
        return _super.call(this) || this;
    }
    /**
     * Builds a DecomposeGenIdentifier from a DecomposeGenID string
     * @param {string} decomposeGenId The DecomposeGenID string
     * @returns {CsTypes.DecomposeGenIdentifier}
     */
    InferenceActivityMap.prototype.BuildDecomposeGenIdentifier = function (decomposeGenId) {
        if (Utilities.IsNotDefined(decomposeGenId, true)) {
            return undefined;
        }
        var parts = decomposeGenId.split(Delimiters.DecomposeGeneration);
        if (parts.length !== 4) {
            return undefined;
        }
        return { Type: parts[0], ParentID: parts[1], EntityID: parts[2], CardinalityIndex: parts[3], DecomposeGenID: decomposeGenId };
    };
    /**
     * Uses a generated decompose Id wrapper to construct a generated decompose Id
     * @param   {CsTypes.DecomposeGenIdentifier} id the generated decompose Id wrapper
     * @returns {string} the generated decompose Id
     */
    InferenceActivityMap.prototype.ConstructDecomposeGenId = function (id) {
        if (Utilities.IsNotDefined(id.Type, true) || Utilities.IsNotDefined(id.EntityID) || Utilities.IsNotDefined(id.ParentID) || Utilities.IsNotDefined(id.CardinalityIndex)) {
            return undefined;
        }
        var parts = [id.Type, id.ParentID, id.EntityID, id.CardinalityIndex];
        var decomposeGenId = parts.join(Delimiters.DecomposeGeneration);
        return decomposeGenId;
    };
    return InferenceActivityMap;
}(ActivityBase));
module.exports = InferenceActivityMap;

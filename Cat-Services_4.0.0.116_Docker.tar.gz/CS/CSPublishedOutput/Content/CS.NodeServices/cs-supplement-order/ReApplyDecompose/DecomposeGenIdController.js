"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var DecomposeGeneratedTypes = require("../../cs-lib-constants/DecomposeGeneratedTypes");
var Delimiters = require("../../cs-lib-constants/Delimiters");
var EntityLinkMappingActivityMap = require("./EntityLinkMappingActivityMap");
var InferenceActivityMap = require("./InferenceActivityMap");
var MappingActivityMap = require("./MappingActivityMap");
/**
 * Handler class for mapping decomposed items when removed from and re-added to an order
 * @type {[type]}
 */
var DecomposeGenIdController = /** @class */ (function () {
    function DecomposeGenIdController(errorContext, expectedDecomposeItemSource) {
        this._mappingActivityMap = new MappingActivityMap();
        this._inferenceActivityMap = new InferenceActivityMap();
        this._existingMap = {};
        this._mappedDecomposeGenIds = {};
        this._entityLinkMap = new EntityLinkMappingActivityMap();
        this._entityLinkChildMap = new EntityLinkMappingActivityMap();
        this._mappedIds = {};
        this._errorContext = errorContext;
        this._expectedDecomposeItemSource = expectedDecomposeItemSource;
    }
    /**
     * Adds an order item to the mapping table
     * @param {OrderItem} orderItem The order item to add
     */
    DecomposeGenIdController.prototype.AddOrderItem = function (orderItem) {
        var decomposeGenIdentifier = this.BuildDecomposeGenIdentifier(orderItem.DecomposeGenID);
        if (Utilities.IsNotDefined(decomposeGenIdentifier)) {
            return;
        }
        var mapDecomposeItem = { DecomposeGenIdentifier: decomposeGenIdentifier, OrderItemId: orderItem.ID, PortfolioItemId: orderItem.PortfolioItemID };
        this.MapDecomposeItem(mapDecomposeItem);
    };
    /**
     * Adds a link to the mapping table
     * @param {LinkTarget} linkTarget The link to add to the mapping table
     */
    DecomposeGenIdController.prototype.AddEntityLink = function (linkTarget) {
        var decomposeGenIdentifier = this.BuildDecomposeGenIdentifier(linkTarget.DecomposeGenID);
        if (Utilities.IsNotDefined(decomposeGenIdentifier)) {
            return;
        }
        var mapDecomposeItem = { DecomposeGenIdentifier: decomposeGenIdentifier, PortfolioItemId: linkTarget.PortfolioItemID, OrderItemId: undefined };
        this.MapDecomposeItem(mapDecomposeItem);
    };
    /**
     * Remaps the Portfolio and Order ID's of the order item to the original order item that was provided in the request
     * @param {OrderItem} orderItem The order item
     */
    DecomposeGenIdController.prototype.RemapOrderItem = function (orderItem) {
        var mappedDecomposeItem = this.RemapItem(orderItem, orderItem.PortfolioItemID);
        if (Utilities.IsNotDefined(mappedDecomposeItem)) {
            return;
        }
        this.AddMappedId(orderItem.ID, mappedDecomposeItem.OrderItemId);
        this.AddMappedId(orderItem.PortfolioItemID, mappedDecomposeItem.PortfolioItemId);
        orderItem.ID = mappedDecomposeItem.OrderItemId;
        orderItem.PortfolioItemID = mappedDecomposeItem.PortfolioItemId;
        orderItem.DecomposeGenID = mappedDecomposeItem.DecomposeGenIdentifier.DecomposeGenID;
    };
    /**
     * Remaps the portfolio item Id of the original link on an entity to the one that was provided in the request
     * @param linkTarget
     * @returns {}
     */
    DecomposeGenIdController.prototype.RemapEntityLink = function (linkTarget) {
        var mappedDecomposeItem = this.RemapItem(linkTarget);
        if (Utilities.IsNotDefined(mappedDecomposeItem)) {
            return;
        }
        linkTarget.PortfolioItemID = mappedDecomposeItem.PortfolioItemId;
        linkTarget.DecomposeGenID = mappedDecomposeItem.DecomposeGenIdentifier.DecomposeGenID;
    };
    /**
     * Returns any stored mapping relationship between a new Id and the original Id (Portfolio or Order)
     * @param   {string} newId the Id of the new item
     * @returns {string} the Id of the original item
     */
    DecomposeGenIdController.prototype.MapId = function (newId) {
        if (Utilities.IsNotDefined(newId, true)) {
            return undefined;
        }
        var originalId = this._mappedIds[newId];
        return Utilities.IsDefined(originalId, true) ? originalId : newId;
    };
    /**
     * Finds the entry in the mapping table for the item provided
     * @param {DecomposedItem} decomposedItem The decomposed item to look for
     * @param {string} portfolioItemId The portfolio item id, only used if we are retrieving an order
     * @returns {CsTypes.MappedDecomposeItem} The entry from the table
     */
    DecomposeGenIdController.prototype.RemapItem = function (decomposedItem, portfolioItemId) {
        if (Utilities.IsNotDefined(decomposedItem.ItemSource) || decomposedItem.ItemSource !== this._expectedDecomposeItemSource) {
            return undefined;
        }
        var decomposeGenIdentifier = this.BuildDecomposeGenIdentifier(decomposedItem.DecomposeGenID);
        if (Utilities.IsNotDefined(decomposeGenIdentifier)) {
            return undefined;
        }
        return this.RetrieveMappedDecomposeItem(decomposeGenIdentifier, portfolioItemId);
    };
    /**
     * Updates an order items Order ID and Portfolio ID using the list of IDs from the original decompose
     * @param   {CsTypes.DecomposeGenIdentifier} decomposeGenIdentifier the generated decompose ID of the item to be retrieved
     * @param   {string} portfolioItemId The portfolio item ID
     * @returns {CsTypes.MappedDecomposeItem} the decomposed item details
     */
    DecomposeGenIdController.prototype.RetrieveMappedDecomposeItem = function (decomposeGenIdentifier, portfolioItemId) {
        // Our parent could have been mapped so we need to make sure we use the correct ID
        decomposeGenIdentifier.ParentID = this.MapId(decomposeGenIdentifier.ParentID);
        switch (decomposeGenIdentifier.Type) {
            case DecomposeGeneratedTypes.Inference:
                return this._inferenceActivityMap.RetrieveOriginalItem(decomposeGenIdentifier);
            case DecomposeGeneratedTypes.Mapping:
                return this._mappingActivityMap.RetrieveOriginalItem(decomposeGenIdentifier);
            case DecomposeGeneratedTypes.EntityLinkMapping:
                return this._entityLinkMap.RetrieveOriginalItem(decomposeGenIdentifier);
            case DecomposeGeneratedTypes.EntityLinkChildMapping:
                return this._entityLinkChildMap.RetrieveOriginalItem(decomposeGenIdentifier);
            case DecomposeGeneratedTypes.Existing:
                return this.RetrieveExistingOriginalItem(portfolioItemId);
            default:
                return undefined;
        }
    };
    /**
     * Builds the DecomposeGenIdentifier for a DecomposeGenID
     * @param {string} decomposeGenId The DecomposeGenID
     * @returns {CsTypes.DecomposeGenIdentifier}
     */
    DecomposeGenIdController.prototype.BuildDecomposeGenIdentifier = function (decomposeGenId) {
        var decomposeGenType = this.DetermineDecomposeTypeFromDecomposeGenId(decomposeGenId);
        switch (decomposeGenType) {
            case DecomposeGeneratedTypes.Inference:
                return this._inferenceActivityMap.BuildDecomposeGenIdentifier(decomposeGenId);
            case DecomposeGeneratedTypes.Mapping:
                return this._mappingActivityMap.BuildDecomposeGenIdentifier(decomposeGenId);
            case DecomposeGeneratedTypes.Existing:
                return { Type: DecomposeGeneratedTypes.Existing, ParentID: undefined, DecomposeGenID: decomposeGenId };
            case DecomposeGeneratedTypes.EntityLinkMapping:
                return this._entityLinkMap.BuildDecomposeGenIdentifier(decomposeGenId);
            case DecomposeGeneratedTypes.EntityLinkChildMapping:
                return this._entityLinkChildMap.BuildDecomposeGenIdentifier(decomposeGenId);
            default:
                return undefined;
        }
    };
    /**
     * Stores the details of the decompose item using the generated decompose ID
     * @param   {CsTypes.MappedDecomposeItem} decomposeItem The mapped decompose item
     */
    DecomposeGenIdController.prototype.MapDecomposeItem = function (decomposeItem) {
        var decomposeGenType = this.DetermineDecomposeTypeFromDecomposeGenWrapper(decomposeItem.DecomposeGenIdentifier);
        if (Utilities.IsNotDefined(decomposeGenType, true)) {
            return undefined;
        }
        switch (decomposeGenType) {
            case DecomposeGeneratedTypes.Existing:
                this._existingMap[decomposeItem.PortfolioItemId] = decomposeItem;
                break;
            case DecomposeGeneratedTypes.Inference:
                this._inferenceActivityMap.Add(decomposeItem);
                break;
            case DecomposeGeneratedTypes.Mapping:
                this._mappingActivityMap.Add(decomposeItem);
                break;
            case DecomposeGeneratedTypes.EntityLinkMapping:
                this._entityLinkMap.Add(decomposeItem);
                break;
            case DecomposeGeneratedTypes.EntityLinkChildMapping:
                this._entityLinkChildMap.Add(decomposeItem);
                break;
            default:
                return;
        }
    };
    /**
     * Stores a mapping relationship between the original ID of an item and the new ID generated by decompose
     * @param {string} newId the Id of the new item
     * @param {string} originalId the Id of the original item
     */
    DecomposeGenIdController.prototype.AddMappedId = function (newId, originalId) {
        if (Utilities.IsNotDefined(newId, true) || Utilities.IsNotDefined(originalId, true)) {
            return;
        }
        this._mappedIds[newId] = originalId;
    };
    /**
     * Use generated decompose Id to work out type of action which created the item
     * @param   {string} decomposeGenId the generated decompose ID
     * @returns {string} the type of action performed by decompose
     */
    DecomposeGenIdController.prototype.DetermineDecomposeTypeFromDecomposeGenId = function (decomposeGenId) {
        if (Utilities.IsNotDefined(decomposeGenId, true)) {
            return undefined;
        }
        return decomposeGenId.split(Delimiters.DecomposeGeneration)[0];
    };
    /**
     * Use the DecomposeGenIdentifier wrapper to retrieve the type of action which created the item
     * @param   {CsTypes.DecomposeGenIdentifier} decomposeGenId the generated decompose ID wrapper
     * @returns {string} the type of action performed by decompose
     */
    DecomposeGenIdController.prototype.DetermineDecomposeTypeFromDecomposeGenWrapper = function (decomposeGenId) {
        if (Utilities.IsNotDefined(decomposeGenId, true)) {
            return undefined;
        }
        return decomposeGenId.Type;
    };
    /**
     * Retrieves the mapped decompose item for type EXISTING
     * @param {string} portfolioId The portfolio item ID
     * @returns {CsTypes.MappedDecomposeItem} The mapped decompose item
     */
    DecomposeGenIdController.prototype.RetrieveExistingOriginalItem = function (portfolioId) {
        if (Utilities.IsNotDefined(portfolioId)) {
            return undefined;
        }
        return this._existingMap[portfolioId];
    };
    return DecomposeGenIdController;
}());
module.exports = DecomposeGenIdController;

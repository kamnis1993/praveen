"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts"/>
var ActivityBase = /** @class */ (function () {
    function ActivityBase() {
        this._mappedDecomposeItems = {};
    }
    /**
     * Uses a generated decompose Id to return details of the decompose item
     * @param   {CsTypes.DecomposeGenIdentifier} id the Id of the decompose item
     * @returns {CsTypes.MappedDecomposeItem} the details of the decompose item
     */
    ActivityBase.prototype.RetrieveOriginalItem = function (id) {
        var decomposeGenId = this.ConstructDecomposeGenId(id);
        return this._mappedDecomposeItems[decomposeGenId];
    };
    /**
     * Adds details of a mapped decompose item
     * @param   {CsTypes.MappedDecomposeItem} item the item details to store
     */
    ActivityBase.prototype.Add = function (item) {
        this._mappedDecomposeItems[item.DecomposeGenIdentifier.DecomposeGenID] = item;
    };
    return ActivityBase;
}());
module.exports = ActivityBase;

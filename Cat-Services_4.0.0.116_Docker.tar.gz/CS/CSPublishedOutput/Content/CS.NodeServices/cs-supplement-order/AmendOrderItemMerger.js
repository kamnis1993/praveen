"use strict";
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
/// <reference types="node" />
var AmendCharacteristicUseMerger = require("./AmendCharacteristicUseMerger");
var AmendEntityLinkMerger = require("./AmendEntityLinkMerger");
var AmendRateAttributeMerger = require("./AmendRateAttributeMerger");
var AmendUserDefinedCharacteristicUseMerger = require("./AmendUserDefinedCharacteristicUseMerger");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Class responsible for merging an amend section of a supplemental order
 */
var AmendOrderItemMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the AmendOrderItemMerger class
     * @param {CsErrorContext} errorContext The error context
     */
    function AmendOrderItemMerger(errorContext) {
        this._errorContext = errorContext;
        this._characteristicUseMerger = new AmendCharacteristicUseMerger(this._errorContext);
        this._userDefinedCharacteriticUseMerger = new AmendUserDefinedCharacteristicUseMerger(this._errorContext);
        this._rateAttributeMerger = new AmendRateAttributeMerger(this._errorContext);
        this._entityLinkMerger = new AmendEntityLinkMerger(this._errorContext);
    }
    /**
     * Merges a amend order item into the in flight order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {SupplementalOrderRequest} supplementalOrderRequest The supplemental order request
     */
    AmendOrderItemMerger.prototype.MergeAmendOrderItem = function (amendOrderItem, supplementalOrderRequest) {
        var orderItemLookup = supplementalOrderRequest.OrderCandidate.OrderItemLookup;
        if (Utilities.IsNotDefined(amendOrderItem.OrderItemID, true)) {
            var validationContext = {
                Item: "AmendOrderItem",
                Property: "OrderItemID"
            };
            this._errorContext.RaiseCsError(400, ErrorCode.SupplementalOrder.InvalidSupplementalOrderRequest.MissingProperty, validationContext);
            return;
        }
        if (Utilities.IsNotDefined(orderItemLookup[amendOrderItem.OrderItemID])) {
            var validationContext = {
                InstructionType: "Amend",
                InstructionID: amendOrderItem.ID,
                OrderItemID: amendOrderItem.OrderItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.OrderItemDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var orderItemEntry = orderItemLookup[amendOrderItem.OrderItemID];
        var orderItem = orderItemEntry.OrderItem;
        if (Utilities.IsDefined(amendOrderItem.ItemAction, true)) {
            Logger.debug(2, "SupplementalOrder", "Amend Order Item has an item action of " + amendOrderItem.ItemAction, amendOrderItem);
            this.UpdateItemAction(orderItem, amendOrderItem, supplementalOrderRequest.ID);
        }
        this._characteristicUseMerger.Merge(amendOrderItem, orderItem);
        this._userDefinedCharacteriticUseMerger.Merge(amendOrderItem, orderItem);
        this._entityLinkMerger.Merge(amendOrderItem, orderItem);
        this._rateAttributeMerger.Merge(amendOrderItem, orderItem);
    };
    /**
     * Updates the item action of the order item passed in
     * @param {CsTypes.IOrderItem} orderItem The order item to update
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {string} requestId The request ID
     */
    AmendOrderItemMerger.prototype.UpdateItemAction = function (orderItem, amendOrderItem, requestId) {
        orderItem.ItemAction = amendOrderItem.ItemAction;
        orderItem.ItemSource = OrderfolioQueries.GetItemSource({ ItemSource: amendOrderItem.ItemSource }, requestId);
        if (amendOrderItem.ItemAction !== OrderActions.Delete) {
            return;
        }
        orderItem.ChildOrderItems = [];
        orderItem.CharacteristicUses = [];
        orderItem.RateAttributes = [];
        orderItem.ConfiguredValues = [];
        orderItem.LinkedEntities = [];
        Logger.debug(3, "SupplementalOrder", "Updated item action of amend order item ", orderItem);
    };
    return AmendOrderItemMerger;
}());
module.exports = AmendOrderItemMerger;

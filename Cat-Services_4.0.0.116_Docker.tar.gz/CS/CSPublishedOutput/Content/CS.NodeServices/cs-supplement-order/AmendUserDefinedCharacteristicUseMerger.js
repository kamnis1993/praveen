"use strict";
/// <reference path='../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>
/// <reference types="node" />
var ChangeTypes = require("../cs-lib-constants/ChangeTypes");
var CharacteristicQueries = require("../cs-lib-composition/CharacteristicQueries");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Class responsible for merging configured values in an amend section of a supplemental order
 */
var AmendUserDefinedCharacteristicUseMerger = /** @class */ (function () {
    /**
     * Initializes a new instance of the AmendConfiguredValueMerger class
     * @param {CsErrorContext} errorContext The error context
     */
    function AmendUserDefinedCharacteristicUseMerger(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Merges the user defined characteristics into the in flight order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param CsTypes.IOrderItem orderItem The order item
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.Merge = function (amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(amendOrderItem.ConfiguredValues, true)) {
            return;
        }
        Logger.debug(2, "SupplementalOrder", "Processing UDCs for inflight order");
        amendOrderItem.ConfiguredValues.forEach(function (udc) {
            Logger.debug(3, "SupplementalOrder", "Processing UDC with ID " + udc.CharacteristicID, udc);
            if (udc.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateUserDefinedCharacteristic(udc, amendOrderItem, orderItem);
            }
            else if (udc.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelUserDefinedCharacteristic(udc, amendOrderItem, orderItem);
            }
            else if (udc.ChangeType === ChangeTypes.Amend) {
                _this.MergeUserDefinedCharacteristicValues(udc, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    Property: "ConfiguredValue",
                    ChangeType: udc.ChangeType,
                    PropertyIdentification: "UseArea: " + udc.UseArea + ", CharacteristicID: " + udc.CharacteristicID
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnProperty, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Creates a user defined characteristic in the in flight order
     * @param {CsTypes.IOrderUserDefinedCharacteristicUse} udc The user defined characteristic use to create
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to create the characteristic on
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.MergeCreateUserDefinedCharacteristic = function (udc, amendOrderItem, orderItem) {
        var existingUdc = CharacteristicQueries.GetUdcFromCollection(orderItem.ConfiguredValues, udc.UseArea, udc.CharacteristicID);
        if (Utilities.IsDefined(existingUdc)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "ConfiguredValue",
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        orderItem.ConfiguredValues.push(udc);
        Logger.debug(4, "SupplementalOrder", "Added UDC to orderItem", {
            CharacteristicUseID: udc.CharacteristicID,
            OrderItemID: orderItem.ID,
            EntityID: orderItem.EntityID
        });
    };
    /**
     * Cancels a user defined characteristic from the in flight order
     * @param {CsTypes.IUserDefinedCharacteristicUse} udc The user defined characteristic to cancel
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item to cancel it from
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.MergeCancelUserDefinedCharacteristic = function (udc, amendOrderItem, orderItem) {
        var existingUdc = CharacteristicQueries.GetUdcFromCollection(orderItem.ConfiguredValues, udc.UseArea, udc.CharacteristicID);
        if (Utilities.IsNotDefined(existingUdc)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "ConfiguredValue",
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = orderItem.ConfiguredValues.indexOf(existingUdc);
        orderItem.ConfiguredValues.splice(index, 1);
        Logger.debug(4, "SupplementalOrder", "Removed UDC" + existingUdc.CharacteristicID + " from order item", {
            CharacteristicIDToRemove: existingUdc.CharacteristicID,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID
            }
        });
    };
    /**
     * Merges the user defined characteristic values into the user defined characteristic on the order
     * @param {CsTypes.IOrderUserDefinedCharacteristicUse} udc The user defined characteristic from the order
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.MergeUserDefinedCharacteristicValues = function (udc, amendOrderItem, orderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(udc.Value, true)) {
            return;
        }
        udc.Value.forEach(function (udcValue) {
            Logger.debug(4, "SupplementalOrder", "Processing UDC Value - " + udcValue.Value, udcValue);
            if (udcValue.ChangeType === ChangeTypes.Create) {
                _this.MergeCreateCharacteristicValue(udcValue, udc, amendOrderItem, orderItem);
            }
            else if (udcValue.ChangeType === ChangeTypes.Cancel) {
                _this.MergeCancelUserDefinedCharacteristicValue(udcValue, udc, amendOrderItem, orderItem);
            }
            else {
                // We don't recognise this change type
                var validationContext = {
                    AmendOrderItemID: amendOrderItem.ID,
                    PropertyValue: "ConfiguredValue.Value",
                    ChangeType: udcValue.ChangeType,
                    ValueIdentification: "UseArea: " + udc.UseArea + ", CharacteristicID: " + udc.CharacteristicID + ", Value: " + udcValue.Value
                };
                _this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UnrecognisedChangeTypeOnValue, amendOrderItem.OrderItemID, undefined, validationContext);
            }
        });
    };
    /**
     * Merges a create user defined characteristic value into the in flight order
     * @param {CsTypes.IUserDefinedCharacteristicValue} udcValue The user defined characteristic value to create
     * @param {CsTypes.IOrderUserDefinedCharacteristicUse} udc The user defined characteristic use on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.MergeCreateCharacteristicValue = function (udcValue, udc, amendOrderItem, orderItem) {
        var existingUdc = CharacteristicQueries.GetUdcFromCollection(orderItem.ConfiguredValues, udc.UseArea, udc.CharacteristicID);
        if (Utilities.IsNotDefined(existingUdc)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "ConfiguredValue",
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingUdcValue = CharacteristicQueries.GetUdcValueFromCollection(existingUdc.Value, udcValue.Value);
        if (Utilities.IsDefined(existingUdcValue)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID,
                Value: udcValue.Value
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UserDefinedCharacteristicValueAlreadyExists, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        existingUdc.Value.push(udcValue);
        Logger.debug(5, "SupplementalOrder", "Added characteristic value to characteristic use", {
            Value: udcValue.Value,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                CharacteristicUse: existingUdc.CharacteristicID
            }
        });
    };
    /**
     * Merges the cancelled user defined characteristic values into the in flight order
     * @param {CsTypes.IUserDefinedCharacteristicValue} udcValue The user defined characteristic value to create
     * @param {CsTypes.IOrderCharacteristicUse} udc The user defined characteristic use on the amend order item
     * @param {CsTypes.AmendOrderItem} amendOrderItem The amend order item
     * @param {CsTypes.IOrderItem} orderItem The order item
     */
    AmendUserDefinedCharacteristicUseMerger.prototype.MergeCancelUserDefinedCharacteristicValue = function (udcValue, udc, amendOrderItem, orderItem) {
        var existingUdc = CharacteristicQueries.GetUdcFromCollection(orderItem.ConfiguredValues, udc.UseArea, udc.CharacteristicID);
        if (Utilities.IsNotDefined(existingUdc)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                Property: "ConfiguredValue",
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.CharacteristicDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var existingValue = CharacteristicQueries.GetUdcValueFromCollection(existingUdc.Value, udcValue.Value);
        if (Utilities.IsNotDefined(existingValue)) {
            var validationContext = {
                AmendOrderItemID: amendOrderItem.ID,
                UseArea: udc.UseArea,
                CharacteristicID: udc.CharacteristicID,
                Value: udcValue.Value
            };
            this._errorContext.RaiseValidationError(ErrorCode.SupplementalOrder.UserDefinedCharacteristicValueDoesNotExist, amendOrderItem.OrderItemID, undefined, validationContext);
            return;
        }
        var index = existingUdc.Value.indexOf(existingValue);
        existingUdc.Value.splice(index, 1);
        Logger.debug(5, "SupplementalOrder", "Removed UDC value from order item", {
            UDCValueToRemove: existingValue.Value,
            AffectedOrderItem: {
                ID: orderItem.ID,
                EntityID: orderItem.EntityID,
                CharacteristicID: existingUdc.CharacteristicID
            }
        });
    };
    return AmendUserDefinedCharacteristicUseMerger;
}());
module.exports = AmendUserDefinedCharacteristicUseMerger;

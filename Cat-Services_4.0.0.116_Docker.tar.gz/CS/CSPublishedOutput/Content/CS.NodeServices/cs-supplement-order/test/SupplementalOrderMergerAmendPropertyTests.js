"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var SupplementalOrderMerger = require("../SupplementalOrderMerger");
var fs = require("fs");
var chai = require("chai");
describe("Merging supplemental orders with the in flight order", function () {
    var supplementalOrderRequestContents = fs.readFileSync('cs-supplement-order/test/files/SupplementalOrderAmendProperty.json', { encoding: 'utf8' });
    var inputSupplementalOrderRequest = ConverterUtils.OrderPluralize(JSON.parse(supplementalOrderRequestContents));
    var merger = new SupplementalOrderMerger(new CsErrorContext({}));
    var supplementalOrderRequest = merger.Merge(inputSupplementalOrderRequest);
    chai.expect(supplementalOrderRequest).to.not.be.undefined;
    chai.expect(supplementalOrderRequest.SupplementalOrder.Amend).to.not.be.undefined;
    chai.expect(supplementalOrderRequest.SupplementalOrder.Amend.AmendOrderItems.length).to.equal(1);
    var orderCandidate = supplementalOrderRequest.OrderCandidate;
    var amendOrderItem = supplementalOrderRequest.SupplementalOrder.Amend.AmendOrderItems[0];
    var orderItem = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === amendOrderItem.OrderItemID; });
    chai.expect(orderItem).to.not.be.undefined;
    describe("Should be able to create entire properties", function () {
        it("Should create Characteristic Uses", function () {
            var createdCharUse = LodashUtilities.Find(orderItem.CharacteristicUses, function (c) { return c.CharacteristicID === "1e26bf73-b265-422d-85a4-decfac762dd2"; });
            chai.expect(createdCharUse).to.not.be.undefined;
            chai.expect(createdCharUse.UseArea).to.equal("CommercialSpecChar");
            chai.expect(createdCharUse.Action).to.equal("modify");
            chai.expect(createdCharUse.Value.length).to.equal(1);
            chai.expect(createdCharUse.Value[0].ValueID).to.equal("074a5ab7-d568-4b0d-b450-f3fe2c489b9c");
            chai.expect(createdCharUse.Value[0].Action).to.equal("add");
        });
        it("Should create User Defined Characteristics", function () {
            var createdUdc = LodashUtilities.Find(orderItem.ConfiguredValues, function (c) { return c.CharacteristicID === "ece0ce62-1e99-4c45-a341-948d01c7ba3b"; });
            chai.expect(createdUdc).to.not.be.undefined;
            chai.expect(createdUdc.UseArea).to.equal("CommercialUserDefinedValue");
            chai.expect(createdUdc.Action).to.equal("modify");
            chai.expect(createdUdc.Value.length).to.equal(1);
            chai.expect(createdUdc.Value[0].Value).to.equal("127.0.0.1");
            chai.expect(createdUdc.Value[0].Action).to.equal("add");
        });
        it("Should create rate attributes", function () {
            var createdRate = LodashUtilities.Find(orderItem.RateAttributes, function (r) { return r.Name === "CreateName"; });
            chai.expect(createdRate).to.not.be.undefined;
            chai.expect(createdRate.Value).to.equal("CreateValue");
        });
        it("Should create entity links", function () {
            var createdEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === "linktype_1"; });
            chai.expect(createdEntityLink).to.not.be.undefined;
            chai.expect(createdEntityLink.Action).to.equal("modify");
            chai.expect(createdEntityLink.Links.length).to.equal(1);
            chai.expect(createdEntityLink.Links[0].PortfolioItemID).to.equal("p_01");
            chai.expect(createdEntityLink.Links[0].Action).to.equal("add");
        });
    });
    describe("Should be able to cancel entire properties", function () {
        it("Should cancel Characteristic Uses", function () {
            var canceledCharUse = LodashUtilities.Find(orderItem.CharacteristicUses, function (c) { return c.CharacteristicID === "4c688dba-eff2-4cbc-bd07-8893af14273f"; });
            chai.expect(canceledCharUse).to.be.undefined;
        });
        it("Should cancel User Defined Characteristics", function () {
            var cancelledUdc = LodashUtilities.Find(orderItem.ConfiguredValues, function (c) { return c.CharacteristicID === "930d2587-af1a-44d2-86b6-aea3b8065350"; });
            chai.expect(cancelledUdc).to.be.undefined;
        });
        it("Should cancel Rate Attributes", function () {
            var cancelledRate = LodashUtilities.Find(orderItem.RateAttributes, function (r) { return r.Name === "CancelName"; });
            chai.expect(cancelledRate).to.be.undefined;
        });
        it("Should cancel entity links", function () {
            var cancelledEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === "linktype_2"; });
            chai.expect(cancelledEntityLink).to.be.undefined;
        });
    });
});

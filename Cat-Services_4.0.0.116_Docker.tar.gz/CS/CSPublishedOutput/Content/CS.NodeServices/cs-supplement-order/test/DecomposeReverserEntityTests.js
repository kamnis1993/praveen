"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var path = require("path");
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var DecomposeGenIdController = require("../ReApplyDecompose/DecomposeGenIdController");
var DecomposeReverser = require("../ReApplyDecompose/DecomposeReverser");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
describe("When Order Candidate Requests have Entities", function () {
    var csErrorContext = new CsErrorContext({});
    var expectedDecomposeItemSource = "Decompose:ORQ001";
    var decomposeReverser = new DecomposeReverser(csErrorContext, new DecomposeGenIdController(csErrorContext, expectedDecomposeItemSource), expectedDecomposeItemSource);
    describe("When the Order Candidate Request has Entities", function () {
        it("Should remove all entities except the root", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario1.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario1.json");
        });
        it("Should raise an error because a root order item cannot have an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario2.json");
            decomposeReverser.Execute(request);
            var validationErrors = csErrorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(1);
            var validationError = validationErrors[0];
            chai.expect(validationError.ErrorCode).to.equal(ErrorCode.Validation.InvalidRootOrderItemSource.Code.split(".")[1]);
            chai.expect(validationError.EntityUniqueCode).to.equal("oi_entityA");
            chai.expect(validationError.EntityID).to.equal("entitya");
        });
        it("Should not remove order items above where a child that was not created by Decompose is found", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario3.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario3.json");
        });
        it("Should not remove order items above where a property that was not created by Decompose is found", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario4.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario4.json");
        });
        it("Should not remove order items above where a value that was not created by Decompose is found", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario5.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario5.json");
        });
        it("Should remove order items when all properties and values have been created by Decompose", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario6.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario6.json");
        });
        it("Should not remove order items above where a child that was not created by Decompose is found for a particular tree branch", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario7.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario7.json");
        });
        it("Should not remove order items above where a property that was not created by Decompose is found for a particular tree branch", function () {
            var request = ReadOrderCandidateRequest("Input/Scenario8.json");
            decomposeReverser.Execute(request);
            AssertOrderCandidateRequest(request, "Output/Scenario8.json");
        });
    });
});
function ReadOrderCandidateRequest(fileName) {
    var request = fs.readFileSync(path.join("cs-supplement-order/test/files/DecomposeReverser/Entities", fileName), "utf8");
    var orderCandidateRequest = new OrderCandidateRequest(ConverterUtils.OrderPluralize(JSON.parse(request)));
    return orderCandidateRequest;
}
function AssertOrderCandidateRequest(actual, fileName) {
    var expected = ReadOrderCandidateRequest(fileName);
    actual.RemoveInternalData();
    expected.RemoveInternalData();
    chai.expect(expected).to.deep.equal(actual);
}

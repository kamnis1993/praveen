"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var path = require("path");
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var DecomposeGenIdController = require("../ReApplyDecompose/DecomposeGenIdController");
var DecomposeReverser = require("../ReApplyDecompose/DecomposeReverser");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
describe("When Order Candidate Requests have Properties", function () {
    var csErrorContext = new CsErrorContext({});
    var expectedDecomposeItemSource = "Decompose:ORQ001";
    var decomposeReverser = new DecomposeReverser(csErrorContext, new DecomposeGenIdController(csErrorContext, expectedDecomposeItemSource), expectedDecomposeItemSource);
    describe("When the Order Candidate Request has Characteristic Uses", function () {
        it("Should remove Characteristic Uses with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedCharUse.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.CharacteristicUses.length).to.equal(0);
        });
        it("Should not remove Characteristic Uses that have Values that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserModifiedCharUse.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.CharacteristicUses.length).to.equal(1);
            var colour = handset.CharacteristicUses[0];
            chai.expect(colour.CharacteristicID).to.equal("colour");
            chai.expect(colour.Value.length).to.equal(1);
            var red = colour.Value[0];
            chai.expect(red.ValueID).to.equal("red");
        });
    });
    describe("When the Order Candidate Request has User Defined Characteristics", function () {
        it("Should remove User Defined Characteristics with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedUdc.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.ConfiguredValues.length).to.equal(0);
        });
        it("Should not remove User Defined Characteristics that have Values that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserModifiedUdc.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.ConfiguredValues.length).to.equal(1);
            var mobileNumber = handset.ConfiguredValues[0];
            chai.expect(mobileNumber.CharacteristicID).to.equal("mobile_number");
            chai.expect(mobileNumber.Value.length).to.equal(1);
            var udcValue = mobileNumber.Value[0];
            chai.expect(udcValue.Value).to.equal("01633224466");
        });
    });
    describe("When the Order Candidate Request has Entity Links", function () {
        it("Should remove Links with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedEntityLink.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.LinkedEntities.length).to.equal(0);
        });
        it("Should not remove Entity Links that have Links that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserModifiedEntityLink.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.LinkedEntities.length).to.equal(1);
            var handsetToSim = handset.LinkedEntities[0];
            chai.expect(handsetToSim.LinkTypeID).to.equal("handset_to_sim");
            chai.expect(handsetToSim.Links.length).to.equal(1);
            var link = handsetToSim.Links[0];
            chai.expect(link.PortfolioItemID).to.equal("pi_sim_2");
        });
    });
    describe("When the Order Candidate Request has Rate Attributes", function () {
        it("Should remove Rate Attributes with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedRateAttribute.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.RateAttributes.length).to.equal(0);
        });
        it("Should remove Rate Attributes with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("UserCreatedRateAttribute.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.RateAttributes.length).to.equal(1);
            var rateAttribute = handset.RateAttributes[0];
            chai.expect(rateAttribute.Name).to.equal("Saturday");
            chai.expect(rateAttribute.Value).to.equal("Double");
        });
    });
});
function ReadOrderCandidateRequest(fileName) {
    var request = fs.readFileSync(path.join("cs-supplement-order/test/files/DecomposeReverser/Properties", fileName), "utf8");
    var orderCandidateRequest = new OrderCandidateRequest(ConverterUtils.OrderPluralize(JSON.parse(request)));
    return orderCandidateRequest;
}
function AssertEntityStructure(request) {
    chai.expect(request.OrderCandidate.OrderItems.length).to.equal(1);
    var mobilePackage = request.OrderCandidate.OrderItems[0];
    chai.expect(mobilePackage.EntityID).to.equal("mobile_package");
    chai.expect(mobilePackage.ChildOrderItems.length).to.greaterThan(0);
    var handset = mobilePackage.ChildOrderItems[0];
    chai.expect(handset.EntityID).to.equal("handset");
    if (mobilePackage.ChildOrderItems.length >= 2) {
        var sim = mobilePackage.ChildOrderItems[1];
        chai.expect(sim.EntityID).to.equal("sim");
    }
    if (mobilePackage.ChildOrderItems.length >= 3) {
        var sim = mobilePackage.ChildOrderItems[2];
        chai.expect(sim.EntityID).to.equal("sim");
    }
    return handset;
}

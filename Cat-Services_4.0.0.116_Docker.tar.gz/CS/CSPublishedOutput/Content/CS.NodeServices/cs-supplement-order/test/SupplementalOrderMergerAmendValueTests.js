"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var SupplementalOrderMerger = require("../SupplementalOrderMerger");
var fs = require("fs");
var chai = require("chai");
describe("Merging supplemental orders with the in flight order", function () {
    var supplementalOrderRequestContents = fs.readFileSync('cs-supplement-order/test/files/SupplementalOrderAmendValue.json', { encoding: 'utf8' });
    var inputSupplementalOrderRequest = ConverterUtils.OrderPluralize(JSON.parse(supplementalOrderRequestContents));
    var merger = new SupplementalOrderMerger(new CsErrorContext({}));
    var supplementalOrderRequest = merger.Merge(inputSupplementalOrderRequest);
    chai.expect(supplementalOrderRequest).to.not.be.undefined;
    chai.expect(supplementalOrderRequest.SupplementalOrder.Amend).to.not.be.undefined;
    chai.expect(supplementalOrderRequest.SupplementalOrder.Amend.AmendOrderItems.length).to.equal(1);
    var orderCandidate = supplementalOrderRequest.OrderCandidate;
    var amendOrderItem = supplementalOrderRequest.SupplementalOrder.Amend.AmendOrderItems[0];
    var orderItem = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === amendOrderItem.OrderItemID; });
    var orderCharUse = LodashUtilities.Find(orderItem.CharacteristicUses, function (c) { return c.CharacteristicID === "4c688dba-eff2-4cbc-bd07-8893af14273f"; });
    chai.expect(orderCharUse).to.not.be.undefined;
    var orderUdc = LodashUtilities.Find(orderItem.ConfiguredValues, function (c) { return c.CharacteristicID === "930d2587-af1a-44d2-86b6-aea3b8065350"; });
    chai.expect(orderUdc).to.not.be.undefined;
    var orderEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === "linktype_1"; });
    chai.expect(orderEntityLink).to.not.be.undefined;
    describe("Should be able to create property values", function () {
        it("Should be able to create Characteristic Values", function () {
            chai.expect(orderCharUse.UseArea).to.equal("CommercialSpecChar");
            chai.expect(orderCharUse.Action).to.equal("modify");
            chai.expect(orderCharUse.Value.length).to.equal(1);
            chai.expect(orderCharUse.Value[0].ValueID).to.equal("074a5ab7-d568-4b0d-b450-f3fe2c489b9c");
            chai.expect(orderCharUse.Value[0].Action).to.equal("add");
        });
        it("Should be able to create User Defined Characteristic Values", function () {
            chai.expect(orderUdc.UseArea).to.equal("CommercialUserDefinedValue");
            chai.expect(orderUdc.Action).to.equal("modify");
            chai.expect(orderUdc.Value.length).to.equal(1);
            chai.expect(orderUdc.Value[0].Value).to.equal("3 Test House");
            chai.expect(orderUdc.Value[0].Action).to.equal("add");
        });
        it("Should be able to create links on an entity link", function () {
            chai.expect(orderEntityLink.Action).to.equal("modify");
            chai.expect(orderEntityLink.Links.length).to.equal(1);
            chai.expect(orderEntityLink.Links[0].PortfolioItemID).to.equal("pi_01");
            chai.expect(orderEntityLink.Links[0].Action).to.equal("add");
        });
    });
    describe("Should be able to cancel property values", function () {
        it("Should be able to cancel Characteristic Values", function () {
            var cancelledValue = LodashUtilities.Find(orderCharUse.Value, function (cv) { return cv.ValueID === "3f4adef5-d966-4e3f-880b-1198242859bd"; });
            chai.expect(cancelledValue).to.be.undefined;
        });
        it("Should be able to cancel User Defined Characteristic Values", function () {
            var cancelledValue = LodashUtilities.Find(orderUdc.Value, function (cv) { return cv.Value === "127.0.0.1"; });
            chai.expect(cancelledValue).to.be.undefined;
        });
        it("Should be able to cancel links on an entity link", function () {
            var cancelledLink = LodashUtilities.Find(orderEntityLink.Links, function (l) { return l.PortfolioItemID === "pi_02"; });
            chai.expect(cancelledLink).to.be.undefined;
        });
    });
});

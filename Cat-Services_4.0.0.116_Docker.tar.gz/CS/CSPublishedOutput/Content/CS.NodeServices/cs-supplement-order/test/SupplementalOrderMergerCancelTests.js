"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var SupplementalOrderMerger = require("../SupplementalOrderMerger");
var fs = require("fs");
var chai = require("chai");
describe("Merging supplemental orders with the in flight order", function () {
    describe("Should merge cancel order items correctly", function () {
        var supplementalOrderRequestContents = fs.readFileSync('cs-supplement-order/test/files/SupplementalOrderCancel.json', { encoding: 'utf8' });
        var inputSupplementalOrderRequest = ConverterUtils.OrderPluralize(JSON.parse(supplementalOrderRequestContents));
        var merger = new SupplementalOrderMerger(new CsErrorContext({}));
        var supplementalOrderRequest = merger.Merge(inputSupplementalOrderRequest);
        chai.expect(supplementalOrderRequest).to.not.be.undefined;
        var orderCandidate = supplementalOrderRequest.OrderCandidate;
        var cancelOrderItems = supplementalOrderRequest.SupplementalOrder.Cancel.CancelOrderItems;
        it("Should cancel a root item", function () {
            var cancelOrderItem = LodashUtilities.Find(cancelOrderItems, function (c) { return c.OrderItemID === "r_ord_01" && c.ID === "cancel_01"; });
            chai.expect(cancelOrderItem).to.not.be.undefined;
            var rootCancelOrderItem = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === cancelOrderItem.OrderItemID; });
            chai.expect(rootCancelOrderItem).to.be.undefined;
        });
        it("Should cancel a child item", function () {
            var cancelOrderItem = LodashUtilities.Find(cancelOrderItems, function (c) { return c.OrderItemID === "oi_03" && c.ID === "cancel_02"; });
            chai.expect(cancelOrderItem).to.not.be.undefined;
            var grandparent = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === "r_ord_02"; });
            chai.expect(grandparent).to.not.be.undefined;
            var parent = LodashUtilities.Find(grandparent.ChildOrderItems, function (o) { return o.ID === "oi_02"; });
            chai.expect(parent).to.not.be.undefined;
            var child = LodashUtilities.Find(parent.ChildOrderItems, function (o) { return o.ID === cancelOrderItem.OrderItemID; });
            chai.expect(child).to.be.undefined;
        });
    });
});

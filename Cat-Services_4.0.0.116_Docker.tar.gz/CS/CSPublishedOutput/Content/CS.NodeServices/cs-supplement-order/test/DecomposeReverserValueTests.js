"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var path = require("path");
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var DecomposeGenIdController = require("../ReApplyDecompose/DecomposeGenIdController");
var DecomposeReverser = require("../ReApplyDecompose/DecomposeReverser");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
describe("When Order Candidate Requests have Values", function () {
    var csErrorContext = new CsErrorContext({});
    var expectedDecomposeItemSource = "Decompose:ORQ001";
    var decomposeReverser = new DecomposeReverser(csErrorContext, new DecomposeGenIdController(csErrorContext, expectedDecomposeItemSource), expectedDecomposeItemSource);
    describe("When the Order Candidate Request has Characteristic Values", function () {
        it("Should remove Characteristic Values with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedCharValue.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.CharacteristicUses.length).to.equal(1);
            var colour = handset.CharacteristicUses[0];
            chai.expect(colour.CharacteristicID).to.equal("colour");
            chai.expect(colour.Value.length).to.equal(0);
        });
        it("Should not remove Characteristic Values that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserCreatedCharValue.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.CharacteristicUses.length).to.equal(1);
            var colour = handset.CharacteristicUses[0];
            chai.expect(colour.CharacteristicID).to.equal("colour");
            chai.expect(colour.Value.length).to.equal(1);
            var blue = colour.Value[0];
            chai.expect(blue.ValueID).to.equal("blue");
        });
    });
    describe("When the Order Candidate Request has User Defined Characteristic Values", function () {
        it("Should remove User Defined Characteristic Values with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedUdcValue.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.ConfiguredValues.length).to.equal(1);
            var mobileNumber = handset.ConfiguredValues[0];
            chai.expect(mobileNumber.CharacteristicID).to.equal("mobile_number");
            chai.expect(mobileNumber.Value.length).to.equal(0);
        });
        it("Should not remove User Defined Characteristic Values that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserCreatedUdcValue.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.ConfiguredValues.length).to.equal(1);
            var mobileNumber = handset.ConfiguredValues[0];
            chai.expect(mobileNumber.CharacteristicID).to.equal("mobile_number");
            chai.expect(mobileNumber.Value.length).to.equal(1);
            var udcValue = mobileNumber.Value[0];
            chai.expect(udcValue.Value).to.equal("077112233");
        });
    });
    describe("When the Order Candidate Request has Links", function () {
        it("Should remove Links with an Item Source of Decompose", function () {
            var request = ReadOrderCandidateRequest("DecomposeCreatedLink.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.LinkedEntities.length).to.equal(1);
            var handsetToSim = handset.LinkedEntities[0];
            chai.expect(handsetToSim.LinkTypeID).to.equal("handset_to_sim");
            chai.expect(handsetToSim.Links.length).to.equal(0);
        });
        it("Should not remove Links that were created by the user", function () {
            var request = ReadOrderCandidateRequest("UserCreatedLink.json");
            decomposeReverser.Execute(request);
            // Assert
            var handset = AssertEntityStructure(request);
            chai.expect(handset.LinkedEntities.length).to.equal(1);
            var handsetToSim = handset.LinkedEntities[0];
            chai.expect(handsetToSim.LinkTypeID).to.equal("handset_to_sim");
            chai.expect(handsetToSim.Links.length).to.equal(1);
            var link = handsetToSim.Links[0];
            chai.expect(link.PortfolioItemID).to.equal("pi_sim");
        });
    });
});
function ReadOrderCandidateRequest(fileName) {
    var request = fs.readFileSync(path.join("cs-supplement-order/test/files/DecomposeReverser/Values", fileName), "utf8");
    var orderCandidateRequest = new OrderCandidateRequest(ConverterUtils.OrderPluralize(JSON.parse(request)));
    return orderCandidateRequest;
}
function AssertEntityStructure(request) {
    chai.expect(request.OrderCandidate.OrderItems.length).to.equal(1);
    var mobilePackage = request.OrderCandidate.OrderItems[0];
    chai.expect(mobilePackage.EntityID).to.equal("mobile_package");
    chai.expect(mobilePackage.ChildOrderItems.length).to.greaterThan(0);
    var handset = mobilePackage.ChildOrderItems[0];
    chai.expect(handset.EntityID).to.equal("handset");
    if (mobilePackage.ChildOrderItems.length === 2) {
        var sim = mobilePackage.ChildOrderItems[1];
        chai.expect(sim.EntityID).to.equal("sim");
    }
    return handset;
}

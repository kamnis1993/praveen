"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var SupplementalOrderBuilder = require("../SupplementalOrderBuilder");
var fs = require("fs");
var chai = require("chai");
describe("Testing hydrating a Supplemental Order Request", function () {
    it("Should have all sections populated correctly", function (done) {
        fs.readFile('cs-supplement-order/test/files/SupplementalOrder.json', { encoding: 'utf8' }, function (err, supplementalOrderContents) {
            var inputSupplementalOrder = ConverterUtils.OrderPluralize(JSON.parse(supplementalOrderContents));
            var builder = new SupplementalOrderBuilder();
            var supplementalOrder = builder.Build(inputSupplementalOrder);
            fs.readFile('cs-supplement-order/test/files/SupplementalOrderOutput.json', { encoding: 'utf8' }, function (err, expectedContents) {
                var expectedSupplementalOrder = JSON.parse(expectedContents);
                // Remove properties that are not populated, so deep equal works properly
                supplementalOrder = JSON.parse(JSON.stringify(supplementalOrder));
                chai.expect(supplementalOrder).to.deep.equal(expectedSupplementalOrder);
                done();
            });
        });
    });
});

"use strict";
/// <reference types="node" />
/// <reference types="chai" />
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
var ConverterUtils = require("../../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var SupplementalOrderMerger = require("../SupplementalOrderMerger");
var fs = require("fs");
var chai = require("chai");
describe("Merging supplemental orders with the in flight order", function () {
    describe("Should merge create order items correctly", function () {
        var supplementalOrderRequestContents = fs.readFileSync('cs-supplement-order/test/files/SupplementalOrderCreate.json', { encoding: 'utf8' });
        var inputSupplementalOrderRequest = ConverterUtils.OrderPluralize(JSON.parse(supplementalOrderRequestContents));
        var merger = new SupplementalOrderMerger(new CsErrorContext({}));
        var supplementalOrderRequest = merger.Merge(inputSupplementalOrderRequest);
        chai.expect(supplementalOrderRequest).to.not.be.undefined;
        var orderCandidate = supplementalOrderRequest.OrderCandidate;
        var createOrderItems = supplementalOrderRequest.SupplementalOrder.Create.CreateOrderItems;
        // create_01 - Adding a new root
        var rootCreateOrder = LodashUtilities.Find(createOrderItems, function (c) { return c.ID === "create_01"; });
        chai.expect(rootCreateOrder).to.not.be.undefined;
        chai.expect(rootCreateOrder.OrderItems).to.not.be.undefined;
        chai.expect(rootCreateOrder.OrderItems.length).to.equal(1);
        it("Should add a new root item", function () {
            var orderItem = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === rootCreateOrder.OrderItems[0].ID; });
            chai.expect(orderItem).to.not.be.undefined;
            chai.expect(orderItem.EntityID).to.equal(rootCreateOrder.OrderItems[0].EntityID);
            chai.expect(orderItem.ItemAction).to.equal(rootCreateOrder.OrderItems[0].ItemAction);
        });
        it("Should add a child to an existing parent", function () {
            // create_02 - Adding to existing parent
            var createOrderItem = LodashUtilities.Find(createOrderItems, function (c) { return c.ID === "create_02"; });
            chai.expect(createOrderItem).to.not.be.undefined;
            chai.expect(createOrderItem.OrderItems).to.not.be.undefined;
            chai.expect(rootCreateOrder.OrderItems.length).to.equal(1);
            var root = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === "r_ord_02"; });
            chai.expect(root).to.not.be.undefined;
            chai.expect(root.EntityID).to.equal("9f34a5e0-1707-4211-ada3-1347d1ad8fc3");
            chai.expect(root.ItemAction).to.equal("add");
            var parent = LodashUtilities.Find(root.ChildOrderItems, function (o) { return o.ID === "parent_02"; });
            chai.expect(parent).to.not.be.undefined;
            chai.expect(parent.EntityID).to.equal("c1c2f732-d8c8-4900-9033-0c5413fa012f");
            chai.expect(parent.ItemAction).to.equal("add");
            var child = LodashUtilities.Find(parent.ChildOrderItems, function (o) { return o.ID === createOrderItem.OrderItems[0].ID; });
            chai.expect(child).to.not.be.undefined;
            chai.expect(child.EntityID).to.equal(createOrderItem.OrderItems[0].EntityID);
            chai.expect(child.ItemAction).to.equal(createOrderItem.OrderItems[0].ItemAction);
            var grandchildOrderCreate = createOrderItem.OrderItems[0].ChildOrderItems[0];
            var grandchild = LodashUtilities.Find(child.ChildOrderItems, function (o) { return o.ID === grandchildOrderCreate.ID; });
            chai.expect(grandchild).to.not.be.undefined;
            chai.expect(grandchild.EntityID).to.equal(grandchildOrderCreate.EntityID);
            chai.expect(grandchild.ItemAction).to.equal(grandchildOrderCreate.ItemAction);
        });
        var rootOrderItem = LodashUtilities.Find(orderCandidate.OrderItems, function (o) { return o.ID === rootCreateOrder.OrderItems[0].ID; });
        chai.expect(rootOrderItem).to.not.be.undefined;
        it("Should populate characteristic uses", function () {
            chai.expect(rootOrderItem.CharacteristicUses).to.not.be.undefined;
            chai.expect(rootOrderItem.CharacteristicUses.length).to.equal(1);
            var charUse = rootOrderItem.CharacteristicUses[0];
            chai.expect(charUse.CharacteristicID).to.equal("32064b28-9800-428c-b9f2-41ec2f8ff515");
            chai.expect(charUse.UseArea).to.equal("CommercialCharUse");
            chai.expect(charUse.Action).to.equal("modify");
            chai.expect(charUse.Value).to.not.be.undefined;
            chai.expect(charUse.Value.length).to.equal(1);
            var charValue = charUse.Value[0];
            chai.expect(charValue.ValueID).to.equal("ae9e76ca-987f-4e2b-8287-586325de155a");
            chai.expect(charValue.Action).to.equal("add");
        });
        it("Should populate configured values", function () {
            chai.expect(rootOrderItem.ConfiguredValues).to.not.be.undefined;
            chai.expect(rootOrderItem.ConfiguredValues.length).to.equal(1);
            var configuredValue = rootOrderItem.ConfiguredValues[0];
            chai.expect(configuredValue.CharacteristicID).to.equal("80a6a7fa-5cff-464b-89b1-f54f71198398");
            chai.expect(configuredValue.UseArea).to.equal("CommercialConfiguredValue");
            chai.expect(configuredValue.Action).to.equal("modify");
            chai.expect(configuredValue.Value).to.not.be.undefined;
            chai.expect(configuredValue.Value.length).to.equal(1);
            var charValue = configuredValue.Value[0];
            chai.expect(charValue.Value).to.equal("127.0.0.1");
            chai.expect(charValue.Action).to.equal("add");
        });
        it("Should populate rate attributes", function () {
            chai.expect(rootOrderItem.RateAttributes).to.not.be.undefined;
            chai.expect(rootOrderItem.RateAttributes.length).to.equal(1);
            var rateAttribute = rootOrderItem.RateAttributes[0];
            chai.expect(rateAttribute.Name).to.equal("RateName");
            chai.expect(rateAttribute.Value).to.equal("RateValue");
            chai.expect(rateAttribute.Action).to.equal("add");
        });
        it("Should populate linked entities", function () {
            chai.expect(rootOrderItem.LinkedEntities).to.not.be.undefined;
            chai.expect(rootOrderItem.LinkedEntities.length).to.equal(1);
            var linkedEntity = rootOrderItem.LinkedEntities[0];
            chai.expect(linkedEntity.LinkTypeID).to.equal("3d00ebc6-c2c2-4ef0-ae3a-8974db01a64c");
            chai.expect(linkedEntity.Links).to.not.be.undefined;
            chai.expect(linkedEntity.Links.length).to.equal(1);
            var link = linkedEntity.Links[0];
            chai.expect(link.PortfolioItemID).to.equal("s_1");
        });
    });
});

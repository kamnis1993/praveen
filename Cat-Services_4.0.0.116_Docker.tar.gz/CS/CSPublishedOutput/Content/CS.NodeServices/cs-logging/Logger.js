"use strict";
var CsContext = require("../cs-lib-types/CsContext");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Wrapper class for console logging
 * All console.logs raised in CS javascript will be handled by the .Net NodeServices ILogger
 */
var getCurrentObject = require("disposable-cls").getCurrentObject;
var Logger = /** @class */ (function () {
    function Logger() {
    }
    // LogLevels: Trace = 0, Debug = 1, Information = 2, Warning = 3, Error = 4, Critical = 5
    Logger.LogLevel = function () {
        var context = getCurrentObject(CsContext);
        if (Utilities.IsNotDefined(context)) {
            return 3; // default to Warning
        }
        return context.LogLevel;
    };
    /**
     * Log Information
     */
    Logger.debug = function (zOrder, category, message, context) {
        var csContext = getCurrentObject(CsContext);
        if (Utilities.IsNotDefined(csContext)) {
            return;
        }
        // Add to Diagnostics
        if (csContext.IncludeDiagnostics) {
            var contextString = void 0;
            if (typeof context === "function") {
                contextString = context();
            }
            else {
                contextString = context;
            }
            var traceLog = {
                ZOrder: zOrder,
                TimeStamp: Date.now(),
                Category: category,
                Message: message,
                Context: contextString
            };
            csContext.TraceEvents.push(traceLog);
        }
        // Create log entry
        if (csContext.LogLevel <= 1) {
            message = "[" + category + "] " + message;
            console.debug(message, context);
        }
    };
    /**
    * Log info
    */
    Logger.info = function (category, message, context) {
        if (Logger.LogLevel() <= 2) {
            message = "[" + category + "] " + message;
            console.info(message, context);
        }
    };
    /**
    * Log Error
    */
    Logger.error = function (message, context) {
        if (Logger.LogLevel() <= 4) {
            console.error(message, context);
        }
    };
    /**
     * Log Warning
     */
    Logger.warn = function (message, context) {
        if (Logger.LogLevel() <= 3) {
            console.warn(message, context);
        }
    };
    return Logger;
}());
module.exports = Logger;

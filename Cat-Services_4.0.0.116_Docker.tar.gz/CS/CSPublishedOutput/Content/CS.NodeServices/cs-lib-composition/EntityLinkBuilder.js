"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var ItemPairBuilder = require("./ItemPairBuilder");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioBuilderBase = require("./OrderfolioBuilderBase");
var OrderfolioQueries = require("./OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Builds entity links for item pairs
 */
var EntityLinkBuilder = /** @class */ (function (_super) {
    __extends(EntityLinkBuilder, _super);
    function EntityLinkBuilder(errorContext, requestId) {
        var _this = _super.call(this, errorContext, requestId) || this;
        _this._itemPairBuilder = new ItemPairBuilder(errorContext);
        return _this;
    }
    /**
     * Build the entity link lookups
     * @param {Array<ItemPair>} itemPairsProcessed The item pairs that have been processed
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    EntityLinkBuilder.prototype.BuildLinkedEntityLookups = function (itemPairsProcessed, decomposeContext) {
        for (var itemPairIdx = 0; itemPairIdx < itemPairsProcessed.length; itemPairIdx++) {
            if (this._errorContext.HasBreakingErrors) {
                return;
            }
            var itemPair = itemPairsProcessed[itemPairIdx];
            this.CombineEntityLinks(itemPair, decomposeContext);
        }
    };
    /**
     * Combines the entity links from the portfolio and order
     * @param {ItemPair} itemPair The item pair
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    EntityLinkBuilder.prototype.CombineEntityLinks = function (itemPair, decomposeContext) {
        var entityLinksOnOrder = Utilities.IsDefined(itemPair.OrderItem) && Utilities.IsDefined(itemPair.OrderItem.LinkedEntities) ? itemPair.OrderItem.LinkedEntities : [];
        var entityLinksOnPortfolio = Utilities.IsDefined(itemPair.PortfolioItem) && Utilities.IsDefined(itemPair.PortfolioItem.LinkedEntities) ? itemPair.PortfolioItem.LinkedEntities : [];
        for (var orderLinkedEntityIdx = 0; orderLinkedEntityIdx < entityLinksOnOrder.length; orderLinkedEntityIdx++) {
            var entityLinkOnOrder = entityLinksOnOrder[orderLinkedEntityIdx];
            var entityLinkOnPortfolio = this.GetEntityLinkFromCollection(entityLinksOnPortfolio, entityLinkOnOrder.LinkTypeID);
            this.CombineEntityLink(entityLinkOnOrder, entityLinkOnPortfolio, itemPair, decomposeContext);
            if (this._errorContext.HasBreakingErrors) {
                return;
            }
        }
        for (var portfolioLinkedEntityIdx = 0; portfolioLinkedEntityIdx < entityLinksOnPortfolio.length; portfolioLinkedEntityIdx++) {
            var entityLinkOnPortfolio = entityLinksOnPortfolio[portfolioLinkedEntityIdx];
            var entityLinkOnOrder = this.GetEntityLinkFromCollection(entityLinksOnOrder, entityLinkOnPortfolio.LinkTypeID);
            if (Utilities.IsDefined(entityLinkOnOrder)) {
                continue;
            }
            this.CombineEntityLink(entityLinkOnOrder, entityLinkOnPortfolio, itemPair, decomposeContext);
            if (this._errorContext.HasBreakingErrors) {
                return;
            }
        }
    };
    /**
     * Combines a single entity link that is on an order, portfolio, or both
     * @param {EntityLink} entityLinkOnOrder The entity link on the order
     * @param {EntityLink} entityLinkOnPortfolio The entity link on the portfolio
     * @param {ItemPair} itemPair The item pair
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    EntityLinkBuilder.prototype.CombineEntityLink = function (entityLinkOnOrder, entityLinkOnPortfolio, itemPair, decomposeContext) {
        var compiledSpec = decomposeContext.CompiledSpec;
        var entityLink = (Utilities.IsDefined(entityLinkOnOrder)) ? (entityLinkOnOrder) : (entityLinkOnPortfolio);
        var entityRelation = this.GetEntityLinkSpecification(compiledSpec, itemPair, entityLink);
        var sourceOrderfolioItem = this.FindMatchingSourceOrderfolioForLink(decomposeContext, itemPair);
        if (Utilities.IsNotDefined(sourceOrderfolioItem) || this._errorContext.HasBreakingErrors) {
            return;
        }
        var entityLinkAction = this.GetEntityLinkAction(entityLinkOnOrder, sourceOrderfolioItem);
        this.ValidateEntityLinkAgainstOrderItem(sourceOrderfolioItem, entityLinkOnOrder);
        var combinedLinks = this.CombineLinks(entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem);
        if (this._errorContext.HasBreakingErrors) {
            return;
        }
        // then each individual link:
        for (var linkIdx = 0; linkIdx < combinedLinks.length; linkIdx++) {
            var mergedLink = combinedLinks[linkIdx];
            var targetOrderfolioItem = this.FindMatchingTargetOrderfolioForLink(decomposeContext, mergedLink);
            var sourceToTargetLink = this.BuildSourceToTargetLink(entityRelation, sourceOrderfolioItem, targetOrderfolioItem, entityLinkAction, mergedLink, entityLink);
            decomposeContext.LinkedEntities.push(sourceToTargetLink);
        }
    };
    /**
     * Combines the links for an order and portfolio item
     * @param {EntityLink} entityLinkOnOrder The links on the order
     * @param {EntityLink} entityLinkOnPortfolio The links on the portfolio
     * @param {string} entityLinkAction The entity link action
     * @param {ItemPair} itemPair The item pair
     * @returns {Array<MergedLink>}
     */
    EntityLinkBuilder.prototype.CombineLinks = function (entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem) {
        var combinedValues = this.CombineOrderLinks(entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem);
        combinedValues = combinedValues.concat(this.CombinePortfolioLinks(entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem));
        return combinedValues;
    };
    /**
     * Adds the links for the order item
     * @param {EntityLink} entityLinkOnOrder The links on the order
     * @param {EntityLink} entityLinkOnPortfolio The links on the portfolio
     * @param {string} entityLinkAction The entity link action
     * @param {CsTypes.OrderfolioItem} sourceOrderfolioItem The source orderfolio item
     * @returns {Array<MergedLink>}
     */
    EntityLinkBuilder.prototype.CombineOrderLinks = function (entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem) {
        var combinedValues = [];
        var linksOnOrder = Utilities.IsDefined(entityLinkOnOrder) ? entityLinkOnOrder.Links : [];
        var linksOnPortfolio = Utilities.IsDefined(entityLinkOnPortfolio) ? entityLinkOnPortfolio.Links : [];
        if (linksOnOrder.length < 1) {
            return combinedValues;
        }
        for (var orderLinkIdx = 0; orderLinkIdx < linksOnOrder.length; orderLinkIdx++) {
            var linkOnOrder = linksOnOrder[orderLinkIdx];
            if (Utilities.IsNotDefined(linkOnOrder.PortfolioItemID, true)) {
                this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidEntityLink.MissingPortfolioItemID, { LinkTypeID: entityLinkOnOrder.LinkTypeID, EntityUniqueCode: sourceOrderfolioItem.EntityUniqueCode, ItemType: "order item" });
                return combinedValues;
            }
            var linkOnPortfolio = this.GetLinkFromCollection(linksOnPortfolio, linkOnOrder.PortfolioItemID);
            this.ValidateLinkAgainstEntityLink(entityLinkOnOrder, linkOnOrder, sourceOrderfolioItem);
            this.ValidateLinkAgainstOrderItem(sourceOrderfolioItem, entityLinkOnOrder, linkOnOrder);
            var mergedLink = this.BuildMergeLinkForOrder(linkOnOrder, linkOnPortfolio, entityLinkAction);
            if (Utilities.IsNotDefined(mergedLink)) {
                continue;
            }
            mergedLink.OrderEntityLinkItemSource = entityLinkOnOrder.ItemSource;
            mergedLink.PortfolioEntityLinkItemSource = (Utilities.IsDefined(entityLinkOnPortfolio) && Utilities.IsDefined(entityLinkOnPortfolio.ItemSource, true)) ? (entityLinkOnPortfolio.ItemSource) : (entityLinkOnOrder.ItemSource);
            combinedValues.push(mergedLink);
        }
        return combinedValues;
    };
    /**
     * Builds a merged link for an order
     * @param {LinkTarget} linkOnOrder The link on the order
     * @param {LinkTarget} linkOnPortfolio The link on the portfolio
     * @param {string} entityLinkAction The entity link action
     * @returns {MergedLink}
     */
    EntityLinkBuilder.prototype.BuildMergeLinkForOrder = function (linkOnOrder, linkOnPortfolio, entityLinkAction) {
        var mergedLink = {
            PortfolioItemID: linkOnOrder.PortfolioItemID,
            Action: null,
            OrderLinkItemSource: linkOnOrder.ItemSource,
            PortfolioLinkItemSource: (Utilities.IsDefined(linkOnPortfolio) && Utilities.IsDefined(linkOnPortfolio.ItemSource, true)) ? (linkOnPortfolio.ItemSource) : (linkOnOrder.ItemSource),
            OrderEntityLinkItemSource: undefined,
            PortfolioEntityLinkItemSource: undefined
        };
        switch (linkOnOrder.Action) {
            case OrderActions.Add:
                mergedLink.Action = Utilities.IsDefined(linkOnPortfolio) ? MergedActions.AddExisting : MergedActions.AddMissing;
                return mergedLink;
            case OrderActions.Delete:
                if (entityLinkAction === OrderActions.Modify) {
                    mergedLink.Action = Utilities.IsDefined(linkOnPortfolio) ? MergedActions.DeleteExisting : MergedActions.DeleteMissing;
                    return mergedLink;
                }
                return undefined;
            default:
                return undefined;
        }
    };
    /**
     * Adds the links for the portfolio item
     * @param {EntityLink} entityLinkOnOrder The links on the order
     * @param {EntityLink} entityLinkOnPortfolio The links on the portfolio
     * @param {string} entityLinkAction The entity link action
     * @param {CsTypes.OrderfolioItem} sourceOrderfolioItem The source orderfolio item
     * @returns {Array<MergedLink>}
     */
    EntityLinkBuilder.prototype.CombinePortfolioLinks = function (entityLinkOnOrder, entityLinkOnPortfolio, entityLinkAction, sourceOrderfolioItem) {
        var linksOnOrder = Utilities.IsDefined(entityLinkOnOrder) ? entityLinkOnOrder.Links : [];
        var linksOnPortfolio = Utilities.IsDefined(entityLinkOnPortfolio) ? entityLinkOnPortfolio.Links : [];
        var combinedValues = [];
        if (this._errorContext.HasBreakingErrors || linksOnPortfolio.length < 1) {
            return combinedValues;
        }
        for (var portfolioLinkIdx = 0; portfolioLinkIdx < linksOnPortfolio.length; portfolioLinkIdx++) {
            var linkOnPortfolio = linksOnPortfolio[portfolioLinkIdx];
            if (Utilities.IsNotDefined(linkOnPortfolio.PortfolioItemID, true)) {
                this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidEntityLink.MissingPortfolioItemID, { LinkTypeID: entityLinkOnPortfolio.LinkTypeID, EntityUniqueCode: sourceOrderfolioItem.PortfolioItemId, ItemType: "portfolio item" });
                return combinedValues;
            }
            var linkOnOrder = this.GetLinkFromCollection(linksOnOrder, linkOnPortfolio.PortfolioItemID);
            if (Utilities.IsDefined(linkOnOrder)) {
                continue;
            }
            var action = (entityLinkAction === OrderActions.Modify || entityLinkAction === OrderActions.NoChange) ? (MergedActions.SkipExisting) : (MergedActions.DeleteExisting);
            combinedValues.push({
                PortfolioItemID: linkOnPortfolio.PortfolioItemID,
                Action: action,
                PortfolioLinkItemSource: linkOnPortfolio.ItemSource,
                PortfolioEntityLinkItemSource: entityLinkOnPortfolio.ItemSource,
                OrderEntityLinkItemSource: undefined,
                OrderLinkItemSource: undefined
            });
        }
        return combinedValues;
    };
    /**
     * Builds a linked source to target link
     * @param {CsTypes.EntityLink} entityLinkSpec The entity link from the specification
     * @param {CsTypes.OrderfolioItem} sourceOrderfolioItem The source orderfolio item
     * @param {CsTypes.OrderfolioItemLookup} targetOrderfolioItemLookup The target orderfolio item lookup
     * @param {string} entityLinkAction The action on the entity link
     * @param {MergedLink} mergedLink The merged link
     * @param {EntityLink} mergedLink The entity link from the request
     * @returns {CsTypes.SourceToTargetEntityLink}
     */
    EntityLinkBuilder.prototype.BuildSourceToTargetLink = function (entityLinkSpec, sourceOrderfolioItem, targetOrderfolioItem, entityLinkAction, mergedLink, requestEntityLink) {
        var orderParentItemSource = (Utilities.IsDefined(sourceOrderfolioItem)) ? (sourceOrderfolioItem.OrderItemSource) : (undefined);
        var portfolioParentItemSource = (Utilities.IsDefined(sourceOrderfolioItem)) ? (sourceOrderfolioItem.PortfolioItemSource) : (undefined);
        // Order
        var orderEntityLinkItemSource = OrderfolioQueries.GetItemSource({ ItemSource: mergedLink.OrderEntityLinkItemSource }, this._requestId, { ItemSource: orderParentItemSource });
        var orderLinkItemSource = OrderfolioQueries.GetItemSource({ ItemSource: mergedLink.OrderLinkItemSource }, this._requestId, { ItemSource: orderEntityLinkItemSource });
        // Portfolio
        var portfolioEntityLinkItemSource = OrderfolioQueries.GetItemSource({ ItemSource: mergedLink.PortfolioEntityLinkItemSource }, this._requestId, { ItemSource: portfolioParentItemSource });
        var portfolioLinkItemSource = OrderfolioQueries.GetItemSource({ ItemSource: mergedLink.PortfolioLinkItemSource }, this._requestId, { ItemSource: portfolioEntityLinkItemSource });
        var linkedEntity = {
            LinkTypeID: undefined,
            EntityLinkAction: entityLinkAction,
            Source: (Utilities.IsDefined(sourceOrderfolioItem)) ? (sourceOrderfolioItem.CompoundKey) : (undefined),
            Target: (Utilities.IsDefined(targetOrderfolioItem)) ? (targetOrderfolioItem.CompoundKey) : (undefined),
            ExpectedSource: undefined,
            ExpectedTarget: undefined,
            IsMulti: false,
            IsUnique: false,
            TargetIsDependent: false,
            LinkAction: mergedLink.Action,
            IsInvalid: this.IsEntityLinkInvalid(sourceOrderfolioItem, targetOrderfolioItem, entityLinkSpec),
            PortfolioItemID: mergedLink.PortfolioItemID,
            OrderEntityLinkItemSource: orderEntityLinkItemSource,
            PortfolioEntityLinkItemSource: portfolioEntityLinkItemSource,
            OrderLinkItemSource: orderLinkItemSource,
            PortfolioLinkItemSource: portfolioLinkItemSource
        };
        if (Utilities.IsDefined(entityLinkSpec)) {
            linkedEntity.LinkTypeID = entityLinkSpec.Id;
            linkedEntity.ExpectedSource = entityLinkSpec.Source;
            linkedEntity.ExpectedTarget = entityLinkSpec.Target;
            linkedEntity.IsMulti = entityLinkSpec.IsMulti;
            linkedEntity.IsUnique = entityLinkSpec.IsUnique;
            linkedEntity.TargetIsDependent = entityLinkSpec.TargetIsDependent;
        }
        else {
            // Link doesn't exist in the spec for the source, so just output what was sent in
            linkedEntity.LinkTypeID = requestEntityLink.LinkTypeID;
        }
        return linkedEntity;
    };
    /**
    * Gets the action on the entity link
    * @param { EntityLink } entityLinkOnOrder The entity link on the order
        * @returns { string }
    */
    EntityLinkBuilder.prototype.GetEntityLinkAction = function (entityLinkOnOrder, orderfolioItem) {
        if (Utilities.IsDefined(orderfolioItem) && orderfolioItem.Action === OrderActions.Delete) {
            return OrderActions.Delete;
        }
        if (Utilities.IsDefined(entityLinkOnOrder)) {
            return Utilities.IsDefined(entityLinkOnOrder.Action) ? entityLinkOnOrder.Action : OrderActions.Update;
        }
        else {
            return OrderActions.NoChange;
        }
    };
    /**
     * Returns whether or not an entity link is invalid
     * @param {CsTypes.OrderfolioItem} sourceOrderfolioItem The source orderfolio item for the entity link
     * @param {CsTypes.OrderfolioItem} targetOrderfolioItem The target orderfolio item for the entity link
     * @param {CsTypes.EntityLink} entityLinkSpec The specification for the entity link
     * @returns {boolean}
     */
    EntityLinkBuilder.prototype.IsEntityLinkInvalid = function (sourceOrderfolioItem, targetOrderfolioItem, entityLinkSpec) {
        if (Utilities.IsNotDefined(sourceOrderfolioItem) || sourceOrderfolioItem.IsInvalid) {
            return true;
        }
        if (Utilities.IsNotDefined(targetOrderfolioItem) || targetOrderfolioItem.IsInvalid) {
            return true;
        }
        if (Utilities.IsNotDefined(entityLinkSpec)) {
            return true;
        }
        return false;
    };
    /**
     * Gets an entity link from a collection of entity links
     * @param {Array<EntityLink>} entityLinks The entity links
     * @param {string} linkTypeId The link type ID
     * @returns {EntityLink}
     */
    EntityLinkBuilder.prototype.GetEntityLinkFromCollection = function (entityLinks, linkTypeId) {
        var entityLink = LodashUtilities.Find(entityLinks, function (el) {
            return el.LinkTypeID === linkTypeId;
        });
        return entityLink;
    };
    /**
     * Gets a link target from the collection of link targets passed in
     * @param {Array<LinkTarget>} links The collection of links
     * @param {string} portfolioItemId The portfolio item ID to find
     * @returns {LinkTarget}
     */
    EntityLinkBuilder.prototype.GetLinkFromCollection = function (links, portfolioItemId) {
        var link = LodashUtilities.Find(links, function (l) {
            return l.PortfolioItemID === portfolioItemId;
        });
        return link;
    };
    /**
     * Finds the matching orderfolio item for a link source
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {ItemPair} itemPair The item pair
     * @returns {CsTypes.OrderfolioItemLookup}
     */
    EntityLinkBuilder.prototype.FindMatchingSourceOrderfolioForLink = function (decomposeContext, itemPair) {
        var matchingSourceOrderfolioItems = decomposeContext.Orderfolio[itemPair.Uuid].filter(function (ofi) {
            return itemPair.PortfolioItem ? ofi.PortfolioItemId === itemPair.PortfolioItem.ID : ofi.PortfolioItemId === itemPair.OrderItem.PortfolioItemID;
        });
        if (matchingSourceOrderfolioItems.length <= 0) {
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.OrderMissingPortfolioItemID, itemPair.EntityUniqueCode, itemPair.EntityID, { entityUniqueCode: itemPair.EntityUniqueCode });
            return undefined;
        }
        var lookup = matchingSourceOrderfolioItems[0].CompoundKey;
        return decomposeContext.Orderfolio[lookup.Key][lookup.Index];
    };
    /**
     * Find the matching orderfolio item for an entity link
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {LinkTarget} mergedLink The link
     * @returns {any}
     */
    EntityLinkBuilder.prototype.FindMatchingTargetOrderfolioForLink = function (decomposeContext, mergedLink) {
        var matchingTargetOrderfolioItems = [];
        for (var orderfolioItemKey in decomposeContext.Orderfolio) {
            matchingTargetOrderfolioItems = matchingTargetOrderfolioItems.concat(decomposeContext.Orderfolio[orderfolioItemKey].filter(function (ofi) {
                return ofi.PortfolioItemId === mergedLink.PortfolioItemID;
            }));
        }
        if (!matchingTargetOrderfolioItems || matchingTargetOrderfolioItems.length < 1) {
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.TargetNotFound, mergedLink.PortfolioItemID, undefined, { PortfolioItemID: mergedLink.PortfolioItemID });
            return undefined;
        }
        return matchingTargetOrderfolioItems[0];
    };
    /**
     * Validates an entity link against the specification
     * @param {CsTypes.CompiledSpecification} compiledSpec The compiled specification
     * @param {ItemPair} itemPair The item pair
     * @param {EntityLink} entityLink The entity link
     * @returns {CsTypes.EntityLink}
     */
    EntityLinkBuilder.prototype.GetEntityLinkSpecification = function (compiledSpec, itemPair, entityLink) {
        if (!compiledSpec.EntityLinksBySourceLookup[itemPair.Uuid] || compiledSpec.EntityLinksBySourceLookup[itemPair.Uuid].length < 1) {
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.InvalidSource, itemPair.EntityUniqueCode, itemPair.EntityID, { PortfolioItemID: itemPair.EntityUniqueCode, EntityLinkID: entityLink.LinkTypeID });
            return undefined;
        }
        var entityRelations = compiledSpec.EntityLinksBySourceLookup[itemPair.Uuid].filter(function (entityRelation) {
            return entityRelation.Id === entityLink.LinkTypeID;
        });
        if (!entityRelations || entityRelations.length < 1) {
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.InvalidLinkTypeID, itemPair.EntityUniqueCode, itemPair.EntityID, { LinkTypeID: entityLink.LinkTypeID, PortfolioItemID: itemPair.EntityUniqueCode });
            return undefined;
        }
        return entityRelations[0];
    };
    EntityLinkBuilder.prototype.ValidateEntityLinkAgainstOrderItem = function (orderfolioItem, entityLink) {
        if (Utilities.IsNotDefined(entityLink)) {
            return;
        }
        var isActionValid = this.ValidatePropertyActionAgainstOrderItem(orderfolioItem.Action, entityLink.Action);
        if (!isActionValid) {
            var params = {
                EntityLinkAction: entityLink.Action,
                OrderItemAction: orderfolioItem.Action,
                LinkTypeID: entityLink.LinkTypeID
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.OrderItemToEntityLink, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    EntityLinkBuilder.prototype.ValidateLinkAgainstEntityLink = function (entityLink, link, orderfolioItem) {
        var isActionValid = this.ValidateValueActionAgainstProperty(entityLink.Action, link.Action);
        if (!isActionValid) {
            var params = {
                LinkAction: link.Action,
                EntityLinkAction: entityLink.Action,
                LinkTypeID: entityLink.LinkTypeID,
                PortfolioItemID: link.PortfolioItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.EntityLinkToLink, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    EntityLinkBuilder.prototype.ValidateLinkAgainstOrderItem = function (orderfolioItem, entityLink, link) {
        var isActionValid = this.ValidateValueActionAgainstOrderItem(orderfolioItem.Action, link.Action);
        if (!isActionValid) {
            var params = {
                LinkAction: link.Action,
                OrderItemAction: orderfolioItem.Action,
                LinkTypeID: entityLink.LinkTypeID,
                PortfolioItemID: link.PortfolioItemID
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.OrderItemToLink, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    return EntityLinkBuilder;
}(OrderfolioBuilderBase));
module.exports = EntityLinkBuilder;

"use strict";
var DateAvailabilityFilter = require("../cs-lib-composition/compiler/DateAvailabilityFilter");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var ItemPairBuilder = require("./ItemPairBuilder");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderCandidateRequest = require("../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var OrderIdValidator = require("../cs-validate/OrderIdValidator");
var OrderfolioBuilder = require("../cs-lib-composition/OrderfolioBuilder");
var OrderfolioQueries = require("./OrderfolioQueries");
var PortfolioCandidate = require("../cs-lib-types/CPQ-BusinessEntities/PortfolioCandidate");
var PortfolioWideConditionBuilder = require("./PortfolioWideConditionBuilder");
var ProductCandidateRequest = require("../cs-lib-types/CPQ-BusinessEntities/ProductCandidateRequest");
var ReassignCandidateHydrator = require("./ReassignCandidateHydrator");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Object contains methods for building / manipulating a decompose context
 */
var DecomposeContextBuilder = /** @class */ (function () {
    /**
     * Creates a new instance of the decompose context builder
     * @param {string} boundaryCondition -- the boundary condition to store in the decompose contexts created
     */
    function DecomposeContextBuilder(boundaryCondition, errorContext) {
        this._boundaryCondition = boundaryCondition;
        this._errorContext = errorContext;
        this._portfolioWideConditionBuilder = new PortfolioWideConditionBuilder();
    }
    /**
     * Builds the decompose contexts for the single item contained in a product candidate request
     * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to be processed
     * @param {string} contractId The frameworkContracts contractId
     * @param {SpecificationHandler} specificationHandler The specification handler
     * @param {(err : CsError, result : CsTypes.DecomposeContextCollection)=>void} callback the method to call once this operation has completed
     */
    DecomposeContextBuilder.prototype.BuildFromProductCandidate = function (requestBody, compiledSpecs, callback) {
        var _this = this;
        if (Object.keys(requestBody).length === 0 && requestBody.constructor === Object) {
            requestBody = undefined;
        }
        var pcRequest = new ProductCandidateRequest(requestBody);
        if (!this.IsValidProductCandidateRequest(pcRequest)) {
            return callback([]);
        }
        var decomposeContexts = [];
        Object.keys(compiledSpecs).forEach(function (entityGuid) {
            var compiledSpec = compiledSpecs[entityGuid];
            if (Utilities.IsNotDefined(compiledSpec)) {
                return callback([]);
            }
            var filterer = new DateAvailabilityFilter(pcRequest.CreationDate);
            compiledSpec = filterer.ApplyFilter(compiledSpec);
            var decomposeContext = _this.BuildForProductCandidateRoot(pcRequest, compiledSpec);
            decomposeContexts.push(decomposeContext);
        });
        this._portfolioWideConditionBuilder.CompilePortfolioWideCompatibilityRules(decomposeContexts);
        this._portfolioWideConditionBuilder.CompilePortfolioWideMappingRules(decomposeContexts);
        return callback(decomposeContexts);
    };
    /**
     * Checks the structure of a product candidate request for basic components
     * @param   {ProductCandidateRequest} request the product candidate
     * @returns {boolean} whether or not the candidate is valid
     */
    DecomposeContextBuilder.prototype.IsValidProductCandidateRequest = function (request) {
        if (Utilities.IsNotDefined(request.CreationDate)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.ProductCandidateRequestInvalid.MissingOrInvalidCreationDate);
            return false;
        }
        if (Utilities.IsNotDefined(request.ProductCandidate) || Utilities.IsNotDefined(request.ProductCandidate.EntityID)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.ProductCandidateRequestInvalid.MissingProductCandidate);
            return false;
        }
        return true;
    };
    /**
     * Builds the decompose contexts for the items contains in the supplied order candidate request
     * @param {any} request The order candidate request
     * @param {string} contractId The frameworkContracts contractId
     * @param {SpecificationHandler} specificationHandler The specification handler
     * @param {(err : CsError, result : Array<CsTypes.DecomposeContext>)=>void} callback the method to call once this operation has completed
     */
    DecomposeContextBuilder.prototype.BuildFromOrderCandidateRequest = function (request, compiledSpecs, callback) {
        if (Object.keys(request).length === 0 && request.constructor === Object) {
            request = undefined;
        }
        return this.BuildFromOrderCandidate(new OrderCandidateRequest(request), compiledSpecs, callback);
    };
    /**
     * Builds the decompose contexts for the items contains in the supplied order candidate request
     * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to be processed
     * @param {any} compiledSpecs
     * @param {(err : CsError, result : Array<CsTypes.DecomposeContext>)=>void} callback the method to call once this operation has completed
     */
    DecomposeContextBuilder.prototype.BuildFromOrderCandidate = function (orderCandidateRequest, compiledSpecs, callback) {
        // TODO: CAB - Does this need to be a callback now?
        var _this = this;
        if (!this.IsValidOrderCandidateRequest(orderCandidateRequest)) {
            return callback([]);
        }
        // TODO: The OrderIdValidator should be retrieved from architect and not a direct import
        OrderIdValidator.Validate(orderCandidateRequest, this._errorContext);
        if (this._errorContext.HasBreakingErrors) {
            return callback([]);
        }
        // Perform all pre-decompose reassign related actions
        var reassignCandidateHydrator = new ReassignCandidateHydrator(this._errorContext);
        orderCandidateRequest = reassignCandidateHydrator.HydrateOrderCandidate(orderCandidateRequest);
        if (this._errorContext.HasBreakingErrors) {
            // Returning here on the basis that the reassign validation raised severe errors
            return callback([]);
        }
        var itemPairBuilder = new ItemPairBuilder(this._errorContext);
        var entitiesToBuildAContextFor = itemPairBuilder.GetItemsToBuildContextsFor(orderCandidateRequest, false);
        if (this._errorContext.HasBreakingErrors) {
            return callback([]);
        }
        // We now need to build the decomposeContexts for each entity in the orderCandidateRequest.
        // This in done in 2 steps to improve performance.
        // Step 1: Retrieves all the relevant specifications in the order and portfolio and adds them to the compiledSpecs array.
        // - It makes only one call per entityId, so data access and date filtering is only done once per entity.
        // Step 2: Builds the decompose contexts using the specifications in step 1 and returns them as the decomposeContexts array
        var decomposeContexts = [];
        //let compiledSpecs: Array<CsTypes.CompiledSpecification> = [];
        // Get all specifications required for the decompose.
        entitiesToBuildAContextFor.forEach(function (itemPair) {
            // Get the specification and create the Decompose Contexts
            if (Utilities.IsDefined(compiledSpecs[itemPair.EntityID])) {
                // TODO: IS THIS THE RIGHT PLACE TO FILTER?????  DO WE EVER NOT FILTER?
                // Apply the date filter
                var filterer = new DateAvailabilityFilter(orderCandidateRequest.ActivationDate);
                var compiledSpec = filterer.ApplyFilter(compiledSpecs[itemPair.EntityID]);
                var decomposeContext = _this.BuildForRootItem(itemPair, compiledSpec, orderCandidateRequest);
                decomposeContexts.push(decomposeContext);
            }
        });
        this._portfolioWideConditionBuilder.CompilePortfolioWideCompatibilityRules(decomposeContexts);
        this._portfolioWideConditionBuilder.CompilePortfolioWideMappingRules(decomposeContexts);
        decomposeContexts.forEach(function (decomposeContext) { _this.ApplyContextualDataToOrderfolio(decomposeContext); });
        return callback(decomposeContexts);
    };
    /**
     * Checks the structure of an order candidate request for basic components
     * @param   {OrderCandidateRequest} request the order candidate
     * @returns {boolean} whether or not the candidate is valid
     */
    DecomposeContextBuilder.prototype.IsValidOrderCandidateRequest = function (request) {
        if (Utilities.IsNotDefined(request.ActivationDate)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingOrInvalidActivationDate);
            return false;
        }
        if (Utilities.IsNotDefined(request.ID)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: "ID", Item: "OrderCandidateRequest" });
        }
        if (Utilities.IsNotDefined(request.OrderCandidate)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingOrderCandidate);
            return false;
        }
        if (Utilities.IsNotDefined(request.CustomerPortfolio)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingCustomerPortfolio);
            return false;
        }
        return true;
    };
    /**
    * Builds the decompose contexts for the items contains in the supplied order candidate request
    * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to be processed
    * @param {CompiledSpecs} compiledSpecs
    * @param {(err : CsError, result : Array<CsTypes.DecomposeContext>)=>void} callback the method to call once this operation has completed
    */
    DecomposeContextBuilder.prototype.BuildFromPortfolioCandidate = function (requestBody, compiledSpecs, callback) {
        var _this = this;
        var portfolio = new PortfolioCandidate(requestBody);
        if (portfolio.HasErrors) {
            this._errorContext.RaiseCsError(400, portfolio.ErrorDescriptor);
            return callback([]);
        }
        else if (portfolio.IsEmpty) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.PortfolioCandidate.NoPortfolioSupplied);
            return callback([]);
        }
        // We now need to build the decomposeContexts for each productCandidate in the portfolioItems.
        // This in done in 2 steps to improve performance.
        // Step 1: Retrieves all the relevant specifications and adds them to the compiledSpecs array.
        // - It makes only one call per entityId, so data access and date filtering is only done once per entity.
        // Step 2: Builds the decompose contexts using the specifications in step 1 and returns them as the decomposeContexts array
        var decomposeContexts = [];
        // Create the Decompose Contexts
        portfolio.PortfolioItems.forEach(function (portfolioItem) {
            var pcRequest = new ProductCandidateRequest();
            pcRequest.CreationDate = portfolioItem.CreationDate;
            pcRequest.ProductCandidate = portfolioItem.ProductCandidate;
            pcRequest.ContextualParameters = portfolio.ContextualParameters;
            var compiledSpec = compiledSpecs[pcRequest.ProductCandidate.EntityID];
            if (Utilities.IsDefined(compiledSpec)) {
                var decomposeContext = _this.BuildForProductCandidateRoot(pcRequest, compiledSpec, false);
                decomposeContexts.push(decomposeContext);
            }
        });
        // Update all decomposeContexts
        this._portfolioWideConditionBuilder.CompilePortfolioWideCompatibilityRules(decomposeContexts);
        this._portfolioWideConditionBuilder.CompilePortfolioWideMappingRules(decomposeContexts);
        decomposeContexts.forEach(function (decomposeContext) { _this.ApplyContextualDataToOrderfolio(decomposeContext); });
        return callback(decomposeContexts);
    };
    /**
     * Applies contextual data on this decompose context to appropriate items in the orderfolio
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context that contains the context data and the orderfolio
     */
    DecomposeContextBuilder.prototype.ApplyContextualDataToOrderfolio = function (decomposeContext) {
        if (!decomposeContext.ContextData || !decomposeContext.ContextData.OrderContext) {
            return;
        }
        for (var c = 0; c < decomposeContext.ContextData.OrderContext.length; c++) {
            var contextItem = decomposeContext.ContextData.OrderContext[c];
            // We are only interested in context items that have meaning to CS
            if (Utilities.IsNotDefined(contextItem.CharacteristicId, true)) {
                continue;
            }
            var orderfolioItemKeys = decomposeContext.CompiledSpec.CharacteristicUseLookups.IdToOrderfolioItem[contextItem.CharacteristicId.toLowerCase()];
            if (!orderfolioItemKeys) {
                continue;
            }
            for (var j = 0; j < orderfolioItemKeys.length; j++) {
                var orderfolioItemKey = orderfolioItemKeys[j];
                var orderfolioItems = decomposeContext.Orderfolio[orderfolioItemKey];
                if (!orderfolioItems || orderfolioItems.length === 0) {
                    continue;
                }
                var charType = decomposeContext.CompiledSpec.CharacteristicUseLookups.IdToType[contextItem.CharacteristicId];
                var isContextualCharacteristic = charType.indexOf('SigmaContextCharUse') >= 0;
                var isContextualUDC = charType.indexOf('SigContextDefinedCharValue') >= 0;
                if (isContextualCharacteristic) {
                    this.ApplyContextToOrderfolioItemsCharacteristics(orderfolioItems, contextItem, decomposeContext);
                }
                else if (isContextualUDC) {
                    this.ApplyContextToOrderfolioItemsUDCs(orderfolioItems, contextItem, decomposeContext);
                }
            }
        }
    };
    /**
     * USED FOR UNIT TESTING ONLY!
     * Builds decompose contexts for the supplied order candidate request using the supplied compiled specification
     * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to build the decompose contexts for
     * @param {CsTypes.CompiledSpecification} compiledSpec the compiled specification for the first root portfolio item in the request
     * @param {string} boundaryCondition the boundary condition to be taken into consideration during this operation
     * @returns {Array<CsTypes.DecomposeContext>} the array of decompose contexts for the supplied order candidate request
     */
    DecomposeContextBuilder.prototype.BuildUsingCompiledSpecification = function (orderCandidateRequest, compiledSpec) {
        var decomposeContexts = [];
        var itemPairBuilder = new ItemPairBuilder(this._errorContext);
        var entitiesToBuildAContextFor = itemPairBuilder.GetItemsToBuildContextsFor(orderCandidateRequest, false);
        if (!entitiesToBuildAContextFor) {
            return decomposeContexts;
        }
        var decomposeContext = this.BuildForRootItem(entitiesToBuildAContextFor[0], compiledSpec, orderCandidateRequest);
        decomposeContexts.push(decomposeContext);
        return decomposeContexts;
    };
    /**
     * Apply a context item to its corresponding UDC in the supplied list of orderfolio items
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the orderfolio items that contain the UDCs
     * @param {CsTypes.ContextItem} contextItem the context item that contains the data to be applied
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    DecomposeContextBuilder.prototype.ApplyContextToOrderfolioItemsUDCs = function (orderfolioItems, contextItem, decomposeContext) {
        var compiledSpecification = decomposeContext.CompiledSpec;
        var itemSource = OrderfolioQueries.GetItemSource({ ItemSource: undefined }, decomposeContext.OrderRequestId);
        var charIdLookup = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic;
        var newUdcValues = LodashUtilities.Uniq(contextItem.Values).map(function (value) {
            return {
                Value: value,
                Action: MergedActions.AddMissing,
                ItemSource: itemSource
            };
        });
        for (var c = 0; c < orderfolioItems.length; c++) {
            var orderfolioItem = orderfolioItems[c];
            var targetUdcs = orderfolioItem.UserDefinedCharacteristics.filter(function (charUse) {
                return charIdLookup[charUse.UseId].CharacteristicId === contextItem.CharacteristicId;
            });
            var udcInfos = compiledSpecification.CharacteristicUseLookups.UuidToSpecItem[orderfolioItem.CompoundKey.Key];
            if (!targetUdcs || targetUdcs.length === 0) {
                var udcs = udcInfos.filter(function (useInfo) { return useInfo.CharacteristicId === contextItem.CharacteristicId; });
                for (var j = 0; j < udcs.length; j++) {
                    var udc = udcs[j];
                    orderfolioItem.UserDefinedCharacteristics.push({
                        UseId: udc.CharacteristicUseId,
                        Action: OrderActions.Add,
                        Values: newUdcValues,
                        OrderItemSource: itemSource,
                        PortfolioItemSource: itemSource
                    });
                }
                continue;
            }
            for (var k = 0; k < targetUdcs.length; k++) {
                var targetCharUse = targetUdcs[k];
                targetCharUse.Values = !targetCharUse.Values || targetCharUse.Values.length === 0 ? newUdcValues : targetCharUse.Values;
            }
        }
    };
    /**
     * Apply a context item to its corresponding characteristic use in the supplied list of orderfolio items
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the orderfolio items that contain the characteristic uses
     * @param {CsTypes.ContextItem} contextItem the context item that contains the data to be applied
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    DecomposeContextBuilder.prototype.ApplyContextToOrderfolioItemsCharacteristics = function (orderfolioItems, contextItem, decomposeContext) {
        var compiledSpecification = decomposeContext.CompiledSpec;
        var charIdLookup = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic;
        var itemSource = OrderfolioQueries.GetItemSource({ ItemSource: undefined }, decomposeContext.OrderRequestId);
        for (var c = 0; c < orderfolioItems.length; c++) {
            var orderfolioItem = orderfolioItems[c];
            var uuid_1 = orderfolioItem.CompoundKey.Key.toString();
            var targetCharacteristicUses = orderfolioItem.CharacteristicUses.filter(function (charUse) {
                return charIdLookup[charUse.UseId].CharacteristicId === contextItem.CharacteristicId;
            });
            var charuseInfos = compiledSpecification.CharacteristicUseLookups.UuidToSpecItem[orderfolioItem.CompoundKey.Key];
            if (!targetCharacteristicUses || targetCharacteristicUses.length === 0) {
                var charUses = charuseInfos.filter(function (useInfo) { return useInfo.CharacteristicId === contextItem.CharacteristicId; });
                for (var j = 0; j < charUses.length; j++) {
                    var charuse = charUses[j];
                    var newCharValues = this.CreateMergedValueFromContextItem(contextItem, uuid_1, charuse.CharacteristicUseId, decomposeContext);
                    if (!newCharValues || newCharValues.length === 0) {
                        continue;
                    }
                    orderfolioItem.CharacteristicUses.push({
                        UseId: charuse.CharacteristicUseId,
                        Action: OrderActions.Add,
                        Values: newCharValues,
                        OrderItemSource: itemSource,
                        PortfolioItemSource: itemSource
                    });
                }
                continue;
            }
            for (var k = 0; k < targetCharacteristicUses.length; k++) {
                var targetCharUse = targetCharacteristicUses[k];
                targetCharUse.Values = !targetCharUse.Values || targetCharUse.Values.length === 0 ?
                    this.CreateMergedValueFromContextItem(contextItem, uuid_1, targetCharUse.UseId, decomposeContext) : targetCharUse.Values;
            }
        }
    };
    /**
     * Creates an array of Merged values using the values on the supplied contextItem
     * @param {CsTypes.ContextItem} contextItem the contextItem that contains the Merged Values
     * @param {string} uuid the uuid of the entity containing the char use
     * @param {string} useId the useId of the char use that will contain these merged values
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {Array<CsTypes.MergedValue>} the merged values
     */
    DecomposeContextBuilder.prototype.CreateMergedValueFromContextItem = function (contextItem, uuid, useId, decomposeContext) {
        var compiledSpecification = decomposeContext.CompiledSpec;
        var validValuesForUseId = compiledSpecification.CharacteristicUseLookups.UuidAndUseIdToValidValues[uuid + "|" + useId];
        var validValuesInDataContext = contextItem.Values.filter(function (valueId) {
            return validValuesForUseId.indexOf(valueId) >= 0;
        });
        return LodashUtilities.Uniq(validValuesInDataContext).map(function (valueId) {
            return {
                Value: valueId,
                Action: MergedActions.AddMissing,
                ItemSource: OrderfolioQueries.GetItemSource({ ItemSource: undefined }, decomposeContext.OrderRequestId)
            };
        });
    };
    /**
     * Builds a decompose context for an item pair using the supplied specification and order candidate request
     * @param {ItemPair} rootItemPair the item pair to build a decompose context for
     * @param {CsTypes.CompiledSpecification} compiledSpecification the compiled specification to use when building the decompose context
     * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to use when building the decompose context
     * @returns {CsTypes.DecomposeContext} the newly built decompose context
     */
    DecomposeContextBuilder.prototype.BuildForProductCandidateRoot = function (root, compiledSpecification, ignorePortfolioRules) {
        if (ignorePortfolioRules === void 0) { ignorePortfolioRules = true; }
        var decomposeContext = {
            ActivationDate: Utilities.EnsureDate(root.CreationDate),
            OrderRequestId: root.ProductCandidate.ID,
            CandidateOrderId: root.ProductCandidate.ID,
            DecomposeId: root.ProductCandidate.ID,
            Orderfolio: {},
            ContextData: { Customer: null, OrderContext: null, Limits: null },
            CompiledSpec: compiledSpecification,
            ParentToChildTable: {},
            ChildToParentTable: {},
            BoundaryCondition: this._boundaryCondition,
            MappingRuleIndex: 0,
            IgnorePortfolioWideRules: ignorePortfolioRules,
            LinkedEntities: []
        };
        if (root.ContextualParameters && root.ContextualParameters.length > 0) {
            decomposeContext.ContextData.Limits = [];
        }
        root.ContextualParameters.forEach(function (cp) {
            decomposeContext.ContextData.Limits.push(cp.Value);
        });
        new OrderfolioBuilder(this._errorContext, decomposeContext.OrderRequestId).BuildFromProductCandidate(root.ProductCandidate, decomposeContext);
        return decomposeContext;
    };
    /**
     * Builds a decompose context for an item pair using the supplied specification and order candidate request
     * @param {ItemPair} rootItemPair the item pair to build a decompose context for
     * @param {CsTypes.CompiledSpecification} compiledSpecification the compiled specification to use when building the decompose context
     * @param {OrderCandidateRequest} orderCandidateRequest the order candidate request to use when building the decompose context
     * @returns {CsTypes.DecomposeContext} the newly built decompose context
     */
    DecomposeContextBuilder.prototype.BuildForRootItem = function (rootItemPair, compiledSpecification, orderCandidateRequest) {
        var decomposeContext = {
            ActivationDate: Utilities.EnsureDate(orderCandidateRequest.ActivationDate),
            OrderRequestId: orderCandidateRequest.ID,
            CandidateOrderId: orderCandidateRequest.OrderCandidate.OrderID,
            DecomposeId: orderCandidateRequest.DecomposeID,
            Orderfolio: {},
            ContextData: { Customer: null, OrderContext: null, Limits: orderCandidateRequest.OrderCandidate.Limits },
            CompiledSpec: compiledSpecification,
            ParentToChildTable: {},
            ChildToParentTable: {},
            BoundaryCondition: this._boundaryCondition,
            MappingRuleIndex: 0,
            IgnorePortfolioWideRules: false,
            LinkedEntities: []
        };
        this.AddCustomerData(decomposeContext, orderCandidateRequest);
        if (rootItemPair.OrderItem && rootItemPair.OrderItem.ItemAction === OrderActions.NoChange) {
            this._errorContext.RaiseValidationError(ErrorCode.Validation.OrderNotApplicableToPortfolio.NoChangeOnRoot, rootItemPair.PortfolioItem.ID, rootItemPair.EntityID);
        }
        new OrderfolioBuilder(this._errorContext, decomposeContext.OrderRequestId).Build(rootItemPair, decomposeContext);
        return decomposeContext;
    };
    /**
     * Adds contextual data to DecomposeContext
     * @param   {CsTypes.DecomposeContext} dc the decompose context to add contextual data to
     * @param   {OrderCandidateRequest} ocr the order candidate request to take the contextual data from
     */
    DecomposeContextBuilder.prototype.AddCustomerData = function (dc, ocr) {
        if (!ocr || !ocr.OrderCandidate) {
            return;
        }
        if (ocr.OrderCandidate.Customer) {
            dc.ContextData.Customer = ocr.OrderCandidate.Customer;
        }
        if (ocr.OrderCandidate.OrderContext) {
            dc.ContextData.OrderContext = ocr.OrderCandidate.OrderContext.map(function (contextItem) {
                var characteristicId = dc.CompiledSpec.CharacteristicUseLookups.NameToId[contextItem.Characteristic];
                return { CharacteristicName: contextItem.Characteristic, CharacteristicId: characteristicId, Values: contextItem.Value };
            });
        }
        if (Utilities.IsDefined(ocr.CustomerPortfolio)) {
            if (!dc.ContextData.Limits) {
                dc.ContextData.Limits = [];
            }
            dc.ContextData.Limits.concat(Utilities.ValueOrDefault(ocr.CustomerPortfolio.ContextualParameters, []));
        }
    };
    return DecomposeContextBuilder;
}());
module.exports = DecomposeContextBuilder;

"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var DecomposeGeneratedTypes = require("../cs-lib-constants/DecomposeGeneratedTypes");
var Delimiters = require("../cs-lib-constants/Delimiters");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var ItemSources = require("../cs-lib-constants/ItemSources");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class that contains common methods for dealing with CsTypes
 */
var OrderfolioQueries = /** @class */ (function () {
    function OrderfolioQueries() {
    }
    /**
     * Gets the item action for the root orderfolio item
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio The orderfolio
     * @returns {string}
     */
    OrderfolioQueries.GetRootOrderfolioAction = function (orderfolio) {
        var rootOrderfolioItem = orderfolio["1"];
        // No root item for this orderfolio
        if (Utilities.IsNotDefined(rootOrderfolioItem, true)) {
            Logger.debug(99, "OrderfolioBuilder", "No rootOrderfolioItem found");
            return undefined;
        }
        var rootAction = rootOrderfolioItem[0].Action;
        return Utilities.IsDefined(rootAction) ? rootAction : OrderActions.NoChange;
    };
    /**
     * Gets the entity unique code for the root orderfolio item
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio The orderfolio
     * @returns {string}
     */
    OrderfolioQueries.GetRootOrderfolioEntityUniqueCode = function (orderfolio) {
        var rootOrderfolioItem = orderfolio["1"];
        // No root item for this orderfolio
        if (!rootOrderfolioItem || rootOrderfolioItem.length < 1) {
            Logger.debug(0, "OrderfolioBuilder", "No rootOrderfolioItem found");
            return undefined;
        }
        return rootOrderfolioItem[0].EntityUniqueCode;
    };
    /**
     * Returns a flag to indicate whether the root orderfolio item will be output in the affected portfolio
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio The orderfolio
     */
    OrderfolioQueries.IsRootOrderfolioItemInAffectedPortfolio = function (orderfolio) {
        var rootOrderfolioAction = OrderfolioQueries.GetRootOrderfolioAction(orderfolio);
        return Utilities.IsDefined(rootOrderfolioAction) && rootOrderfolioAction !== OrderActions.Delete && rootOrderfolioAction !== OrderActions.NoChange;
    };
    /**
     * Returns the dictionary key for the supplied OrderfolioItemLookup as used by the ParentToChild dictionary for example.
     * @param {CsTypes.OrderfolioItemLookup} itemLookup the lookup to get the dictionary key for
     * @return {string} OrderfolioItemLookup formatted correctly as a Dictionary Key
     */
    OrderfolioQueries.GetOrderfolioItemKey = function (itemLookup) {
        return itemLookup.Key.toString() + Delimiters.OrderfolioKey + itemLookup.Index.toString();
    };
    /**
     * Filters the child orderfolio items passed in to only the children that belong to the parent orderfolio lookup provided
     * @param {CsTypes.OrderfolioItemLookup} parent The compound key for the parent orderfolio item
     * @param {string} childOrderfolioItems The uuid of the child we are looking for
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    OrderfolioQueries.FilterChildrenToParent = function (parent, childOrderfolioItems, decomposeContext, excludeDeleted) {
        if (excludeDeleted === void 0) { excludeDeleted = false; }
        var isChild = function (lookup) {
            if (!lookup) {
                return false;
            }
            if (lookup.Key === parent.Key && lookup.Index === parent.Index) {
                return true;
            }
            return isChild(decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(lookup)]);
        };
        var applicableChildren = [];
        if (!childOrderfolioItems || childOrderfolioItems.length === 0) {
            return applicableChildren;
        }
        // Add all children that have this parent
        for (var childIdx = 0; childIdx < childOrderfolioItems.length; childIdx++) {
            var currentChild = childOrderfolioItems[childIdx];
            if (excludeDeleted && currentChild.Action === OrderActions.Delete) {
                continue;
            }
            if (isChild(currentChild.CompoundKey)) {
                applicableChildren.push(childOrderfolioItems[childIdx]);
            }
        }
        return applicableChildren;
    };
    /**
     * Find the parent for a child by a parent Uuid
     * @param {CsTypes.Uuid} parentKey The parent Uuid
     * @param {CsTypes.OrderfolioItemLookup} childLookup The child lookup
     * @param {any} decomposeContext The decompose context
     */
    OrderfolioQueries.FindParentForChild = function (parentKey, childLookup, decomposeContext) {
        var findParent = function (lookup) {
            if (!lookup) {
                return undefined;
            }
            if (lookup.Key === parentKey) {
                return lookup;
            }
            return findParent(decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(lookup)]);
        };
        return findParent(childLookup);
    };
    /**
     * Check the action on a given orderfolio item. If it is null, undefined or no-change then it is set to update.
     * If the action is changed, the child->parent table is walked setting actions to 'update' until an already set action is found
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item to update
     */
    OrderfolioQueries.EnsureActionHierarchy = function (decomposeContext, orderfolioItem) {
        var NoAction = function (ofi) { return ofi.Action == null || ofi.Action === undefined || ofi.Action === OrderActions.NoChange; };
        var HasAction = function (ofi) { return !NoAction(ofi); };
        var GetParent = function (ofi) {
            var cmk = decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(ofi.CompoundKey)];
            if (!cmk) {
                return null;
            }
            return decomposeContext.Orderfolio[cmk.Key][cmk.Index];
        };
        if (HasAction(orderfolioItem)) {
            return;
        }
        // Flip to 'update' (MAYBE -- this could be the source of bugs where an update should be a no-change)
        // Look at parent in child->parent table. If no action, propagate up. Keep doing that until no parent found, or it has an action.
        do {
            orderfolioItem.Action = OrderActions.Update;
            orderfolioItem.OrderItemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
            orderfolioItem.DecomposeGenID = DecomposeGeneratedTypes.Existing;
            orderfolioItem = GetParent(orderfolioItem);
        } while (orderfolioItem && NoAction(orderfolioItem));
    };
    /**
     * Check the action on a given orderfolio item. If it is null, undefined or no-change then it is set to update.
     * Orderfolio item is identified by OrderfolioItem lookup
     * If the action is changed, the child->parent table is walked setting actions to 'update' until an already set action is found
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItemLookup} orderfolioItemLookup The lookup to the orderfolio item to update
     */
    OrderfolioQueries.EnsureActionHierarchyByLookup = function (decomposeContext, orderfolioItemLookup) {
        var orderfolioItem = decomposeContext.Orderfolio[orderfolioItemLookup.Key][orderfolioItemLookup.Index];
        this.EnsureActionHierarchy(decomposeContext, orderfolioItem);
    };
    /**
     * Gets the key/lookup, that uniquely identifies an item in an orderfolio, for the supplied itemPair
     * @param {ItemPair} itemPairForEntityID the itemPair to get the corresponding orderfolio lookup for
     * @param {CsTypes.SpecItem} specEntity the specEntity that contains part of the item lookup (key)
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio the orderfolio that contains the orderfolio item we are trying to get the lookup of
     * @returns {string} a concatenated string that represents an ofi lookup
     */
    OrderfolioQueries.GetDictionaryKeyForItem = function (itemPairForEntityID, specEntity, orderfolio, errorContext) {
        var ofiIndex = this.GetPositionOfOrderfolioItem(specEntity.Key, itemPairForEntityID.EntityUniqueCode, orderfolio, errorContext);
        if (errorContext.HasBreakingErrors) {
            return undefined;
        }
        return { Key: specEntity.Key, Index: ofiIndex };
    };
    /**
     * Gets all the orderfolioItems in a Decompose Context which have a specified action
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context containing the OrderfolioItems to look through
     * @param {string} filterAction the action to filter on. This should be one of the values in OrderActions
     * @return {Array<CsTypes:OrderfolioItem>} the orderfolioItems found
     */
    OrderfolioQueries.GetOrderfolioItemsByAction = function (decomposeContext, filterAction) {
        var actionToLookFor = filterAction.toLowerCase();
        var foundOrderfolioItems = [];
        Object.keys(decomposeContext.Orderfolio).forEach(function (uuid) {
            var actionedItems = decomposeContext.Orderfolio[uuid].filter(function (orderItem) { return orderItem.Action === actionToLookFor; });
            foundOrderfolioItems.push.apply(foundOrderfolioItems, actionedItems);
        });
        return foundOrderfolioItems;
    };
    /**
    * Finds and returns the matching order item for an order item Id
    * @param {string} orderItemId - The unique order item id
    * @param {Array<IOrderItem>} orderItems - The order items
    * @returns {IOrderItem}
    */
    OrderfolioQueries.GetOrderItemById = function (orderItemId, orderItems) {
        var foundItem = undefined;
        var scanItems = function (orderItems) {
            return orderItems.some(function (item) {
                if (item.ID === orderItemId) {
                    foundItem = item;
                    return true;
                }
                if (item.ChildOrderItems && item.ChildOrderItems.length > 0) {
                    return scanItems(item.ChildOrderItems);
                }
                return false;
            });
        };
        scanItems(orderItems);
        return foundItem;
    };
    /**
    * Finds and returns the matching portfolio item for a portfolio item Id
    * @param {string} portfolioItemId - The unique portfolio item id
    * @param {Array<IPortfolioItem>} portfolioItems - The portfolio items
    * @returns {IPortfolioItem}
    */
    OrderfolioQueries.GetPortFolioItemById = function (portfolioItemId, portfolioItems) {
        var foundItem = undefined;
        var scanItems = function (portfolioItems) {
            return portfolioItems.some(function (item) {
                if (item.ID === portfolioItemId) {
                    foundItem = item;
                    return true;
                }
                if (item.ChildEntities && item.ChildEntities.length > 0) {
                    return scanItems(item.ChildEntities);
                }
                return false;
            });
        };
        scanItems(portfolioItems);
        return foundItem;
    };
    /**
     * Gets the position of the orderfolio item with the supplied key/portfolio id from the supplied orderfolio
     * @param {string} key the key/uuid of the orderfolio item
     * @param {string} portfolioItemId the portfolioID of the item you are searching for
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio the orderfolio to search
     * @returns {number} the index in the array of the orderfolio item with the supplied key/uuid and portfolioItemID
     */
    OrderfolioQueries.GetPositionOfOrderfolioItem = function (key, entityUniqueCode, orderfolio, errorContext) {
        for (var c = 0; c < orderfolio[key].length; c++) {
            if (orderfolio[key][c].EntityUniqueCode === entityUniqueCode) {
                return c;
            }
        }
        errorContext.RaiseCsError(400, ErrorCode.Validation.MissingOrderfolioItem);
        Logger.debug(0, "OrderfolioBuilder", "MissingOrderfolioItem Error");
        return undefined;
    };
    /**
     * Apply the MergedAction truth table for an OrderItem
     * See truth table for MergedAction in the Visio diagram
     * @param {string} mergedAction the mergedAction to decipher
     * @returns {string} a valid OrderAction or undefined if no action
     */
    OrderfolioQueries.OrderActionForMergedAction = function (mergedAction) {
        var valueAction = undefined;
        switch (mergedAction) {
            case MergedActions.DeleteExisting:
                valueAction = OrderActions.Delete;
                break;
            case MergedActions.AddMissing:
                valueAction = OrderActions.Add;
                break;
            case MergedActions.UpdateExisting:
                valueAction = OrderActions.Update;
                break;
            // case MergedActions.AddExisting:
            // case MergedActions.SkipExisting:
            // case MergedActions.DeleteMissing:
            default:
                valueAction = undefined;
                break;
        }
        return valueAction;
    };
    OrderfolioQueries.CascadeActionFromParent = function (itemPair, lastKnownParentAction) {
        if (itemPair && itemPair.OrderItem) {
            return itemPair.OrderItem.ItemAction;
        }
        if (lastKnownParentAction === OrderActions.Add) {
            return lastKnownParentAction;
        }
        if (lastKnownParentAction === OrderActions.Delete) {
            return lastKnownParentAction;
        }
        return undefined;
    };
    /**
    * Checks whether the characteristic uses on an orderfolio item contain the specified value ID
    * @param {string} valueId The value ID to find
    * @param {string} useId If specified, the CharacteristicUse also must have this UseId as well as the ValueId
    * @param {CsTypes.OrderfolioItem} orderfolioItems The orderfolio items to check
    * @returns {boolean}
    */
    OrderfolioQueries.HasValueId = function (valueId, useId, orderfolioItems) {
        var _this = this;
        for (var orderfolioIdx = 0; orderfolioIdx < orderfolioItems.length; orderfolioIdx++) {
            var orderfolioItem = orderfolioItems[orderfolioIdx];
            if (Utilities.IsNotDefined(orderfolioItem.CharacteristicUses, true)) {
                continue;
            }
            for (var charUseIdx = 0; charUseIdx < orderfolioItem.CharacteristicUses.length; charUseIdx++) {
                var charUse = orderfolioItem.CharacteristicUses[charUseIdx];
                if (Utilities.IsNotDefined(charUse.Values) || (Utilities.IsDefined(charUse.UseId) && charUse.UseId !== useId)) {
                    continue;
                }
                var valueExists = charUse.Values.some(function (value) {
                    return value.Value === valueId && !_this.IsDeleted(value);
                });
                if (valueExists) {
                    return true;
                }
            }
        }
        return false;
    };
    /**
     * Get the item source from the object passed in, defaulting if one is not set
     * @param {CsTypes.ItemSourceObject} itemSourceObject The object that contains the item source
     * @param {string} requestId The ID of the decompose request
     * @param {CsTypes.ItemSourceObject} parentItemSourceObject The parent object
     * @returns {string}
     */
    OrderfolioQueries.GetItemSource = function (itemSourceObject, requestId, parentItemSourceObject) {
        if (Utilities.IsDefined(itemSourceObject) && Utilities.IsDefined(itemSourceObject.ItemSource, true)) {
            return itemSourceObject.ItemSource;
        }
        else {
            if (Utilities.IsDefined(parentItemSourceObject) && Utilities.IsDefined(parentItemSourceObject.ItemSource, true)) {
                return parentItemSourceObject.ItemSource;
            }
            else {
                return ItemSources.Existing + requestId;
            }
        }
    };
    /**
     * Gets the item source for an item that has been generated by decompose
     * @param {string} orderRequestId The order request ID
     * @returns {string}
     */
    OrderfolioQueries.GetGeneratedItemSource = function (orderRequestId) {
        return ItemSources.Decompose + orderRequestId;
    };
    /**
     * Compares two orderfolio item lookup values to see if they are considered equal
     * @param {CsTypes.OrderfolioItemLookup} expected The expected orderfolio item lookup
     * @param {CsTypes.OrderfolioItemLookup} actual The actual orderfolio item lookup
     * @returns {boolean}
     */
    OrderfolioQueries.CompareOrderfolioItemLookup = function (expected, actual) {
        if (Utilities.IsNotDefined(expected) || Utilities.IsNotDefined(actual)) {
            return false;
        }
        return expected.Key === actual.Key && expected.Index === actual.Index;
    };
    /**
     * Checks if the activity is valid for the orderfolio item
     * @param {CsTypes.CompiledSpecification} compiledSpec The compiled specification
     * @param {string} uuid The UUID of the entity
     * @param {string} activity The activity to check
     * @returns {boolean}
     */
    OrderfolioQueries.IsActivityValidForOrderfolioItem = function (compiledSpec, uuid, activity) {
        var availableActivities = compiledSpec.EntityDates[uuid].AvailableActivities;
        if (Utilities.IsNotDefined(availableActivities, true)) {
            return false;
        }
        return LodashUtilities.Contains(availableActivities, activity);
    };
    /**
     * Whether the merged value is deleted
     * @param {CsTypes.MergedValue} value The merged value to check
     * @returns {boolean}
     */
    OrderfolioQueries.IsDeleted = function (value) {
        return value.Action === MergedActions.DeleteExisting || value.Action === MergedActions.DeleteMissing;
    };
    /**
     * Creates a decompose generation ID from the parameters passed in
     * @param {string} decomposeType The decompose type
     * @param {string[]} params The parameters to use
     * @returns {string}
     */
    OrderfolioQueries.GetDecomposeGenID = function (decomposeType, params) {
        return decomposeType + Delimiters.DecomposeGeneration + params.join(Delimiters.DecomposeGeneration);
    };
    /**
     * Checks whether the date for a rule falls within the order request date
     * @param  {CsTypes.MaybeDate} startDate The start date of the rule
     * @param  {CsTypes.MaybeDate} endDate   The end date of the rule
     * @param  {Date}              orderDate The activation date of the order request
     * @return {boolean}                     True if the rule is within the allowed dates, otherwise false
     */
    OrderfolioQueries.RuleDateCriteriaIsMet = function (startDate, endDate, orderDate) {
        var testDate = Utilities.EnsureDate(orderDate);
        if (Utilities.IsNotDefined(testDate)) {
            return false;
        }
        var meetsStartCriteria = Utilities.IsNotDefined(startDate) || testDate.getTime() >= Utilities.EnsureDate(startDate).getTime();
        var meetsEndCriteria = Utilities.IsNotDefined(endDate) || testDate.getTime() <= Utilities.EnsureDate(endDate).getTime();
        return (meetsStartCriteria && meetsEndCriteria);
    };
    return OrderfolioQueries;
}());
module.exports = OrderfolioQueries;

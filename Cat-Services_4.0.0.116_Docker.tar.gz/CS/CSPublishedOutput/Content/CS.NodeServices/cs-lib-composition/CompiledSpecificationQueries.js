"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/// <reference types="lodash" />
/**
 * Contains methods for querying the compiled specification
 */
var CompiledSpecificationQueries = /** @class */ (function () {
    function CompiledSpecificationQueries() {
    }
    /**
     * Combines all the rule conditions together
     * @param {CsTypes.RuleConditionCollection} conditions The rule conditions
     * @returns {Array<CsTypes.Condition>}
     */
    CompiledSpecificationQueries.AllRuleConditions = function (conditions) {
        return [].concat(conditions.Exists, conditions.NotExists, conditions.ExistsValue, conditions.NotExistsValue, conditions.ExistsOrdActItem, conditions.ExistsOrderValueAction, conditions.NotExistsOrderValueAction, conditions.NoValueExistsOrderAction, conditions.NotExistsOrdActItem, conditions.NoValueExists, conditions.ExistsEntityLink, conditions.NotExistsEntityLink, conditions.UDCMatchesValue, conditions.ExistsData, conditions.NotExistsData, conditions.EntToEnt, conditions.EntToStatic, conditions.EntToUDC);
    };
    /**
     * Returns only the conditions that match
     * @param {CsTypes.RuleConditionCollection} conditions DescriptionOfParam
     * @param {string[]} conditionTypes DescriptionOfParam
     */
    CompiledSpecificationQueries.FilterConditions = function (conditions, conditionFilter) {
        var allConditions = CompiledSpecificationQueries.AllRuleConditions(conditions);
        return allConditions.filter(function (c) {
            return conditionFilter.some(function (cf) {
                return c.ConditionType === cf.ConditionType && c.ExistsCondition === cf.Exists;
            });
        });
    };
    /**
     * Reset all conditions on a RuleCondition Collection to empty arrays
     * @param {CsTypes.RuleConditionCollection} conditions the condition collection to reset
     */
    CompiledSpecificationQueries.ClearRuleConditionCollection = function (conditions) {
        conditions.Exists = [];
        conditions.NotExists = [];
        conditions.ExistsValue = [];
        conditions.NotExistsValue = [];
        conditions.ExistsOrdActItem = [];
        conditions.NotExistsOrdActItem = [];
        conditions.NoValueExists = [];
        conditions.ExistsEntityLink = [];
        conditions.NotExistsEntityLink = [];
        conditions.UDCMatchesValue = [];
        conditions.ExistsData = [];
    };
    return CompiledSpecificationQueries;
}());
module.exports = CompiledSpecificationQueries;

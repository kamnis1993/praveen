"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var CsValidationError = require("../../cs-lib-types/CsValidationError");
var DateAvailabilityFilter = require("../../cs-lib-composition/compiler/DateAvailabilityFilter");
var DecomposeContextBuilder = require("../DecomposeContextBuilder");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var OrderCandidateResponseBuilder = require("../OrderCandidateResponseBuilder");
var OrderfolioLinkedEntityQueries = require("../../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var Utilities = require("../../cs-lib-utilities/Utilities");
var Fakei18n = /** @class */ (function () {
    function Fakei18n() {
    }
    Fakei18n.prototype.translate = function (messageCode) {
        return 'Translated: ' + messageCode;
    };
    return Fakei18n;
}());
describe("When unflattening an orderfolio where an entity does not satisfy group cardinality", function () {
    it("Should output a validation error in the response", function (done) {
        // Arrange
        var errorContext = new CsErrorContext({});
        var orderCandidateResponseBuilder = new OrderCandidateResponseBuilder(errorContext);
        var decomposeContextsFileContents = fs.readFileSync('cs-lib-composition/test/data/GroupCardinality.json', { encoding: 'utf8' });
        var decomposeContext = JSON.parse(decomposeContextsFileContents.toString());
        var decomposeContexts = Utilities.asArray(decomposeContext);
        decomposeContext[0].QueryableLinkedEntities = new OrderfolioLinkedEntityQueries();
        // Act
        var orderCandidateResponse = orderCandidateResponseBuilder.Build(decomposeContexts);
        // Assert
        orderCandidateResponse.ValidationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(orderCandidateResponse.ValidationErrors.length).to.equal(3);
        // Create a new GroupCardinalityNotSatisfied validation error as the expected validation error
        // This strips the "Validation" category from the error code. (i.e. "GroupCardinalityNotSatisfied")
        var groupCardinalityNotSatisfied = new CsValidationError(Utilities.GenerateGuid(), ErrorCode.Validation.GroupCardinalityNotSatisfied.Code, null, null, null, null, null, null, null);
        console.log(orderCandidateResponse.ValidationErrors[0].ErrorCode);
        console.log(groupCardinalityNotSatisfied.ErrorCode);
        chai.expect(orderCandidateResponse.ValidationErrors[0].ErrorCode).to.equal(groupCardinalityNotSatisfied.ErrorCode.split(".")[1]);
        chai.expect(orderCandidateResponse.ValidationErrors[1].ErrorCode).to.equal(groupCardinalityNotSatisfied.ErrorCode.split(".")[1]);
        chai.expect(orderCandidateResponse.ValidationErrors[2].ErrorCode).to.equal(groupCardinalityNotSatisfied.ErrorCode.split(".")[1]);
        chai.expect(orderCandidateResponse.ValidationErrors[0].EntityUniqueCode).to.equal('pi_z');
        chai.expect(orderCandidateResponse.ValidationErrors[1].EntityUniqueCode).to.equal('pi_y');
        chai.expect(orderCandidateResponse.ValidationErrors[2].EntityUniqueCode).to.equal('pi_x');
        done();
    });
});
describe("When unflattening an orderfolio into an order candidate response", function () {
    it("Should contain all of the expected elements present in the orderfolio", function (done) {
        var errorContext = new CsErrorContext({});
        var compiledSpecification = JSON.parse(fs.readFileSync('cs-lib-composition/test/data/ParentChildIntepretationSpec.json', { encoding: 'utf8' }));
        var orderRequestContents = fs.readFileSync('cs-lib-composition/test/data/ParentChildIntepretationOrderRequest.json', { encoding: 'utf8' });
        var orderRequest = new OrderCandidateRequest(JSON.parse(orderRequestContents));
        var decomposeContextBuilder = new DecomposeContextBuilder('technical', errorContext);
        // Apply the datefilter
        var filterer = new DateAvailabilityFilter(orderRequest.ActivationDate);
        compiledSpecification = filterer.ApplyFilter(compiledSpecification);
        var compiledSpecs = { "b0834ea4-14e9-4ed2-a3d8-f294c7aba935": compiledSpecification };
        //decomposeContextBuilder.BuildFromOrderCandidate(orderRequest, "", <any>fakeSpecificationHandler, (result: CsTypes.DecomposeContextCollection) =>
        decomposeContextBuilder.BuildFromOrderCandidate(orderRequest, compiledSpecs, function (result) {
            var orderCandidateResponseBuilder = new OrderCandidateResponseBuilder(errorContext);
            var orderCandidateResponse = orderCandidateResponseBuilder.Build(result);
            chai.expect(orderCandidateResponse).to.not.be.undefined;
            chai.expect(orderCandidateResponse.OrderCandidate).to.not.be.undefined;
            chai.expect(orderCandidateResponse.CustomerPortfolio).to.not.be.undefined;
            chai.expect(orderCandidateResponse.RequestID).to.equal("12345");
            chai.expect(orderCandidateResponse.OrderCandidate.OrderID).to.equal("o_1");
            chai.expect(orderCandidateResponse.OrderCandidate.Customer.ID).to.equal("cid");
            chai.expect(orderCandidateResponse.OrderCandidate.OrderContext[1].Value[0]).to.equal("D");
            // Order
            chai.expect(orderCandidateResponse.OrderCandidate.OrderItems.length).to.equal(1);
            // Parent Order
            var parentOrderItem = orderCandidateResponse.OrderCandidate.OrderItems[0];
            chai.expect(parentOrderItem.EntityID).to.equal("b0834ea4-14e9-4ed2-a3d8-f294c7aba935");
            chai.expect(parentOrderItem.ID).to.equal("oi_1");
            chai.expect(parentOrderItem.ItemAction).to.equal(OrderActions.Add);
            chai.expect(parentOrderItem.ChildOrderItems.length).to.equal(1);
            // Child Order
            var childOrderItem = parentOrderItem.ChildOrderItems[0];
            chai.expect(childOrderItem.EntityID).to.equal("acada96b-2ee7-4a0a-94cb-f21e96919802");
            chai.expect(childOrderItem.ID).to.equal("coi_1");
            chai.expect(childOrderItem.ItemAction).to.equal(OrderActions.Add);
            // Portfolio
            chai.expect(orderCandidateResponse.CustomerPortfolio.AffectedPortfolioItems.length).to.equal(1);
            // Parent Portfolio
            var parentPortfolioItem = orderCandidateResponse.CustomerPortfolio.AffectedPortfolioItems[0];
            chai.expect(parentPortfolioItem.EntityID).to.equal("b0834ea4-14e9-4ed2-a3d8-f294c7aba935");
            chai.expect(parentPortfolioItem.ItemAction).to.be.undefined;
            chai.expect(parentPortfolioItem.ChildEntities.length).to.equal(1);
            // Child Portfolio
            var childPortfolioItem = parentPortfolioItem.ChildEntities[0];
            chai.expect(childPortfolioItem.EntityID).to.equal("acada96b-2ee7-4a0a-94cb-f21e96919802");
            chai.expect(childPortfolioItem.ItemAction).to.be.undefined;
            // Ensure portfolio and order are linked.
            chai.expect(parentOrderItem.PortfolioItemID).to.equal(parentPortfolioItem.ID);
            chai.expect(childOrderItem.PortfolioItemID).to.equal(childPortfolioItem.ID);
            done();
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var ReassignCandidateHydrator = require("../ReassignCandidateHydrator");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderItem = require("../../cs-lib-types/BusinessEntities/OrderItem");
/**
* Functionality Under Test:
*  HydrateOrderCandidate function of ReassignCandidateHydrator class
*
* Scenarios Covered:
*    1. Original Order Candidate request should return unchanged when no reassign items are found in Order Candidate
*    2. For the Portfolio which has GrandParent, Parent and Child hierarchy:
*        a. Inclusion of missing Child component with appropriate reassign state in OrderCandidate when Parent is marked for reassign.
*        b. Addition of missing Child component with reassigned state when the same Child component is marked for reassign.
*        c. Addition of missing Child component with reassign state when the same Child component is marked for reassigned.
*
* JSON files used:
*    1. cs-lib-composition\test\data\ReassignCandidateHydratorTests_3level.json
*    2. cs-lib-composition\test\data\ReassignCandidateHydratorTests_NoReassign.json
*/
describe('ReassignCandidateHydrator', function () {
    describe('When making a call to HydrateOrderCandidate with no Reassign items', function () {
        it('Should return Original Order Candidate request unchanged', function (done) {
            /* ValidatePortfolioItems and ValidateOrderCandidate functions are very specify to this test case.
               Code is repeated hence it is grouped in a function and kept very local to this unit test case*/
            var ValidatePortfolioItems = function (orderCandidateRequest) {
                var GParentA = orderCandidateRequest.CustomerPortfolio.PortfolioItems[0];
                var ParentA = GParentA.ChildEntities[0];
                var childA = ParentA.ChildEntities[0];
                AssertPortfolioItem(GParentA, "GrandParent A", "d3252856-ca99-4410-ac6e-49a6670101ef");
                AssertPortfolioItem(ParentA, "ParentA", "66716b34-508e-4016-82a6-5c77fb07c732");
                AssertPortfolioItem(childA, "ChildA", "a20d9f45-0b23-4512-8e24-7d423cc40b8f");
                chai.expect(childA.ChildEntities).to.be.empty;
            };
            var ValidateOrderCandidate = function (orderCandidateRequest) {
                var GParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
                var ParentA_order = GParentA_order.ChildOrderItems[0];
                var ChildA_order = ParentA_order.ChildOrderItems[0];
                var GParentB_order = orderCandidateRequest.OrderCandidate.OrderItems[1];
                var ParentB_order = GParentB_order.ChildOrderItems[0];
                var ChildB_order = ParentB_order.ChildOrderItems[0];
                AssertOrderItems(GParentA_order, "d3252856-ca99-4410-ac6e-49a6670101ef", "GrandParent A", "delete");
                AssertOrderItems(ParentA_order, "66716b34-508e-4016-82a6-5c77fb07c732", "ParentA", "delete");
                AssertOrderItems(ChildA_order, "a20d9f45-0b23-4512-8e24-7d423cc40b8f", "ChildA", "delete");
                chai.expect(ChildA_order.ChildOrderItems).to.be.empty;
                AssertOrderItems(GParentB_order, "9bfdfff4-5a6d-471b-9dec-0605fcdc1f5c", "GrandParent B", "add");
                AssertOrderItems(ParentB_order, "66716b34-508e-4016-82a6-5c77fb07c900", "ParentB", "add");
                AssertOrderItems(ChildB_order, "k80d9f45-0b23-4512-8e24-7d423kl89g6t", "ChildB", "add");
                chai.expect(ChildB_order.ChildOrderItems).to.be.empty;
            };
            // Begin of Unit test case
            // Creating Order Candidate request
            var orderCandidateRequest = createGPC_NoReassignItems();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GrandParentA -> ParentA->ChildA
                         Order candidate: GrandParentA(delete)->ParentA(delete)-> ChildA(delete)
                                          GrandParent B(add)-> Parent B(add) -> Child B(add)*/
            ValidatePortfolioItems(orderCandidateRequest);
            ValidateOrderCandidate(orderCandidateRequest);
            var reassignHydrator = new ReassignCandidateHydrator(null);
            var hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Checking output and no changes expected.
            ValidatePortfolioItems(hydratedCandidateRequest);
            ValidateOrderCandidate(hydratedCandidateRequest);
            done();
        });
    });
    describe('When making a call to HydrateOrderCandidate for GrandParent-Parent-Child Portfolio', function () {
        var orderCandidateRequest;
        var hydratedCandidateRequest;
        var reassignHydrator = new ReassignCandidateHydrator(null);
        it('Should return Order candidate with an addition of missing child component with appropriate reassign state ', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGPC_ParentReassign();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GrandParentA -> Parent->Child
                          Order candidate: GrandParentA(delete)->parent(reassign)
                                          GrandParent B(add)-> parent(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            // Confirming Order Candidate is as per expected
            var GParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
            var ParentA_order = GParentA_order.ChildOrderItems[0];
            var GParentB_order = orderCandidateRequest.OrderCandidate.OrderItems[1];
            var Parent_rorder = GParentB_order.ChildOrderItems[0];
            AssertOrderItems(GParentA_order, "d3252856-ca99-4410-ac6e-49a6670101ef", "GrandParent A", "delete");
            AssertOrderItems(ParentA_order, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassign");
            chai.expect(ParentA_order.ChildOrderItems).to.be.empty;
            AssertOrderItems(GParentB_order, "9bfdfff4-5a6d-471b-9dec-0605fcdc1f5c", "GrandParent B", "add");
            AssertOrderItems(Parent_rorder, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassigned");
            chai.expect(Parent_rorder.ChildOrderItems).to.be.empty;
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Portfolio items : No change
            ValidatePortfolioItems(hydratedCandidateRequest);
            // There should be addition of Child with appropriate reassign state.
            ValidateResultantOrderCandidate(hydratedCandidateRequest);
            done();
        });
        it('Should return Order candidate with an addition of missing reassigned child order item ', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGPC_MissingReassignedChild();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GrandParentA -> Parent->Child
                         Order candidate: GrandParentA(delete)->parent(reassign)->child(reassign)
                                          GrandParent B(add)-> parent(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            // Confirming Order Candidate is as per expected
            var GParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
            var ParentA_order = GParentA_order.ChildOrderItems[0];
            var Child_order = ParentA_order.ChildOrderItems[0];
            var GParentB_order = orderCandidateRequest.OrderCandidate.OrderItems[1];
            var Parent_rorder = GParentB_order.ChildOrderItems[0];
            AssertOrderItems(GParentA_order, "d3252856-ca99-4410-ac6e-49a6670101ef", "GrandParent A", "delete");
            AssertOrderItems(ParentA_order, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassign");
            AssertOrderItems(Child_order, "a20d9f45-0b23-4512-8e24-7d423cc40b8f", "Child", "reassign");
            chai.expect(Child_order.ChildOrderItems).to.be.empty;
            AssertOrderItems(GParentB_order, "9bfdfff4-5a6d-471b-9dec-0605fcdc1f5c", "GrandParent B", "add");
            AssertOrderItems(Parent_rorder, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassigned");
            chai.expect(Parent_rorder.ChildOrderItems).to.be.empty;
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Portfolio items : No change
            ValidatePortfolioItems(hydratedCandidateRequest);
            // Addition of Child with state "reassigned" under GrandParentB
            ValidateResultantOrderCandidate(hydratedCandidateRequest);
            done();
        });
        it('Should return Order candidate with an addition of missing reassign child order item ', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGPC_MissingReassignChild();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GrandParentA -> Parent->Child
                          Order candidate: GrandParentA(delete)->parent(reassign)
                                          GrandParent B(add)-> parent(reassigned)->child(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            // Confirming Order Candidate is as per expected
            var GParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
            var ParentA_order = GParentA_order.ChildOrderItems[0];
            var GParentB_order = orderCandidateRequest.OrderCandidate.OrderItems[1];
            var Parent_rorder = GParentB_order.ChildOrderItems[0];
            var Child_rorder = Parent_rorder.ChildOrderItems[0];
            AssertOrderItems(GParentA_order, "d3252856-ca99-4410-ac6e-49a6670101ef", "GrandParent A", "delete");
            AssertOrderItems(ParentA_order, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassign");
            chai.expect(ParentA_order.ChildOrderItems).to.be.empty;
            AssertOrderItems(GParentB_order, "9bfdfff4-5a6d-471b-9dec-0605fcdc1f5c", "GrandParent B", "add");
            AssertOrderItems(Parent_rorder, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassigned");
            AssertOrderItems(Child_rorder, "a20d9f45-0b23-4512-8e24-7d423cc40b8f", "Child", "reassigned");
            chai.expect(Child_rorder.ChildOrderItems).to.be.empty;
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Portfolio items : No change
            ValidatePortfolioItems(hydratedCandidateRequest);
            // Grand parent A order items: Addition of child with reassign state
            ValidateResultantOrderCandidate(hydratedCandidateRequest);
            done();
        });
    });
});
/**
* OrderItem is validated against given entityID, portfolioID and ItemAction
* @param {OrderItem} Order Item
*        {string} EntityID
*        {string} PortfolioID
*        {string} ItemAction
*/
function AssertOrderItems(orderItem, entityID, portfolioID, itemAction) {
    chai.expect(orderItem.EntityID).equal(entityID);
    chai.expect(orderItem.PortfolioItemID).equal(portfolioID);
    chai.expect(orderItem.ItemAction).equal(itemAction);
}
/**
* PortfolioItem is validated against given ID and entityID
* @param {PortfolioItem} portfolio item
*        {string} EntityID
*/
function AssertPortfolioItem(portfolio, ID, entityID) {
    chai.expect(portfolio.EntityID).equal(entityID);
    chai.expect(portfolio.ID).equal(ID);
}
/**
* Builds an ordercandidate from a JSON file.
* @param {string} filePath
* @returns {OrderCandidate}
*/
function GetOrderCandidateFromFile(filePath) {
    var orderCandidateRaw = fs.readFileSync(filePath, { encoding: 'utf8' });
    var orderCandidateArray = Utilities.asArray(JSON.parse(orderCandidateRaw.toString()));
    chai.expect(orderCandidateArray).not.to.be.null;
    chai.expect(orderCandidateArray.length).to.be.greaterThan(0);
    return new OrderCandidateRequest(orderCandidateArray[0]);
}
/**
* Function generates the Order Candidate request as shown below.
* OrderCandidate request --> |--> CustomerPortfolio-->|->Grandparent A
                               |                            |->Parent A
                               |                                |-> Child A
                               |--> OrderCandidates-->|-->Grandparent A(delete)
                                                      |    |->Parent A(delete)
                                                      |       |-> Child A(delete)
                                                      |-->GrandParent B(add)
                                                      |     |->Parent B(add)
                                                      |         |-> Child B(add)
*/
function createGPC_NoReassignItems() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/ReassignCandidateHydratorTests_NoReassign.json");
}
/**
* Function generates the Order Candidate request as shown below.
* OrderCandidate request --> |--> CustomerPortfolio-->|->Grandparent A
                               |                            |->Parent
                               |                                |-> Child
                               |--> OrderCandidates-->|-->Grandparent A(delete)
                                                      |    |->Parent(reassign)
                                                      |-->GrandParent B(add)
                                                      |     |->Parent(reassigned)
*/
function CreateGPC_ParentReassign() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/ReassignCandidateHydratorTests_3level.json");
}
/**
* Function generates the Order Candidate request as shown below.
* OrderCandidate request --> |--> CustomerPortfolio-->|->Grandparent A
                               |                            |->Parent
                               |                                |-> Child
                               |--> OrderCandidates-->|-->Grandparent A(delete)
                                                      |    |->Parent(reassign)
                                                      |         |->child(reassign)
                                                      |-->GrandParent B(add)
                                                      |     |->Parent(reassigned)
*/
function CreateGPC_MissingReassignedChild() {
    var orderCandidateRequest = CreateGPC_ParentReassign();
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0] = new OrderItem();
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].ID = "Child_Order";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].PortfolioItemID = "Child";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].EntityID = "a20d9f45-0b23-4512-8e24-7d423cc40b8f";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].ItemAction = "reassign";
    return orderCandidateRequest;
}
/**
* Function generates the Order Candidate request as shown below.
* OrderCandidate request --> |--> CustomerPortfolio-->|->Grandparent A
                               |                            |->Parent
                               |                                |-> Child
                               |--> OrderCandidates-->|-->Grandparent A(delete)
                                                      |    |->Parent(reassign)
                                                      |-->GrandParent B(add)
                                                      |     |->Parent(reassigned)
                                                      |         |->child(reassigned)
*/
function CreateGPC_MissingReassignChild() {
    var orderCandidateRequest = CreateGPC_ParentReassign();
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0] = new OrderItem();
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].ID = "Child_Order";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].PortfolioItemID = "Child";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].EntityID = "a20d9f45-0b23-4512-8e24-7d423cc40b8f";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].ItemAction = "reassigned";
    return orderCandidateRequest;
}
/**
* Function checks whether given Portfolio item has same data as of Source.
* All test cases of 3 level hierarchy portfolio expects same output hence it is grouped under this function.
* @param {orderCandidateRequest} Order candidate request
*/
function ValidatePortfolioItems(orderCandidateRequest) {
    var GParentA = orderCandidateRequest.CustomerPortfolio.PortfolioItems[0];
    var Parent = GParentA.ChildEntities[0];
    var child = Parent.ChildEntities[0];
    AssertPortfolioItem(GParentA, "GrandParent A", "d3252856-ca99-4410-ac6e-49a6670101ef");
    AssertPortfolioItem(Parent, "Parent", "66716b34-508e-4016-82a6-5c77fb07c732");
    AssertPortfolioItem(child, "Child", "a20d9f45-0b23-4512-8e24-7d423cc40b8f");
    chai.expect(child.ChildEntities).to.be.empty;
}
/**
* Function checks whether given OrderCandidate item has full data with all reassigned states.
* All test cases of 3 level hierarchy portfolio expects same output hence it is grouped under this function.
* @param {orderCandidateRequest} Order candidate request
*/
function ValidateResultantOrderCandidate(orderCandidateRequest) {
    var GParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
    var ParentA_order = GParentA_order.ChildOrderItems[0];
    var GParentB_order = orderCandidateRequest.OrderCandidate.OrderItems[1];
    var Parent_rorder = GParentB_order.ChildOrderItems[0];
    var Child_order = ParentA_order.ChildOrderItems[0];
    var Child_rorder = Parent_rorder.ChildOrderItems[0];
    AssertOrderItems(GParentA_order, "d3252856-ca99-4410-ac6e-49a6670101ef", "GrandParent A", "delete");
    AssertOrderItems(ParentA_order, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassign");
    AssertOrderItems(Child_order, "a20d9f45-0b23-4512-8e24-7d423cc40b8f", "Child", "reassign");
    chai.expect(Child_order.ChildOrderItems).to.be.empty;
    AssertOrderItems(GParentB_order, "9bfdfff4-5a6d-471b-9dec-0605fcdc1f5c", "GrandParent B", "add");
    AssertOrderItems(Parent_rorder, "66716b34-508e-4016-82a6-5c77fb07c732", "Parent", "reassigned");
    AssertOrderItems(Child_rorder, "a20d9f45-0b23-4512-8e24-7d423cc40b8f", "Child", "reassigned");
    chai.expect(Child_rorder.ChildOrderItems).to.be.empty;
}

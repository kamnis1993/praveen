"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var ReassignCandidateHydrator = require("../ReassignCandidateHydrator");
var Fakei18n = /** @class */ (function () {
    function Fakei18n() {
    }
    Fakei18n.prototype.translate = function (messageCode) {
        return 'Translated: ' + messageCode;
    };
    return Fakei18n;
}());
/**
* Functionality Under Test:
*  HydrateOrderCandidate function of ReassignCandidateHydrator class
* Scenarios Covered:
*   1. A request containing no reassign items is unchanged.
*   2. A request containing a reassign item that targets a missing portfolio item should return PortfolioItemMissing Error.
*   3. A request containing a reassign item that has a child item in the portfoli, but not in the order.
*   4. A request containing 2 reassigned items with the same entityID, and both have a child item in the portfolio but not in the order.
*   5. A request containing 2 reassignedupdate items with the same entityID, and both have a child item in the portfolio but not in the order.
*   6. A request containing 2 reassigned items with the same entityID but different CharacteristicUses in the portfolio.
*   7. A request containing 2 reassignedupdate items with the same entityID but with a replace CharacteristicUses.
*
* JSON files used:
*   1. cs-lib-composition\test\data\S10195\1NoReassignItem.json
*   2. cs-lib-composition\test\data\S10195\2ReassignToMissingPortfolioItem.json
*   3. cs-lib-composition\test\data\S10195\3ReassignRequestWithInferredChild.json
*   4. cs-lib-composition\test\data\S10195\4ReassignedTwoEntityWithSameEntityId.json
*   5. cs-lib-composition\test\data\S10195\5ReassignedUpdateTwoEntityWithSameEntityId.json
*   6. cs-lib-composition\test\data\S10195\6ReassignedTwoEntityWithSameEntityIdDiffCharUse.json
*   7. cs-lib-composition\test\data\S10195\7ReassignedUpdateTwoEntityWithSameEntityIdDiffCharUse.json
*
*/
describe("ReassignCandidateHydrator", function () {
    var errorContext = new CsErrorContext({});
    describe("making a call to HydrateOrderCandidate with multiple reassign items", function () {
        it("should return the correctly hydrated candidate request", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/ReassignCandidateHydratorTest1.json", { encoding: 'utf8' }).toString());
            var orderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(orderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignedPackage = orderCandidate.OrderCandidate.OrderItems[1].ChildOrderItems[0];
            chai.expect(reassignedPackage.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_2_CHILD1");
            chai.expect(reassignedPackage.ChildOrderItems[0].ItemAction).to.equal("delete");
            chai.expect(reassignedPackage.ChildOrderItems[1].PortfolioItemID).to.equal("cpi_4_CHILD1");
            chai.expect(reassignedPackage.ChildOrderItems[1].ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedPackage.ChildOrderItems[2].PortfolioItemID).to.equal("cpi_3_CHILD1");
            chai.expect(reassignedPackage.ChildOrderItems[2].ItemAction).to.equal("reassigned");
            chai.expect(reassignedPackage.ChildOrderItems[3].PortfolioItemID).to.equal("ID4");
            chai.expect(reassignedPackage.ChildOrderItems[3].ItemAction).to.equal("add");
            done();
        });
    });
    describe("A Request Containing no Reassign Items", function () {
        it("there should be no change to the entity returned", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/1NoReassignItem.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(1);
            var updatedPackage = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            chai.expect(updatedPackage.ChildOrderItems).to.be.undefined;
            chai.expect(updatedPackage.ID).to.equal("coi_1_PACKAGE1");
            done();
        });
    });
    describe("A Request Containing a Reassign Items that target a Missing Portfolio Item", function () {
        it("should It should return a Portfolio item Missing Error", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/2ReassignToMissingPortfolioItem.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.be.equal(1);
            chai.expect(validationErrors[0].ErrorCode).to.equal("OrderNotApplicableToPortfolio.PortfolioItemMissing");
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            chai.expect(reassignComponent.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_2_CHILD1");
            chai.expect(reassignComponent.ChildOrderItems[0].ID).to.equal("coi_2_CHILD1");
            chai.expect(reassignComponent.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            chai.expect(reassignedComponent.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_2_CHILD1");
            chai.expect(reassignedComponent.ChildOrderItems[0].ID).to.equal("coi_4_CHILD1");
            chai.expect(reassignedComponent.ChildOrderItems[0].ItemAction).to.equal("reassigned");
            chai.expect(reassignedComponent.ID).to.equal("coi_3_PACKAGE2");
            done();
        });
    });
    describe("A Request Containing a Reassign Items with an Inferred child in the Portfolio", function () {
        it("the inferred child should be in the response as childOrderItem of reassign entity", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/3ReassignRequestWithInferredChild.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            var reassignChild = reassignComponent.ChildOrderItems[0];
            chai.expect(reassignChild.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignChild.ID).to.equal("coi_CHILD1");
            chai.expect(reassignChild.ItemAction).to.equal("reassign");
            chai.expect(reassignChild.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignChild.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            var reassignedChild = reassignedComponent.ChildOrderItems[0];
            chai.expect(reassignedChild.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignedChild.ID).to.equal("coi_3_CHILD1");
            chai.expect(reassignedChild.ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignedChild.ChildOrderItems[0].ItemAction).to.equal("reassigned");
            chai.expect(reassignedComponent.ID).to.equal("coi_2_PACKAGE2");
            done();
        });
    });
    describe("A Request Containing two Reassigned Items with Same EntityID", function () {
        it("should return the child item in the response for both entities with correct PortfolioItemID", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/4ReassignedTwoEntityWithSameEntityId.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            var reassignChild1 = reassignComponent.ChildOrderItems[0];
            var reassignChild3 = reassignComponent.ChildOrderItems[1];
            chai.expect(reassignChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild1.ID).to.equal("coi_CHILD1");
            chai.expect(reassignChild1.ItemAction).to.equal("reassign");
            chai.expect(reassignChild1.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignChild1.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignChild3.PortfolioItemID).to.equal("cpi_CHILD3");
            chai.expect(reassignChild3.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild3.ID).to.equal("coi_CHILD3");
            chai.expect(reassignChild3.ItemAction).to.equal("reassign");
            chai.expect(reassignChild3.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignChild3.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            var reassignedChild1 = reassignedComponent.ChildOrderItems[0];
            var reassignedChild3 = reassignedComponent.ChildOrderItems[1];
            chai.expect(reassignedChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignedChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild1.ID).to.equal("coi_CHILD5");
            chai.expect(reassignedChild1.ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild1.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignedChild1.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignedChild1.ChildOrderItems[0].ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild3.PortfolioItemID).to.equal("cpi_CHILD3");
            chai.expect(reassignedChild3.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild3.ID).to.equal("coi_CHILD6");
            chai.expect(reassignedChild3.ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild3.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignedChild3.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_CHILD4");
            chai.expect(reassignedChild3.ChildOrderItems[0].ItemAction).to.equal("reassigned");
            chai.expect(reassignedComponent.ID).to.equal("coi_2_PACKAGE2");
            done();
        });
    });
    describe("A Request Containing two ReassignedUpdate Items with Same EntityID", function () {
        it("should return the child item in the response for both entities with correct PortfolioItemID", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/5ReassignedUpdateTwoEntityWithSameEntityId.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            var reassignChild1 = reassignComponent.ChildOrderItems[0];
            var reassignChild3 = reassignComponent.ChildOrderItems[1];
            chai.expect(reassignChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild1.ID).to.equal("coi_CHILD1");
            chai.expect(reassignChild1.ItemAction).to.equal("reassign");
            chai.expect(reassignChild1.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignChild1.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignChild3.PortfolioItemID).to.equal("cpi_CHILD3");
            chai.expect(reassignChild3.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild3.ID).to.equal("coi_CHILD3");
            chai.expect(reassignChild3.ItemAction).to.equal("reassign");
            chai.expect(reassignChild3.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignChild3.ChildOrderItems[0].ItemAction).to.equal("reassign");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            var reassignedChild1 = reassignedComponent.ChildOrderItems[0];
            var reassignedChild3 = reassignedComponent.ChildOrderItems[1];
            chai.expect(reassignedChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignedChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild1.ID).to.equal("coi_CHILD5");
            chai.expect(reassignedChild1.ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedChild1.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignedChild1.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignedChild1.ChildOrderItems[0].ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedChild3.PortfolioItemID).to.equal("cpi_CHILD3");
            chai.expect(reassignedChild3.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild3.ID).to.equal("coi_CHILD6");
            chai.expect(reassignedChild3.ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedChild3.ChildOrderItems[0].EntityID).to.equal("CHILD2");
            chai.expect(reassignedChild3.ChildOrderItems[0].PortfolioItemID).to.equal("cpi_CHILD4");
            chai.expect(reassignedChild3.ChildOrderItems[0].ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedComponent.ID).to.equal("coi_2_PACKAGE2");
            done();
        });
    });
    describe("A Request Containing two Reassigned Items with an Inferred CharUse in the Portfolio", function () {
        it("the inferred CharUse should be in the response as childOrderItem of reassigned entity", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/6ReassignedTwoEntityWithSameEntityIdDiffCharUse.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            var reassignChild1 = reassignComponent.ChildOrderItems[0];
            var reassignChild2 = reassignComponent.ChildOrderItems[1];
            chai.expect(reassignChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignChild1.ID).to.equal("coi_CHILD1");
            chai.expect(reassignChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild1.ItemAction).to.equal("reassign");
            chai.expect(reassignChild1.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignChild1.CharacteristicUses[0].Value[0].ValueID).to.equal("red");
            chai.expect(reassignChild2.PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignChild2.ID).to.equal("coi_CHILD2");
            chai.expect(reassignChild2.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild2.ItemAction).to.equal("reassign");
            chai.expect(reassignChild2.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignChild2.CharacteristicUses[0].Value[0].ValueID).to.equal("green");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            var reassignedChild1 = reassignedComponent.ChildOrderItems[0];
            var reassignedChild2 = reassignedComponent.ChildOrderItems[1];
            chai.expect(reassignedChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignedChild1.ID).to.equal("coi_CHILD3");
            chai.expect(reassignedChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild1.ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild1.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignedChild1.CharacteristicUses[0].Value[0].ValueID).to.equal("red");
            chai.expect(reassignedChild2.PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignedChild2.ID).to.equal("coi_CHILD4");
            chai.expect(reassignedChild2.EntityID).to.equal("CHILD1");
            chai.expect(reassignedChild2.ItemAction).to.equal("reassigned");
            chai.expect(reassignedChild2.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignedChild2.CharacteristicUses[0].Value[0].ValueID).to.equal("green");
            chai.expect(reassignedComponent.ID).to.equal("coi_2_PACKAGE2");
            done();
        });
    });
    describe("A Request Containing two Reassignedupdate Items with an Inferred CharUse in the Portfolio being replace ", function () {
        it("the replace CharUse should be in the response of reassignedpdate entity", function (done) {
            var request = JSON.parse(fs.readFileSync("cs-lib-composition/test/data/S10195/7ReassignedUpdateTwoEntityWithSameEntityIdDiffCharUse.json", { encoding: 'utf8' }).toString());
            var HydratedOrderCandidate = new ReassignCandidateHydrator(errorContext).HydrateOrderCandidate(request);
            chai.expect(HydratedOrderCandidate.OrderCandidate.OrderItems.length).to.equal(2);
            var reassignComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[0];
            var reassignChild1 = reassignComponent.ChildOrderItems[0];
            var reassignChild2 = reassignComponent.ChildOrderItems[1];
            chai.expect(reassignChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignChild1.ID).to.equal("coi_CHILD1");
            chai.expect(reassignChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild1.ItemAction).to.equal("reassign");
            chai.expect(reassignChild1.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignChild1.CharacteristicUses[0].Value[0].ValueID).to.equal("red");
            chai.expect(reassignChild2.PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignChild2.ID).to.equal("coi_CHILD2");
            chai.expect(reassignChild2.EntityID).to.equal("CHILD1");
            chai.expect(reassignChild2.ItemAction).to.equal("reassign");
            chai.expect(reassignChild2.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignChild2.CharacteristicUses[0].Value[0].ValueID).to.equal("green");
            chai.expect(reassignComponent.ID).to.equal("coi_1_PACKAGE1");
            var reassignedupdateComponent = HydratedOrderCandidate.OrderCandidate.OrderItems[1];
            var reassignedupdateChild1 = reassignedupdateComponent.ChildOrderItems[0];
            var reassignedupdateChild2 = reassignedupdateComponent.ChildOrderItems[1];
            chai.expect(reassignedupdateChild1.PortfolioItemID).to.equal("cpi_CHILD1");
            chai.expect(reassignedupdateChild1.ID).to.equal("coi_CHILD3");
            chai.expect(reassignedupdateChild1.EntityID).to.equal("CHILD1");
            chai.expect(reassignedupdateChild1.ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedupdateChild1.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignedupdateChild1.CharacteristicUses[0].Action).to.equal("replace");
            chai.expect(reassignedupdateChild1.CharacteristicUses[0].Value[0].ValueID).to.equal("blue");
            chai.expect(reassignedupdateChild1.CharacteristicUses[0].Value[0].Action).to.equal("add");
            chai.expect(reassignedupdateChild2.PortfolioItemID).to.equal("cpi_CHILD2");
            chai.expect(reassignedupdateChild2.ID).to.equal("coi_CHILD4");
            chai.expect(reassignedupdateChild2.EntityID).to.equal("CHILD1");
            chai.expect(reassignedupdateChild2.ItemAction).to.equal("reassignedupdate");
            chai.expect(reassignedupdateChild2.CharacteristicUses[0].CharacteristicID).to.equal("colour");
            chai.expect(reassignedupdateChild2.CharacteristicUses[0].Action).to.equal("replace");
            chai.expect(reassignedupdateChild2.CharacteristicUses[0].Value[0].ValueID).to.equal("orange");
            chai.expect(reassignedupdateChild2.CharacteristicUses[0].Value[0].Action).to.equal("add");
            chai.expect(reassignedupdateComponent.ID).to.equal("coi_2_PACKAGE2");
            done();
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var ReassignPairsBuilder = require("../../cs-lib-composition/ReassignPairsBuilder");
var OrderCandidate = require("../../cs-lib-types/BusinessEntities/OrderCandidate");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
* Functionality Under Test: ReassignPairsBuilder class
*
* Scenarios Covered:
*   1. BuildReassignPair function:
*       a. Returns Reassign pair from given reassign and reassigned order item
*   2. FindReassignPair function:
*       a. Returns matching reassign pair for a given Entity ID
*       b. Returns undefined if reassign pair is not found for a given Entity ID
*   3. BuildReassignPairs function:
*       a. Returns Empty array of reassign pair if no reassign items are found
*       b. Returns array of reassign pair with matching reassign/reassigned update item from single depth array
*       c. Returns array of reassign pair with matching reassign/reassigned update item from Multi depth array
*       d. Returns array of reassign pair for only to those, whose matching reassign, reassigned or reassigned update pair(as applicable) exists
*
* JSON files used:
*   1. cs-lib-composition\test\data\InvalidReassignRequest.json
*   2. cs-lib-composition\test\data\MultiDepthOrderCandidaterequest.json
*   3. cs-lib-composition\test\data\SingleDepthOrderCandidaterequest.json
*   4. cs-lib-composition\test\data\SingleDepthReassignedUpdateRequest.json
*   5. cs-lib-composition\test\data\ValidOrderCandidaterequest.json
*/
describe("ReassignPairBuilder", function () {
    describe("When making a call to BuildReassignPair", function () {
        it("Should return a valid reassignpair when invoked with valid reassign item and matching reassignedItem", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateValidOrderCandidate();
            var reassignOrderItem = orderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0];
            var reassignedOrderItem = orderCandidate.OrderItems[0].ChildOrderItems[1].ChildOrderItems[0];
            // Build the reassign pair
            var reassignPair = ReassignPairsBuilder.BuildReassignPair(reassignOrderItem, reassignedOrderItem);
            chai.expect(reassignPair).not.to.be.null;
            AssertReassignPair(reassignPair, reassignOrderItem.EntityID, reassignOrderItem.PortfolioItemID, reassignOrderItem, reassignedOrderItem);
            done();
        });
    });
    describe('When making a call to FindReassignPair', function () {
        it('Should return a reassign pair from an array of reassign pairs, which matches with a given entity id', function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateSingleDepthReassignedItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPairs = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            chai.expect(reassignPairs.length).equal(2);
            // Find Reassign Pairs
            var reassignpair_1 = ReassignPairsBuilder.FindReassignPair(reassignPairs, "0ddea1ee-03c5-4077-be88-339df94b3546");
            AssertReassignPair(reassignpair_1, "0ddea1ee-03c5-4077-be88-339df94b3546", "Package1", orderCandidate.OrderItems[0].ChildOrderItems[0], orderCandidate.OrderItems[1].ChildOrderItems[0]);
            var reassignpair_2 = ReassignPairsBuilder.FindReassignPair(reassignPairs, "0ddea1ee-03c5-4077-be88-339df94b3123");
            AssertReassignPair(reassignpair_2, "0ddea1ee-03c5-4077-be88-339df94b3123", "Component1", orderCandidate.OrderItems[0].ChildOrderItems[1], orderCandidate.OrderItems[1].ChildOrderItems[1]);
            done();
        });
        it("Should return a undefined, reassign pair for the given entity id is not found in an array of reassign pairs", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateSingleDepthReassignedItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPairs = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            chai.expect(reassignPairs.length).equal(2);
            var reassignpair_1 = ReassignPairsBuilder.FindReassignPair(reassignPairs, "0ddea1ee-03c5-4077-be88-339df94b3400");
            chai.expect(reassignpair_1).to.be.undefined;
            var reassignpair_2 = ReassignPairsBuilder.FindReassignPair(reassignPairs, "ba362cfb-4600-4b50-9024-21ef9681d259");
            chai.expect(reassignpair_2).to.be.undefined;
            done();
        });
    });
    describe("When making a call to BuildReassignPairs", function () {
        it('Should return a Empty reassignpair when invoked with no reassign and matching reassigned items', function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateNoReassignOrderCandidate();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPair = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            // Verify the results
            chai.expect(reassignPair).to.be.empty;
            done();
        });
        it("Should return an array of ReassignPair when invoked with array of order items with matching reassign and reassigned items", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateSingleDepthReassignedItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPair = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            chai.expect(reassignPair.length).equal(2);
            AssertReassignPair(reassignPair[0], "0ddea1ee-03c5-4077-be88-339df94b3546", "Package1", orderCandidate.OrderItems[0].ChildOrderItems[0], orderCandidate.OrderItems[1].ChildOrderItems[0]);
            AssertReassignPair(reassignPair[1], "0ddea1ee-03c5-4077-be88-339df94b3123", "Component1", orderCandidate.OrderItems[0].ChildOrderItems[1], orderCandidate.OrderItems[1].ChildOrderItems[1]);
            done();
        });
        it("Should return an array of ReassignPair when invoked with array of order items with matching reassign and reassignedUpdate items", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateSingleDepthReassignedUpdateItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPair = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            chai.expect(reassignPair.length).equal(2);
            AssertReassignPair(reassignPair[0], "0ddea1ee-03c5-4077-be88-339df94b3546", "Package1", orderCandidate.OrderItems[0].ChildOrderItems[0], orderCandidate.OrderItems[1].ChildOrderItems[0]);
            AssertReassignPair(reassignPair[1], "0ddea1ee-03c5-4077-be88-339df94b3123", "Component1", orderCandidate.OrderItems[0].ChildOrderItems[1], orderCandidate.OrderItems[1].ChildOrderItems[1]);
            done();
        });
        it("Should return a valid array of reassignPair containing all child items when invoked with multidepth array of orderitems with matching reassign and reassigned item", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateMultiDepthReassignedItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPair = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            // Verify the results
            chai.expect(reassignPair).not.to.be.empty;
            chai.expect(reassignPair.length).to.equal(3);
            AssertReassignPair(reassignPair[0], "k12d0778-9d0c-4e84-8caa-60db61007klb", "Handset_Package", orderCandidate.OrderItems[0].ChildOrderItems[0], orderCandidate.OrderItems[1].ChildOrderItems[0]);
            AssertReassignPair(reassignPair[1], "c100d0778-9d0c-4e84-8caa-60db61007c01", "Component1", orderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0], orderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0]);
            AssertReassignPair(reassignPair[2], "c100d0778-9d0c-4e84-8caa-60db61007c02", "Component2", orderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[1], orderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[1]);
            done();
        });
        it("Should return an reassignPair array which shouldnt have a entry of reassign/reassigned/reassignedupdate item without a matching pair", function (done) {
            // Creating Order Candidate
            var orderCandidate = CreateInvalidReassignItems();
            // Create ReassignPairBuilder and build the reassign pair
            var reassignPairBuilder = new ReassignPairsBuilder();
            var reassignPair = reassignPairBuilder.BuildReassignPairs(orderCandidate.OrderItems).ReassignPairs;
            chai.expect(reassignPair.length).equal(2);
            AssertReassignPair(reassignPair[0], "ba362cfb-4600-4b50-9024-21ef9681d259", "Package1", orderCandidate.OrderItems[0], orderCandidate.OrderItems[1]);
            AssertReassignPair(reassignPair[1], "e3129ce1-af0f-41e4-9e38-146641ef4e31", "Comp2", orderCandidate.OrderItems[0].ChildOrderItems[1], orderCandidate.OrderItems[1].ChildOrderItems[1]);
            done();
        });
    });
});
/**
* This Function Creates Valid Order Candidate request i.e it has both Reassign and reassigned items
*
* Order Candidate structure:
    existing:    pi_1_Bundle -->  cpi_1_Silver_Package -->cpi_2_Reassignable_Item
                    (update)          (delete)                (reassign)
    new:    pi_1_Bundle -->  cpi_1_Gold_Package->|-->cpi_4_Reassignable_Item
                (update)          (add)          |     (reassigned)
                                                 |-->coi_6_ NonReassignable_Item_Gold-->  coi_7_Content_Item_CFS2
                                                   (add)                                 (add)
*/
function CreateValidOrderCandidate() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/ValidOrderCandidaterequest.json");
}
/**
* Function to Create OrderItem with no reassign and reassigned item
*
* Order Candidate structure:
    existing:    pi_1_Bundle -->  cpi_1_Silver_Package -->cpi_2_Reassignable_Item
                    (update)          (delete)                           (delete)
    new:    pi_1_Bundle -->  cpi_1_Gold_Package->|-->cpi_4_Reassignable_Item
                (update)          (add)          |     (add)
                                                 |-->coi_6_ NonReassignable_Item_Gold-->  coi_7_Content_Item_CFS2
                                                   (add)                                 (add)
*/
function CreateNoReassignOrderCandidate() {
    // Take valid request and modify it to the desired one.
    var orderCandidate = CreateValidOrderCandidate();
    var reassignItem = orderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0];
    // Changing the reassign item into delete item
    reassignItem.ItemAction = "delete";
    var reassignedItem = orderCandidate.OrderItems[0].ChildOrderItems[1].ChildOrderItems[0];
    // Changing the reassigned item into add item
    reassignedItem.ItemAction = "add";
    // In crux, whole silver package has to be replaced with Gold package
    return orderCandidate;
}
/**
* Function to Create single depth matching reassign and reassigned order items
*
* Order Candidate structure:
    existing:    pi_1_Bundle --> |--> Package1
                    (delete)      |    (reassign)
                                  |--> Component1
                                  |    (reassign)
                                  |--> component2 (delete)
                  pi_2_Bundle --> |--> Package1
                  (add)           |    (reassigned)
                                  |--> Component1
                                  |    (reassigned)
                                  |--> component3 (add)   */
function CreateSingleDepthReassignedItems() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/SingleDepthOrderCandidaterequest.json");
}
/**
* Function to Create single depth matching reassign and reassigned update order items
*
* OrderItem structure:
    existing:    pi_1_Bundle --> |--> Package1
                    (delete)      |    (reassign)
                                  |--> Component1
                                  |    (reassign)
                                  |--> component2 (delete)
                  pi_2_Bundle --> |--> Package1    -->       packagechild1
                  (add)           |    (reassignedupdate)     (add)
                                  |--> Component1 -->        childcomponent1
                                  |    (reassignedupdate)       (add)
                                  |--> component3 (add)
*/
function CreateSingleDepthReassignedUpdateItems() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/SingleDepthReassignedUpdateRequest.json");
}
/**
* Creates Multidepth array of order items with matching reassign and reassigned/reassignedupdate items
*
* OrderItems structure:
    existing  Mobile_Bundle -> Handset_Package|-->  Component1
            (update)            (reassign)   |       (reassign)
                                             |->   Component2
                                                    (reassign)
    new:     Mobile_Bundle -> NewHandset_Package|-->  Component1 --> Child_Component1
            (update)     (reassignUpdate)   |    (reassignupdate)  (add)
                                            |-->   Component3
                                            |      (reassigned)
                                            |-->   Component4
                                                    (add)
*/
function CreateMultiDepthReassignedItems() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/MultiDepthOrderCandidaterequest.json");
}
/**
* Function to create order item without a matching reassign/reassigned/reassignedupdate items.
*
* OrderItem structure:
    existing:   Package1 -> |--> comp1 (reassign) //no matching pair
                (reassign)   |--> comp2 (reassign)
                             |--> comp3 (nochange)
                 Package1 -> |--> comp4 (add)
                (reassigned) |--> comp2 (reassigned) //Only 1 matching pair
                             |--> comp5 (reassigned)  //no matching pair
                             |--> comp6(reassignedupdate) //no matching pair
*/
function CreateInvalidReassignItems() {
    return GetOrderCandidateFromFile("cs-lib-composition/test/data/InvalidReassignRequest.json");
}
/**
* Builds an ordercandidate from a JSON file.
* @param {string} filePath
* @returns {OrderCandidate}
*/
function GetOrderCandidateFromFile(filePath) {
    var orderCandidateRaw = fs.readFileSync(filePath, { encoding: 'utf8' });
    var orderCandidateArray = Utilities.asArray(JSON.parse(orderCandidateRaw.toString()));
    chai.expect(orderCandidateArray).not.to.be.null;
    chai.expect(orderCandidateArray.length).to.be.greaterThan(0);
    return new OrderCandidate(orderCandidateArray[0]);
}
/**
* Asserts to see if reassign and reassigned/reassignedupdate order items has same Entity ID
*/
function AssertEntityId(reassign, reassigned) {
    chai.expect(reassign.EntityID).to.equal(reassigned.EntityID);
}
/**
* Function validates the given ReassignPair against the inputs also checks whether reassign and reassigned has same entityID
*/
function AssertReassignPair(reassignPair, EntityId, portfolioID, reassign, reassigned) {
    AssertEntityId(reassign, reassigned);
    chai.expect(reassignPair.EntityID).equal(EntityId);
    chai.expect(reassignPair.PortfolioItemID).equal(portfolioID);
    chai.expect(reassignPair.ReassignItem).equal(reassign);
    chai.expect(reassignPair.ReassignedItem).equal(reassigned);
}

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var ReassignCandidateHydrator = require("../ReassignCandidateHydrator");
var OrderCandidateRequest = require("../../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderItem = require("../../cs-lib-types/BusinessEntities/OrderItem");
/**
* Functionality Under Test:
*  HydrateOrderCandidate function of ReassignCandidateHydrator class
*
* Scenarios Covered:
*     For the Portfolio which has Great GrandParent,GrandParent, Parent and Child hierarchy:
*        a. Inclusion of Parent and its child component when GrandParent is marked for reassign
*        b. Addition of Parent and its Child component as reassigned item when only Parent is marked for reassign
*        c. Addition of Parent and its Child component as reassign item when only Parent is marked for reassigned
*
* JSON files used:
*  1. cs-lib-composition\test\data\ReassignCandidateHydratorTests_4level.json
*
*/
describe('ReassignCandidateHydrator', function () {
    describe('When making a call to HydrateOrderCandidate for GreatGrandParent-GrandParent-Parent-Child Portfolio ', function () {
        var orderCandidateRequest;
        var hydratedCandidateRequest;
        var reassignHydrator = new ReassignCandidateHydrator(null);
        it('Should return Order candidate with an addition of missing Parent and its child component with appropriate reassign state', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGGPC_GrandparentReassign();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GreatGrandParentA-> GrandParentA -> Parent ->Child
                          Order candidate: GreatGrandParentA(delete)->GrandParentA(reassign)
                                          GreatGrandParentA(add)->GrandParentA(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            // Confirming the order Candidate as per expectation.
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems.length).equal(2);
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0], "776aae58-c95d-424b-b60a-2b184c4f5563", "GreatGrandParentA", "delete");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassign");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1], "80a6a7fa-5cff-464b-89b1-f54f71198398", "GreatGrandParentB", "add");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassigned");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            // Call hydrator function
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Check portfolio items: No changes expected
            ValidatePortfolioItems(hydratedCandidateRequest);
            // Check Order Candidate items: Parent and Child should be under GreatGrandParentA and GreatGrandParentB
            ValidateResultantOrderCandiadate(hydratedCandidateRequest);
            done();
        });
        it('Should return Order candidate with an addition of missing Reassigned Parent item along with Child Item', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGGPC_MissingReassignedParent();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GreatGrandParentA-> GrandParentA -> Parent ->Child
                          Order candidate: GreatGrandParentA(delete)->GrandParentA(reassign)->Parent(reassign)
                                          GreatGrandParentA(add)->GrandParentA(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            //Confirming the order Candidate as per expectation.
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems.length).equal(2);
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0], "776aae58-c95d-424b-b60a-2b184c4f5563", "GreatGrandParentA", "delete");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassign");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0], "fac5d074-bdee-4cc4-8db5-417180410bd4", "Parent", "reassign");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1], "80a6a7fa-5cff-464b-89b1-f54f71198398", "GreatGrandParentB", "add");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassigned");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            //Check portfolio items: No changes expected
            ValidatePortfolioItems(hydratedCandidateRequest);
            //Check Order Candidate items: Parent and Child should be under GreatGrandParentA and GreatGrandParentB
            ValidateResultantOrderCandiadate(hydratedCandidateRequest);
            done();
        });
        it('Should return Order candidate with an addition of missing Reassign Parent item along with Child item', function (done) {
            // Creating Order Candidate request
            orderCandidateRequest = CreateGGPC_MissingReassignParent();
            // Vaidating the input Order candidate request
            /* Expecting: Portfolio: GreatGrandParentA-> GrandParentA -> Parent ->Child
                         Order candidate: GreatGrandParentA(delete)->GrandParentA(reassign)
                                          GreatGrandParentA(add)->GrandParentA(reassigned)->Parent(reassigned) */
            ValidatePortfolioItems(orderCandidateRequest);
            // Confirming the order Candidate as per expectation.
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems.length).equal(2);
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0], "776aae58-c95d-424b-b60a-2b184c4f5563", "GreatGrandParentA", "delete");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassign");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1], "80a6a7fa-5cff-464b-89b1-f54f71198398", "GreatGrandParentB", "add");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0], "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassigned");
            AssertOrderItems(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0], "fac5d074-bdee-4cc4-8db5-417180410bd4", "Parent", "reassigned");
            chai.expect(orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].ChildOrderItems).to.be.empty;
            // Call hydrator function
            hydratedCandidateRequest = reassignHydrator.HydrateOrderCandidate(orderCandidateRequest);
            // Check portfolio items: No changes expected
            ValidatePortfolioItems(hydratedCandidateRequest);
            // Check Order Candidate items: Parent and Child should be under GreatGrandParentA and GreatGrandParentB
            ValidateResultantOrderCandiadate(hydratedCandidateRequest);
            done();
        });
    });
});
/**
* OrderItem is validated against given entityID, portfolioID and ItemAction
* @param {OrderItem} Order Item
*        {string} EntityID
*        {string} PortfolioID
*        {string} ItemAction
*/
function AssertOrderItems(orderItem, entityID, portfolioID, itemAction) {
    chai.expect(orderItem.EntityID).equal(entityID);
    chai.expect(orderItem.PortfolioItemID).equal(portfolioID);
    chai.expect(orderItem.ItemAction).equal(itemAction);
}
/**
* PortfolioItem is validated against given ID and entityID
* @param {PortfolioItem} portfolio item
*        {string} EntityID
*/
function AssertPortfolioItem(portfolio, ID, entityID) {
    chai.expect(portfolio.EntityID).equal(entityID);
    chai.expect(portfolio.ID).equal(ID);
}
/**
* Creates Order candiate request as shown below
* OrderCandidateRequest->|--> CustomerPortfolio->PortfolioItems->GreatGrandParentA
                           |                                        |->GrandParentA
                           |                                            |->Parent
                           |                                                |->Child
                           |->OrderCandidate->OrderItems|-> GreatGrandParentA(delete)
                                                        |    |->GrandParentA(reassign)
                                                        |-> GreatGrandParentB(add)
                                                            |->GrandParentA(reassigned)
*/
function CreateGGPC_GrandparentReassign() {
    // read from JSON file and create Order candidate request
    var orderCandidateRaw = fs.readFileSync('cs-lib-composition/test/data/ReassignCandidateHydratorTests_4level.json', { encoding: 'utf8' });
    var orderCandidateArray = Utilities.asArray(JSON.parse(orderCandidateRaw.toString()));
    chai.expect(orderCandidateArray).not.to.be.null;
    chai.expect(orderCandidateArray.length).to.be.greaterThan(0);
    return new OrderCandidateRequest(orderCandidateArray[0]);
}
/**
* Creates Order candiate request as shown below
* OrderCandidateRequest->|--> CustomerPortfolio->PortfolioItems->GreatGrandParentA
                           |                                        |->GrandParentA
                           |                                            |->Parent
                           |                                                |->Child
                           |--> OrderCandidate->OrderItems|-> GreatGrandParentA(delete)
                                                          |    |->GrandParentA(reassign)
                                                          |       |->Parent(reassign)
                                                          |-> GreatGrandParentB(add)
                                                              |->GrandParentA(reassigned)
*/
function CreateGGPC_MissingReassignedParent() {
    var orderCandidateRequest = CreateGGPC_GrandparentReassign();
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0] = new OrderItem();
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].ID = "Parent_ReassignOrder";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].PortfolioItemID = "Parent";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].EntityID = "fac5d074-bdee-4cc4-8db5-417180410bd4";
    orderCandidateRequest.OrderCandidate.OrderItems[0].ChildOrderItems[0].ChildOrderItems[0].ItemAction = "reassign";
    return orderCandidateRequest;
}
/**
* Creates Order candiate request as shown below
* OrderCandidateRequest->|--> CustomerPortfolio->PortfolioItems->GreatGrandParentA
                           |                                        |->GrandParentA
                           |                                            |->Parent
                           |                                                |->Child
                           |--> OrderCandidate->OrderItems|-> GreatGrandParentA(delete)
                                                          |    |->GrandParentA(reassign)
                                                          |-> GreatGrandParentB(add)
                                                              |->GrandParentA(reassigned)
                                                                |->Parent(reassigned)
*/
function CreateGGPC_MissingReassignParent() {
    var orderCandidateRequest = CreateGGPC_GrandparentReassign();
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0] = new OrderItem();
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].ID = "Parent_ReassignedOrder";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].PortfolioItemID = "Parent";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].EntityID = "fac5d074-bdee-4cc4-8db5-417180410bd4";
    orderCandidateRequest.OrderCandidate.OrderItems[1].ChildOrderItems[0].ChildOrderItems[0].ItemAction = "reassigned";
    return orderCandidateRequest;
}
/**
* Function checks whether given Portfolio item has same data as of Source.
* All 3 test cases expects same Portfolio items hence it is grouped under this function.
* @param {orderCandidateRequest} Order candidate request
*/
function ValidatePortfolioItems(orderCandidateRequest) {
    var ggParentA = orderCandidateRequest.CustomerPortfolio.PortfolioItems[0];
    var gParentA = ggParentA.ChildEntities[0];
    var ParentA = gParentA.ChildEntities[0];
    var Child = ParentA.ChildEntities[0];
    chai.expect(orderCandidateRequest.CustomerPortfolio.PortfolioItems.length).equal(1);
    AssertPortfolioItem(ggParentA, "GreatGrandParentA", "776aae58-c95d-424b-b60a-2b184c4f5563");
    AssertPortfolioItem(gParentA, "GrandParentA", "d047041c-57ea-4b78-ac3c-a657b58018ff");
    AssertPortfolioItem(ParentA, "Parent", "fac5d074-bdee-4cc4-8db5-417180410bd4");
    AssertPortfolioItem(Child, "Child", "ae9e76ca-987f-4e2b-8287-586325de155a");
    chai.expect(Child.ChildEntities).to.be.empty;
}
/**
* Function checks whether given OrderCandidate item has full data with all reassigned states.
* All 3 test cases expects same output hence it is grouped under this function.
* @param {orderCandidateRequest} Order candidate request
*/
function ValidateResultantOrderCandiadate(orderCandidateRequest) {
    var ggParentA_order = orderCandidateRequest.OrderCandidate.OrderItems[0];
    var gParentA_Order = ggParentA_order.ChildOrderItems[0];
    var parent_order = gParentA_Order.ChildOrderItems[0];
    var child_order = parent_order.ChildOrderItems[0];
    chai.expect(orderCandidateRequest.OrderCandidate.OrderItems.length).equal(2);
    AssertOrderItems(ggParentA_order, "776aae58-c95d-424b-b60a-2b184c4f5563", "GreatGrandParentA", "delete");
    AssertOrderItems(gParentA_Order, "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassign");
    AssertOrderItems(parent_order, "fac5d074-bdee-4cc4-8db5-417180410bd4", "Parent", "reassign");
    AssertOrderItems(child_order, "ae9e76ca-987f-4e2b-8287-586325de155a", "Child", "reassign");
    chai.expect(child_order.ChildOrderItems).to.be.empty;
    var ggParentB_rorder = orderCandidateRequest.OrderCandidate.OrderItems[1];
    var gParentA_rOrder = ggParentB_rorder.ChildOrderItems[0];
    var parent_rorder = gParentA_rOrder.ChildOrderItems[0];
    var child_rorder = parent_rorder.ChildOrderItems[0];
    AssertOrderItems(ggParentB_rorder, "80a6a7fa-5cff-464b-89b1-f54f71198398", "GreatGrandParentB", "add");
    AssertOrderItems(gParentA_rOrder, "d047041c-57ea-4b78-ac3c-a657b58018ff", "GrandParentA", "reassigned");
    AssertOrderItems(parent_rorder, "fac5d074-bdee-4cc4-8db5-417180410bd4", "Parent", "reassigned");
    AssertOrderItems(child_rorder, "ae9e76ca-987f-4e2b-8287-586325de155a", "Child", "reassigned");
    chai.expect(child_rorder.ChildOrderItems).to.be.empty;
}

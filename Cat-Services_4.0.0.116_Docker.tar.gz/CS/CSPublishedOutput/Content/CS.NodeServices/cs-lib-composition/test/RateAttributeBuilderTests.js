"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var RateAttributeBuilder = require("../RateAttributeBuilder");
var chai = require("chai");
var fs = require("fs");
describe("RateAttributeBuilder.CombineRatingAttributes()", function () {
    var errorContext;
    var rateAttributeBuilder;
    beforeEach(function (done) {
        errorContext = new CsErrorContext({});
        rateAttributeBuilder = new RateAttributeBuilder(errorContext, "requestId");
        done();
    });
    var orderfolioItem = {
        "CompoundKey": {
            "Key": "1",
            "Index": 0
        },
        "EntityId": "0b54a44f-e358-434a-8196-12b83ed55a0f",
        "EntityUniqueCode": "oi_1",
        "PortfolioItemId": "ID_fugsflsu9k",
        "OrderItemId": "oi_1",
        "OrderItemSource": "cpq",
        "PortfolioItemSource": "cpq",
        "Action": "add",
        "CharacteristicUses": [],
        "UserDefinedCharacteristics": [],
        "RatingAttributes": [],
        "HasTechnicalChildrenInSpec": false,
        "IsInvalid": false,
        "IsAdditionalCharge": false,
        "IsExcludedCharge": false,
        "IsExcludedCost": false,
        "IsExcludedDiscount": false,
        "ItemAdded": true
    };
    it("Scenario 1: Empty Portfolio, RA added in order, should return 1 RA marked Add", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario1.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(1);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("AddMissing");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(0);
            done();
        });
    });
    it("Scenario 2: Empty Portfolio, RA add & delete in order, should raise validation error", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario2.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "Update";
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(2);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("AddMissing");
            chai.expect(result[1].Name).to.equal("Technology_Type");
            chai.expect(result[1].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[1].Action).to.equal("DeleteMissing");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(1);
            chai.expect(validationErrors[0].ErrorCode).to.equal("InvalidRatingAttributes");
            done();
        });
    });
    it("Scenario 3: RA exists in portfolio, Empty Order, should return 1 RA and action of Skip", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario3.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "Update";
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(1);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("SkipExisting");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(0);
            done();
        });
    });
    it("Scenario 4: RA exists in portfolio, Order Adds matching RA, should return 1 Add and NOT raise validation error", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario4.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "update";
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(1);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("SkipExisting");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(0);
            done();
        });
    });
    it("Scenario 5: RA exists in portfolio, Order Adds different RA with the same name, should return 1 Add & 1 Delete and raise validation error", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario5.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "update";
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(2);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("692017a7-c746-422e-99ea-e80c6afdfc3d");
            chai.expect(result[0].Action).to.equal("AddMissing");
            chai.expect(result[1].Name).to.equal("Technology_Type");
            chai.expect(result[1].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[1].Action).to.equal("SkipExisting");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(1);
            chai.expect(validationErrors[0].ErrorCode).to.equal("InvalidRatingAttributes");
            done();
        });
    });
    it("Scenario 6: RA y exists in portfolio, Order Adds RA x and Deletes RA y, should return 1 Add & 1 Delete", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario6.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "update";
            var errorContext = new CsErrorContext({});
            var rateAttributeBuilder = new RateAttributeBuilder(errorContext, "requestId");
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(2);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("692017a7-c746-422e-99ea-e80c6afdfc3d");
            chai.expect(result[0].Action).to.equal("AddMissing");
            chai.expect(result[1].Name).to.equal("Technology_Type");
            chai.expect(result[1].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[1].Action).to.equal("DeleteExisting");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(0);
            done();
        });
    });
    it("Scenario 7: Empty portfolio, Order Adds 2 identical RAs, should return 1 Add", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario7.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "update";
            var errorContext = new CsErrorContext({});
            var rateAttributeBuilder = new RateAttributeBuilder(errorContext, "requestId");
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(2);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("AddMissing");
            chai.expect(result[1].Name).to.equal("Technology_Type");
            chai.expect(result[1].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[1].Action).to.equal("AddMissing");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(1);
            chai.expect(validationErrors[0].ErrorCode).to.equal("InvalidRatingAttributes");
            done();
        });
    });
    it("Scenario 8: Empty portfolio, Order Adds 2 RAs, same name different value, should return 2 Adds & raise validation error", function (done) {
        fs.readFile('cs-lib-composition/test/data/RateAttributeBuilder/Scenario8.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
            var itemPair = JSON.parse(itemPairFileContents);
            orderfolioItem.Action = "update";
            var errorContext = new CsErrorContext({});
            var rateAttributeBuilder = new RateAttributeBuilder(errorContext, "requestId");
            var result = rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
            chai.expect(result.length).to.equal(2);
            chai.expect(result[0].Name).to.equal("Technology_Type");
            chai.expect(result[0].Value).to.equal("ccec8dcc-6d06-48b3-9794-b01dde354b61");
            chai.expect(result[0].Action).to.equal("AddMissing");
            chai.expect(result[1].Name).to.equal("Technology_Type");
            chai.expect(result[1].Value).to.equal("692017a7-c746-422e-99ea-e80c6afdfc3d");
            chai.expect(result[1].Action).to.equal("AddMissing");
            var validationErrors = errorContext.GetValidationErrorsForResponse();
            chai.expect(validationErrors.length).to.equal(1);
            chai.expect(validationErrors[0].ErrorCode).to.equal("InvalidRatingAttributes");
            done();
        });
    });
});

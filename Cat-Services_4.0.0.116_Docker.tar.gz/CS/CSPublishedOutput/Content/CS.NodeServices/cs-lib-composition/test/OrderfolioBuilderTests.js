"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var MergedActions = require("../../cs-lib-constants/MergedActions");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var OrderfolioBuilder = require("../OrderfolioBuilder");
var chai = require("chai");
var fs = require("fs");
describe("when asking the orderfolio builder to build an orderfolio for 2 item pairs that share the same entityID", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should create 2 orderfolio indexes, index 0 should contain 1 item of ID 'x' and index 1 should contain 2 items of ID 'y'", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/ItemPairWithMutliChildrenWithSameEntityId.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0].length).to.equal(1);
                chai.expect(orderfolio[1].length).to.equal(2);
                done();
            });
        });
    });
});
describe("When deleting a parent with children existing in the portfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("Should cascade the deletes down to the children when building the orderfolio", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/ItemPairWithCascadingDelete.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0].length).to.equal(1);
                chai.expect(orderfolio[1].length).to.equal(2);
                // Parent
                chai.expect(orderfolio[0][0].Action).to.equal(OrderActions.Delete);
                // Children
                chai.expect(orderfolio[1][0].Action).to.equal(OrderActions.Delete);
                chai.expect(orderfolio[1][1].Action).to.equal(OrderActions.Delete);
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should normalize the characteristic uses from each portfolio items / order item correctly (Add Characteristics)", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/CharacteristicsAdd.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                var charUseToAssert = GetFromCollection(orderfolio[0][0].CharacteristicUses, 'UseId', 'AAAA');
                var valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Red');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.AddExisting);
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Blue');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.AddMissing);
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should pass through the value detail on the characteristic values", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/CharacteristicsAdd.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                // Characteristic use
                var charUseToAssert = GetFromCollection(orderfolio[0][0].CharacteristicUses, 'UseId', 'AAAA');
                var valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Red');
                chai.expect(valueToAssert.ValueDetail).to.equal("RedDetail");
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Blue');
                chai.expect(valueToAssert.ValueDetail).to.equal("BlueDetail");
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Green');
                chai.expect(valueToAssert.ValueDetail).to.equal("GreenDetail");
                // User defined characteristic
                var udcToAssert = GetFromCollection(orderfolio[0][0].UserDefinedCharacteristics, 'UseId', 'BBBB');
                var udcValueToAssert = GetFromCollection(udcToAssert.Values, 'Value', '01443 444444');
                chai.expect(udcValueToAssert.ValueDetail).to.equal("PhoneNumberDetail");
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should normalize the characteristic uses from each portfolio items / order item correctly (Delete Characteristics)", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/CharacteristicsDelete.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                var charUseToAssert = GetFromCollection(orderfolio[0][0].CharacteristicUses, 'UseId', 'AAAA');
                var valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Red');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.DeleteExisting);
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', 'Green');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.DeleteMissing);
                charUseToAssert = GetFromCollection(orderfolio[0][0].UserDefinedCharacteristics, 'UseId', 'BBBB');
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', '01443 444444');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.DeleteExisting);
                valueToAssert = GetFromCollection(charUseToAssert.Values, 'Value', '07888444444');
                chai.expect(valueToAssert.Action).to.equal(MergedActions.DeleteMissing);
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should normalize the characteristic uses from each portfolio items / order item correctly", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/CharacteristicNormalization.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0][0].CharacteristicUses.length).to.equal(1);
                var charUseToAssert = GetFromCollection(orderfolio[0][0].CharacteristicUses, 'UseId', 'AAAA');
                chai.expect(charUseToAssert.Values.length).to.equal(4);
                charUseToAssert = GetFromCollection(orderfolio[0][0].UserDefinedCharacteristics, 'UseId', 'BBBB');
                chai.expect(charUseToAssert.Values.length).to.equal(2);
                chai.expect(orderfolio[0][0].UserDefinedCharacteristics.length).to.equal(1);
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should combine the rate attributes from each portfolio items / order item correctly", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/RateAttributesItemPair.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0][0].RatingAttributes.length).to.equal(2);
                chai.expect(orderfolio[0][0].RatingAttributes[0].Name).to.equal('Day');
                chai.expect(orderfolio[0][0].RatingAttributes[0].Value).to.equal('Wednesday');
                chai.expect(orderfolio[0][0].RatingAttributes[0].Action).to.equal(MergedActions.AddMissing);
                chai.expect(orderfolio[0][0].RatingAttributes[1].Name).to.equal('Day');
                chai.expect(orderfolio[0][0].RatingAttributes[1].Value).to.equal('Monday');
                chai.expect(orderfolio[0][0].RatingAttributes[1].Action).to.equal(MergedActions.SkipExisting);
                var validationErrors = errorContext.GetValidationErrorsForResponse();
                chai.expect(validationErrors.length).to.equal(1);
                chai.expect(validationErrors[0].ErrorCode).to.equal("InvalidRatingAttributes");
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio for 2 item pairs that share the same entityID, each having a child with the same EntityID", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should create 3 orderfolio indexes, orderfolio indexes, index 0 should contain 1 item (x), 1 should contain 2 items (y), 2 should contain 2 items (z)", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/MutliChildrenAndGrandchildrenSameEntityId.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0].length).to.equal(1);
                chai.expect(orderfolio[1].length).to.equal(2);
                chai.expect(orderfolio[2].length).to.equal(4);
                done();
            });
        });
    });
});
describe("when asking the orderfolio builder to build an orderfolio for a structure", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("should populate parent to child / child to parent table with the correct data", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/MutliChildrenAndGrandchildrenSameEntityId.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var parentToChildTable = decomposeContext.ParentToChildTable;
                var childToParentTable = decomposeContext.ChildToParentTable;
                //parent to child - number of children assertion
                chai.expect(parentToChildTable['0-0'].length).to.equal(2);
                //first child should exist under the same parent as the second child
                chai.expect(parentToChildTable['0-0'][0].Key).to.equal('1');
                chai.expect(parentToChildTable['0-0'][0].Index).to.equal(0);
                //first grandchild should exists under the first child
                chai.expect(parentToChildTable['1-0'][0].Key).to.equal('2');
                chai.expect(parentToChildTable['1-0'][0].Index).to.equal(0);
                //third grandchild should exist under the second child
                chai.expect(parentToChildTable['1-1'][0].Key).to.equal('2');
                chai.expect(parentToChildTable['1-1'][0].Index).to.equal(2);
                //second child should exist under the same parent as the first child
                chai.expect(parentToChildTable['0-0'][1].Key).to.equal('1');
                chai.expect(parentToChildTable['0-0'][1].Index).to.equal(1);
                //child to parent table length assertion
                chai.expect(Object.keys(childToParentTable).length).to.equal(6);
                //first child - should point at the same parent as the second child
                chai.expect(childToParentTable['1-0'].Key).to.equal('0');
                chai.expect(childToParentTable['1-0'].Index).to.equal(0);
                //second child - should point at same parent as first child
                chai.expect(childToParentTable['1-1'].Key).to.equal('0');
                chai.expect(childToParentTable['1-1'].Index).to.equal(0);
                //first grandchild - should point at the first child
                chai.expect(childToParentTable['2-0'].Key).to.equal('1');
                chai.expect(childToParentTable['2-0'].Index).to.equal(0);
                //second grandchild - should point at the second child
                chai.expect(childToParentTable['2-1'].Key).to.equal('1');
                chai.expect(childToParentTable['2-1'].Index).to.equal(0);
                //fourth grandchild - should point at the second child
                chai.expect(childToParentTable['2-3'].Key).to.equal('1');
                chai.expect(childToParentTable['2-3'].Index).to.equal(1);
                done();
            });
        });
    });
});
describe("When the orderfolio creates/adds orderfolio items to an array for a given orderfolio index", function () {
    var errorContext = new CsErrorContext({});
    var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
    var itemPair;
    var decomposeContext;
    it("the compound key on those OFI should corresponds to its index in the array", function (done) {
        fs.readFile('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
            decomposeContext = JSON.parse(decomposeContextFileContents);
            fs.readFile('cs-lib-composition/test/data/MutliChildrenAndGrandchildrenSameEntityId.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                itemPair = JSON.parse(itemPairFileContents);
                orderfolioBuilder.Build(itemPair, decomposeContext);
                var orderfolio = decomposeContext.Orderfolio;
                chai.expect(orderfolio[0].length).to.equal(1);
                for (var uuid in orderfolio) {
                    for (var c = 0; c < orderfolio[uuid].length; c++) {
                        chai.expect(orderfolio[uuid][c].CompoundKey.Index).to.equal(c);
                    }
                }
                done();
            });
        });
    });
});
describe("Given a product candidate", function () {
    var productCandidateRequest = JSON.parse(fs.readFileSync('cs-lib-composition/test/data/ProductCandidateRequest.json', { encoding: 'utf8' }));
    var decomposeContext = JSON.parse(fs.readFileSync('cs-lib-composition/test/data/DecomposeContext.json', { encoding: 'utf8' }));
    describe("When building an orderfolio", function () {
        var errorContext = new CsErrorContext({});
        var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
        it("should have actions of update on the root and add on the child entities", function () {
            orderfolioBuilder.BuildFromProductCandidate(productCandidateRequest.ProductCandidate, decomposeContext);
            var orderfolio = decomposeContext.Orderfolio;
            // Existence
            chai.expect(orderfolio[0].length).to.equal(1);
            chai.expect(orderfolio[1].length).to.equal(1);
            chai.expect(orderfolio[2]).to.be.undefined;
            // Actions
            chai.expect(orderfolio[0][0].Action).to.equal('update');
            chai.expect(orderfolio[1][0].Action).to.equal('add');
            // Characteristics
            chai.expect(orderfolio[0][0].CharacteristicUses[0].Action).to.equal('modify');
            chai.expect(orderfolio[0][0].CharacteristicUses[0].Values[0].Action).to.equal('AddMissing');
            chai.expect(orderfolio[0][0].UserDefinedCharacteristics[0].Action).to.equal('modify');
            chai.expect(orderfolio[0][0].UserDefinedCharacteristics[0].Values[0].Action).to.equal('AddMissing');
        });
    });
});
describe("Given an OrderCandidate", function () {
    var itemPair = JSON.parse(fs.readFileSync('cs-lib-composition/test/data/S03905/EndDatedParent.json', { encoding: 'utf8' }));
    var decomposeContext = JSON.parse(fs.readFileSync('cs-lib-composition/test/data/S03905/DecomposeContext.json', { encoding: 'utf8' }));
    describe("When building an orderfolio with invalid items", function () {
        var errorContext = new CsErrorContext({});
        var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
        it("should stop building the orderfolio at the point an invalid item is hit and store the order and portfolio from the request", function () {
            orderfolioBuilder.Build(itemPair, decomposeContext, false);
            // Root Mobile Package
            var rootOrderfolioItems = decomposeContext.Orderfolio["1"];
            chai.expect(rootOrderfolioItems).to.not.be.undefined;
            chai.expect(rootOrderfolioItems.length).to.equal(1);
            var rootOrderfolioItem = rootOrderfolioItems[0];
            chai.expect(rootOrderfolioItem.EntityId).to.equal("30d27fc7-9d9b-4a66-8191-e587bd8fdfba");
            chai.expect(rootOrderfolioItem.IsInvalid).to.be.false;
            // Invalid Handset and therefore Mobile Data is invalid as well
            var invalidOrderfolioItems = decomposeContext.Orderfolio["2"];
            chai.expect(invalidOrderfolioItems).to.not.be.undefined;
            chai.expect(invalidOrderfolioItems.length).to.equal(1);
            var invalidOrderfolioItem = invalidOrderfolioItems[0];
            chai.expect(invalidOrderfolioItem.EntityId).to.equal("f1f532f7-e475-49e5-88fc-d95ffb08002f");
            chai.expect(invalidOrderfolioItem.IsInvalid).to.be.true;
            chai.expect(invalidOrderfolioItem.ItemPair).to.not.be.undefined;
            var invalidItemPair = invalidOrderfolioItem.ItemPair;
            chai.expect(invalidItemPair.OrderItem).to.not.be.undefined;
            chai.expect(invalidItemPair.OrderItem.EntityID).to.equal("f1f532f7-e475-49e5-88fc-d95ffb08002f");
            chai.expect(invalidItemPair.OrderItem.ChildOrderItems).to.not.be.undefined;
            chai.expect(invalidItemPair.OrderItem.ChildOrderItems.length).to.equal(1);
            chai.expect(invalidItemPair.OrderItem.ChildOrderItems[0].EntityID).to.equal("256f9569-bb91-40d8-b7ca-d9e375809c0a");
            chai.expect(invalidItemPair.PortfolioItem).to.not.be.undefined;
            chai.expect(invalidItemPair.PortfolioItem.EntityID).to.equal("f1f532f7-e475-49e5-88fc-d95ffb08002f");
            chai.expect(invalidItemPair.PortfolioItem.ChildEntities).to.not.be.undefined;
            chai.expect(invalidItemPair.PortfolioItem.ChildEntities.length).to.equal(1);
            chai.expect(invalidItemPair.PortfolioItem.ChildEntities[0].EntityID).to.equal("256f9569-bb91-40d8-b7ca-d9e375809c0a");
            // No orderfolio entry for Mobile Data
            chai.expect(decomposeContext.Orderfolio["3"]).to.be.undefined;
        });
    });
    // S-15128 Override rate Id and value
    describe("when asking the orderfolio builder to build an orderfolio", function () {
        var errorContext = new CsErrorContext({});
        var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
        var itemPair;
        var decomposeContext;
        it("should build rate details as part of the orderfolio", function (done) {
            fs.readFile('cs-lib-composition/test/data/TK-14623/decomposecontext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                decomposeContext = JSON.parse(decomposeContextFileContents);
                fs.readFile('cs-lib-composition/test/data/TK-14623/ratedetails.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                    itemPair = JSON.parse(itemPairFileContents);
                    orderfolioBuilder.Build(itemPair, decomposeContext);
                    var orderfolio = decomposeContext.Orderfolio;
                    var rateDetailToAssert = orderfolio[0][0].RateDetail;
                    chai.expect(rateDetailToAssert).to.not.be.undefined;
                    chai.expect(rateDetailToAssert.RateIdOverride).to.equal("abc");
                    chai.expect(rateDetailToAssert.ValueOverride).to.equal("123");
                    chai.expect(rateDetailToAssert.RateActivationDate).to.equal("01-Dec-2000");
                    done();
                });
            });
        });
    });
    describe("when asking the orderfolio builder to build an orderfolio", function () {
        var errorContext = new CsErrorContext({});
        var orderfolioBuilder = new OrderfolioBuilder(errorContext, "requestId");
        var itemPair;
        var decomposeContext;
        it("should only output Periodicity for valid charge types", function (done) {
            fs.readFile('cs-lib-composition/test/data/D-15924/decomposeContext.json', { encoding: 'utf8' }, function (error, decomposeContextFileContents) {
                decomposeContext = JSON.parse(decomposeContextFileContents);
                fs.readFile('cs-lib-composition/test/data/D-15924/itempair.json', { encoding: 'utf8' }, function (error, itemPairFileContents) {
                    itemPair = JSON.parse(itemPairFileContents);
                    orderfolioBuilder.Build(itemPair, decomposeContext);
                    var orderfolio = decomposeContext.Orderfolio;
                    var target = orderfolio[2][0];
                    chai.expect(target.Periodicity).to.be.undefined;
                    done();
                });
            });
        });
    });
});
/**
 * Gets a value from the supplied collection where the value has a given property with a given value
 * @param {Array<any>} collection the collection to get the value from
 * @param {string} propertyNameToMatch the property on the value that must contain a given value
 * @param {string} valueToMatch the value that the property must contain
 * @returns {any} the value from the collection
 */
function GetFromCollection(collection, propertyNameToMatch, valueToMatch) {
    for (var c = 0; c < collection.length; c++) {
        if (collection[c][propertyNameToMatch] === valueToMatch) {
            return collection[c];
        }
    }
}

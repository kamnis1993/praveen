"use strict";
var BadDataTypes = require("../../cs-lib-constants/BadDataTypes");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class that contains common methods used by the Compiled DAL
 */
var CompilerUtils = /** @class */ (function () {
    function CompilerUtils() {
    }
    /**
     * Returns the pathInfo for the root object of the supplied productEntity
     * @param {ProductEntity} productEntity the product entity to get the root pathInfo of
     * @param {Array<CsTypes.PathInfo>} paths the list of possible paths
     * @returns {CsTypes.PathInfo}
     */
    CompilerUtils.FindRootPath = function (productEntity, paths, errorContext) {
        var pathSet = LodashUtilities.Where(paths, { guids: productEntity.PathInfo });
        if (pathSet.length < 1) {
            errorContext.RaiseBadDataError(ErrorCode.BadData.MissingRootPath, productEntity.Element_Guid, BadDataTypes.MissingRequiredProperty);
            return undefined;
        }
        if (pathSet.length > 1) {
            errorContext.RaiseBadDataError(ErrorCode.BadData.AmbiguousRootPath, productEntity.Element_Guid, BadDataTypes.InvalidProperty);
            return undefined;
        }
        return LodashUtilities.First(pathSet);
    };
    /**
     * Find a Uuid for an entity by the business ID path
     * @param {string} base The base path from the parent to the entity we are looking for
     * @param {string} toFind The entity to look for
     * @param {Array<CsTypes.PathInfo>} paths The paths through the entity
     */
    CompilerUtils.FindUuidByBusinessId = function (base, toFind, paths, errorContext) {
        var matchFunction = function (path) { return path.businessIds; };
        return CompilerUtils.FindUuid(base, toFind, matchFunction, paths, errorContext);
    };
    /**
     * Finds the UUID for the path of an action
     * @param {string} toFind The path on the action
     * @param {(path: any) => string} matchValue The function that defines what property on the path to match on
     * @param {Array<CsTypes.PathInfo>} paths The paths through the entity
     * @returns {string}
     */
    CompilerUtils.FindUuid = function (base, toFind, matchValue, paths, errorContext, excludedPaths) {
        if (excludedPaths === void 0) { excludedPaths = []; }
        // turn the relative path into an absolute path
        var rootPathParts = matchValue(LodashUtilities.First(LodashUtilities.Where(paths, { uuid: base }))).split(',').slice(0, -1);
        var rootPath = rootPathParts.length > 0 ? rootPathParts.join(',') : '';
        var pathToFind = toFind.toLowerCase();
        if (rootPath.length > 0) {
            var toFindAppend = pathToFind.length > 0 ? ',' + pathToFind : '';
            pathToFind = rootPath.toLowerCase() + toFindAppend;
        }
        if (this.PathIsExcluded(pathToFind, excludedPaths)) {
            return undefined;
        }
        // hunt for the absolute path and return a UUID
        for (var pathIdx = 0; pathIdx < paths.length; pathIdx++) {
            var path = paths[pathIdx];
            var value = matchValue(path);
            if (Utilities.IsDefined(value)) {
                if (value.toLowerCase() === pathToFind) {
                    return path.uuid.toString();
                }
            }
        }
        var badDataContext = {
            BasePath: rootPath,
            PathToTarget: toFind
        };
        errorContext.RaiseBadDataError(ErrorCode.BadData.MissingEntityPath, undefined, BadDataTypes.MissingRequiredProperty, badDataContext);
        return undefined;
    };
    /**
    * Converts an ItemTarget to an array.
    * This compresses the data size to be handled more efficiently.
    * @param {CsTypes.ItemTarget} target The uncompressed ItemTarget object
    * @returns {any} A compressed ItemTarget array
    */
    CompilerUtils.SquashItemTarget = function (target) {
        return [
            target.Key,
            target.DecomposeContextIndex,
            target.UseFurtherScope,
            target.AutoCreateTriggerUuid,
            target.AutoCreateTriggerParentUuid
        ];
    };
    /**
    * Converts an array to ItemTarget.
    * This uncompresses the data to be more easily read and utilized in the code.
    * @param {any} array The compressed ItemTarget array
    * @returns {CsTypes.ItemTarget[]} An uncompressed ItemTarget object
    */
    CompilerUtils.UnsquashItemTarget = function (array) {
        var target = {
            Key: array[0],
            DecomposeContextIndex: array[1],
            UseFurtherScope: array[2],
            AutoCreateTriggerUuid: array[3],
            AutoCreateTriggerParentUuid: array[4]
        };
        return target;
    };
    /**
     * Checks whether the path targeted by the mapping action has been previously removed from the specification
     * @param   {string} targetPath the path to check
     */
    CompilerUtils.PathIsExcluded = function (targetPath, excludedPaths) {
        if (Utilities.IsNotDefined(targetPath, true)) {
            return false;
        }
        var target = targetPath.toLowerCase();
        // Check if the targetPath path starts with any of the excluded paths (the full path back to the root entity)
        // This ensures that any childen of an excluded entity, that are targets for a mapping rule action, will return a match.
        // It also ensures that the same entity excluded elsewhere in the specification does not return a false match.
        return excludedPaths.some(function (path) { return target.toLowerCase().lastIndexOf(path, 0) === 0; });
    };
    return CompilerUtils;
}());
module.exports = CompilerUtils;

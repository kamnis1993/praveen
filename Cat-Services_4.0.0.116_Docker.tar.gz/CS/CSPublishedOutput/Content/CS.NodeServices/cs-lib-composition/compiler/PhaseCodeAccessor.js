"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var Logger = require("../../cs-logging/Logger");
var Utilities = require("../../cs-lib-utilities/Utilities");
var PhaseCodeAccessor = /** @class */ (function () {
    function PhaseCodeAccessor() {
    }
    /**
     * Gets the phase codes for Compatibility Rule
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param { CsTypes.OrderfolioItem} entity
     * @param {string} boundaryCondition
     * @param {number} logLevel desired zorder for logging. Defaulted to 0.
     */
    PhaseCodeAccessor.GetCompatibilityRulePhaseCodes = function (compiledSpec, entity, boundaryCondition, logLevel) {
        if (logLevel === void 0) { logLevel = 0; }
        var compatibilityRulephaseCodes = {};
        var entityUuid = entity.CompoundKey.Key;
        if (Utilities.IsDefined(compiledSpec)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups[entityUuid])) {
            compatibilityRulephaseCodes = LodashUtilities.Clone(compiledSpec.PhaseCodeLookups[entityUuid].CompatibilityRules, true);
            Logger.debug(logLevel, "CompatibilityRule", "Gathering Phase codes for : " + entity.PortfolioItemId);
            Object.keys(compatibilityRulephaseCodes).forEach(function (key) {
                compatibilityRulephaseCodes[key] = PhaseCodeAccessor.RemoveTechnicalPhases(compatibilityRulephaseCodes[key], boundaryCondition);
                compatibilityRulephaseCodes[key] = PhaseCodeAccessor.FormatPhaseCodes(compatibilityRulephaseCodes[key], entity.EntityId, logLevel + 1);
            });
        }
        return compatibilityRulephaseCodes;
    };
    /**
     * Gets the phase codes for Group Cardinality rules
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} entityUuid
     * @param {string} boundaryCondition
     */
    PhaseCodeAccessor.GetGroupCardinalityPhaseCodes = function (compiledSpec, entityUuid, boundaryCondition) {
        var phaseCodes = undefined;
        var targetEntityID = undefined;
        if (Utilities.IsDefined(compiledSpec)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups[entityUuid])) {
            targetEntityID = PhaseCodeAccessor.GetEntityIDFromUuid(compiledSpec, entityUuid);
            phaseCodes = LodashUtilities.Clone(compiledSpec.PhaseCodeLookups[entityUuid].GroupCardinalityRule, true);
            phaseCodes = PhaseCodeAccessor.RemoveTechnicalPhases(phaseCodes, boundaryCondition);
        }
        return PhaseCodeAccessor.FormatPhaseCodes(phaseCodes, targetEntityID);
    };
    /**
     * Gets the phase codes for Relation Cardinality rules
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} entityUuid
     * @param {string} boundaryCondition
     */
    PhaseCodeAccessor.GetRelationCardinalityPhaseCodes = function (compiledSpec, entityUuid, boundaryCondition) {
        var relationCardinalityPhaseCodes = undefined;
        var targetEntityID = undefined;
        if (Utilities.IsDefined(compiledSpec)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups[entityUuid])) {
            targetEntityID = PhaseCodeAccessor.GetEntityIDFromUuid(compiledSpec, entityUuid);
            relationCardinalityPhaseCodes = LodashUtilities.Clone(compiledSpec.PhaseCodeLookups[entityUuid].RelationCardinality, true);
            relationCardinalityPhaseCodes = PhaseCodeAccessor.RemoveTechnicalPhases(relationCardinalityPhaseCodes, boundaryCondition);
            relationCardinalityPhaseCodes = PhaseCodeAccessor.FormatPhaseCodes(relationCardinalityPhaseCodes, targetEntityID);
        }
        return relationCardinalityPhaseCodes;
    };
    /**
     * Gets the phase codes for Characteristic uses
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} entityUuid
     * @param {string} boundaryCondition
     */
    PhaseCodeAccessor.GetCharacteristicUsePhaseCodes = function (compiledSpec, entityUuid, boundaryCondition) {
        var charUsephaseCodes = {};
        if (Utilities.IsDefined(compiledSpec)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups[entityUuid])) {
            charUsephaseCodes = LodashUtilities.Clone(compiledSpec.PhaseCodeLookups[entityUuid].CharacteristicUses, true);
            var targetEntityID_1 = PhaseCodeAccessor.GetEntityIDFromUuid(compiledSpec, entityUuid);
            Object.keys(charUsephaseCodes).forEach(function (key) {
                charUsephaseCodes[key] = PhaseCodeAccessor.RemoveTechnicalPhases(charUsephaseCodes[key], boundaryCondition);
                charUsephaseCodes[key] = PhaseCodeAccessor.FormatPhaseCodes(charUsephaseCodes[key], targetEntityID_1);
            });
        }
        return charUsephaseCodes;
    };
    /**
     * Gets the phase codes for Entity Links
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} entityUuid
     * @param {string} boundaryCondition
     */
    PhaseCodeAccessor.GetEntityLinkPhaseCodes = function (compiledSpec, entityUuid, boundaryCondition) {
        var entityLinkphaseCodes = {};
        if (Utilities.IsDefined(compiledSpec)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups)
            && Utilities.IsDefined(compiledSpec.PhaseCodeLookups[entityUuid])) {
            entityLinkphaseCodes = LodashUtilities.Clone(compiledSpec.PhaseCodeLookups[entityUuid].EntityLinks, true);
            var targetEntityID_2 = PhaseCodeAccessor.GetEntityIDFromUuid(compiledSpec, entityUuid);
            Object.keys(entityLinkphaseCodes).forEach(function (key) {
                entityLinkphaseCodes[key] = PhaseCodeAccessor.RemoveTechnicalPhases(entityLinkphaseCodes[key], boundaryCondition);
                entityLinkphaseCodes[key] = PhaseCodeAccessor.FormatPhaseCodes(entityLinkphaseCodes[key], targetEntityID_2);
            });
        }
        return entityLinkphaseCodes;
    };
    /**
     * Remove any Technical phase codes if the boundarycondition is commercial
     * @param {CsTypes.PhaseCodes} phaseCodes
     * @param {string} boundaryCondition
     */
    PhaseCodeAccessor.RemoveTechnicalPhases = function (phaseCodes, boundaryCondition) {
        if (boundaryCondition.toLowerCase() === "commercial"
            && Utilities.IsDefined(phaseCodes)
            && Utilities.IsDefined(phaseCodes.Technical)) {
            // remove all technical phase codes
            phaseCodes.Technical = undefined;
        }
        return phaseCodes;
    };
    /**
    * Format the phase codes into an array of string values
    * @param {CsTypes.PhaseCodes} phaseCodes
    * @param {number} logLevel desired zorder for logging. Defaulted to 0.
    */
    PhaseCodeAccessor.FormatPhaseCodes = function (phaseCodes, targetEntityId, logLevel) {
        if (logLevel === void 0) { logLevel = 0; }
        if (Utilities.IsDefined(phaseCodes)) {
            // Log the phase codes here, before formatting
            PhaseCodeAccessor.LogPhaseCodes(phaseCodes, targetEntityId, logLevel);
            // Remove all meta data from the phase codes and return just a list of codes
            var commPhaseCodeValues = LodashUtilities.Map(phaseCodes.Commercial, function (phaseCode) {
                return phaseCode.Value;
            });
            var techPhaseCodeValues = LodashUtilities.Map(phaseCodes.Technical, function (phaseCode) {
                return phaseCode.Value;
            });
            // Deduplicate the phaseCodes before returning
            var commPhaseCodes = PhaseCodeAccessor.FilterUniquePhaseCodes(commPhaseCodeValues);
            var techPhaseCodes = PhaseCodeAccessor.FilterUniquePhaseCodes(techPhaseCodeValues);
            if (Utilities.IsDefined(commPhaseCodes) || Utilities.IsDefined(techPhaseCodes)) {
                return {
                    Commercial: commPhaseCodes,
                    Technical: techPhaseCodes
                };
            }
        }
        return undefined;
    };
    /**
     * De-duplicate the phase codes and return a list of unique values
     * @param {string[]} phasecodeValues Array of phase code strings
     * @returns {string[]}
     */
    PhaseCodeAccessor.FilterUniquePhaseCodes = function (phaseCodeValues) {
        if (Utilities.IsDefined(phaseCodeValues) && phaseCodeValues.length > 0) {
            return LodashUtilities.Uniq(phaseCodeValues);
        }
        return undefined;
    };
    /**
     * Logs the given Phase code with target EntityId information
     * @param {CsTypes.PhaseCode} Phase code information to log
     * @param {string} targetEntityId information to log
     * @param {number} logLevel desired zorder for logging. Defaulted to 0.
     */
    PhaseCodeAccessor.LogPhaseCodes = function (phaseCodes, targetEntityId, logLevel) {
        if (logLevel === void 0) { logLevel = 0; }
        if (Utilities.IsDefined(phaseCodes)) {
            if (Utilities.IsDefined(phaseCodes.Commercial)) {
                phaseCodes.Commercial.forEach(function (phaseCode) {
                    PhaseCodeAccessor.LogPhaseCode(phaseCode, targetEntityId, logLevel);
                });
            }
            if (Utilities.IsDefined(phaseCodes.Technical)) {
                phaseCodes.Technical.forEach(function (phaseCode) {
                    PhaseCodeAccessor.LogPhaseCode(phaseCode, targetEntityId, logLevel);
                });
            }
        }
    };
    /**
     * Logs the given data
     * @param {CsTypes.PhaseCode} Phase code information to log
     * @param {string} targetEntityId information to log
     * @param {number} logLevel desired zorder for logging. Defaulted to 0.
     */
    PhaseCodeAccessor.LogPhaseCode = function (phaseCode, targetEntityId, logLevel) {
        Logger.debug(logLevel, "PhaseCodes", phaseCode.Value, { phaseCode: phaseCode, TargetId: targetEntityId });
    };
    /**
     * Gets the Entity Id for the given Uuid
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} entityUuid
     */
    PhaseCodeAccessor.GetEntityIDFromUuid = function (compiledSpec, entityUuid) {
        if (Utilities.IsDefined(compiledSpec.UuidToGuidPathLookup)) {
            var entityGuidPath = compiledSpec.UuidToGuidPathLookup[entityUuid];
            if (Utilities.IsDefined(entityGuidPath)) {
                var guidStrings = entityGuidPath.split(',');
                return guidStrings[guidStrings.length - 1];
            }
        }
        return undefined;
    };
    return PhaseCodeAccessor;
}());
module.exports = PhaseCodeAccessor;

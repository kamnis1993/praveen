"use strict";
/// <reference path='../../cs-lib-types/CompiledTypes/CsTypes.d.ts'/>>
var DateStatus = require("../../cs-lib-constants/DateStatus");
var DecomposeActivities = require("../../cs-lib-constants/DecomposeActivities");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
 * Class applies a date filter to a CompiledSpecification, removing any entities which are not in date
 */
var DateAvailabilityFilter = /** @class */ (function () {
    function DateAvailabilityFilter(filterDate) {
        this._filterDate = filterDate;
    }
    /**
     * Filter out relations and entities which are out of date or not yet available
     * @param {Date} filterDate the date to filter by
     * @param {CsTypes.CompiledSpecification} compiledSpecification the compiled specification to filter
     * @return {CsTypes.CompiledSpecification} the filtered compiled Spec
     */
    DateAvailabilityFilter.prototype.ApplyFilter = function (compiledSpecification) {
        var _this = this;
        if (Utilities.IsNotDefined(compiledSpecification)) {
            return compiledSpecification;
        }
        if (Utilities.IsNotDefined(this._filterDate)) {
            return compiledSpecification;
        }
        var relationCardinalities = compiledSpecification.CardinalityLookups.EntityCardinalities;
        var entityDateDictionary = compiledSpecification.EntityDates;
        // This will update the date info of the root entity
        this.UpdateDateInfo(this._filterDate, entityDateDictionary[1]);
        // This will update the date info of non-root entities in the composition tree
        relationCardinalities.forEach(function (cardinalityInfo) {
            var entityDates = entityDateDictionary[cardinalityInfo.ChildKey.toString()];
            _this.UpdateDateInfo(_this._filterDate, entityDates);
        });
        return compiledSpecification;
    };
    /**
     * Updates the date information with the date status, available actions and available activities
     * This implements the functionality outlined in the truth table in the document (Documentation Of Wexford/CS Date Truth Table.docx)
     * @param {Date} dateToCheck The date to check against
     * @param {CsTypes.DateInfo} dates The date information
     */
    DateAvailabilityFilter.prototype.UpdateDateInfo = function (dateToCheck, dates) {
        dateToCheck = Utilities.EnsureDate(dateToCheck);
        var effStart = Utilities.EnsureDate(dates.EffectiveStartDate);
        var effEnd = Utilities.EnsureDate(dates.EffectiveEndDate);
        var avStart = Utilities.EnsureDate(dates.StartDate);
        var avEnd = Utilities.EnsureDate(dates.EndDate);
        // If the date to check is undefined, Utilities.IsDateValidForDateRange would return true, so follow same functionality here
        // Otherwise, check if the date falls within available date boundaries
        if (Utilities.IsNotDefined(dateToCheck) || Utilities.IsDateValidForDateRange(dateToCheck, avStart, avEnd)) {
            dates.DateStatus = DateStatus.Available;
            dates.AvailableActions = [OrderActions.Add, OrderActions.Update, OrderActions.Delete, OrderActions.NoChange, OrderActions.Reassign, OrderActions.Reassigned, OrderActions.ReassignedUpdate];
            dates.AvailableActivities = [DecomposeActivities.Inference, DecomposeActivities.Mapping];
            return;
        }
        // If the date falls outside the available date boundaries, figure out whether it is
        // before or after the available dates (but within effective dates)
        if (Utilities.IsDefined(avStart) &&
            dateToCheck < avStart &&
            dateToCheck >= effStart) {
            dates.DateStatus = DateStatus.NotYetAvailable;
            dates.AvailableActions = [];
            dates.AvailableActivities = [];
            return;
        }
        if (Utilities.IsDefined(avEnd) &&
            dateToCheck > avEnd &&
            (Utilities.IsNotDefined(effEnd) || dateToCheck <= effEnd)) {
            dates.DateStatus = DateStatus.NoLongerAvailable;
            dates.AvailableActions = [OrderActions.Update, OrderActions.Delete, OrderActions.NoChange];
            dates.AvailableActivities = [DecomposeActivities.Inference, DecomposeActivities.Mapping];
            return;
        }
        // If the date to check lies outside the effective date range, then the available operations are very limited
        dates.AvailableActivities = [];
        if (Utilities.IsDefined(effEnd) && dateToCheck > effEnd) {
            dates.DateStatus = DateStatus.AfterEffective;
            dates.AvailableActions = [OrderActions.Delete];
        }
        else {
            dates.DateStatus = DateStatus.BeforeEffective;
            dates.AvailableActions = [];
        }
    };
    return DateAvailabilityFilter;
}());
module.exports = DateAvailabilityFilter;

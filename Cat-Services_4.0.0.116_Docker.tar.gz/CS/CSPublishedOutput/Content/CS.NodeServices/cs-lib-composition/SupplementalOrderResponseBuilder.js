"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
/// <reference types="node" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utilities = require("../cs-lib-utilities/Utilities");
var ChangeTypes = require("../cs-lib-constants/ChangeTypes");
var CharacteristicQueries = require("./CharacteristicQueries");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var OrderCandidateResponseBuilder = require("./OrderCandidateResponseBuilder");
var OrderfolioQueries = require("./OrderfolioQueries");
/**
 * Class responsible for building a supplemental order response
 */
var SupplementalOrderResponseBuilder = /** @class */ (function (_super) {
    __extends(SupplementalOrderResponseBuilder, _super);
    /**
     * Creates a new Supplemental order response builder
     * @param {CsTypes.Dictionary<IOrderItemLookup>} originalOrderLookup Lookup that contains only the original order items
     * @param {SupplementalOrderMergeResponse} mergeResponse The details of when the in flight order and supplemental order were merged
     * @param {CsErrorContext} errorContext The error context
     */
    /**
     * Creates a new Supplemental order response builder
     * @param  {OrderCandidateRequest}    originalOrderCandidateRequest          The original order candidate request
     * @param  {supplementalOrderRequest} processedSupplementalOrderRequest      The processed supplemental order request
     * @param  {DecomposeGenIdController} decomposeController                    The decompose controller
     * @param  {CsErrorContext}           errorContext                           The error context
     */
    function SupplementalOrderResponseBuilder(originalOrderCandidateRequest, processedSupplementalOrderRequest, decomposeController, errorContext) {
        var _this = _super.call(this, errorContext) || this;
        _this._originalOrderCandidateRequest = originalOrderCandidateRequest;
        _this._originalOrderLookup = originalOrderCandidateRequest.OrderCandidate.OrderItemLookup;
        _this._currentOrderLookup = {};
        _this._processedSupplementalOrderRequest = processedSupplementalOrderRequest;
        _this._decomposeController = decomposeController;
        return _this;
    }
    /**
     * Build (unflatten, pump up) an OrderCandidateResponse from an array of DecomposeContexts.
     * @param {CsTypes.DecomposeContextCollection} compiledOrder - the array of decompose contexts
     * @returns {OrderCandidateResponse}
     */
    SupplementalOrderResponseBuilder.prototype.Build = function (compiledOrder) {
        var response = _super.prototype.Build.call(this, compiledOrder);
        // Swap the ID's back over to return the response
        response.OriginalRequestID = response.RequestID;
        response.RequestID = this._processedSupplementalOrderRequest.SupplementalOrderRequestID;
        this.CancelRemovedRootItems(response);
        return response;
    };
    /**
     * Build the children of a parent entity
     * @param {CsTypes.DecomposeContext} rootContext the DecomposeContext for the current entity tree
     * @param {CsTypes.OrderfolioItemLookup} parentLookup The unique identifier for the root entity in the orderfolio
     * @param {OrderItem} parentOrderItem child order items are pushed into the ChildOrderItems array of this item
     * @param {AffectedPortfolioItem} parentPortfolioItem child portfolio items are stored in the ChildEntities array of this item
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     */
    SupplementalOrderResponseBuilder.prototype.BuildChildren = function (rootContext, parentLookup, parentOrderItem, parentPortfolioItem, includeProductCandidateData) {
        _super.prototype.BuildChildren.call(this, rootContext, parentLookup, parentOrderItem, parentPortfolioItem, includeProductCandidateData);
        this.CancelRemovedChildOrderItems(parentOrderItem);
    };
    /**
     * Create an OrderItem from the supplied Orderfolio
     * @param {CsTypes.OrderfolioItem} ofItem the OrderfolioItem to use as the source
     * @param {string} parentAction the action on the parent order item
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem>} The orderfolio
     * @returns {OrderItem} an OrderItem
     */
    SupplementalOrderResponseBuilder.prototype.CreateOrderItemFromOrderfolio = function (ofItem, decomposeContext, parent) {
        if (ofItem.IsInvalid) {
            return ofItem.ItemPair.OrderItem;
        }
        var newOrderItem = _super.prototype.CreateOrderItemFromOrderfolio.call(this, ofItem, decomposeContext, parent);
        if (Utilities.IsNotDefined(newOrderItem)) {
            return undefined;
        }
        this._decomposeController.RemapOrderItem(newOrderItem);
        ofItem.PortfolioItemId = newOrderItem.PortfolioItemID;
        var parentOrderId = (Utilities.IsDefined(parent)) ? parent.ID : undefined;
        this._currentOrderLookup[newOrderItem.ID] = { ParentOrderItemId: parentOrderId, OrderItem: newOrderItem };
        this.SetChangeTypeOnOrderItem(newOrderItem, parent);
        this.AddChangeTypesToCharacteristicUses(newOrderItem);
        this.AddChangeTypesToUserDefinedCharacteristicUses(newOrderItem);
        this.AddChangeTypesToRateAttributes(newOrderItem);
        this.AddChangeTypesToEntityLinks(newOrderItem);
        return newOrderItem;
    };
    /**
     * Builds a link target from a compiled entity link
     * @param {CsTypes.SourceToTargetEntityLink} link The compiled entity link
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {boolean} buildForOrder If we are building for an order
     * @returns {LinkTarget} The link target
     */
    SupplementalOrderResponseBuilder.prototype.BuildLinkTarget = function (link, decomposeContext, buildForOrder) {
        var linkTarget = _super.prototype.BuildLinkTarget.call(this, link, decomposeContext, buildForOrder);
        if (Utilities.IsNotDefined(linkTarget)) {
            return;
        }
        this._decomposeController.RemapEntityLink(linkTarget);
        return linkTarget;
    };
    /**
     * Builds validation errors using the error context
     * @returns {Array<ValidationError>} validation errors recorded in error context
     */
    SupplementalOrderResponseBuilder.prototype.BuildValidationErrors = function () {
        return this._errorContext.GetValidationErrorsForResponse(this._decomposeController);
    };
    /**
     * Sets the change type for an order item and its ancestors
     * @param {OrderItem} orderItem The order item
     * @param {OrderItem} parent The parent order item
     */
    SupplementalOrderResponseBuilder.prototype.SetChangeTypeOnOrderItem = function (orderItem, parent) {
        var orderItemLookup = this._originalOrderLookup[orderItem.ID];
        if (Utilities.IsNotDefined(orderItemLookup)) {
            this.SetAmendChangeType(parent);
            orderItem.ChangeType = ChangeTypes.Create;
            return;
        }
        if (orderItemLookup.OrderItem.ItemAction !== orderItem.ItemAction) {
            this.SetAmendChangeType(orderItem);
        }
        else {
            orderItem.ChangeType = ChangeTypes.NoChange;
        }
    };
    /**
     * Cascades the cancel action to the order item and all children
     * @param {OrderItem} orderItem The order item that has been cancelled
     */
    SupplementalOrderResponseBuilder.prototype.CascadeCancelAction = function (orderItem) {
        var _this = this;
        var recurseOrderItems = function (item) {
            item.ChangeType = ChangeTypes.Cancel;
            item.ItemSource = OrderfolioQueries.GetItemSource({ ItemSource: item.ItemSource }, _this._processedSupplementalOrderRequest.ID);
            item.CharacteristicUses.forEach(function (charUse) { _this.CascadeCancelActionOnProperty(charUse, charUse.Value); });
            item.ConfiguredValues.forEach(function (udc) { _this.CascadeCancelActionOnProperty(udc, udc.Value); });
            item.RateAttributes.forEach(function (rateAttribute) { _this.CascadeCancelActionOnProperty(rateAttribute, []); });
            item.LinkedEntities.forEach(function (linkedEntity) { _this.CascadeCancelActionOnProperty(linkedEntity, linkedEntity.Links); });
            if (Utilities.IsNotDefined(item.ChildOrderItems, true)) {
                return;
            }
            item.ChildOrderItems.forEach(function (child) {
                recurseOrderItems(child);
            });
        };
        recurseOrderItems(orderItem);
    };
    /**
     * Cascades the cancel action down to the property and its values
     * @param {CsTypes.ChangeTypeItem} property The property to cancel
     * @param {Array<CsTypes.ChangeTypeItem>} propertyValues The property values to cancel
     */
    SupplementalOrderResponseBuilder.prototype.CascadeCancelActionOnProperty = function (property, propertyValues) {
        var _this = this;
        property.ChangeType = ChangeTypes.Cancel;
        property.ItemSource = OrderfolioQueries.GetItemSource({ ItemSource: property.ItemSource }, this._processedSupplementalOrderRequest.ID);
        propertyValues.forEach(function (propertyValue) {
            propertyValue.ChangeType = ChangeTypes.Cancel;
            propertyValue.ItemSource = OrderfolioQueries.GetItemSource({ ItemSource: propertyValue.ItemSource }, _this._processedSupplementalOrderRequest.ID);
        });
    };
    /**
     * Sets the change type amend to any parents that do not already have an item action
     * @param {OrderItem} parentOrderItem The parent
     */
    SupplementalOrderResponseBuilder.prototype.SetAmendChangeType = function (parentOrderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(parentOrderItem)) {
            return;
        }
        var recurseParents = function (lookup) {
            if (Utilities.IsNotDefined(lookup) || _this.HasChangeType(lookup.OrderItem.ChangeType)) {
                return;
            }
            lookup.OrderItem.ChangeType = ChangeTypes.Amend;
            if (Utilities.IsNotDefined(lookup.ParentOrderItemId, true)) {
                return;
            }
            recurseParents(_this._currentOrderLookup[lookup.ParentOrderItemId]);
        };
        recurseParents(this._currentOrderLookup[parentOrderItem.ID]);
    };
    /**
     * Sets the amend change type on the characteristic and sets it on all order items above it
     * @param {CsTypes.ChangeTypeItem} changeTypeProperty The change type item to amend
     * @param {OrderItem} parentOrderItem The parent order of the property
     */
    SupplementalOrderResponseBuilder.prototype.SetAmendChangeTypeOnProperty = function (changeTypeProperty, parentOrderItem) {
        if (!this.HasChangeType(changeTypeProperty.ChangeType)) {
            changeTypeProperty.ChangeType = ChangeTypes.Amend;
        }
        this.SetAmendChangeType(parentOrderItem);
    };
    /**
     * Adds change type to the characteristic uses
     * @param {OrderItem} orderItem The order item
     */
    SupplementalOrderResponseBuilder.prototype.AddChangeTypesToCharacteristicUses = function (orderItem) {
        var _this = this;
        var getCharacteristicUses = function (orderItem) { return orderItem.CharacteristicUses; };
        var getCharacteristicValues = function (property) {
            var characteristicUse = property;
            return characteristicUse.Value;
        };
        var findCharacteristicUse = function (property, orderItem) {
            var charUse = property;
            var existingCharUse = CharacteristicQueries.GetCharUseFromCollection(orderItem.CharacteristicUses, charUse.UseArea, charUse.CharacteristicID);
            return existingCharUse;
        };
        var findCharacteristicValue = function (value, property) {
            var charUse = property;
            var charValue = value;
            var existingValue = CharacteristicQueries.GetCharValueFromCollection(charUse.Value, charValue.ValueID);
            return existingValue;
        };
        orderItem.CharacteristicUses.forEach(function (charUse) {
            _this.SetChangeTypeOnProperty(charUse, charUse.Value, orderItem, findCharacteristicUse, findCharacteristicValue);
        });
        this.CancelRemovedProperties(orderItem, getCharacteristicUses, getCharacteristicValues, findCharacteristicUse, findCharacteristicValue);
    };
    /**
     * Adds change type to the user defined characteristic uses
     * @param {OrderItem} orderItem The order item
     */
    SupplementalOrderResponseBuilder.prototype.AddChangeTypesToUserDefinedCharacteristicUses = function (orderItem) {
        var _this = this;
        var getUdcs = function (orderItem) { return orderItem.ConfiguredValues; };
        var getUdcValues = function (property) {
            var udc = property;
            return udc.Value;
        };
        var findUserDefinedCharacteristicUse = function (property, orderItem) {
            var udc = property;
            var existingUdc = CharacteristicQueries.GetUdcFromCollection(orderItem.ConfiguredValues, udc.UseArea, udc.CharacteristicID);
            return existingUdc;
        };
        var findUserDefinedCharacteristicValue = function (value, property) {
            var udc = property;
            var udcValue = value;
            var existingValue = CharacteristicQueries.GetUdcValueFromCollection(udc.Value, udcValue.Value);
            return existingValue;
        };
        orderItem.ConfiguredValues.forEach(function (udc) {
            _this.SetChangeTypeOnProperty(udc, udc.Value, orderItem, findUserDefinedCharacteristicUse, findUserDefinedCharacteristicValue);
        });
        this.CancelRemovedProperties(orderItem, getUdcs, getUdcValues, findUserDefinedCharacteristicUse, findUserDefinedCharacteristicValue);
    };
    /**
     * Adds change type to the rate attribute
     * @param {OrderItem} orderItem The order item
     */
    SupplementalOrderResponseBuilder.prototype.AddChangeTypesToRateAttributes = function (orderItem) {
        var _this = this;
        // Rate attributes don't have values, so we can reuse the code I have just created placeholders
        // for the value functions that just return nothing
        var getRateAttributes = function (orderItem) { return orderItem.RateAttributes; };
        var getValues = function (property) { return []; };
        var findRateAttribute = function (property, orderItem) {
            var rateAttribute = property;
            var existingRate = LodashUtilities.Find(orderItem.RateAttributes, function (r) { return r.Name === rateAttribute.Name && r.Value === rateAttribute.Value; });
            return existingRate;
        };
        var findValue = function (value, property) {
            return undefined;
        };
        orderItem.RateAttributes.forEach(function (rateAttribute) {
            _this.SetChangeTypeOnProperty(rateAttribute, [], orderItem, findRateAttribute);
        });
        this.CancelRemovedProperties(orderItem, getRateAttributes, getValues, findRateAttribute, findValue);
    };
    /**
     * Adds the change types to the entity links
     * @param {OrderItem} orderItem The order item
     */
    SupplementalOrderResponseBuilder.prototype.AddChangeTypesToEntityLinks = function (orderItem) {
        var _this = this;
        var getEntityLinks = function (orderItem) { return orderItem.LinkedEntities; };
        var getLinks = function (property) {
            var entityLink = property;
            return entityLink.Links;
        };
        var findEntityLink = function (property, orderItem) {
            var entityLink = property;
            var existingEntityLink = LodashUtilities.Find(orderItem.LinkedEntities, function (el) { return el.LinkTypeID === entityLink.LinkTypeID; });
            return existingEntityLink;
        };
        var findLink = function (value, property) {
            var entityLink = property;
            var link = value;
            var existingLink = LodashUtilities.Find(entityLink.Links, function (l) { return l.PortfolioItemID === link.PortfolioItemID; });
            return existingLink;
        };
        orderItem.LinkedEntities.forEach(function (entityLink) {
            _this.SetChangeTypeOnProperty(entityLink, entityLink.Links, orderItem, findEntityLink, findLink);
        });
        this.CancelRemovedProperties(orderItem, getEntityLinks, getLinks, findEntityLink, findLink);
    };
    /**
     * Adds any root items that have been cancelled
     * @param {OrderCandidateResponse} response The order candidate response
     */
    SupplementalOrderResponseBuilder.prototype.CancelRemovedRootItems = function (response) {
        var _this = this;
        this._originalOrderCandidateRequest.OrderCandidate.OrderItems.forEach(function (originalRootOrderItem) {
            var newRootOrderItem = LodashUtilities.Find(response.OrderCandidate.OrderItems, function (ro) { return ro.ID === originalRootOrderItem.ID; });
            if (Utilities.IsNotDefined(newRootOrderItem)) {
                _this.CascadeCancelAction(originalRootOrderItem);
                originalRootOrderItem.ItemSource = OrderfolioQueries.GetItemSource(originalRootOrderItem, _this._processedSupplementalOrderRequest.ID);
                response.OrderCandidate.OrderItems.push(originalRootOrderItem);
            }
        });
    };
    /**
     * Cancels any order items that were in the original order, but are now not in the new order after decompose has been re-applied
     * @param {OrderItem} newOrderItem The order item to check
     */
    SupplementalOrderResponseBuilder.prototype.CancelRemovedChildOrderItems = function (newOrderItem) {
        var _this = this;
        if (Utilities.IsNotDefined(newOrderItem)) {
            return;
        }
        var originalOrderItemLookup = this._originalOrderLookup[newOrderItem.ID];
        if (Utilities.IsNotDefined(originalOrderItemLookup)) {
            return;
        }
        var originalOrderItem = originalOrderItemLookup.OrderItem;
        originalOrderItem.ChildOrderItems.forEach(function (originalChildOrderItem) {
            if (originalChildOrderItem.ChangeType === ChangeTypes.Cancel) {
                return;
            }
            var newChildOrderItem = LodashUtilities.Find(newOrderItem.ChildOrderItems, function (co) { return co.ID === originalChildOrderItem.ID; });
            if (Utilities.IsNotDefined(newChildOrderItem)) {
                _this.SetAmendChangeType(newOrderItem);
                _this.CascadeCancelAction(originalChildOrderItem);
                newOrderItem.ChildOrderItems.push(originalChildOrderItem);
            }
        });
    };
    /**
     * Cancels any properties/values that have not been recreated when Decompose was ReApplied
     * Generic Function so it works for Characteristic Uses, Udcs, Entity Links and Rate Attributes
     * @param {OrderItem} newOrderItem The order item generated when decompose was run
     * @param {(orderItem: CsTypes.IOrderItem) => Array<CsTypes.ChangeTypeItem>} getProperties Function that gets properties from an order item
     * @param {(property: CsTypes.ChangeTypeItem) => Array<CsTypes.ChangeTypeItem>} getValues Function that gets values from a property
     * @param {(propertyToFind: CsTypes.ChangeTypeItem, orderItem: CsTypes.IOrderItem) => CsTypes.ChangeTypeItem} findProperty Function that finds a specific property in an order item
     * @param {(valueToFind: CsTypes.ChangeTypeItem, property: CsTypes.ChangeTypeItem) => CsTypes.ChangeTypeItem)} findValue Function that finds a specific value in a property
     */
    SupplementalOrderResponseBuilder.prototype.CancelRemovedProperties = function (newOrderItem, getProperties, getValues, findProperty, findValue) {
        var _this = this;
        var originalOrderItemLookup = this._originalOrderLookup[newOrderItem.ID];
        if (Utilities.IsNotDefined(originalOrderItemLookup)) {
            return;
        }
        var originalOrderItem = originalOrderItemLookup.OrderItem;
        var originalProperties = getProperties(originalOrderItem);
        var newProperties = getProperties(newOrderItem);
        // Loop through the properties in the order item that came in on the request
        originalProperties.forEach(function (originalProperty) {
            var originalValues = getValues(originalProperty);
            var newProperty = findProperty(originalProperty, newOrderItem);
            // If this property that was on the request hasn't been created when decompose was run again, then it is cancelled
            if (Utilities.IsNotDefined(newProperty)) {
                _this.SetAmendChangeType(newOrderItem);
                _this.CascadeCancelActionOnProperty(originalProperty, originalValues);
                newProperties.push(originalProperty);
                return;
            }
            if (Utilities.IsNotDefined(originalValues, true)) {
                return;
            }
            var newValues = getValues(newProperty);
            // Property still exists so make sure that values do
            originalValues.forEach(function (originalValue) {
                var newValue = findValue(originalValue, newProperty);
                // Value existed on the original request but hasn't been created when decompose was run again, then it is cancelled
                if (Utilities.IsNotDefined(newValue)) {
                    _this.SetAmendChangeTypeOnProperty(newProperty, newOrderItem);
                    originalValue.ChangeType = ChangeTypes.Cancel;
                    originalValue.ItemSource = OrderfolioQueries.GetItemSource({ ItemSource: originalValue.ItemSource }, _this._processedSupplementalOrderRequest.ID);
                    newValues.push(originalValue);
                }
            });
            // If all values on a property are cancelled, mark the property as cancelled
            if (newValues.every(function (value) { return value.ChangeType === ChangeTypes.Cancel; })) {
                newProperty.ChangeType = ChangeTypes.Cancel;
            }
        });
    };
    /**
     * Sets the change type on the property and its order item ancestors
     * @param {CsTypes.ChangeTypeItem} newProperty The change type property
     * @param {Array<CsTypes.ChangeTypeItem>} newValues The values on a change type property
     * @param {OrderItem} orderItem The order item
     * @param matchOriginalProperty Function to get the original property
     * @param matchOriginalValue Function to get the original value
     */
    SupplementalOrderResponseBuilder.prototype.SetChangeTypeOnProperty = function (newProperty, newValues, orderItem, matchOriginalProperty, matchOriginalValue) {
        var _this = this;
        if (orderItem.ChangeType === ChangeTypes.Cancel) {
            this.CascadeCancelActionOnProperty(newProperty, newValues);
            return;
        }
        var existingProperty;
        var originalOrderItem = this._originalOrderLookup[orderItem.ID];
        if (Utilities.IsNotDefined(originalOrderItem)) {
            this.SetAmendChangeType(orderItem);
            newProperty.ChangeType = ChangeTypes.Create;
        }
        else {
            existingProperty = matchOriginalProperty(newProperty, originalOrderItem.OrderItem);
            if (Utilities.IsNotDefined(existingProperty)) {
                this.SetAmendChangeType(orderItem);
                newProperty.ChangeType = ChangeTypes.Create;
            }
            else {
                newProperty.ChangeType = ChangeTypes.NoChange;
            }
        }
        if (Utilities.IsDefined(matchOriginalValue)) {
            newValues.forEach(function (changeTypeValue) {
                _this.SetChangeTypeOnValue(changeTypeValue, newProperty, existingProperty, orderItem, matchOriginalValue);
            });
        }
    };
    /**
     * Sets the change type on a value that has a change type
     * @param {CsTypes.ChangeTypeItem} newValue The value to set the change type on
     * @param {CsTypes.ChangeTypeItem] changeTypeProperty The The change type property
     * @param {CsTypes.ChangeTypeItem} originalProperty The change type property from the original order
     * @param {OrderItem} orderItem the order item that the change type property belongs to
     * @param matchOriginalValue Function to get the original value
     */
    SupplementalOrderResponseBuilder.prototype.SetChangeTypeOnValue = function (newValue, newProperty, originalProperty, orderItem, matchOriginalValue) {
        if (newProperty.ChangeType === ChangeTypes.Create || newProperty.ChangeType === ChangeTypes.Cancel) {
            newValue.ChangeType = newProperty.ChangeType;
            return;
        }
        if (Utilities.IsNotDefined(originalProperty)) {
            newValue.ChangeType = ChangeTypes.Create;
            return;
        }
        // Change type on characteristic must be amend or no change
        var existingValue = matchOriginalValue(newValue, originalProperty);
        if (Utilities.IsNotDefined(existingValue)) {
            // Set change type
            newValue.ChangeType = ChangeTypes.Create;
            this.SetAmendChangeTypeOnProperty(newProperty, orderItem);
            return;
        }
        else {
            newValue.ChangeType = ChangeTypes.NoChange;
        }
    };
    /**
     * Returns whether the change type has been set
     * @param {string} changeType The change type to check
     * @returns {boolean}
     */
    SupplementalOrderResponseBuilder.prototype.HasChangeType = function (changeType) {
        return Utilities.IsDefined(changeType, true) && changeType !== ChangeTypes.NoChange;
    };
    return SupplementalOrderResponseBuilder;
}(OrderCandidateResponseBuilder));
module.exports = SupplementalOrderResponseBuilder;

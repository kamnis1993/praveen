"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var OrderCandidateResponseBuilder = require("./OrderCandidateResponseBuilder");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class responsible for building an OrderCandidateResponse with pricing elements from a set of DecomposeContexts
 * Synonyms: unflatten, inflate, pump,
 */
var PricingOrderCandidateResponseBuilder = /** @class */ (function (_super) {
    __extends(PricingOrderCandidateResponseBuilder, _super);
    function PricingOrderCandidateResponseBuilder(errorContext) {
        return _super.call(this, errorContext) || this;
    }
    /**
     * Create an OrderItem from the supplied Orderfolio
     * @param {CsTypes.OrderfolioItem} ofItem the OrderfolioItem to use as the source
     * @param {string} parentAction the action on the parent order item
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem>} The orderfolio
     * @returns {OrderItem} an OrderItem
     */
    PricingOrderCandidateResponseBuilder.prototype.CreateOrderItemFromOrderfolio = function (ofItem, decomposeContext, parentOrderItem) {
        if (ofItem.IsInvalid) {
            return ofItem.ItemPair.OrderItem;
        }
        // Set properties
        var newOrderItem = _super.prototype.CreateOrderItemFromOrderfolio.call(this, ofItem, decomposeContext, parentOrderItem);
        if (Utilities.IsNotDefined(newOrderItem)) {
            return undefined;
        }
        // Pricing
        this.BuildOrderPricing(ofItem, newOrderItem, decomposeContext.CompiledSpec, decomposeContext.ActivationDate);
        return newOrderItem;
    };
    /**
     * Create an AffectedPortfolioItem from the supplied Orderfolio
     * Deleted entities or characteristics are not included.
     * Only include final position of portfolio item
     * @param {CsTypes.OrderfolioItem} ofItem the OrderfolioItem to use as the source
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     * @param {boolean} [isRoot] Default: false. Whether this is a root item or not
     * @returns {AffectedPortfolioItem} an AffectedPortfolioItem, undefined if item should not be included in portfolio
     */
    PricingOrderCandidateResponseBuilder.prototype.CreatePortfolioItemFromOrderfolio = function (ofItem, includeProductCandidateData, decomposeContext, isRoot) {
        if (isRoot === void 0) { isRoot = false; }
        if (ofItem.IsInvalid) {
            return ofItem.ItemPair.PortfolioItem;
        }
        // Set properties
        var newPortfolioItem = _super.prototype.CreatePortfolioItemFromOrderfolio.call(this, ofItem, includeProductCandidateData, decomposeContext, isRoot);
        if (Utilities.IsNotDefined(newPortfolioItem)) {
            return undefined;
        }
        // Pricing
        this.BuildPortfolioPricing(ofItem, newPortfolioItem, decomposeContext.CompiledSpec, decomposeContext.ActivationDate);
        return newPortfolioItem;
    };
    /**
     * Constructs the response order item for an orderfolio charge or cost
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item to construct a response for
     * @param {OrderItem} newOrderItem the response item
     * @param {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this orderfolio item
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildOrderPricing = function (orderfolioItem, newOrderItem, compiledSpec, orderActivationDate) {
        this.BuildPricingEntity(orderfolioItem, newOrderItem, compiledSpec, orderActivationDate);
        this.BuildOrderApplicableDiscounts(orderfolioItem, newOrderItem, compiledSpec);
        this.BuildOrderApplicableDiscountDetails(orderfolioItem, newOrderItem, compiledSpec);
    };
    /**
     * Constructs the response portfolio item for an orderfolio charge or cost
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item to construct a response for
     * @param {AffectedPortfolioItem} newPortfolioItem the response item
     * @param {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this orderfolio item
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildPortfolioPricing = function (orderfolioItem, newPortfolioItem, compiledSpec, orderActivationDate) {
        this.BuildPricingEntity(orderfolioItem, newPortfolioItem, compiledSpec, orderActivationDate);
        this.BuildPortfolioApplicableDiscounts(orderfolioItem, newPortfolioItem, compiledSpec);
        this.BuildPortfolioApplicableDiscountDetails(orderfolioItem, newPortfolioItem, compiledSpec);
    };
    /**
    * Constructs the applicable discount details or the order folio
    * @param   {CsTypes.OrderfolioItem} ofItem the orderfolio discount to construct a response for
    * @param   {OrderItem} newOrderItem the response discount item
    * @param   {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this discount
    */
    PricingOrderCandidateResponseBuilder.prototype.BuildOrderApplicableDiscountDetails = function (ofItem, newOrderItem, compiledSpec) {
        compiledSpec.ApplicableDiscountDetails.forEach(function (discountDetail) {
            if (discountDetail.DiscountGuid === ofItem.EntityId) {
                newOrderItem.DiscountType = discountDetail.DiscountType;
                newOrderItem.ActualDiscountType = discountDetail.ExactType;
                if (discountDetail.DiscountClass) {
                    newOrderItem.DiscountClass = discountDetail.DiscountClass;
                }
                if (discountDetail.UnitOfMeasure) {
                    newOrderItem.UnitOfMeasure = discountDetail.UnitOfMeasure;
                }
            }
        });
    };
    /**
     * Constructs the applicable discount details or the portfolio
     * @param   {CsTypes.OrderfolioItem} ofItem the orderfolio discount to construct a response for
     * @param   {OrderItem} newOrderItem the response discount item
     * @param   {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this discount
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildPortfolioApplicableDiscountDetails = function (ofItem, newPortfolioItem, compiledSpec) {
        compiledSpec.ApplicableDiscountDetails.forEach(function (discountDetail) {
            if (discountDetail.DiscountGuid === ofItem.EntityId) {
                newPortfolioItem.DiscountType = discountDetail.DiscountType;
                newPortfolioItem.ActualDiscountType = discountDetail.ExactType;
                if (discountDetail.DiscountClass) {
                    newPortfolioItem.DiscountClass = discountDetail.DiscountClass;
                }
                if (discountDetail.UnitOfMeasure) {
                    newPortfolioItem.UnitOfMeasure = discountDetail.UnitOfMeasure;
                }
            }
        });
    };
    /**
    * Constructs the Applicable discount response order item for an orderfolio discount
    * @param   {CsTypes.OrderfolioItem} ofItem the orderfolio Applicable discount to construct a response for
    * @param   {OrderItem} newOrderItem the response Applicable discount item
    * @param   {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this Applicable discount
    */
    PricingOrderCandidateResponseBuilder.prototype.BuildOrderApplicableDiscounts = function (ofItem, newOrderItem, compiledSpec) {
        if (Utilities.IsNotDefined(ofItem.ApplicableDiscounts, true)) {
            return;
        }
        newOrderItem.ApplicableDiscount = ofItem.ApplicableDiscounts;
    };
    /**
     * Constructs the applicable discount response portfolio item for an orderfolio applicable discount
     * @param   {CsTypes.OrderfolioItem} ofItem the orderfolio Applicable discount to construct a response for
     * @param   {OrderItem} newOrderItem the response Applicable discount item
     * @param   {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this Applicable discount
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildPortfolioApplicableDiscounts = function (ofItem, newPortfolioItem, compiledSpec) {
        if (Utilities.IsNotDefined(ofItem.ApplicableDiscounts, true)) {
            return;
        }
        newPortfolioItem.ApplicableDiscount = ofItem.ApplicableDiscounts;
    };
    /**
     * Constructs the charge response portfolio item for an orderfolio charge
     * @param   {CsTypes.OrderfolioItem} ofItem the orderfolio charge to construct a response for
     * @param   {AffectedPortfolioItem} newPortfolioItem the response charge item
     * @param   {CsTypes.CompiledSpecification} compiledSpec the compiled specification for this charge
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildPricingEntity = function (ofItem, outputItem, compiledSpec, orderActivationDate) {
        if (!this.IsPricingEntity(ofItem)) {
            return;
        }
        outputItem.ChargeType = ofItem.ChargeType;
        outputItem.CostType = ofItem.CostType;
        outputItem.DiscountType = ofItem.DiscountType;
        outputItem.ExactType = ofItem.ExactType;
        outputItem.Periodicity = ofItem.Periodicity;
        outputItem.UnitQuantity = ofItem.UnitQuantity;
        var key = ofItem.CompoundKey.Key.toString();
        var ratesToUse = this.GetRates(outputItem, compiledSpec, key);
        if (Utilities.IsDefined(ratesToUse, true)) {
            this.BuildStandardRate(ofItem, outputItem);
            if (Utilities.IsDefined(ofItem.TargetAdjustmentSet) && Utilities.IsDefined(outputItem.DiscountType)) {
                outputItem.TargetAdjustmentSet = ofItem.TargetAdjustmentSet;
            }
        }
        outputItem = this.BuildRateDetail(outputItem, ofItem, ratesToUse, orderActivationDate);
    };
    /**
     * Check if the Orderfolio item is a pricing entity
     * If will have a Charge, Cost or Discount type if it is
     * @private
     * @param {CsTypes.OrderfolioItem} ofItem
     * @returns {boolean}
     */
    PricingOrderCandidateResponseBuilder.prototype.IsPricingEntity = function (ofItem) {
        if (Utilities.IsDefined(ofItem.ChargeType) || Utilities.IsDefined(ofItem.CostType) || Utilities.IsDefined(ofItem.DiscountType)) {
            return true;
        }
        return false;
    };
    /**
     * Copies a rate from the orderfolio to the output
     * Formats any date fields
     * @private
     * @param {CsTypes.RateInfo[]} ratesToUse
     * @param {CsTypes.OrderfolioItem} ofItem
     * @param {*} outputItem
     * @returns {*}
     * @memberof PricingOrderCandidateResponseBuilder
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildStandardRate = function (ofItem, outputItem) {
        if (Utilities.IsDefined(ofItem.Rate) && (Utilities.IsDefined(outputItem.CostType) || Utilities.IsDefined(outputItem.ChargeType))) {
            outputItem.Rate = ofItem.Rate;
            outputItem.Rate.StartDate = Utilities.DateString(outputItem.Rate.StartDate);
            outputItem.Rate.EndDate = Utilities.DateString(outputItem.Rate.EndDate);
            outputItem.Rate.ActivationStartDate = Utilities.DateString(outputItem.Rate.ActivationStartDate);
            outputItem.Rate.ActivationEndDate = Utilities.DateString(outputItem.Rate.ActivationEndDate);
        }
        return outputItem;
    };
    /**
     * Return an array of rates by selecting it from the compiled spec
     * Depending upon which type of Pricing entity we have
     * @private
     * @param {any} outputItem
     * @param {CsTypes.CompiledSpecification} compiledSpec
     * @param {string} key
     * @returns {CsTypes.RateInfo[]}
     */
    PricingOrderCandidateResponseBuilder.prototype.GetRates = function (outputItem, compiledSpec, key) {
        if (Utilities.IsDefined(outputItem.ChargeType)) {
            return compiledSpec.ChargeLookups.ChargeUuidToRateInfo[key];
        }
        else if (Utilities.IsDefined(outputItem.CostType)) {
            return compiledSpec.CostLookups.CostUuidToRateInfo[key];
        }
        else if (Utilities.IsDefined(outputItem.DiscountType)) {
            return compiledSpec.DiscountLookups.DiscountUuidToRateInfo[key];
        }
    };
    /**
     * Build the RateDetail section of the item if necessary
     * @private
     * @param {any} outputItem
     * @param {CsTypes.OrderfolioItem} ofItem
     * @param {CsTypes.RateInfo[]} ratesToUse
     * @param {Date} orderActivationDate
     * @returns {any}
     */
    PricingOrderCandidateResponseBuilder.prototype.BuildRateDetail = function (outputItem, ofItem, ratesToUse, orderActivationDate) {
        var activationDatesExist = this.CheckForRateActivationDates(ratesToUse);
        if (ofItem.RateDetail) {
            outputItem.RateDetail = ofItem.RateDetail;
            if (Utilities.IsNotDefined(outputItem.RateDetail.RateActivationDate) && activationDatesExist) {
                outputItem.RateDetail.RateActivationDate = Utilities.DateString(orderActivationDate);
            }
        }
        else if (Utilities.IsNotDefined(ofItem.RateDetail) && activationDatesExist) {
            outputItem.RateDetail = {};
            outputItem.RateDetail.RateActivationDate = Utilities.DateString(orderActivationDate);
        }
        return outputItem;
    };
    /**
     * Check for any ActivationDates on rates
     * If these are present we need to identify which date we used to match them to
     * If one was passed in use that, other use the OrderActivationDate
     * @private
     * @param {CsTypes.RateInfo[]} inputRates
     * @returns {boolean}
     */
    PricingOrderCandidateResponseBuilder.prototype.CheckForRateActivationDates = function (inputRates) {
        if (Utilities.IsNotDefined(inputRates)) {
            return false;
        }
        var activationDatesExist = inputRates.some(function (rate) {
            if (Utilities.IsDefined(rate.ActivationStartDate || rate.ActivationEndDate)) {
                return true;
            }
            return false;
        });
        return activationDatesExist;
    };
    return PricingOrderCandidateResponseBuilder;
}(OrderCandidateResponseBuilder));
module.exports = PricingOrderCandidateResponseBuilder;

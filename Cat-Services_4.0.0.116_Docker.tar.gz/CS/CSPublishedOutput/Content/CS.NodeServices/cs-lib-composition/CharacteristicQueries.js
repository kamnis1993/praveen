"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var CharacteristicUse = require("../cs-lib-types/BusinessEntities/CharacteristicUse");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
var CharacteristicQueries = /** @class */ (function () {
    function CharacteristicQueries() {
    }
    /**
     * Builds and normalizes orderfolio characteristic uses
     * @param   {string} uuid The uuid of the orderfolio item the characteristic uses are located on
     * @param   {ItemPair} itemPair The order item and portfolio item pair for this orderfolio item
     * @param   {CsTypes.CompiledSpecification} compiledSpecification The specification definition of the orderfolio
     * @param   {string} orderfolioItemAction The item action for the orderfolio item
     * @param   {CsErrorContext} errorContext The collection of errors raised during processing
     * @returns {CombinedCharacteristicUses}
     */
    CharacteristicQueries.BuildOrderfolioCharacteristicUses = function (uuid, itemPair, compiledSpecification, orderfolioItemAction, errorContext) {
        var combinedCharUses = {
            OrderItemCharacteristicUses: Utilities.IsDefined(itemPair.OrderItem) ? Utilities.asArray(itemPair.OrderItem.CharacteristicUses) : [],
            PortfolioItemCharacteristicUses: Utilities.IsDefined(itemPair.PortfolioItem) ? Utilities.asArray(itemPair.PortfolioItem.CharacteristicUses) : [],
            ValueIDToCharacteristicIDLookup: compiledSpecification.CharacteristicUseLookups.CharValueToCharId
        };
        combinedCharUses.OrderItemCharacteristicUses = CharacteristicQueries.NormalizeCharUses(uuid, combinedCharUses.OrderItemCharacteristicUses, combinedCharUses.ValueIDToCharacteristicIDLookup);
        this.PopulateMissingCharUseData(combinedCharUses.OrderItemCharacteristicUses, compiledSpecification, uuid, itemPair.EntityUniqueCode, orderfolioItemAction, errorContext);
        combinedCharUses.PortfolioItemCharacteristicUses = CharacteristicQueries.NormalizeCharUses(uuid, combinedCharUses.PortfolioItemCharacteristicUses, combinedCharUses.ValueIDToCharacteristicIDLookup);
        this.PopulateMissingCharUseData(combinedCharUses.PortfolioItemCharacteristicUses, compiledSpecification, uuid, itemPair.EntityUniqueCode, orderfolioItemAction, errorContext);
        return combinedCharUses;
    };
    /**
     * Builds and normalizes orderfolio user defined characteristic uses
     * @param   {string} uuid The uuid of the orderfolio item the user defined characteristic uses are located on
     * @param   {ItemPair} itemPair The order item and portfolio item pair for this orderfolio item
     * @param   {CsTypes.CompiledSpecification} compiledSpecification The specification definition of the orderfolio
     * @param   {string} orderfolioItemAction The item action for the orderfolio item
     * @param   {CsErrorContext} errorContext The collection of errors raised during processing
     * @returns {CombinedCharacteristicUses}
     */
    CharacteristicQueries.BuildOrderfolioUserDefinedCharacteristicUses = function (uuid, itemPair, compiledSpecification, orderfolioItemAction, errorContext) {
        var combinedUDCs = {
            OrderItemUDCs: itemPair.OrderItem && itemPair.OrderItem.ConfiguredValues ? itemPair.OrderItem.ConfiguredValues : [],
            PortfolioItemUdcs: itemPair.PortfolioItem && itemPair.PortfolioItem.ConfiguredValues ? itemPair.PortfolioItem.ConfiguredValues : []
        };
        CharacteristicQueries.PopulateMissingCharUseData(combinedUDCs.OrderItemUDCs, compiledSpecification, uuid, itemPair.EntityUniqueCode, orderfolioItemAction, errorContext, true);
        CharacteristicQueries.PopulateMissingCharUseData(combinedUDCs.PortfolioItemUdcs, compiledSpecification, uuid, itemPair.EntityUniqueCode, orderfolioItemAction, errorContext, true);
        return combinedUDCs;
    };
    /**
    * Groups / Normalizes the char uses by char ID
    * @param {string} uuid of the item for which the supplied char uses exists on
    * @param {Array<CharacteristicUse>} characteristicUses the char uses to be normalized
    * @param {CsTypes.Dictionary<string>} valueIdToCharIdLookup the valuedId to charId lookup table
    */
    CharacteristicQueries.NormalizeCharUses = function (uuid, characteristicUses, valueIdToCharIdLookup) {
        var allUses = Utilities.asArray(characteristicUses);
        var normalizedUses = [];
        // For each charUse, if it has a characteristic ID pass it through unmodified
        // Otherwise look up the characteristic ID using a lookup table -- this might result in more than one charUse element
        for (var c = 0; c < allUses.length; c++) {
            var charUse = allUses[c];
            // Has a CharacteristicID or a UseID, so assume it's already correct -- add to output and move on
            if (Utilities.IsDefined(charUse.CharacteristicID, true) || Utilities.IsDefined(charUse.UseID, true)) {
                normalizedUses.push(charUse);
                continue;
            }
            if (Utilities.IsNotDefined(charUse.Value, true)) {
                continue;
            }
            // Build the normalized characteristic use based on its values
            normalizedUses = normalizedUses.concat(CharacteristicQueries.BuildNormalizedCharacteristicUses(charUse, valueIdToCharIdLookup, uuid));
        }
        // return normalized characteristic uses
        return normalizedUses;
    };
    /**
     * Builds characteristic uses using a characteristic uses's values to determine its CharacteristicID
     * @param   {CharacteristicUse} charUse The characteristic use containing values to identify CharacteristicIDs for
     * @param   {CsTypes.Dictionary<string>} charUseIdLookup The dictionary of characteristic IDs keyed on uuid/useArea/valueID
     * @param   {string} uuid The uuid of the entity the characteristic use is located on
     * @returns {Array<CharacteristicUse>}
     */
    CharacteristicQueries.BuildNormalizedCharacteristicUses = function (charUse, charUseIdLookup, uuid) {
        var charUses = {};
        // Because a CharacteristicUse could represent a char use or a UDC, the Value is of type T
        // even though this method is not used for normalizing UDCs.
        var charUseValues = Utilities.asArray(charUse.Value);
        // Loop through the values on the characteristic use to find the characteristic ID
        // Note values may be provided under the same UseArea that have different characteristic IDs
        // This will result in creation of multiple characteristic uses with unique CharacteristicIDs
        for (var valueIndex = 0; valueIndex < charUseValues.length; valueIndex++) {
            // No ID, need to look for the char ID based on the ValueID
            var characteristicID = charUseIdLookup[uuid + "|" + charUse.UseArea + "|" + charUseValues[valueIndex].ValueID];
            var normalizedUse = charUses[characteristicID];
            if (Utilities.IsNotDefined(normalizedUse)) {
                normalizedUse = new CharacteristicUse({
                    UseArea: charUse.UseArea,
                    CharacteristicID: characteristicID,
                    Value: [],
                    Action: charUse.Action
                });
            }
            normalizedUse.Value.push(LodashUtilities.CloneTargetOnly(charUseValues[valueIndex]));
            charUses[characteristicID] = normalizedUse;
        }
        var normalizedUses = [];
        LodashUtilities.ForOwn(charUses, function (use) { return normalizedUses.push(use); });
        return normalizedUses;
    };
    /**
     * Populates the missing characteristic data and raises a validation error if it is not possible
     * Please note that we do not raise errors for orderfolio items that are marked as deleted
     * @param {CharacteristicUse} charUse The characteristic use
     * @param {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @param {string} uuid the uuid of the entity that the characteristic belongs to
     * @param {string} entityUniqueCode The entity unique code
     * @param {string} orderfolioItemAction The action of the orderfolio item that these characteristic uses belong to
     * @param {boolean} Whether this characteristic use is a boolean
     */
    CharacteristicQueries.PopulateMissingCharUseData = function (charUses, compiledSpecification, uuid, entityUniqueCode, orderfolioItemAction, errorContext, isUdc) {
        if (isUdc === void 0) { isUdc = false; }
        if (errorContext.HasBreakingErrors) {
            return;
        }
        // Populate missing data on characteristic uses given the information we have been provided
        for (var charUseIdx = 0; charUseIdx < charUses.length; charUseIdx++) {
            var charUse = charUses[charUseIdx];
            if (Utilities.IsDefined(charUse.CharacteristicID, true) && Utilities.IsDefined(charUse.UseArea, true)) {
                // If we have the CharacteristicID and UseArea, we can determine the UseID
                CharacteristicQueries.PopulateUseId(charUse, compiledSpecification, uuid, orderfolioItemAction, entityUniqueCode, errorContext);
            }
            else if (Utilities.IsDefined(charUse.UseID, true)) {
                // If we have the UseID, we can determine the CharacteristicID and UseArea
                CharacteristicQueries.PopulateCharacteristicIDAndUseArea(charUse, compiledSpecification, orderfolioItemAction, entityUniqueCode, errorContext);
            }
            else {
                // Unless we are deleting the item, we don't have enough data to proceed and should raise an error
                if (orderfolioItemAction === OrderActions.Delete) {
                    continue;
                }
                var itemName = (!isUdc) ? 'CharacteristicUse' : 'ConfiguredValue';
                errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: 'UseID, or CharacteristicID & UseArea', Item: itemName });
                return;
            }
        }
    };
    /**
     * Uses the CharacteristicID and UseArea to populate the UseID
     * @param   {CharacteristicUseBase<CharacteristicValueBase>} charUse The characteristic use to set the UseID on
     * @param   {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @param   {string} uuid The uuid of the orderfolio item
     * @param   {string} orderfolioItemAction The orderfolio item action
     * @param   {string} entityUniqueCode The unique code of the orderfolio item
     * @param   {CsErrorContext} errorContext The error context
     */
    CharacteristicQueries.PopulateUseId = function (charUse, compiledSpecification, uuid, orderfolioItemAction, entityUniqueCode, errorContext) {
        if (Utilities.IsDefined(charUse.UseID, true)) {
            return;
        }
        var useId = compiledSpecification.CharacteristicUseLookups.CharAndArea[uuid + "|" + charUse.UseArea + "|" + charUse.CharacteristicID];
        if (Utilities.IsNotDefined(useId, true)) {
            if (orderfolioItemAction === OrderActions.Delete) {
                return;
            }
            errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.InvalidCharacteristicUse, { EntityUniqueCode: entityUniqueCode, CharacteristicID: charUse.CharacteristicID });
            return;
        }
        else {
            charUse.UseID = useId;
        }
    };
    /**
     * Uses the UseID to populate the CharacteristicID and UseArea
     * @param   {CharacteristicUseBase<CharacteristicValueBase>} charUse The characteristic use to set the CharacteristicID and UseArea on
     * @param   {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @param   {string} orderfolioItemAction The orderfolio item action
     * @param   {string} entityUniqueCode The unique code of the orderfolio item
     * @param   {CsErrorContext} errorContext The error context
     */
    CharacteristicQueries.PopulateCharacteristicIDAndUseArea = function (charUse, compiledSpecification, orderfolioItemAction, entityUniqueCode, errorContext) {
        var charUseLookup = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseID];
        if (Utilities.IsNotDefined(charUseLookup, true)) {
            if (orderfolioItemAction === OrderActions.Delete) {
                return;
            }
            errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.InvalidCharacteristicUse, { EntityUniqueCode: entityUniqueCode, CharacteristicID: charUse.UseID });
            return;
        }
        else {
            charUse.CharacteristicID = charUseLookup.CharacteristicId;
            charUse.UseArea = charUseLookup.UseArea;
        }
    };
    /**
     * Gets the char use from the supplied collection with the supplied use area and char id
     * @param {Array<CharacteristicUse>} collection the collection to get the char use from
     * @param {string} useArea the use are that the udc must have
     * @param {string} characteristicID the char id that the udc must have
     * @returns {CharacteristicUse} the char use that matches the supplied char id and use area in the supplied collection
     */
    CharacteristicQueries.GetCharUseFromCollection = function (collection, useArea, characteristicID) {
        return LodashUtilities.Find(collection, function (charUse) {
            return charUse.UseArea === useArea && charUse.CharacteristicID === characteristicID;
        });
    };
    /**
     * Gets the char value from the supplied collection that has a given value
     * @param {Array<CharacteristicValue>} collection the collection to get the char value from
     * @param {string} valueID the valueID to match against
     * @returns {CharacteristicValue} the char value from the collection with the matching value
     */
    CharacteristicQueries.GetCharValueFromCollection = function (collection, valueID) {
        return LodashUtilities.Find(collection, function (charVal) {
            return charVal.ValueID === valueID;
        });
    };
    /**
     * Gets the udc from the supplied collection with the supplied use area and char id
     * @param {Array<IUserDefinedCharacteristicUse>} collection the collection to get the udc from
     * @param {string} useArea the use are that the udc must have
     * @param {string} characteristicID the char id that the udc must have
     * @returns {IUserDefinedCharacteristicUse} the udc that matches the supplied char id and use area in the supplied collection
     */
    CharacteristicQueries.GetUdcFromCollection = function (collection, useArea, characteristicID) {
        return LodashUtilities.Find(collection, function (udcUse) {
            return udcUse.UseArea === useArea && udcUse.CharacteristicID === characteristicID;
        });
    };
    /**
     * Gets the udc from the supplied collection that has a given value
     * @param {Array<UserDefinedCharacteristicValue>} collection the collection to get the udc from
     * @param {string} value the value to match against
     * @returns {UserDefinedCharacteristicValue} the udc from the collection with the matching value
     */
    CharacteristicQueries.GetUdcValueFromCollection = function (collection, value) {
        return LodashUtilities.Find(collection, function (udcValue) {
            return udcValue.Value === value;
        });
    };
    /**
     * Validates the values on a characteristic use and raises a validation error if there are any issues
     * @param {Array<CsTypes.MergedValue>} mergedValues The values on the characteristic use
     */
    CharacteristicQueries.ValidateCharacteristicValues = function (mergedValues, errorContext) {
        // Check that all of the values have a ValueID
        for (var charValueIdx = 0; charValueIdx < mergedValues.length; charValueIdx++) {
            var charValue = mergedValues[charValueIdx];
            // CharacteristicUes Values are Guids so an empty string is not acceptable
            if (Utilities.IsNotDefined(charValue.Value, true)) {
                errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: 'ValueID', Item: 'CharacteristicUse.Value' });
                return false;
            }
        }
        return true;
    };
    /**
     * Validates the values on a user defined characteristic use and raises a validation error if there are any issues
     * @param {Array<CsTypes.MergedValue>} mergedValues The values on the Udc
     * @returns {boolean}
     */
    CharacteristicQueries.ValidateUdcValues = function (mergedValues, errorContext) {
        // Check that all of the values are defined, even if only with an empty string
        for (var udcValueIdx = 0; udcValueIdx < mergedValues.length; udcValueIdx++) {
            var udcValue = mergedValues[udcValueIdx];
            // Empty strings are valid values for UDC
            if (Utilities.IsNotDefined(udcValue.Value)) {
                errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: 'Value', Item: 'ConfiguredValue.Value' });
                return false;
            }
        }
        return true;
    };
    return CharacteristicQueries;
}());
module.exports = CharacteristicQueries;

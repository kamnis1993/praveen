"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BadDataTypes = require("../cs-lib-constants/BadDataTypes");
var CharacteristicBuilder = require("./CharacteristicBuilder");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var DateStatus = require("../cs-lib-constants/DateStatus");
var EntityLinkBuilder = require("./EntityLinkBuilder");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var ItemPairBuilder = require("./ItemPairBuilder");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderItem = require("../cs-lib-types/BusinessEntities/OrderItem");
var OrderfolioBuilderBase = require("./OrderfolioBuilderBase");
var OrderfolioLinkedEntityActions = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityActions");
var OrderfolioQueries = require("./OrderfolioQueries");
var PortfolioItem = require("../cs-lib-types/BusinessEntities/PortfolioItem");
var RateAttributeBuilder = require("./RateAttributeBuilder");
var Utilities = require("../cs-lib-utilities/Utilities");
/*
 * Class contains methods for manipulating / building an orderfolio
 */
var OrderfolioBuilder = /** @class */ (function (_super) {
    __extends(OrderfolioBuilder, _super);
    /**
     * Creates a new instance of the OrderfolioBuilder
     * @param {CsErrorContext} errorContext the error context to use during the build process
     * @param {string} The request ID
     */
    function OrderfolioBuilder(errorContext, requestId) {
        var _this = _super.call(this, errorContext, requestId) || this;
        _this._itemPairBuilder = new ItemPairBuilder(errorContext);
        _this._entityLinkBuilder = new EntityLinkBuilder(errorContext, requestId);
        _this._characteristicBuilder = new CharacteristicBuilder(errorContext, requestId);
        _this._rateAttributeBuilder = new RateAttributeBuilder(errorContext, requestId);
        return _this;
    }
    /**
     * Builds an orderfolio using the supplied itemPair and compiledSpec
     * @param {ItemPair} itemPair -- the item pair to create an orderfolio for
     * @param {CsTypes.DecomposeContext} decomposeContext -- the decompose context that contains the orderfolio that we want to build
     * @param {boolean} isProductCandidate Whether we are building for a product candidate
     */
    OrderfolioBuilder.prototype.Build = function (itemPair, decomposeContext, isProductCandidate) {
        if (isProductCandidate === void 0) { isProductCandidate = false; }
        // Keep track of all the item pairs we have created for this decompose context
        var itemPairsProcessed = [];
        var rootAction = (itemPair.OrderItem) ? (itemPair.OrderItem.ItemAction) : (OrderActions.NoChange);
        this.PopulateOrderfolio([itemPair], itemPairsProcessed, [decomposeContext.CompiledSpec.CompositionTree], decomposeContext, isProductCandidate, { LastKnownAction: rootAction }, null, null);
        if (this._errorContext.HasBreakingErrors) {
            return;
        }
        this._entityLinkBuilder.BuildLinkedEntityLookups(itemPairsProcessed, decomposeContext);
        OrderfolioLinkedEntityActions.ApplyEntityLinks(decomposeContext);
    };
    /**
     * Builds an orderfolio using the supplied productCandidate and compiledSpec
     * @param {IProductCandidate} itemPair -- source structure
     * @param {CsTypes.DecomposeContext} decomposeContext -- the decompose context that contains the target orderfolio
     */
    OrderfolioBuilder.prototype.BuildFromProductCandidate = function (productCandidate, decomposeContext) {
        if (this._errorContext.HasBreakingErrors) {
            return;
        }
        if (!decomposeContext || !(decomposeContext.CompiledSpec) || !(decomposeContext.CompiledSpec.CharacteristicUseLookups.UseIdToCharacteristic)) {
            Logger.debug(0, "OrderfolioBuilder", "Invalid CompiledSpec Error");
            this._errorContext.RaiseBadDataError(ErrorCode.BadData.InvalidCompiledSpec, undefined, BadDataTypes.FatalBadData);
            return;
        }
        // tree surgeon functions
        var rewrite = function (kind) { return (kind === "ChildEntities") ? ("ChildOrderItems") : (kind); };
        productCandidate = ConverterUtils.RecurseTree(productCandidate, rewrite);
        // Note actions are set by the state of the IsNewForCustomer flag
        var orderItem = new OrderItem(productCandidate, null, true);
        var itemPair = {
            EntityID: productCandidate.EntityID,
            EntityUniqueCode: orderItem.ID,
            PortfolioItem: null,
            OrderItem: orderItem
        };
        this.Build(itemPair, decomposeContext, true);
    };
    /**
     * Populates the supplied orderfolio using the supplied itemPairs and spec entities
     * @param {Array<ItemPair>} itemPairs The item pairs to use to populate the orderfolio
     * @param {Array<CsTypes.SpecItem>} specEntities The spec entities to use to populate the orderfolio process
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context to populate the parent child tables on
     * @param {boolean} isProductCandidate Whether this is a product candidate
     * @param {string} parentOrderfolioItemStatus The status of the parent portfolio item
     * @param {string} parentKey? The parent key
     * @param {ItemPair} parentItemPair? The parent item pair
     */
    OrderfolioBuilder.prototype.PopulateOrderfolio = function (itemPairs, itemPairsProcessed, specEntities, decomposeContext, isProductCandidate, parentOrderfolioItemStatus, parentKey, parentItemPair) {
        if (this._errorContext.HasBreakingErrors) {
            return;
        }
        if (!parentOrderfolioItemStatus || !parentOrderfolioItemStatus.LastKnownAction) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.MissingParentAction);
            return;
        }
        // SUMMARY - This method is passed a list of item pairs, An item pair consist of an order item, and the corresponding portfolio item which that order item targets.
        // It is also valid for an item pair to consist of a portfolio item without an order item.The idea is that the method should combine the 2 items into an OrderfolioItem.
        // The method is also passed a list of entities(spec entities).The supplied item pairs should correspond to an entity in this list, i.e.we walk the entity tree and item pairs together
        var invalidItemPairs = this.GetInvalidItems(itemPairs, specEntities);
        var parentAction = OrderfolioQueries.CascadeActionFromParent(parentItemPair, parentOrderfolioItemStatus.LastKnownAction);
        for (var p = 0; p < invalidItemPairs.length; p++) {
            var invalidItemPair = invalidItemPairs[p];
            this._errorContext.RaiseValidationError(ErrorCode.Validation.UnexpectedChild, invalidItemPair.EntityUniqueCode, invalidItemPair.EntityID);
            Logger.debug(0, "OrderfolioBuilder", "UnexpectedChild Error:", {
                EntityId: invalidItemPair.EntityID,
                EntityUniqueCode: invalidItemPair.EntityUniqueCode
            });
        }
        var orderfolio = decomposeContext.Orderfolio;
        var atLeastOneTechnicalItemExists = false;
        for (var c = 0; c < specEntities.length; c++) {
            var specEntity = specEntities[c];
            if (!atLeastOneTechnicalItemExists) {
                atLeastOneTechnicalItemExists = this.IsTechnicalItem(specEntity.Key, decomposeContext.CompiledSpec);
            }
            var itemPairsWithMatchingEntityId = itemPairs.filter(function (itemPair) { return itemPair.EntityID === specEntity.EntityId; });
            if (itemPairsWithMatchingEntityId.length === 0) {
                continue;
            }
            var newOrderfolioItems = this.BuildOrderfolioItems(itemPairsWithMatchingEntityId, itemPairsProcessed, specEntity.Key, decomposeContext.CompiledSpec, parentAction, parentOrderfolioItemStatus, isProductCandidate);
            this.InsertOrderfolioItems(specEntity.Key, newOrderfolioItems, orderfolio);
            for (var j = 0; j < itemPairsWithMatchingEntityId.length; j++) {
                var itemPairForEntityID = itemPairsWithMatchingEntityId[j];
                if (this._errorContext.HasBreakingErrors) {
                    return;
                }
                var orderfolioItemLookup = OrderfolioQueries.GetDictionaryKeyForItem(itemPairForEntityID, specEntity, orderfolio, this._errorContext);
                if (this._errorContext.HasBreakingErrors) {
                    return;
                }
                var dictionaryKey = orderfolioItemLookup.Key + "-" + orderfolioItemLookup.Index;
                if (parentKey) {
                    this.UpdateParentToChildDictionary(decomposeContext.ParentToChildTable, parentKey, dictionaryKey);
                    this.UpdateChildToParentDictionary(decomposeContext.ChildToParentTable, dictionaryKey, parentKey);
                    // Check the order action validity
                    this.CheckOrderActionIsValid(itemPairForEntityID, parentKey, decomposeContext);
                }
                var orderfolioItem = orderfolio[orderfolioItemLookup.Key][orderfolioItemLookup.Index];
                // If the orderfolio item is invalid, then we do not process any more children on it, when we come to output the response, the order and portfolio from this point
                // Will be returned exactly as it was in the request
                if (orderfolioItem.IsInvalid) {
                    continue;
                }
                var childEntities = Utilities.IsDefined(itemPairForEntityID.PortfolioItem) ? Utilities.asArray(itemPairForEntityID.PortfolioItem.ChildEntities) : [];
                var childOrderItems = Utilities.IsDefined(itemPairForEntityID.OrderItem) ? Utilities.asArray(itemPairForEntityID.OrderItem.ChildOrderItems) : [];
                if (childEntities.length === 0 && childOrderItems.length === 0) {
                    continue;
                }
                if (!decomposeContext.ParentToChildTable[dictionaryKey]) {
                    decomposeContext.ParentToChildTable[dictionaryKey] = [];
                }
                // This node's action to cascade to children. If the entity is not in the order, default the parent
                var thisAction = itemPairForEntityID.OrderItem && itemPairForEntityID.OrderItem.ItemAction ? itemPairForEntityID.OrderItem.ItemAction : parentOrderfolioItemStatus.LastKnownAction;
                var itemPairsForChildren = this._itemPairBuilder.CreateItemPairs(childEntities, childOrderItems, isProductCandidate);
                this.PopulateOrderfolio(itemPairsForChildren, itemPairsProcessed, specEntity.Children, decomposeContext, isProductCandidate, { LastKnownAction: thisAction }, dictionaryKey, itemPairForEntityID); // RECURSION
            }
        }
        if (atLeastOneTechnicalItemExists && parentKey) {
            this.MarkOrderfolioToIndicateItContainsTechnicalChildren(parentKey, decomposeContext);
        }
    };
    /**
     * Builds the supplied itempairs into an array of orderfolio items
     * @param {Array<ItemPair>} itemPairs the itemPairs to combine
     * @param {CsTypes.Uuid} uuid the uuid for the created orderfolio item
     * @param {CsTypes.Dictionary<string>} valueIdToCharIdLookup the table that relates a characteristic value to a characteristic id for a given uuid and user area
     * @param {string} parentAction The action for the parent item pair
     * @param {ParentOrderfolioItemStatus} parentOrderfolioItemStatus The status of the parent orderfolio item
     * @returns {Array<CsTypes.OrderfolioItem>} the combined itempair as an orderfolio item
     */
    OrderfolioBuilder.prototype.BuildOrderfolioItems = function (itemPairs, itemPairsProcessed, uuid, compiledSpecification, parentAction, parentOrderfolioItemStatus, isProductCandidate) {
        var orderfolioItems = [];
        for (var c = 0; c < itemPairs.length; c++) {
            var itemPair = itemPairs[c];
            itemPair.Uuid = uuid;
            itemPairsProcessed.push(itemPair);
            var dateInfo = compiledSpecification.EntityDates[uuid];
            var orderfolioItem = this.BuildOrderfolioItem(itemPair, compiledSpecification, parentAction, parentOrderfolioItemStatus, dateInfo);
            if (orderfolioItem.IsInvalid) {
                var action = Utilities.IsNotDefined(orderfolioItem.Action) ? OrderActions.NoChange : orderfolioItem.Action;
                if (action === OrderActions.NoChange) {
                    this._errorContext.RaiseValidationError(ErrorCode.Validation.EntityOutOfDate, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, { DateMessage: OrderfolioBuilder.BuildDateMessage(dateInfo.DateStatus) });
                }
                else {
                    this._errorContext.RaiseValidationError(ErrorCode.Validation.ActionNotAllowed, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, { Action: action, DateMessage: OrderfolioBuilder.BuildDateMessage(dateInfo.DateStatus) });
                }
                orderfolioItem.ItemPair = this.BuildItemPairForInvalidItem(itemPair, isProductCandidate);
            }
            orderfolioItems.push(orderfolioItem);
        }
        return orderfolioItems;
    };
    /**
     * Builds the orderfolio items
     * @param {ItemPair} itemPair The item pair
     * @param {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @param {string} parentAction The parent action
     * @param {ParentOrderfolioItemStatus} parentOrderfolioItemStatus The parent orderfolio item status
     * @param {CsTypes.DateInfo} dateInfo The date info
     * @returns {CsTypes.OrderfolioItem}
     */
    OrderfolioBuilder.prototype.BuildOrderfolioItem = function (itemPair, compiledSpecification, parentAction, parentOrderfolioItemStatus, dateInfo) {
        // If the parent is deleted then the child will always be deleted, otherwise take the action on the order
        var itemAction = OrderfolioQueries.CascadeActionFromParent(itemPair, parentAction);
        var portfolioItemId = itemPair.OrderItem ? itemPair.OrderItem.PortfolioItemID : itemPair.PortfolioItem.ID;
        if (Utilities.IsNotDefined(portfolioItemId, true)) {
            portfolioItemId = Utilities.CreateID();
        }
        var entityTemplate = compiledSpecification.EntityTemplateLookup[itemPair.Uuid.toString()];
        var isAdditionalCharge = Utilities.IsDefined(entityTemplate) ? entityTemplate.IsAdditionalCharge : false;
        var isExcludedCharge = Utilities.IsDefined(entityTemplate) ? entityTemplate.IsExcludedCharge : false;
        var isExcludedCost = Utilities.IsDefined(entityTemplate) ? entityTemplate.IsExcludedCost : false;
        var isExcludedDiscount = Utilities.IsDefined(entityTemplate) ? entityTemplate.IsExcludedDiscount : false;
        var chargeInfo = Utilities.IsDefined(compiledSpecification.ChargeLookups) ? compiledSpecification.ChargeLookups.ChargeUuidToChargeInfo[itemPair.Uuid.toString()] : undefined;
        var costInfo = Utilities.IsDefined(compiledSpecification.CostLookups) ? compiledSpecification.CostLookups.CostUuidToCostInfo[itemPair.Uuid.toString()] : undefined;
        var discountInfo = Utilities.IsDefined(compiledSpecification.DiscountLookups) ? compiledSpecification.DiscountLookups.DiscountUuidToDiscountInfo[itemPair.Uuid.toString()] : undefined;
        var chargeType, costType, discountType, exactType, periodicity = undefined;
        if (Utilities.IsDefined(chargeInfo)) {
            chargeType = chargeInfo.ChargeType;
            exactType = chargeInfo.ExactType;
            periodicity = chargeInfo.Periodicity;
        }
        else if (Utilities.IsDefined(costInfo)) {
            costType = costInfo.CostType;
            exactType = costInfo.ExactType;
            periodicity = costInfo.Periodicity;
        }
        else if (Utilities.IsDefined(discountInfo)) {
            discountType = discountInfo.DiscountType;
            exactType = discountInfo.ExactType;
        }
        var orderfolioItem = {
            CompoundKey: { Key: itemPair.Uuid, Index: 0 },
            EntityId: itemPair.EntityID,
            EntityUniqueCode: itemPair.EntityUniqueCode,
            PortfolioItemId: portfolioItemId,
            OrderItemId: (Utilities.IsDefined(itemPair.OrderItem)) ? (itemPair.OrderItem.ID) : (undefined),
            OrderItemSource: this.GetItemSource(itemPair.OrderItem, itemPair.PortfolioItem),
            PortfolioItemSource: this.GetItemSource(itemPair.PortfolioItem, itemPair.OrderItem),
            Action: itemAction,
            CharacteristicUses: [],
            UserDefinedCharacteristics: [],
            RatingAttributes: [],
            HasTechnicalChildrenInSpec: false,
            IsInvalid: OrderfolioBuilder.IsOrderfolioItemInvalid(itemPair.Uuid, itemAction, dateInfo),
            IsAdditionalCharge: isAdditionalCharge,
            IsExcludedCharge: isExcludedCharge,
            IsExcludedCost: isExcludedCost,
            IsExcludedDiscount: isExcludedDiscount,
            UnitQuantity: (Utilities.IsDefined(itemPair.OrderItem)) ? (Utilities.ParseAsNumber(itemPair.OrderItem.UnitQuantity, undefined)) : (undefined),
            ChargeType: chargeType,
            CostType: costType,
            DiscountType: discountType,
            ExactType: exactType,
            Periodicity: (Utilities.IsDefined(periodicity)) ? periodicity : undefined,
            ItemAdded: undefined,
            RateDetail: (Utilities.IsDefined(itemPair.OrderItem)) ? itemPair.OrderItem.RateDetail : undefined
        };
        orderfolioItem.CharacteristicUses = this._characteristicBuilder.CombineCharacteristicUses(itemPair, orderfolioItem, compiledSpecification);
        orderfolioItem.UserDefinedCharacteristics = this._characteristicBuilder.CombineUserDefinedCharacteristics(itemPair, orderfolioItem, compiledSpecification);
        orderfolioItem.RatingAttributes = this._rateAttributeBuilder.CombineRatingAttributes(itemPair, orderfolioItem);
        return orderfolioItem;
    };
    /**
     * Builds the item pair for an invalid items
     * @param {ItemPair} itemPair The item pair
     * @param {boolean} isProductCandidate Whether this is a product candidate
     * @returns {ItemPair}
     */
    OrderfolioBuilder.prototype.BuildItemPairForInvalidItem = function (itemPair, isProductCandidate) {
        // Store off the item pair to build into the response later, we are not going to be building any orderfolio items below this point
        // The portfolio and order from this point will be returned exactly as it was in the request
        // If this is a product candidate then we need to store off a portfolio item as it doesn't look at the order item when building the request
        if (isProductCandidate) {
            itemPair.PortfolioItem = OrderfolioBuilder.ConvertToPortfolioItem(itemPair.OrderItem);
        }
        else {
            if (Utilities.IsDefined(itemPair.PortfolioItem)) {
                itemPair.PortfolioItem.ItemAction = OrderActions.Invalid;
            }
        }
        return itemPair;
    };
    /**
     * Determines whether the other actions is valid given the order action on the parent item.
     * @param {string} orderAction the order action to validate
     * @param {string} parentKey the key of the parent orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context that contains the orderfolio
     * @returns {boolean} a value indicating if the supplied action is valid
     */
    OrderfolioBuilder.prototype.CheckOrderActionIsValid = function (childItemPair, parentKey, decomposeContext) {
        // If no orderitem, then nothing to check
        if (Utilities.IsNotDefined(childItemPair.OrderItem)) {
            return;
        }
        var childAction = childItemPair.OrderItem.ItemAction;
        var parentOrderfolioItem = this.GetOrderfolioGivenKey(decomposeContext, parentKey);
        var invalid = this.ValidateOrderItemAction(parentOrderfolioItem, childAction);
        if (invalid) {
            // Use Order Item ID as preference as actions are order related
            var parentUniqueCode = parentOrderfolioItem.EntityUniqueCode;
            var parentEntityId = parentOrderfolioItem.EntityId;
            var childUniqueCode = childItemPair.EntityUniqueCode;
            var childEntityId = childItemPair.OrderItem.EntityID;
            var extrainfo = 'Parent Action: ' + parentOrderfolioItem.Action + ' Child Action: ' + childAction;
            this._errorContext.RaiseValidationErrorWithChildInfo(ErrorCode.Validation.InvalidInputStructure, parentUniqueCode, parentEntityId, childUniqueCode, childEntityId, null, null, extrainfo);
        }
    };
    /**
     * Validates an order item action against the parent orderfolio item action
     * @param   {CsTypes.OrderfolioItem} parentOrderfolioItem the parent orderfolio item
     * @param   {string} childAction the action on the child orderfolio item to check
     * @returns {boolean}
     */
    OrderfolioBuilder.prototype.ValidateOrderItemAction = function (parentOrderfolioItem, childAction) {
        // Its not valid to have an order action that exists underneath an orderfolio item with no action
        if (parentOrderfolioItem.Action) {
            switch (parentOrderfolioItem.Action) {
                case OrderActions.Add:
                    return (childAction !== OrderActions.Add && childAction !== OrderActions.Reassigned && childAction !== OrderActions.ReassignedUpdate);
                case OrderActions.Delete:
                    return (childAction !== OrderActions.Delete && childAction !== OrderActions.Reassign);
                default:
                    return false;
            }
        }
        return false;
    };
    /**
     * Given a compound key (in string form) retrieve the orderfolio item from a DecomposeContext
     * @param {CsTypes.DecomposeContext} decomposeContext The DecomposeContext which holds the OrderfolioItem
     * @param {string} key the compound key in the string form "key-index"
     * @returns {CsTypes.OrderfolioItem} the OrderfolioItem find
     */
    OrderfolioBuilder.prototype.GetOrderfolioGivenKey = function (decomposeContext, key) {
        var keyParts = key.split('-');
        var orderfolioKey = keyParts[0];
        var orderfolioItemIndex = parseInt(keyParts[1]);
        return decomposeContext.Orderfolio[orderfolioKey][orderfolioItemIndex];
    };
    /**
     * Updates all the orderfolio items for the supplied key to indicate that they have technical children in their specification
     * @param {string} orderfolioKey the key of the orderfolio items to update
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context that contains the orderfolio->orderfolio items to update
     */
    OrderfolioBuilder.prototype.MarkOrderfolioToIndicateItContainsTechnicalChildren = function (orderfolioCompoundKey, decomposeContext) {
        var orderfolioKeyParts = orderfolioCompoundKey.split('-');
        if (orderfolioKeyParts.length !== 2) {
            return;
        }
        var orderfolioItems = decomposeContext.Orderfolio[orderfolioKeyParts[0]];
        if (!orderfolioItems) {
            return;
        }
        for (var c = 0; c < orderfolioItems.length; c++) {
            orderfolioItems[c].HasTechnicalChildrenInSpec = true;
        }
    };
    /**
     * Indicates if the supplied key is the key of a technical item
     * @param {CsTypes.Uuid} key the key of the item to check the technicality of
     * @param {CsTypes.CompiledSpecification} compiledSpecification the compiled spec that contains the list of all technical items
     * @returns {boolean} true or false indicating if the items is technical or not
     */
    OrderfolioBuilder.prototype.IsTechnicalItem = function (key, compiledSpecification) {
        return compiledSpecification.TechnicalItems ? compiledSpecification.TechnicalItems.indexOf(key) >= 0 : false;
    };
    /**
     * Filters out item pairs that are not expected at this level in the specification
     * @param {Array<ItemPair>} itemPairs the items pairs to filter
     * @param {Array<CsTypes.SpecItem>} specEntities the spec entities to consult when filtering
     * @returns {Array<ItemPair>} the invalid item pairs
     */
    OrderfolioBuilder.prototype.GetInvalidItems = function (itemPairs, specEntities) {
        return itemPairs.filter(function (itemPair) {
            return !specEntities.some(function (specEntity) {
                return specEntity.EntityId === itemPair.EntityID;
            });
        });
    };
    /**
     * Inserts the supplied orderfolio items into the orderfolio at the supplied 'key' position
     * @param {string} itemKey the key that points to the array to insert the supplied orderfolio items into
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the orderfolio items to insert
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItem>>} orderfolio the orderfolio to insert the items into
     */
    OrderfolioBuilder.prototype.InsertOrderfolioItems = function (itemKey, orderfolioItems, orderfolio) {
        var orderfolioItemSet = orderfolio[itemKey];
        // Adds flag if there is an 'add' Action on the orderfolioItem
        if (orderfolioItems[0].Action === "add") {
            orderfolioItems[0].ItemAdded = true;
        }
        if (orderfolioItemSet) {
            this.AssignIndexToCompositeKeys(orderfolioItems, orderfolioItemSet.length);
            orderfolio[itemKey] = orderfolioItemSet.concat(orderfolioItems);
        }
        else {
            this.AssignIndexToCompositeKeys(orderfolioItems, 0);
            orderfolio[itemKey] = orderfolioItems;
        }
        Logger.debug(0, "OrderfolioBuilder", "Item added to Orderfolio:", {
            EntityId: orderfolioItems[0].EntityId,
            EntityUniqueCode: orderfolioItems[0].EntityUniqueCode
        });
    };
    /**
     * Updates the child to parent dictionary using the supplied parent/child keys
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItemLookup>} childToParentTable the table to update
     * @param {string} childKey the key that uniquely identifies the child orderfolio item
     * @param {string} parent the key that uniquely identifies the parent orderfolio item
     */
    OrderfolioBuilder.prototype.UpdateChildToParentDictionary = function (childToParentTable, childKey, parentKey) {
        var parentKeyParts = parentKey.split('-');
        var parentLookup = { Key: parentKeyParts[0], Index: parseInt(parentKeyParts[1]) };
        childToParentTable[childKey] = parentLookup;
    };
    /**
     * Updates the parent to child dictionary using the supplied parent/child keys
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderfolioItemLookup>>} parentToChildTable the table to update
     * @param {string} parentKey the key that uniquely identifies the parent orderfolio item
     * @param {string} childKey the key that uniquely identifies the child orderfolio item
     */
    OrderfolioBuilder.prototype.UpdateParentToChildDictionary = function (parentToChildTable, parentKey, childKey) {
        var childKeyParts = childKey.split('-');
        var childLookup = { Key: childKeyParts[0], Index: parseInt(childKeyParts[1]) };
        if (parentToChildTable[parentKey]) {
            parentToChildTable[parentKey].push(childLookup);
        }
        else {
            parentToChildTable[parentKey] = [childLookup];
        }
    };
    /**
     * Assign the index property of the composite key on each of the supplied orderfolio items, starting with the 'firstIndex'
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the list of orderfolio items
     * @param {number} firstIndex the first index to assign to an orderfolio item key->Index
     */
    OrderfolioBuilder.prototype.AssignIndexToCompositeKeys = function (orderfolioItems, firstIndex) {
        for (var c = 0; c < orderfolioItems.length; c++) {
            orderfolioItems[c].CompoundKey.Index = firstIndex + c;
        }
    };
    /**
     * Checks whether an orderfolio item is invalid based on its parent and the actions that are available for the orderfolio item
     * @param {CsTypes.Uuid} uuid The uuid of the orderfolio item
     * @param {string} itemAction The orderfolio item action
     * @param {CsTypes.DateInfo} dateInfo The date info
     * @returns {boolean}
     */
    OrderfolioBuilder.IsOrderfolioItemInvalid = function (uuid, itemAction, dateInfo) {
        var action = (Utilities.IsDefined(itemAction)) ? (itemAction) : (OrderActions.NoChange);
        if (Utilities.IsNotDefined(dateInfo.AvailableActions)) {
            return true;
        }
        return dateInfo.AvailableActions.indexOf(action) === -1;
    };
    /**
     * Converts an order item to a portfolio item
     * @param {OrderItem} orderItem The order item to convert
     * @returns {PortfolioItem}
     */
    OrderfolioBuilder.ConvertToPortfolioItem = function (orderItem) {
        // tree surgeon functions
        var rewrite = function (kind) { return (kind === "ChildOrderItems") ? ("ChildEntities") : (kind); };
        orderItem = ConverterUtils.RecurseTree(orderItem, rewrite);
        return new PortfolioItem(orderItem);
    };
    /**
     * Build the message for when errors with dates are returned
     * @param {string} dateStatus The date status to map
     * @returns {string}
     */
    OrderfolioBuilder.BuildDateMessage = function (dateStatus) {
        switch (dateStatus) {
            case DateStatus.BeforeEffective:
                return "before the Effective Start Date";
            case DateStatus.NotYetAvailable:
                return "before the Available Start Date";
            case DateStatus.NoLongerAvailable:
                return "after the Available End Date has passed";
            case DateStatus.AfterEffective:
                return "after the Effective End Date has passed";
            default:
                return "";
        }
    };
    return OrderfolioBuilder;
}(OrderfolioBuilderBase));
module.exports = OrderfolioBuilder;

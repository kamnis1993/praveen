"use strict";
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class responsible for building item pairs
 */
var ItemPairBuilder = /** @class */ (function () {
    function ItemPairBuilder(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Gets all the entities to build a decompose context for
     * @param {OrderCandidateRequest} orderCandidateRequest The order candidate request that contains the root portfolio / order items
     * @param {isProductCandidate} whether this request is a product candidate
     * @returns {Array<PortfolioOrderItemPair>} A list of entity pairs that will share a decompose context
     */
    ItemPairBuilder.prototype.GetItemsToBuildContextsFor = function (orderCandidateRequest, isProductCandidate) {
        var rootOrderItems = Utilities.asArray(orderCandidateRequest.OrderCandidate.OrderItems);
        var rootPortfolioItems = [];
        if (Utilities.IsDefined(orderCandidateRequest.CustomerPortfolio) && orderCandidateRequest.CustomerPortfolio.PortfolioItems) {
            rootPortfolioItems = orderCandidateRequest.CustomerPortfolio.PortfolioItems;
        }
        return this.CreateItemPairs(rootPortfolioItems, rootOrderItems, isProductCandidate);
    };
    /**
     * Creates item pairs from the portfolio and order items passed in
     * @param {Array<PortfolioItem>} portfolioItems The portfolio items
     * @param {Array<OrderItem>} orderItems The order items
     * @param {isProductCandidate} whether this request is a product candidate
     * @returns {Array<ItemPair>}
     */
    ItemPairBuilder.prototype.CreateItemPairs = function (portfolioItems, orderItems, isProductCandidate) {
        var entitiesToBuildAContextsFor = [];
        for (var orderItemIdx = 0; orderItemIdx < orderItems.length; orderItemIdx++) {
            var orderItem = orderItems[orderItemIdx];
            if (!orderItem.EntityID) {
                this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.NoOrderEntityIDSupplied, { OrderItemID: orderItem.ID });
                return entitiesToBuildAContextsFor;
            }
            var newItemPair = {
                EntityID: orderItem.EntityID,
                EntityUniqueCode: orderItem.ID,
                PortfolioItem: null,
                OrderItem: orderItem
            };
            var portfolioItemForOrderItem = this.GetPortfolioItemWithID(orderItem.PortfolioItemID, portfolioItems);
            if (isProductCandidate || this.IsValidOrderItem(orderItem, portfolioItemForOrderItem)) {
                if (Utilities.IsDefined(portfolioItemForOrderItem)) {
                    newItemPair.PortfolioItem = portfolioItemForOrderItem;
                }
                entitiesToBuildAContextsFor.push(newItemPair);
            }
            else if (this._errorContext.HasBreakingErrors) {
                return entitiesToBuildAContextsFor;
            }
        }
        var HaveWeAlreadyAddedThisPortfolioItem = function (portfolioItem) {
            return entitiesToBuildAContextsFor.some(function (pair) {
                return Utilities.IsDefined(pair.PortfolioItem) && pair.PortfolioItem.ID === portfolioItem.ID;
            });
        };
        for (var portfolioItemIdx = 0; portfolioItemIdx < portfolioItems.length; portfolioItemIdx++) {
            var portfolioItem = portfolioItems[portfolioItemIdx];
            if (Utilities.IsNotDefined(portfolioItem.ID, true)) {
                this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.PortfolioItemIDMissing);
                return entitiesToBuildAContextsFor;
            }
            if (!HaveWeAlreadyAddedThisPortfolioItem(portfolioItem)) {
                if (!portfolioItem.EntityID) {
                    this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.NoPortfolioEntityIDSupplied, { PortfolioItemID: portfolioItem.ID });
                    return entitiesToBuildAContextsFor;
                }
                entitiesToBuildAContextsFor.push({
                    EntityID: portfolioItem.EntityID,
                    EntityUniqueCode: portfolioItem.ID,
                    PortfolioItem: portfolioItem,
                    OrderItem: null
                });
            }
        }
        return entitiesToBuildAContextsFor;
    };
    /**
     * Determines whether this is a valid order item for the portfolio item
     * @param {OrderItem} orderItem The order item to check
     * @param {PortfolioItem} portfolioItemForOrderItem The portfolio item linked to this order item
     * @returns {boolean}
     */
    ItemPairBuilder.prototype.IsValidOrderItem = function (orderItem, portfolioItemForOrderItem) {
        if (Utilities.IsDefined(portfolioItemForOrderItem)) {
            if (orderItem.EntityID !== portfolioItemForOrderItem.EntityID) {
                this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.EntityIDDoesNotMatch, { PortfolioItemID: portfolioItemForOrderItem.ID, EntityID: portfolioItemForOrderItem.EntityID });
                return false;
            }
            if (orderItem.ItemAction !== OrderActions.Add) {
                return true;
            }
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.AttemptToAddDuplicateItem, { OrderItemID: orderItem.ID });
            return false;
        }
        if (this.OrderItemActionIsValidWithoutPortfolioId(orderItem)) {
            return true;
        }
        if (this.ParentOrderItemActionIsValidWithoutPortfolioId(orderItem)) {
            return true;
        }
        if (Utilities.IsNotDefined(orderItem.PortfolioItemID, true)) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.OrderPortfolioItemIDMissing, { OrderItemID: orderItem.ID });
        }
        else {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.OrderNotApplicableToPortfolio.PortfolioItemMissing, { OrderItemID: orderItem.ID, PortfolioItemID: orderItem.PortfolioItemID });
        }
        return false;
    };
    /**
    * Check if an order item action is valid without a portfolio id
    * @param {OrderItem} orderItem - The order item to check
    */
    ItemPairBuilder.prototype.OrderItemActionIsValidWithoutPortfolioId = function (orderItem) {
        if (Utilities.IsNotDefined(orderItem.ItemAction, true)) {
            return false;
        }
        return (orderItem.ItemAction === OrderActions.Add
            || orderItem.ItemAction === OrderActions.Reassign
            || orderItem.ItemAction === OrderActions.Reassigned
            || orderItem.ItemAction === OrderActions.ReassignedUpdate);
    };
    /**
    * Check if an order item action is valid without a portfolio id based on it's parent order item action
    * @param {OrderItem} orderItem - The order item to check
    */
    ItemPairBuilder.prototype.ParentOrderItemActionIsValidWithoutPortfolioId = function (orderItem) {
        if (Utilities.IsNotDefined(orderItem.ItemAction, true)) {
            return false;
        }
        if (Utilities.IsNotDefined(orderItem.ParentItemAction, true)) {
            return false;
        }
        // We do not need to check that a portolio item exists for any child
        // who's parent has a reassigned or reassignedUpdate action
        return (orderItem.ParentItemAction === OrderActions.Reassigned
            || orderItem.ParentItemAction === OrderActions.ReassignedUpdate);
        // Note. Child actions under a reassigned or reassignedUpdate item are validated
        // in DecomposeContextBuilder.ts ValidateReassignItemActions()
    };
    /**
     * Checks the supplied collection to see if it contains an item with the same PortfolioItemID as the one supplied
     * @param {string} portfolioItemID the ID of the portfolio item to search the collection for
     * @param {Array<PortfolioItem>} items The collection of portfolio items to search for the entity
     * @returns {boolean} true or false indicating if the entity exists in the collection or not
     */
    ItemPairBuilder.prototype.GetPortfolioItemWithID = function (portfolioItemID, portfolioItems) {
        var matchingItems = portfolioItems.filter(function (portfolioItem) {
            return (portfolioItemID === portfolioItem.ID);
        });
        if (matchingItems.length > 0) {
            return matchingItems[0];
        }
        return undefined;
    };
    return ItemPairBuilder;
}());
module.exports = ItemPairBuilder;

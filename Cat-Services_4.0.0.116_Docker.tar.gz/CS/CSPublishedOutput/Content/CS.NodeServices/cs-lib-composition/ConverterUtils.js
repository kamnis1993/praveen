"use strict";
var Utilities = require("../cs-lib-utilities/Utilities");
var ConverterUtils = /** @class */ (function () {
    function ConverterUtils() {
    }
    /**
     * Finds properties with plural names and returns the input with the singular version of the name
     * @param input -- the object to singularize
     * @returns -- an object with singularized names
     */
    ConverterUtils.OrderSingularize = function (input) {
        var outputNameRenderer = function (propertyName) {
            return ConverterUtils.SingularizePropertyName(propertyName);
        };
        var output = this.RecurseTree(input, outputNameRenderer);
        return output;
    };
    /**
     * Finds properties with singular names and returns the input with the plural version of the name
     * @param input -- the object to pluralize
     * @returns -- an object with pluralized names
     */
    ConverterUtils.OrderPluralize = function (input) {
        var outputNameRenderer = function (propertyName) {
            return ConverterUtils.PluralizePropertyName(propertyName);
        };
        var output = this.RecurseTree(input, outputNameRenderer);
        return output;
    };
    /**
     * Recurse over a tree structure running the supplied function on each property name
     * @param input
     * @param func
     * @returns
     */
    ConverterUtils.RecurseTree = function (input, func) {
        var _this = this;
        if (input === null || typeof input !== "object") {
            return input;
        }
        // build will be the output object
        var build = {};
        // Handle array just by handling their contents
        if (Array.isArray(input)) {
            build = input.map(function (item) { return _this.RecurseTree(item, func); });
        }
        else {
            for (var key in input) {
                // Get the new key
                var newKey = func(key);
                // Get the value
                var value = input[key];
                // If this is an object, recurse
                if (typeof value === "object") {
                    value = this.RecurseTree(value, func);
                }
                // Set it on the result using the new key
                build[newKey] = value;
            }
        }
        return build;
    };
    ConverterUtils.ConvertToArray = function (obj) {
        if (!Utilities.IsDefined(obj)) {
            return [];
        }
        if (Array.isArray(obj)) {
            return obj;
        }
        return [].concat.apply([], [obj]);
    };
    /**
     * Returns the singular version of a property name
     * @param propertyName -- the property name to singularize
     * @returns -- a string with the singularized name
     */
    ConverterUtils.SingularizePropertyName = function (propertyName) {
        switch (propertyName) {
            case "ChildEntities": return "ChildEntity";
            case "ChildOrderItems": return "ChildOrderItem";
            case "PortfolioItems": return "PortfolioItem";
            case "RateAttributes": return "RateAttribute";
            case "ConfiguredValues": return "ConfiguredValue";
            case "CharacteristicUses": return "CharacteristicUse";
            case "OrderItems": return "OrderItem";
            case "Correlations": return "Correlation";
            case "ValidationErrors": return "ValidationError";
            case "AffectedPortfolioItems": return "AffectedPortfolioItem";
            case "ContextualParameters": return "ContextualParameter";
            case "LinkedEntities": return "LinkedEntity";
            case "Links": return "Link";
            case "Periods": return "Period";
            case "RatingAttributes": return "RatingAttribute";
            case "BadDataErrors": return "BadDataError";
            case "ContextParameters": return "ContextParameter";
            default: return propertyName;
        }
    };
    /**
     * Returns the plural version of a property name
     * @param propertyName -- the property name to pluralize
     * @returns -- a string with the pluralized name
     */
    ConverterUtils.PluralizePropertyName = function (propertyName) {
        switch (propertyName) {
            case "ChildEntity": return "ChildEntities";
            case "ChildOrderItem": return "ChildOrderItems";
            case "PortfolioItem": return "PortfolioItems";
            case "RateAttribute": return "RateAttributes";
            case "ConfiguredValue": return "ConfiguredValues";
            case "CharacteristicUse": return "CharacteristicUses";
            case "OrderItem": return "OrderItems";
            case "Correlation": return "Correlations";
            case "ValidationError": return "ValidationErrors";
            case "AffectedPortfolioItem": return "AffectedPortfolioItems";
            case "ContextualParameter": return "ContextualParameters";
            case "LinkedEntity": return "LinkedEntities";
            case "Link": return "Links";
            case "CancelOrderItem": return "CancelOrderItems";
            case "CreateOrderItem": return "CreateOrderItems";
            case "AmendOrderItem": return "AmendOrderItems";
            default: return propertyName;
        }
    };
    return ConverterUtils;
}());
module.exports = ConverterUtils;

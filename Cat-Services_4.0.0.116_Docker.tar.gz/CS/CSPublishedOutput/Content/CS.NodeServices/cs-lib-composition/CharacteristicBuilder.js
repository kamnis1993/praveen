"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CharacteristicQueries = require("./CharacteristicQueries");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioBuilderBase = require("./OrderfolioBuilderBase");
var OrderfolioQueries = require("./OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class that is responsible for building characteristics for an item pair
 */
var CharacteristicBuilder = /** @class */ (function (_super) {
    __extends(CharacteristicBuilder, _super);
    function CharacteristicBuilder(errorContext, requestId) {
        return _super.call(this, errorContext, requestId) || this;
    }
    /**
     * Combines the characteristics from the order item and portfolio item that exist in the supplied item pair
     * @param {ItemPair} itemPair the ItemPair that contains the order and portfolio items
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @param {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @returns {CsTypes.CharacteristicUse[]}
     */
    CharacteristicBuilder.prototype.CombineCharacteristicUses = function (itemPair, orderfolioItem, compiledSpecification) {
        var combinedCharacteristics = [];
        var combinedCharUses = CharacteristicQueries.BuildOrderfolioCharacteristicUses(itemPair.Uuid, itemPair, compiledSpecification, orderfolioItem.Action, this._errorContext);
        if (this._errorContext.HasBreakingErrors) {
            return combinedCharacteristics;
        }
        this.CombineOrderCharacteristicUses(combinedCharacteristics, combinedCharUses, orderfolioItem);
        this.CombinePortfolioCharacteristicUses(combinedCharacteristics, combinedCharUses, orderfolioItem);
        // Normalize characteristics
        this.GroupCharacteristicUsesByCharUseId(combinedCharacteristics, compiledSpecification);
        return combinedCharacteristics;
    };
    /**
     * Combines the Udcs from the order item and portfolio item that exist in the supplied item pair
     * @param {ItemPair} itemPair the ItemPair that contains the order and portfolio items
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @param {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     * @returns {CsTypes.CharacteristicUse[]}
     */
    CharacteristicBuilder.prototype.CombineUserDefinedCharacteristics = function (itemPair, orderfolioItem, compiledSpecification) {
        var combinedUdcs = [];
        var combinedOrderfolioUDCs = CharacteristicQueries.BuildOrderfolioUserDefinedCharacteristicUses(itemPair.Uuid, itemPair, compiledSpecification, orderfolioItem.Action, this._errorContext);
        if (this._errorContext.HasBreakingErrors) {
            return combinedUdcs;
        }
        this.CombineOrderUserDefinedCharacteristicUses(combinedUdcs, combinedOrderfolioUDCs, orderfolioItem);
        this.CombinePortfolioUserDefinedCharacteristicUses(combinedUdcs, combinedOrderfolioUDCs, orderfolioItem);
        // Normalize the characteristic uses
        this.GroupCharacteristicUsesByCharUseId(combinedUdcs, compiledSpecification);
        return combinedUdcs;
    };
    /**
     * Compares and merges order item characteristic uses with those on the portfolio
     * @param   {Array<CsTypes.CharacteristicUse>} combinedCharUses the collection of merged orderfolio characteristic uses to build
     * @param   {CombinedCharacteristicUses} orderfolioCharUses the collection of characteristic uses contained on the order and the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    CharacteristicBuilder.prototype.CombineOrderCharacteristicUses = function (combinedCharUses, orderfolioCharUses, orderfolioItem) {
        for (var c = 0; c < orderfolioCharUses.OrderItemCharacteristicUses.length; c++) {
            // Get the characteristic use on the order item and the matching item (if any) from the portfolio
            var charUseOnOrderItem = orderfolioCharUses.OrderItemCharacteristicUses[c];
            var matchingCharUseOnPortfolioItem = CharacteristicQueries.GetCharUseFromCollection(orderfolioCharUses.PortfolioItemCharacteristicUses, charUseOnOrderItem.UseArea, charUseOnOrderItem.CharacteristicID);
            var combinedCharUse = {
                UseId: charUseOnOrderItem.UseID,
                CharacteristicId: charUseOnOrderItem.CharacteristicID,
                UseArea: charUseOnOrderItem.UseArea,
                Action: charUseOnOrderItem.Action,
                Values: [],
                OrderItemSource: this.GetItemSource(charUseOnOrderItem, matchingCharUseOnPortfolioItem, { ItemSource: orderfolioItem.OrderItemSource }),
                PortfolioItemSource: this.GetItemSource(matchingCharUseOnPortfolioItem, charUseOnOrderItem, { ItemSource: orderfolioItem.PortfolioItemSource })
            };
            this.ValidateCharacteristicAgainstOrderItem(orderfolioItem, combinedCharUse);
            // Get the values on the characteristic use
            var portfolioItemValues = Utilities.IsDefined(matchingCharUseOnPortfolioItem) ? Utilities.asArray(matchingCharUseOnPortfolioItem.Value) : [];
            var combinedValues = this.CombineCharacteristicValues(charUseOnOrderItem.Value, portfolioItemValues, combinedCharUse, orderfolioItem);
            // Add the characteristic use if it has values
            if (combinedValues.length > 0) {
                // Check that the characteristic use values are valid, i.e. all values have a ValueID
                if (!CharacteristicQueries.ValidateCharacteristicValues(combinedValues, this._errorContext)) {
                    return combinedCharUses;
                }
                combinedCharUse.Values = combinedValues;
                combinedCharUses.push(combinedCharUse);
            }
        }
    };
    /**
     * Adds portfolio characteristic uses not contained in the order to the merged collection of orderfolio characteristic uses
     * @param   {Array<CsTypes.CharacteristicUse>} combinedCharUses the collection of merged orderfolio characteristic uses to build
     * @param   {CombinedCharacteristicUses} orderfolioCharUses the collection of characteristic uses contained on the order and the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    CharacteristicBuilder.prototype.CombinePortfolioCharacteristicUses = function (combinedCharUses, orderfolioCharUses, orderfolioItem) {
        // Add values that are only in the portfolio
        for (var cp = 0; cp < orderfolioCharUses.PortfolioItemCharacteristicUses.length; cp++) {
            var cascadedPortfolioAction = void 0;
            if (orderfolioItem.Action === OrderActions.Delete) {
                cascadedPortfolioAction = MergedActions.DeleteExisting;
            }
            else if (orderfolioItem.Action === OrderActions.Reassign) {
                cascadedPortfolioAction = orderfolioItem.Action;
            }
            else {
                cascadedPortfolioAction = MergedActions.SkipExisting;
            }
            var charUseOnPortfolioItem = orderfolioCharUses.PortfolioItemCharacteristicUses[cp];
            // If the order has already defined this characteristic use, retrieve it now
            var mergedCharacteristicUse = combinedCharUses.some(function (combinedVal) {
                return charUseOnPortfolioItem.UseID === combinedVal.UseId;
            });
            // Create the characteristic use and add its values
            var combinedCharUseForPortfolioItemWithNoOrderItem = {
                UseId: charUseOnPortfolioItem.UseID,
                CharacteristicId: charUseOnPortfolioItem.CharacteristicID,
                UseArea: charUseOnPortfolioItem.UseArea,
                Action: cascadedPortfolioAction,
                Values: [],
                PortfolioItemSource: this.GetItemSource(charUseOnPortfolioItem, undefined, { ItemSource: orderfolioItem.PortfolioItemSource }),
                OrderItemSource: undefined
            };
            // If the order didn't already define this characteristic use, go ahead and use the portfolio version
            if (!mergedCharacteristicUse && charUseOnPortfolioItem.Value) {
                // Create a collection of values to add to the characteristic use
                var combinedVals = [];
                for (var j = 0; j < Utilities.asArray(charUseOnPortfolioItem.Value).length; j++) {
                    var currentValue = charUseOnPortfolioItem.Value[j];
                    combinedVals.push({
                        Action: cascadedPortfolioAction,
                        Value: currentValue.ValueID,
                        ValueDetail: currentValue.ValueDetail,
                        ItemSource: OrderfolioQueries.GetItemSource(currentValue, this._requestId, { ItemSource: combinedCharUseForPortfolioItemWithNoOrderItem.PortfolioItemSource })
                    });
                }
                // Check that the characteristic use values are valid, i.e. all values have a ValueID
                if (!CharacteristicQueries.ValidateCharacteristicValues(combinedVals, this._errorContext)) {
                    return combinedCharUses;
                }
                combinedCharUseForPortfolioItemWithNoOrderItem.Values = combinedVals;
                combinedCharUses.push(combinedCharUseForPortfolioItemWithNoOrderItem);
            }
        }
    };
    /**
     * Compares and merges order item user defined characteristic uses with those on the portfolio
     * @param   {Array<CsTypes.CharacteristicUse>} combinedUdcs the collection of merged orderfolio user defined characteristic uses to build
     * @param   {CombinedUserDefinedCharacteristicUses} orderfolioUdcs the collection of user defined characteristic uses contained on the order and the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    CharacteristicBuilder.prototype.CombineOrderUserDefinedCharacteristicUses = function (combinedUdcs, orderfolioUdcs, orderfolioItem) {
        for (var c = 0; c < orderfolioUdcs.OrderItemUDCs.length; c++) {
            // Get the userdef characteristic use on the order item and the matching item (if any) from the portfolio
            var udcOnOrderItem = orderfolioUdcs.OrderItemUDCs[c];
            var matchingUdcOnPortfolioItem = CharacteristicQueries.GetUdcFromCollection(orderfolioUdcs.PortfolioItemUdcs, udcOnOrderItem.UseArea, udcOnOrderItem.CharacteristicID);
            var combinedUdc = {
                UseId: udcOnOrderItem.UseID,
                CharacteristicId: udcOnOrderItem.CharacteristicID,
                UseArea: udcOnOrderItem.UseArea,
                Action: udcOnOrderItem.Action,
                Values: [],
                OrderItemSource: this.GetItemSource(udcOnOrderItem, matchingUdcOnPortfolioItem, { ItemSource: orderfolioItem.OrderItemSource }),
                PortfolioItemSource: this.GetItemSource(matchingUdcOnPortfolioItem, udcOnOrderItem, { ItemSource: orderfolioItem.PortfolioItemSource })
            };
            this.ValidateCharacteristicAgainstOrderItem(orderfolioItem, combinedUdc);
            // Get the values on the userdef characteristic use
            var valuesOnPortfolioItem = matchingUdcOnPortfolioItem && matchingUdcOnPortfolioItem.Value ? matchingUdcOnPortfolioItem.Value : [];
            var combinedValues = this.CombineUdcValues(udcOnOrderItem.Value, valuesOnPortfolioItem, combinedUdc, orderfolioItem);
            // Add the userdef characteristic use if it has values
            if (combinedValues.length > 0) {
                // Check that the characteristic use values are valid (empty strings allowed)
                if (!CharacteristicQueries.ValidateUdcValues(combinedValues, this._errorContext)) {
                    return combinedUdcs;
                }
                combinedUdc.Values = combinedValues;
                combinedUdcs.push(combinedUdc);
            }
        }
    };
    /**
     * Adds portfolio user defined characteristic uses not contained in the order to the merged collection of orderfolio user defined characteristic uses
     * @param   {Array<CsTypes.CharacteristicUse>} combinedUdcs the collection of merged orderfolio user defined characteristic uses to build
     * @param   {CombinedUserDefinedCharacteristicUses} orderfolioUdcs the collection of user defined characteristic uses contained on the order and the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    CharacteristicBuilder.prototype.CombinePortfolioUserDefinedCharacteristicUses = function (combinedUdcs, orderfolioUdcs, orderfolioItem) {
        for (var cp = 0; cp < orderfolioUdcs.PortfolioItemUdcs.length; cp++) {
            var udcOnPortfolioItem = orderfolioUdcs.PortfolioItemUdcs[cp];
            // If the order has already defined this userdef characteristic use, retrieve it now
            var mergedUdc = combinedUdcs.some(function (combinedVal) {
                return udcOnPortfolioItem.UseID === combinedVal.UseId;
            });
            // Create the characteristic use and add its values
            var combinedUdcForPortfolioItemWithNoOrderItem = {
                UseId: udcOnPortfolioItem.UseID,
                CharacteristicId: udcOnPortfolioItem.CharacteristicID,
                UseArea: udcOnPortfolioItem.UseArea,
                Action: OrderActions.NoChange,
                Values: [],
                OrderItemSource: undefined,
                PortfolioItemSource: this.GetItemSource(udcOnPortfolioItem, undefined, { ItemSource: orderfolioItem.PortfolioItemSource })
            };
            // If the order didn't already define this userdef characteristic use, go ahead and use the portfolio version
            if (!mergedUdc && udcOnPortfolioItem.Value) {
                // Create a collection of values to add to the userdef characteristic use
                var combinedVals = [];
                for (var j = 0; j < udcOnPortfolioItem.Value.length; j++) {
                    var currentValue = udcOnPortfolioItem.Value[j];
                    combinedVals.push({
                        Action: orderfolioItem.Action === OrderActions.Delete ? MergedActions.DeleteExisting : MergedActions.SkipExisting,
                        Value: currentValue.Value,
                        ValueDetail: currentValue.ValueDetail,
                        ItemSource: OrderfolioQueries.GetItemSource(currentValue, this._requestId, { ItemSource: combinedUdcForPortfolioItemWithNoOrderItem.PortfolioItemSource })
                    });
                }
                // Check that the characteristic use values are valid (empty strings allowed)
                if (!CharacteristicQueries.ValidateUdcValues(combinedVals, this._errorContext)) {
                    return combinedUdcs;
                }
                combinedUdcForPortfolioItemWithNoOrderItem.Values = combinedVals;
                combinedUdcs.push(combinedUdcForPortfolioItemWithNoOrderItem);
            }
        }
    };
    /**
    * Combines char values from 2 sources a char use on a portfolio item, and a char use on an order item
    * @param {Array<CharacteristicValue>} valuesOnOrderItem the values on order item
    * @param {Array<CharacteristicValue>} valuesOnPortfolioItem the values on the portfolio item
    * @param {CsTypes.CharacteristicUse} charUse The characteristic use
    * @param {string} actionOnCharUse the action that is set on the char use that hosts the char values on the order
    * @returns {Array<CsTypes.MergedValue>} the resultant merged values
    */
    CharacteristicBuilder.prototype.CombineCharacteristicValues = function (valuesOnOrderItem, valuesOnPortfolioItem, charUse, orderfolioItem) {
        var mergedValues = [];
        this.CombineOrderCharacteristicValues(mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, charUse, orderfolioItem);
        this.CombinePortfolioCharacteristicValues(mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, charUse);
        return mergedValues;
    };
    /**
     * Compares and merges order item characteristic values with those on the portfolio
     * @param   {Array<CsTypes.MergedValue>} mergedValues the collection of merged orderfolio characteristic values to build
     * @param   {Array<CharacteristicValue>} valuesOnOrderItem the collection of characteristic values on the order item
     * @param   {Array<CharacteristicValue>} valuesOnPortfolioItem the collection of characteristic values on the portfolio
     * @param {CsTypes.CharacteristicUse} charUse The characteristic use
     * @param   {string} actionOnCharUse the action inherited from the parent characteristic
     */
    CharacteristicBuilder.prototype.CombineOrderCharacteristicValues = function (mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, charUse, orderfolioItem) {
        // if the user specified delete on the char use on the order then we dont care about the actions against the individual values, we can skip them because
        // a delete at this level simply deletes all the values on this char use on the portfolio item
        // so only when they HAVE NOT specified 'delete' do we consider the values on the order
        for (var c = 0; c < valuesOnOrderItem.length; c++) {
            // Determine the orderfolio value by comparing the values on order item and portfolio item
            var valueOnOrderItem = valuesOnOrderItem[c];
            var valueOnPortfolioItem = CharacteristicQueries.GetCharValueFromCollection(valuesOnPortfolioItem, valueOnOrderItem.ValueID);
            var mergedValue = {
                Action: null,
                Value: valueOnOrderItem.ValueID,
                ValueDetail: valueOnOrderItem.ValueDetail,
                ItemSource: OrderfolioQueries.GetItemSource(valueOnOrderItem, this._requestId, { ItemSource: charUse.OrderItemSource })
            };
            this.ValidateCharacteristicValueAgainstCharacteristic(orderfolioItem, charUse, valueOnOrderItem.ValueID, valueOnOrderItem.Action);
            this.ValidateCharacteristicValueAgainstOrderItem(orderfolioItem, charUse, valueOnOrderItem.ValueID, valueOnOrderItem.Action);
            // Create the merged value and set its action
            switch (valueOnOrderItem.Action) {
                case OrderActions.Add:
                    mergedValue.Action = valueOnPortfolioItem ? MergedActions.AddExisting : MergedActions.AddMissing;
                    mergedValues.push(mergedValue);
                    break;
                case OrderActions.Delete:
                    if (charUse.Action === OrderActions.Modify || charUse.Action === OrderActions.Delete) {
                        mergedValue.Action = valueOnPortfolioItem ? MergedActions.DeleteExisting : MergedActions.DeleteMissing;
                        mergedValues.push(mergedValue);
                    }
                    break;
                case OrderActions.Reassigned:
                case OrderActions.ReassignedUpdate:
                    // Set the correct merge action for reassigned items
                    switch (charUse.Action) {
                        case OrderActions.Modify:
                            mergedValue.Action = MergedActions.AddExisting;
                            break;
                        case OrderActions.Delete:
                            mergedValue.Action = MergedActions.DeleteExisting;
                            break;
                        default:
                            mergedValue.Action = valueOnOrderItem.Action;
                            break;
                    }
                    mergedValues.push(mergedValue);
                    break;
                case OrderActions.Reassign:
                case OrderActions.Replace:
                    break;
                default:
                    mergedValue.Action = valueOnOrderItem.Action;
                    mergedValues.push(mergedValue);
                    this._errorContext.RaiseSevereValidationError(ErrorCode.Validation.InvalidActionForType, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, { Action: mergedValue.Action, CharacteristicID: charUse.CharacteristicId, Value: mergedValue.Value });
                    break;
            }
        }
    };
    /**
     * Adds portfolio characteristic values not contained in the order values to the merged collection of orderfolio characteristic values
     * @param   {Array<CsTypes.MergedValue>} mergedValues the collection of merged orderfolio characteristic values to build
     * @param   {Array<CharacteristicValue>} valuesOnOrderItem the collection of characteristic values on the order item
     * @param   {Array<CharacteristicValue>} valuesOnPortfolioItem the collection of characteristic values on the portfolio
     * @param {CsTypes.CharacteristicUse} charUse The characteristic use
     * @param   {string} actionOnCharUse the action inherited from the parent characteristic
     */
    CharacteristicBuilder.prototype.CombinePortfolioCharacteristicValues = function (mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, charUse) {
        // Add portfolio values to the merged values which do not have a match in the order
        for (var j = 0; j < valuesOnPortfolioItem.length; j++) {
            // Check if the order has modified the portfolio item value
            var portfolioValue = valuesOnPortfolioItem[j];
            var matchingValueOnOrderItem = CharacteristicQueries.GetCharValueFromCollection(valuesOnOrderItem, portfolioValue.ValueID);
            // If there isn't a matching order item value, then use the portfolio item value
            if (!matchingValueOnOrderItem) {
                // if the characteristic on the order is modify, then we have found a value on the char use in the portfolio item
                // that did not exist on the char use on the order item. In other words, the user doesn't want to do anything with it (its not in the order)
                // so set the action to SkipExisting. If the user specified an action on the characteristic of Replace or Delete (not Modify) then both
                // of these actions would result in the values on the char use on the portfolio item being deleted, so set the action to DeleteExisting
                mergedValues.push({
                    Action: charUse.Action === OrderActions.Modify ? MergedActions.SkipExisting : MergedActions.DeleteExisting,
                    Value: portfolioValue.ValueID,
                    ValueDetail: portfolioValue.ValueDetail,
                    ItemSource: OrderfolioQueries.GetItemSource(portfolioValue, this._requestId, { ItemSource: charUse.PortfolioItemSource })
                });
            }
        }
    };
    /**
     * Combines Udc values from 2 sources a char use on a portfolio item, and a char use on an order item
     * @param {Array<UserDefinedCharacteristicValue>} valuesOnOrderItem the values on order item
     * @param {Array<UserDefinedCharacteristicValue>} valuesOnPortfolioItem the values on the portfolio item
     * param {CsTypes.CharacteristicUse} udc The user defined characteristic
     * @param {string} actionOnUdc the action that is set on the udc that hosts the udc values on the order
     * @returns {Array<CsTypes.MergedValue>} the resultant merged values
     */
    CharacteristicBuilder.prototype.CombineUdcValues = function (valuesOnOrderItem, valuesOnPortfolioItem, udc, orderfolioItem) {
        var mergedValues = [];
        this.CombineOrderUdcValues(mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, udc, orderfolioItem);
        this.CombinePortfolioUdcValues(mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, udc);
        return mergedValues;
    };
    /**
     * Compares and merges order item user defined characteristic values with those on the portfolio
     * @param   {Array<CsTypes.MergedValue>} mergedValues the collection of merged orderfolio characteristic values to build
     * @param   {Array<UserDefinedCharacteristicValue>} valuesOnOrderItem the collection of characteristic values on the order item
     * @param   {Array<UserDefinedCharacteristicValue>} valuesOnPortfolioItem the collection of characteristic values on the portfolio
     * @param   {CsTypes.CharacteristicUse} udc The User defined characteristic
     * @param   {string} actionOnUdc the action inherited from the parent user defined characteristic
     */
    CharacteristicBuilder.prototype.CombineOrderUdcValues = function (mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, udc, orderfolioItem) {
        // if the user specified delete on the udc on the order then we dont care about the actions against the individual values, we can skip them because
        // a delete at this level simply deletes all the values on this udc on the portfolio item
        // so only when they HAVE NOT specified 'delete' do we consider the values on the order
        for (var j = 0; j < valuesOnOrderItem.length; j++) {
            // Determine the orderfolio value by comparing the values on order item and portfolio item
            var valueOnOrderItem = valuesOnOrderItem[j];
            var valueOnPortfolioItem = CharacteristicQueries.GetUdcValueFromCollection(valuesOnPortfolioItem, valueOnOrderItem.Value);
            var mergedValue = {
                Action: null,
                Value: valueOnOrderItem.Value,
                ValueDetail: valueOnOrderItem.ValueDetail,
                ItemSource: OrderfolioQueries.GetItemSource(valueOnOrderItem, this._requestId, { ItemSource: udc.OrderItemSource })
            };
            this.ValidateCharacteristicValueAgainstCharacteristic(orderfolioItem, udc, valueOnOrderItem.Value, valueOnOrderItem.Action);
            this.ValidateCharacteristicValueAgainstOrderItem(orderfolioItem, udc, valueOnOrderItem.Value, valueOnOrderItem.Action);
            // Create the merged value and set its action
            switch (valueOnOrderItem.Action) {
                case OrderActions.Add:
                    mergedValue.Action = valueOnPortfolioItem ? MergedActions.AddExisting : MergedActions.AddMissing;
                    mergedValues.push(mergedValue);
                    break;
                case OrderActions.Delete:
                    if (udc.Action === OrderActions.Modify || udc.Action === OrderActions.Delete) {
                        mergedValue.Action = valueOnPortfolioItem ? MergedActions.DeleteExisting : MergedActions.DeleteMissing;
                        mergedValues.push(mergedValue);
                    }
                    break;
                case OrderActions.Reassigned:
                case OrderActions.ReassignedUpdate:
                    mergedValue.Action = valueOnOrderItem.Action; // Maintain the Action
                    mergedValues.push(mergedValue);
                    break;
            }
        }
    };
    /**
     * Adds portfolio user defined characteristic values not contained in the order values to the merged collection of orderfolio user defined characteristic values
     * @param   {Array<CsTypes.MergedValue>} mergedValues the collection of merged orderfolio characteristic values to build
     * @param   {Array<UserDefinedCharacteristicValue>} valuesOnOrderItem the collection of characteristic values on the order item
     * @param   {Array<UserDefinedCharacteristicValue>} valuesOnPortfolioItem the collection of characteristic values on the portfolio
     * @param   {CsTypes.CharacteristicUse} udc The User defined characteristic
     * @param   {string} actionOnUdc the action inherited from the parent user defined characteristic
     */
    CharacteristicBuilder.prototype.CombinePortfolioUdcValues = function (mergedValues, valuesOnOrderItem, valuesOnPortfolioItem, udc) {
        for (var c = 0; c < valuesOnPortfolioItem.length; c++) {
            // Check if the order has modified the portfolio item value
            var portfolioValue = valuesOnPortfolioItem[c];
            var matchingValueOnOrderItem = CharacteristicQueries.GetUdcValueFromCollection(valuesOnOrderItem, portfolioValue.Value);
            // If there isn't a matching order item value, then use the portfolio item value
            if (!matchingValueOnOrderItem) {
                // if the udc on the order is modify, then we have found a value on the char use in the portfolio  item
                // that did not exist on the char use on the order item. In other words, the user doesn't want to do anything with it (its not in the order)
                // so set the action to SkipExisting. If the user specified an action on the udc of Replace or Delete (not Modify) then both
                // of these actions would result in the values on the char use on the portfolio item being deleted, so set the action to DeleteExisting
                mergedValues.push({
                    Action: udc.Action === OrderActions.Modify ? MergedActions.SkipExisting : MergedActions.DeleteExisting,
                    Value: portfolioValue.Value,
                    ValueDetail: portfolioValue.ValueDetail,
                    ItemSource: OrderfolioQueries.GetItemSource(portfolioValue, this._requestId, { ItemSource: udc.PortfolioItemSource })
                });
            }
        }
    };
    /**
     * Groups / Normalizes the char uses by char ID
     * @param {Array<CsTypes.CharacteristicUse>} characteristicUses the char uses to group together
     */
    CharacteristicBuilder.prototype.GroupCharacteristicUsesByCharUseId = function (characteristicUses, compiledSpecification) {
        for (var c = 0; c < characteristicUses.length; c++) {
            var charUse = characteristicUses[c];
            if (charUse.Action !== OrderActions.Modify) {
                continue;
            }
            for (var j = c + 1; j < characteristicUses.length; j++) {
                var charUseCompare = characteristicUses[j];
                if (charUseCompare.UseId === charUse.UseId && charUseCompare.Action === charUse.Action) {
                    charUse.Values = charUse.Values.concat(charUseCompare.Values);
                    characteristicUses.splice(j, 1);
                    j = j - 1;
                }
            }
        }
    };
    CharacteristicBuilder.prototype.ValidateCharacteristicAgainstOrderItem = function (orderfolioItem, charUse) {
        var isActionValid = this.ValidatePropertyActionAgainstOrderItem(orderfolioItem.Action, charUse.Action);
        if (!isActionValid) {
            var params = {
                CharAction: charUse.Action,
                OrderItemAction: orderfolioItem.Action,
                UseArea: charUse.UseArea,
                CharID: charUse.CharacteristicId
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.OrderItemToCharacteristic, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    CharacteristicBuilder.prototype.ValidateCharacteristicValueAgainstCharacteristic = function (orderfolioItem, charUse, charValue, charValueAction) {
        var isActionValid = this.ValidateValueActionAgainstProperty(charUse.Action, charValueAction);
        if (!isActionValid) {
            var params = {
                CharValueAction: charValueAction,
                CharAction: charUse.Action,
                UseArea: charUse.UseArea,
                CharID: charUse.CharacteristicId,
                CharValue: charValue
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.CharacteristicToCharacteristicValue, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    CharacteristicBuilder.prototype.ValidateCharacteristicValueAgainstOrderItem = function (orderfolioItem, charUse, charValue, charValueAction) {
        var isActionValid = this.ValidateValueActionAgainstOrderItem(orderfolioItem.Action, charValueAction);
        if (!isActionValid) {
            var params = {
                CharValueAction: charValueAction,
                OrderItemAction: orderfolioItem.Action,
                UseArea: charUse.UseArea,
                CharID: charUse.CharacteristicId,
                CharValue: charValue
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.OrderItemToCharacteristicValue, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    return CharacteristicBuilder;
}(OrderfolioBuilderBase));
module.exports = CharacteristicBuilder;

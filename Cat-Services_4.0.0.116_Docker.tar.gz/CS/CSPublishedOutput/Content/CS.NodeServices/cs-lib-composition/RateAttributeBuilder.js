"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioBuilderBase = require("./OrderfolioBuilderBase");
var Utilities = require("../cs-lib-utilities/Utilities");
var RateAttributeBuilder = /** @class */ (function (_super) {
    __extends(RateAttributeBuilder, _super);
    function RateAttributeBuilder(errorContext, requestId) {
        return _super.call(this, errorContext, requestId) || this;
    }
    /**
     * Combines the rating attributes from the order item and portfolio item that exist in the supplied item pair
     * @param {ItemPair} itemPair the itempair that contains the order and portfolio items
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @returns {Array<CsTypes.RateAttribute>} the combined rate attributes
     */
    RateAttributeBuilder.prototype.CombineRatingAttributes = function (itemPair, orderfolioItem) {
        var combinedRatingAttributes = [];
        var attributesOnOrder = itemPair.OrderItem && itemPair.OrderItem.RateAttributes ? itemPair.OrderItem.RateAttributes : [];
        var attributesOnPortfolio = itemPair.PortfolioItem && itemPair.PortfolioItem.RateAttributes ? itemPair.PortfolioItem.RateAttributes : [];
        this.CombineRatingAttributesOnOrder(combinedRatingAttributes, attributesOnOrder, attributesOnPortfolio, orderfolioItem);
        this.CombineRatingAttributesOnPortfolio(combinedRatingAttributes, attributesOnOrder, attributesOnPortfolio, orderfolioItem);
        this.CheckForDuplicateRatingAttributes(combinedRatingAttributes, orderfolioItem);
        return combinedRatingAttributes;
    };
    /**
     * Checks the provided array for rating attributes with the same name and raises a validation error for each duplicate
     * @param {Array<CsTypes.RateAttribute>} mergedAttributes the collection of attributes harvested from the orderfolio
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item to which the rating attributes belong
     */
    RateAttributeBuilder.prototype.CheckForDuplicateRatingAttributes = function (mergedAttributes, orderfolioItem) {
        var _this = this;
        // Create a collection of rating attribute names, with a count of how many times that name appears
        // The map allows us to check just the name of the attribute, and to add in a counter
        // The reduce groups the names, and adds the count together
        var filteredAttributes = mergedAttributes.filter(function (att) { return att.Action !== MergedActions.DeleteExisting; });
        var uniqueAttributes = filteredAttributes.map(function (att) {
            return { count: 1, name: att.Name };
        }).reduce(function (attributeKeyCount, attributeKey) {
            attributeKeyCount[attributeKey.name] = (attributeKeyCount[attributeKey.name] || 0) + attributeKey.count;
            return attributeKeyCount;
        }, {});
        // Gather any rate attributes whose name appeared more than once
        var duplicateAttributes = Object.keys(uniqueAttributes).filter(function (a) { return uniqueAttributes[a] > 1; });
        // Raise an error for each duplicate rate attribute name
        if (Utilities.IsDefined(duplicateAttributes, true)) {
            duplicateAttributes.forEach(function (duplicate) {
                var params = { RatingAttributeName: duplicate };
                _this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidRatingAttributes, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
            });
        }
    };
    /**
     * Compares and merges order item rating attributes with those on the portfolio
     * @param   {Array<CsTypes.RateAttribute>} mergedAttributes the collection of merged orderfolio rate attributes to build
     * @param   {Array<RateAttribute>} attributesOnOrder the collection of rate attributes contained on the order
     * @param   {Array<RateAttribute>} attributesOnPortfolio the collection of rate attributes contained on the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    RateAttributeBuilder.prototype.CombineRatingAttributesOnOrder = function (mergedAttributes, attributesOnOrder, attributesOnPortfolio, orderfolioItem) {
        for (var c = 0; c < attributesOnOrder.length; c++) {
            var attributeOnOrder = attributesOnOrder[c];
            var existingRateAttributeOnPortfolioItem = this.GetRateAttributeWithName(attributeOnOrder.Name, attributesOnPortfolio);
            var orderItemSource = this.GetItemSource(attributeOnOrder, existingRateAttributeOnPortfolioItem, { ItemSource: orderfolioItem.OrderItemSource });
            var portfolioItemSource = this.GetItemSource(existingRateAttributeOnPortfolioItem, attributeOnOrder, { ItemSource: orderfolioItem.PortfolioItemSource });
            var combinedRateAttribute = {
                Name: attributeOnOrder.Name,
                Value: attributeOnOrder.Value,
                Action: null,
                OrderItemSource: orderItemSource,
                PortfolioItemSource: portfolioItemSource
            };
            this.ValidateRateActionAgainstOrderItem(orderfolioItem, attributeOnOrder);
            switch (attributeOnOrder.Action) {
                //if we have an add action and it already exists, this is effectively a 'replace' so generate separate add and delete actions
                case OrderActions.Add:
                    combinedRateAttribute.Action = MergedActions.AddMissing;
                    break;
                case OrderActions.Delete:
                    combinedRateAttribute.Action = (existingRateAttributeOnPortfolioItem) ? (MergedActions.DeleteExisting) : (MergedActions.DeleteMissing);
                    break;
                case OrderActions.Update:
                    combinedRateAttribute.Action = MergedActions.AddMissing;
                    // check that the existing deleted rating attribute does not already exist
                    if (existingRateAttributeOnPortfolioItem) {
                        // Check that the rating attribute already exist by matching both the name and the action of delete
                        var mergedAttributeAlreadyDeleted = mergedAttributes.some(function (attr) {
                            return attr.Name === existingRateAttributeOnPortfolioItem.Name && attr.Action === MergedActions.DeleteExisting;
                        });
                        if (mergedAttributeAlreadyDeleted) {
                            break;
                        }
                        mergedAttributes.push({
                            Name: existingRateAttributeOnPortfolioItem.Name,
                            Value: existingRateAttributeOnPortfolioItem.Value,
                            Action: MergedActions.DeleteExisting,
                            OrderItemSource: orderItemSource,
                            PortfolioItemSource: portfolioItemSource
                        });
                    }
                    break;
                default:
                    combinedRateAttribute.Action = MergedActions.SkipExisting;
                    break;
            }
            mergedAttributes.push(combinedRateAttribute);
        }
    };
    /**
     * Adds portfolio rate attributes not contained in the order to the merged collection of orderfolio rate attributes
     * @param   {Array<CsTypes.RateAttribute>} mergedAttributes the collection of merged orderfolio rate attributes to build
     * @param   {Array<RateAttribute>} attributesOnOrder the collection of rate attributes contained on the order
     * @param   {Array<RateAttribute>} attributesOnPortfolio the collection of rate attributes contained on the portfolio
     * @param   {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     */
    RateAttributeBuilder.prototype.CombineRatingAttributesOnPortfolio = function (mergedAttributes, attributesOnOrder, attributesOnPortfolio, orderfolioItem) {
        for (var j = 0; j < attributesOnPortfolio.length; j++) {
            var attributeOnPortfolio = attributesOnPortfolio[j];
            var existingRateAttributeOnOrderItem = this.GetRateAttributeWithNameAndValue(attributeOnPortfolio, attributesOnOrder);
            if (!existingRateAttributeOnOrderItem) {
                var rateAttributeAction = (orderfolioItem.Action === OrderActions.Delete) ? (MergedActions.DeleteExisting) : (MergedActions.SkipExisting);
                mergedAttributes.push({
                    Name: attributeOnPortfolio.Name,
                    Value: attributeOnPortfolio.Value,
                    Action: rateAttributeAction,
                    OrderItemSource: undefined,
                    PortfolioItemSource: this.GetItemSource(attributeOnPortfolio, undefined, { ItemSource: orderfolioItem.PortfolioItemSource })
                });
            }
            else if (existingRateAttributeOnOrderItem.Action !== OrderActions.Delete) {
                // if found and not set to Delete set to SkipExisting
                var mergedAttribute = LodashUtilities.Find(mergedAttributes, function (m) {
                    return m.Name === existingRateAttributeOnOrderItem.Name && m.Value === existingRateAttributeOnOrderItem.Value;
                });
                if (Utilities.IsDefined(mergedAttribute)) {
                    mergedAttribute.Action = MergedActions.SkipExisting;
                }
            }
        }
    };
    /**
     * Gets the rating attribute with the supplied name from the supplied collection
     * @param {string} attributeName the attribute name
     * @param {Array<CsTypes.RateAttribute>} rateAttributes the attribute collection
     * @returns the rate attribute with the supplied name from the supplied collection
     */
    RateAttributeBuilder.prototype.GetRateAttributeWithName = function (attributeName, rateAttributes) {
        return LodashUtilities.Find(rateAttributes, function (rateAttribute) {
            return rateAttribute.Name === attributeName;
        });
    };
    /**
     * Gets the rating attribute with the supplied name and valuefrom the supplied collection
     * @param {string} attribute the attribute to match
     * @param {Array<CsTypes.RateAttribute>} rateAttributes the attribute collection
     * @returns the rate attribute with the supplied name from the supplied collection
     */
    RateAttributeBuilder.prototype.GetRateAttributeWithNameAndValue = function (attribute, rateAttributes) {
        if (Utilities.IsNotDefined(attribute) || Utilities.IsNotDefined(rateAttributes)) {
            return null;
        }
        return LodashUtilities.Find(rateAttributes, function (rateAttribute) {
            return rateAttribute.Name === attribute.Name && rateAttribute.Value === attribute.Value;
        });
    };
    RateAttributeBuilder.prototype.ValidateRateActionAgainstOrderItem = function (orderfolioItem, rate) {
        var isValidAction;
        switch (orderfolioItem.Action) {
            case OrderActions.Add:
                isValidAction = rate.Action === OrderActions.Add;
                break;
            case OrderActions.Delete:
                isValidAction = rate.Action === OrderActions.Delete;
                break;
            default:
                isValidAction = true;
        }
        if (!isValidAction) {
            var params = {
                RateAction: rate.Action,
                OrderItemAction: orderfolioItem.Action,
                RateName: rate.Name,
                RateValue: rate.Value
            };
            this._errorContext.RaiseValidationError(ErrorCode.Validation.InvalidPropertyHierarchy.OrderItemToRateAttribute, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, params);
        }
    };
    return RateAttributeBuilder;
}(OrderfolioBuilderBase));
module.exports = RateAttributeBuilder;

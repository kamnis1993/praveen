"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var OrderCandidateResponseBuilder = require("./OrderCandidateResponseBuilder");
var ProductCandidateResponse = require("../cs-lib-types/CPQ-BusinessEntities/ProductCandidateResponse");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class responsible for building a OrderCandidateResponse from a set of DecomposeContexts
 * Synonyms: unflatten, inflate, pump,
 */
var ProductCandidateResponseBuilder = /** @class */ (function () {
    function ProductCandidateResponseBuilder(errorContext) {
        this._errorContext = errorContext;
        this._orderResponseBuilder = new OrderCandidateResponseBuilder(this._errorContext);
    }
    /**
     * Build a ProductCandidateResponse from an array of DecomposeContexts.
     * Adds everything but ValidationErrors which is done by Error service
     * @param {DecomposeContextCollection} order the DecomposeContexts which comprise the order
     * @param {CsErrorContext} errorContext the CsErrorContext to use to record any errors.
     * @returns {OrderCandidateResponse}
     */
    ProductCandidateResponseBuilder.prototype.Build = function (compiledOrder) {
        var response = new ProductCandidateResponse();
        // unflatten an OrderCandidateResponse
        var orderResponse = this._orderResponseBuilder.Build(compiledOrder, true);
        response.ValidationErrors = orderResponse.ValidationErrors;
        if (compiledOrder.length < 1) {
            return response;
        }
        //Need to remove all ItemSource fields from input
        var candidate = orderResponse.CustomerPortfolio.AffectedPortfolioItems[0];
        this.RemoveItemSource(candidate);
        // pick out the bits we want
        response.CreationDate = Utilities.DateString(orderResponse.ActivationDate);
        response.ProductCandidate = candidate;
        return response;
    };
    /**
     * Removes the ItemSource property from the suppied input
     * @param {any} current the data item that is being processed
     */
    ProductCandidateResponseBuilder.prototype.RemoveItemSource = function (current) {
        var _this = this;
        if (current.ItemSource) {
            delete current.ItemSource;
        }
        if (current.CharacteristicUses) {
            current.CharacteristicUses.forEach(function (CharacteristicUses) {
                delete CharacteristicUses.ItemSource;
                if (CharacteristicUses.Value) {
                    CharacteristicUses.Value.forEach(function (Value) {
                        delete Value.ItemSource;
                    });
                }
            });
        }
        if (current.ConfiguredValues) {
            current.ConfiguredValues.forEach(function (ConfiguredValues) {
                delete ConfiguredValues.ItemSource;
                if (ConfiguredValues.Value) {
                    ConfiguredValues.Value.forEach(function (Value) {
                        delete Value.ItemSource;
                    });
                }
            });
        }
        if (current.ChildEntities) {
            current.ChildEntities.forEach(function (ChildEntities) {
                _this.RemoveItemSource(ChildEntities);
            });
        }
    };
    return ProductCandidateResponseBuilder;
}());
module.exports = ProductCandidateResponseBuilder;

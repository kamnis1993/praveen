"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var AffectedPortfolioItem = require("../cs-lib-types/BusinessEntities/AffectedPortfolioItem");
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var CharacteristicUse = require("../cs-lib-types/BusinessEntities/CharacteristicUse");
var EntityLink = require("../cs-lib-types/BusinessEntities/EntityLink");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderCandidateResponse = require("../cs-lib-types/BusinessEntities/OrderCandidateResponse");
var OrderfolioQueries = require("./OrderfolioQueries");
var OrderItem = require("../cs-lib-types/BusinessEntities/OrderItem");
var PhaseCodeAccessor = require("../cs-lib-composition/compiler/PhaseCodeAccessor");
var RateAttribute = require("../cs-lib-types/BusinessEntities/RateAttribute");
var UserDefinedCharacteristicUse = require("../cs-lib-types/BusinessEntities/UserDefinedCharacteristicUse");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class responsible for building a OrderCandidateResponse from a set of DecomposeContexts
 * Synonyms: unflatten, inflate, pump,
 */
var OrderCandidateResponseBuilder = /** @class */ (function () {
    /**
     * Creates an order candidate response builder
     * @param {CsErrorContext} errorContext The error context
     */
    function OrderCandidateResponseBuilder(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Build (unflatten, pump up) an OrderCandidateResponse from an array of DecomposeContexts.
     * Adds everything but ValidationErrors which is done by Error service
     * NOTE: The includeProductCandidateData parameter is purely to resolve properties which were on the
     *       Legacy ProductCandidate but are not on the OrderCandidateResponse. Rip it out if
     *       CPQ 1.x support is ever dropped.
     * @param {CsTypes.DecomposeContextCollection} order the DecomposeContexts which comprise the order
     * @param {boolean} [includeProductCandidateData] Default: false. Include properties required by legacy CPQ 1.x
     * @returns {OrderCandidateResponse}b
     */
    OrderCandidateResponseBuilder.prototype.Build = function (compiledOrder, includeProductCandidateData) {
        var _this = this;
        if (includeProductCandidateData === void 0) { includeProductCandidateData = false; }
        var response = new OrderCandidateResponse();
        if (compiledOrder.length === 0) {
            response.RemoveInternalData();
            response.ValidationErrors = this._errorContext.GetValidationErrorsForResponse();
            return response;
        }
        // Set RequestID and ActivationDate from the first context item
        var decomposeContext = compiledOrder[0];
        response.RequestID = decomposeContext.OrderRequestId;
        response.ActivationDate = Utilities.DateString(decomposeContext.ActivationDate);
        response.DecomposeID = decomposeContext.DecomposeId;
        response.OrderCandidate.OrderID = decomposeContext.CandidateOrderId;
        this.BuildContextData(response, decomposeContext);
        // Process each DecomposeContext item in the order
        compiledOrder.forEach(function (orderContext) {
            _this.BuildRootItem(orderContext, response, includeProductCandidateData);
        });
        if (this._errorContext.HasBreakingErrors) {
            return response;
        }
        // Run a remove internal data to really tidy up
        response.RemoveInternalData();
        response.ValidationErrors = this.BuildValidationErrors();
        return response;
    };
    /**
     * Builds context data on the OrderCandidateResponse
     * @param   {OrderCandidateResponse} response the response object to apply context data to
     * @param   {CsTypes.DecomposeContext} decomposeContext the decompose context
     */
    OrderCandidateResponseBuilder.prototype.BuildContextData = function (response, decomposeContext) {
        if (!decomposeContext.ContextData) {
            return;
        }
        response.OrderCandidate.Customer = decomposeContext.ContextData.Customer;
        if (decomposeContext.ContextData.OrderContext) {
            response.OrderCandidate.OrderContext = Utilities.asArray(decomposeContext.ContextData.OrderContext).map(function (contextualItem) {
                return {
                    Characteristic: contextualItem.CharacteristicName,
                    Value: contextualItem.Values
                };
            });
        }
    };
    /**
     * Build the root items and it's children for a specific DecomposeContext (an entity tree)
     * storing the results in the supplied OrderCandidateResponse
     * @param {CsTypes.DecomposeContext} rootContext the entity tree to build
     * @param {OrderCandidateResponse} response the OrderCandidateResponse which is being built
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     */
    OrderCandidateResponseBuilder.prototype.BuildRootItem = function (rootContext, response, includeProductCandidateData) {
        // Get the Compiled spec and find the root item key
        var rootSpecItem = rootContext.CompiledSpec.CompositionTree;
        var rootKey = rootSpecItem.Key.toString();
        // Get the root item from the Orderfolio
        var rootOrderfolioItems = rootContext.Orderfolio[rootKey];
        if (rootOrderfolioItems.length !== 1) {
            this._errorContext.RaiseCsError(400, ErrorCode.Validation.InvalidStructure);
            return;
        }
        var rootOrderfolioItem = rootOrderfolioItems[0];
        // If the root has no OrderId - nothing to do
        if (Utilities.IsNotDefined(rootOrderfolioItem.OrderItemId, true)) {
            return;
        }
        // Build the root OrderItem and shove into the OrderCandidate
        var rootOrderItem = this.CreateOrderItemFromOrderfolio(rootOrderfolioItem, rootContext);
        if (Utilities.IsDefined(rootOrderItem)) {
            response.OrderCandidate.OrderItems.push(rootOrderItem);
        }
        // Build the root PortfolioItem and shove into the CustomerPortfolio
        var rootPortfolioItem = this.CreatePortfolioItemFromOrderfolio(rootOrderfolioItem, includeProductCandidateData, rootContext, true);
        if (Utilities.IsDefined(rootPortfolioItem)) {
            response.CustomerPortfolio.AffectedPortfolioItems.push(rootPortfolioItem);
        }
        if (rootOrderfolioItem.IsInvalid) {
            return;
        }
        // Build the children
        this.BuildChildren(rootContext, rootOrderfolioItem.CompoundKey, rootOrderItem, rootPortfolioItem, includeProductCandidateData);
        // Get the technical items from the compiled spec
        var technicalItemList = rootContext.CompiledSpec.TechnicalItems;
        // If we have technical items, check whether the root item is one of them
        var itemIsTechnical = technicalItemList ? rootContext.CompiledSpec.TechnicalItems.indexOf(rootSpecItem.Key) !== -1 : false;
        // If our BoundaryCondition is technical, validate
        // If our BoundaryCondition is commercial, only validate if our root item is commercial
        var shouldValidate = (rootContext.BoundaryCondition === BoundaryConditionConstants.Commercial) ? !itemIsTechnical : true;
        if (!rootPortfolioItem || !shouldValidate) {
            return;
        }
        this.ValidateGroupCardinality(rootPortfolioItem, rootOrderfolioItem.CompoundKey.Key, rootContext.CompiledSpec.CardinalityLookups.UuidToGroup, rootContext);
    };
    /**
     * Validates that the group cardinality on the supplied portfolio item has been met
     * @param {string} cardinalityTableKey the key in the group cardinality table that contains the group cardinality data
     * @param {AffectedPortfolioItem} portfolioItem the portfolio item to validate
     * @param {CsTypes.Dictionary<CsTypes.Cardinality>} groupCardinalityTable the ptable that contains all the group cardinalities
     */
    OrderCandidateResponseBuilder.prototype.ValidateGroupCardinality = function (portfolioItem, cardinalityTableKey, groupCardinalityTable, rootContext) {
        var groupCardinality = groupCardinalityTable[cardinalityTableKey];
        if (!groupCardinality) {
            return;
        }
        var numberOfChildren = this.GetApplicableChildCountForGroupCardinality(groupCardinality, portfolioItem);
        // If there are not enough commercial children to satisfy group cardinality, also consider technical children which could be included
        if (numberOfChildren < groupCardinality.Cardinality.Min) {
            var numberOfTechnicalChildren = this.CalculateAvailableTechnicalChildren(portfolioItem, groupCardinality);
            // We may get a maxvalue returned, so guard against overflows by checking if our value is large enough
            // to satisfy cardinality before adding anything to it
            if (numberOfTechnicalChildren >= groupCardinality.Cardinality.Min || (numberOfTechnicalChildren + numberOfChildren) >= groupCardinality.Cardinality.Min) {
                numberOfChildren = groupCardinality.Cardinality.Min;
            }
        }
        var minCardinalityNotMet = (numberOfChildren < groupCardinality.Cardinality.Min);
        var maxCardinalityExceeded = (numberOfChildren > groupCardinality.Cardinality.Max);
        if (minCardinalityNotMet || maxCardinalityExceeded) {
            var phaseCodes = undefined;
            if (minCardinalityNotMet) {
                // Only return PhaseCodes where the minimum Cardinality is not met
                phaseCodes = PhaseCodeAccessor.GetGroupCardinalityPhaseCodes(rootContext.CompiledSpec, cardinalityTableKey, rootContext.BoundaryCondition);
            }
            this._errorContext.RaiseValidationError(ErrorCode.Validation.GroupCardinalityNotSatisfied, portfolioItem.ID, portfolioItem.EntityID, undefined, undefined, undefined, phaseCodes);
        }
    };
    /**
     * Calculates whether enough technical children exist to satisfy minimum group cardinality
     * @param {AffectedPortfolioItem} portfolioItem the portfolio item to check for technical children
     * @param {number} minCardinality the minimum value which must be reached to validate the group cardinality
     * @param {number} existingChildCount the current number of (commercial) children on the portfolio item
     */
    OrderCandidateResponseBuilder.prototype.CalculateAvailableTechnicalChildren = function (portfolioItem, groupCardinality) {
        if (groupCardinality.TechnicalChildCardinality.length === 0) {
            return 0;
        }
        var technicalChildCount = 0;
        for (var technicalChildIndex = 0; technicalChildIndex < groupCardinality.TechnicalChildCardinality.length; technicalChildIndex++) {
            var technicalChildCardinality = groupCardinality.TechnicalChildCardinality[technicalChildIndex];
            // Get the available technical children of this entity by calculating the maximum and subtracting those already applied
            technicalChildCount += technicalChildCardinality.Cardinality.Max -
                portfolioItem.ChildEntities.filter(function (x) { return x.EntityID === technicalChildCardinality.EntityID; }).length;
            // If entity cardinality is not set, it will default to maxvalue, so guard against overflow
            if (technicalChildCount > groupCardinality.Cardinality.Min) {
                break;
            }
        }
        return technicalChildCount;
    };
    /**
     * Gets the number of children on the portfolio item that apply towards the total group cardinality
     * @param {CsTypes.GroupCardinality} groupCardinality The group cardinality to apply
     * @param {AffectedPortfolioItem} portfolioItem The portfolio item
     * @returns {number}
     */
    OrderCandidateResponseBuilder.prototype.GetApplicableChildCountForGroupCardinality = function (groupCardinality, portfolioItem) {
        if (Utilities.IsNotDefined(groupCardinality.AppliesToEntities) || groupCardinality.AppliesToEntities.length < 1) {
            return 0;
        }
        var childEntities = (portfolioItem && portfolioItem.ChildEntities) ? portfolioItem.ChildEntities : [];
        if (childEntities.length === 0) {
            return 0;
        }
        var applicableChildren = childEntities.filter(function (child) { return groupCardinality.AppliesToEntities.indexOf(child.EntityID) > -1; });
        return applicableChildren.length;
    };
    /**
     * Build the children of a parent entity
     * @param {CsTypes.DecomposeContext} rootContext the DecomposeContext for the current entity tree
     * @param {CsTypes.OrderfolioItemLookup} parentLookup The unique identifier for the root entity in the orderfolio
     * @param {OrderItem} parentOrderItem child order items are pushed into the ChildOrderItems array of this item
     * @param {AffectedPortfolioItem} parentPortfolioItem child portfolio items are stored in the ChildEntities array of this item
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     */
    OrderCandidateResponseBuilder.prototype.BuildChildren = function (rootContext, parentLookup, parentOrderItem, parentPortfolioItem, includeProductCandidateData) {
        var _this = this;
        // Nothing to do if parent order and portfolio items are not defined
        if (Utilities.IsNotDefined(parentOrderItem) && Utilities.IsNotDefined(parentPortfolioItem)) {
            return;
        }
        // Get the Array of OrderfolioItems from the ParentToChild table
        var childItemLookups = rootContext.ParentToChildTable[parentLookup.Key + "-" + parentLookup.Index];
        if (Utilities.IsNotDefined(childItemLookups, true)) {
            return;
        }
        childItemLookups.forEach(function (childLookup) {
            // Retrieve the child OrderfolioItem from the context
            var childItem = rootContext.Orderfolio[childLookup.Key.toString()][childLookup.Index];
            // Remove any items that have been added by a mapping rule or inferred and are going to be deleted
            if (childItem.ItemAdded === true && childItem.Action === "delete") {
                return;
            }
            // Create the child OrderItem and shove it into the ChildOrderItems array
            var childOrderItem = Utilities.IsDefined(parentOrderItem)
                ? _this.CreateOrderItemFromOrderfolio(childItem, rootContext, parentOrderItem)
                : undefined;
            if (Utilities.IsDefined(childOrderItem)) {
                parentOrderItem.ChildOrderItems.push(childOrderItem);
            }
            // Create the PortfolioItem, and if created push it into the ChildEntities array
            var childPortfolioItem = Utilities.IsDefined(parentPortfolioItem)
                ? _this.CreatePortfolioItemFromOrderfolio(childItem, includeProductCandidateData, rootContext)
                : undefined;
            if (Utilities.IsDefined(childPortfolioItem)) {
                parentPortfolioItem.ChildEntities.push(childPortfolioItem);
            }
            if (Utilities.IsNotDefined(childOrderItem) && Utilities.IsNotDefined(childPortfolioItem)) {
                return;
            }
            if (childItem.IsInvalid) {
                return;
            }
            // If we have either order or portfolio item then Build the children's children
            _this.BuildChildren(rootContext, childLookup, childOrderItem, childPortfolioItem, includeProductCandidateData);
            var technicalItemList = rootContext.CompiledSpec.TechnicalItems;
            var itemIsTechnical = technicalItemList ? rootContext.CompiledSpec.TechnicalItems.indexOf(childItem.CompoundKey.Key) !== -1 : false;
            var shouldValidate = (rootContext.BoundaryCondition === BoundaryConditionConstants.Commercial) ? !itemIsTechnical : true;
            //only perform group cardinality validation if we have a portfolio item that does not have technical children in the spec
            if (!childPortfolioItem || !shouldValidate) {
                return;
            }
            _this.ValidateGroupCardinality(childPortfolioItem, childItem.CompoundKey.Key, rootContext.CompiledSpec.CardinalityLookups.UuidToGroup, rootContext);
        });
    };
    /**
     * Create an AffectedPortfolioItem from the supplied Orderfolio
     * Deleted entities or characteristics are not included.
     * Only include final position of portfolio item
     * @param {CsTypes.OrderfolioItem} ofItem the OrderfolioItem to use as the source
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     * @param {boolean} [isRoot] Default: false. Whether this is a root item or not
     * @returns {AffectedPortfolioItem} an AffectedPortfolioItem, undefined if item should not be included in portfolio
     */
    OrderCandidateResponseBuilder.prototype.CreatePortfolioItemFromOrderfolio = function (ofItem, includeProductCandidateData, decomposeContext, isRoot) {
        if (isRoot === void 0) { isRoot = false; }
        if (ofItem.IsInvalid) {
            return ofItem.ItemPair.PortfolioItem;
        }
        // If action is Deleted or it's undefined, then item does not go in response
        if (isRoot && (Utilities.IsNotDefined(ofItem.Action) || ofItem.Action === OrderActions.NoChange)) {
            return undefined;
        }
        // If action is Deleted or Reassign, then item does not go in response
        if (ofItem.Action === OrderActions.Delete || ofItem.Action === OrderActions.Reassign) {
            return undefined;
        }
        // If item is an additional charge, it should not be returned in response
        if (ofItem.IsAdditionalCharge) {
            return undefined;
        }
        // Set properties
        var newPortfolioItem = new AffectedPortfolioItem();
        newPortfolioItem.ID = ofItem.PortfolioItemId;
        newPortfolioItem.EntityID = ofItem.EntityId;
        newPortfolioItem.ItemAction = ofItem.Action;
        newPortfolioItem.ItemSource = this.GetPortfolioItemSource(ofItem);
        newPortfolioItem.UnitQuantity = Utilities.ValueOrDefault(ofItem.UnitQuantity, undefined);
        // Include any properties specific for ProductCandidate
        if (includeProductCandidateData) {
            // ProductCandidates are converted to OrderItems on the way in, but use Portfolio on the way out
            // IsNewForCustormer. true if Add, false if update
            newPortfolioItem._IsNewForCustomer = (ofItem.Action === OrderActions.Add);
            // Output IDs need to match input Ids
            newPortfolioItem.ID = ofItem.OrderItemId;
            // Set NotAvailable for compatibility Rule marker
            newPortfolioItem.NotAvailable = Utilities.ValueOrDefault(ofItem.NotAvailable, undefined);
        }
        // Correlations --> Not used in version 2.0
        // Rating Attributes
        newPortfolioItem.RateAttributes = this.BuildRateAttributes(ofItem.RatingAttributes, false);
        // CharacteristicUses
        newPortfolioItem.CharacteristicUses = this.BuildCharacteristicUses(ofItem.CharacteristicUses, false, decomposeContext.CompiledSpec, includeProductCandidateData);
        // ConfiguredValues
        newPortfolioItem.ConfiguredValues = this.BuildConfiguredValues(ofItem.UserDefinedCharacteristics, false, decomposeContext.CompiledSpec, includeProductCandidateData);
        // LinkedEntity
        newPortfolioItem.LinkedEntities = this.BuildEntityLinks(ofItem, decomposeContext, false);
        return newPortfolioItem;
    };
    /**
     * Create an OrderItem from the supplied Orderfolio
     * @param {CsTypes.OrderfolioItem} ofItem the OrderfolioItem to use as the source
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {OrderItem} parent The parent of this order item
     * @returns {OrderItem} an OrderItem
     */
    OrderCandidateResponseBuilder.prototype.CreateOrderItemFromOrderfolio = function (ofItem, decomposeContext, parent) {
        if (ofItem.IsInvalid) {
            return ofItem.ItemPair.OrderItem;
        }
        var itemAction = this.GetOrderItemAction(ofItem, parent);
        // If this orderfolio item has not been affected then do not output it
        if (Utilities.IsNotDefined(itemAction) || itemAction === OrderActions.NoChange) {
            return undefined;
        }
        // If item is an additional charge, it should not be returned in response
        if (ofItem.IsAdditionalCharge) {
            return undefined;
        }
        // Set properties
        var newOrderItem = new OrderItem();
        newOrderItem.ID = Utilities.IsDefined(ofItem.OrderItemId, true) ? ofItem.OrderItemId : Utilities.CreateID();
        newOrderItem.PortfolioItemID = Utilities.IsDefined(ofItem.PortfolioItemId, true) ? ofItem.PortfolioItemId : newOrderItem.PortfolioItemID;
        newOrderItem.EntityID = ofItem.EntityId;
        newOrderItem.ItemAction = itemAction;
        newOrderItem.ItemSource = this.GetOrderItemSource(ofItem);
        newOrderItem.DecomposeGenID = ofItem.DecomposeGenID;
        newOrderItem.UnitQuantity = Utilities.ValueOrDefault(ofItem.UnitQuantity, undefined);
        // Update the orderfolioItem, it may not have a portfolio item, because this is an order that doesn't exist in the portfolio
        ofItem.PortfolioItemId = newOrderItem.PortfolioItemID;
        // Correlations --> Not used in version 2.0
        // Rating Attributes
        newOrderItem.RateAttributes = this.BuildRateAttributes(ofItem.RatingAttributes, true);
        // CharacteristicUses
        newOrderItem.CharacteristicUses = this.BuildCharacteristicUses(ofItem.CharacteristicUses, true, decomposeContext.CompiledSpec, false);
        // ConfiguredValues
        newOrderItem.ConfiguredValues = this.BuildConfiguredValues(ofItem.UserDefinedCharacteristics, true, decomposeContext.CompiledSpec, false);
        // LinkedEntity
        newOrderItem.LinkedEntities = this.BuildEntityLinks(ofItem, decomposeContext, true);
        return newOrderItem;
    };
    /**
     * Build an array of CharacteristicUsesfrom array of compiled CharacteristicUses of a OrderfolioItem.
     * Distinguish between Order & Portfolio requirements
     * @param {Array<CsTypes.CharacteristicUse>} charUses the CharacteristicUse array from an OrderfolioItem
     * @param {boolean} buildForOrder true if this is being built for an Order, otherwise treat as Portfolio
     * @param {boolean} includeProductCandidateData include properties required by legacy CPQ 1.x
     * @returns {Array<CharacteristicUse>} an array of CharacteristicUses ready for the OrderCandidateResponse
     */
    OrderCandidateResponseBuilder.prototype.BuildCharacteristicUses = function (charUses, buildForOrder, compiledSpecification, includeProductCandidateData) {
        var _this = this;
        var builtCharUses = [];
        charUses.forEach(function (charUse) {
            var charUseInfo = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseId];
            if (!charUseInfo) {
                return;
            }
            var newCharUseData = {
                UseArea: charUseInfo.UseArea,
                CharacteristicID: charUseInfo.CharacteristicId,
                Action: (buildForOrder ? OrderActions.Modify : undefined),
                Value: (buildForOrder ? _this.BuildCharValuesForOrder(charUse.Values, false)
                    : _this.BuildCharValuesForPortfolio(charUse.Values, false, includeProductCandidateData)),
                ItemSource: (buildForOrder) ? (_this.GetOrderItemSource(charUse)) : (_this.GetPortfolioItemSource(charUse))
            };
            // If this is for ProductCandidate, include NotAvailable if set && save
            if (!buildForOrder && includeProductCandidateData && Utilities.IsDefined(charUse.NotAvailable)) {
                newCharUseData['NotAvailable'] = charUse.NotAvailable;
                builtCharUses.push(new CharacteristicUse(newCharUseData));
            }
            // Build the CharacteristicUse and push into the results array  only if there are some values
            else if ((newCharUseData.Value && newCharUseData.Value.length > 0)) {
                builtCharUses.push(new CharacteristicUse(newCharUseData));
            }
        });
        return builtCharUses;
    };
    /**
     * Build an array of ConfiguredValues from array of compiled CharacteristicUses of a OrderfolioItem.
     * Distinguish between Order & Portfolio requirements
     * @param {Array<CsTypes.CharacteristicUse>} charUses the CharacteristicUse array from an OrderfolioItem
     * @param {boolean} buildForOrder true if this is being built for an Order, otherwise treat as Portfolio
     * @returns {Array<UserDefinedCharacteristicUse>} an array of ConfiguredValuesUserDefinedCharacteristicUses ready for the OrderCandidateResponse
     */
    OrderCandidateResponseBuilder.prototype.BuildConfiguredValues = function (charUses, buildForOrder, compiledSpecification, includeProductCandidateData) {
        var _this = this;
        var builtConfigValues = [];
        charUses.forEach(function (charUse) {
            if (!charUse.UseId) {
                return;
            }
            var charUseInfo = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseId];
            if (Utilities.IsNotDefined(charUseInfo)) {
                return;
            }
            var newConfValueData = {
                UseID: charUse.UseId,
                UseArea: charUseInfo.UseArea,
                CharacteristicID: charUseInfo.CharacteristicId,
                Action: (buildForOrder ? OrderActions.Modify : undefined),
                Value: (buildForOrder ? _this.BuildCharValuesForOrder(charUse.Values, true)
                    : _this.BuildCharValuesForPortfolio(charUse.Values, true, includeProductCandidateData)),
                ItemSource: (buildForOrder) ? (_this.GetOrderItemSource(charUse)) : (_this.GetPortfolioItemSource(charUse))
            };
            // If this is for ProductCandidate, include NotAvailable if set
            if (!buildForOrder && includeProductCandidateData && Utilities.IsDefined(charUse.NotAvailable)) {
                newConfValueData['NotAvailable'] = charUse.NotAvailable;
                builtConfigValues.push(new UserDefinedCharacteristicUse(newConfValueData));
            }
            // Build the UserDefinedCharacteristicUse and push into the results array only if there are some values
            else if (newConfValueData.Value && newConfValueData.Value.length > 0) {
                builtConfigValues.push(new UserDefinedCharacteristicUse(newConfValueData));
            }
        });
        return builtConfigValues;
    };
    /**
     * Build the pojo values for a CharacteristicUse/ConfiguredValue required for an OrderItem
     * @param {Array<CsTypes.MergedValue>} charValues the array of MergedValues from the OrderfolioItem
     * @param {boolean} buildForConfiguredValue true if the char values should have Value instead of ValudID
     * @returns {Array<any>} an array of POJO classes which can be passed to the constructor of CharactisticValue
     */
    OrderCandidateResponseBuilder.prototype.BuildCharValuesForOrder = function (charValues, buildForConfiguredValue) {
        var builtCharValues = [];
        var buildForCharacteristicUse = !buildForConfiguredValue;
        charValues.forEach(function (charValue) {
            var valueAction = OrderfolioQueries.OrderActionForMergedAction(charValue.Action);
            // only create the value if there is an action
            if (Utilities.IsDefined(valueAction)) {
                builtCharValues.push({
                    Value: (buildForConfiguredValue ? charValue.Value : undefined),
                    ValueID: (buildForCharacteristicUse ? charValue.Value : undefined),
                    ValueDetail: (charValue.ValueDetail ? charValue.ValueDetail : undefined),
                    Action: valueAction,
                    ItemSource: charValue.ItemSource
                });
            }
        });
        return builtCharValues;
    };
    /**
     * Build the pojo values for a CharacteristicUse/ConfiguredValue required for an PortfolioItem
     * @param {Array<CsTypes.MergedValue>} charValues the array of MergedValues from the OrderfolioItem
     * @returns {Array<any>} an array of POJO classes which can be passed to the constructor of CharactisticValue
     */
    OrderCandidateResponseBuilder.prototype.BuildCharValuesForPortfolio = function (charValues, buildForConfiguredValue, includeProductCandidateData) {
        var _this = this;
        var builtCharValues = [];
        var buildForCharacteristicUse = !buildForConfiguredValue;
        charValues.forEach(function (charValue) {
            // only create the value if it should be included
            if (_this.IncludePortfolioValueGivenMergedAction(charValue.Action)) {
                var newCharVal = {
                    Value: (buildForConfiguredValue ? charValue.Value : undefined),
                    ValueID: (buildForCharacteristicUse ? charValue.Value : undefined),
                    ValueDetail: (charValue.ValueDetail ? charValue.ValueDetail : undefined),
                    Action: undefined,
                    ItemSource: charValue.ItemSource
                };
                // If this is for ProductCandidate, include NotAvailable if set
                if (includeProductCandidateData && Utilities.IsDefined(charValue.NotAvailable)) {
                    newCharVal['NotAvailable'] = charValue.NotAvailable;
                }
                builtCharValues.push(newCharVal);
            }
        });
        return builtCharValues;
    };
    /**
     * Build an array of RateAttributes from the Orderfolio compiled RateAttributes array
     * specifying order or portfolio.
     * @param {Array<CsTypes.RateAttribute>} compliledRates the source compiled RateAttributes
     * @param {boolean} buildForOrder true if being built for an OrderItem, otherwise build for PortfolioItem
     * @returns {Array<RateAttribute>} An array of RateAttributes
     */
    OrderCandidateResponseBuilder.prototype.BuildRateAttributes = function (compiledRates, buildForOrder) {
        var _this = this;
        var builtRates = [];
        compiledRates.forEach(function (compiledRate) {
            var rateAction = undefined;
            if (buildForOrder) {
                rateAction = OrderfolioQueries.OrderActionForMergedAction(compiledRate.Action);
                if (Utilities.IsNotDefined(rateAction)) {
                    return;
                }
            }
            else if (!_this.IncludePortfolioValueGivenMergedAction(compiledRate.Action)) {
                // If we're doing portfolio rates and it shouldn't be included, nothing to do
                return;
            }
            builtRates.push(new RateAttribute({
                Name: compiledRate.Name,
                Value: compiledRate.Value,
                Action: rateAction,
                ItemSource: (buildForOrder) ? (_this.GetOrderItemSource(compiledRate)) : (_this.GetPortfolioItemSource(compiledRate))
            }));
        });
        return builtRates;
    };
    /**
     * Builds the entity links for an orderfolio item
     * @param {CsTypes.SourceToTargetEntityLink[]} entityLinks The entity links for the orderfolio item
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem>} orderfolio The orderfolio
     * @param {boolean} buildForOrder Indicates whether we are building for an order
     * @returns {EntityLink[]}
     */
    OrderCandidateResponseBuilder.prototype.BuildEntityLinks = function (orderfolioItem, decomposeContext, buildForOrder) {
        if (Utilities.IsNotDefined(decomposeContext.LinkedEntities, true)) {
            return [];
        }
        var entityLinks = decomposeContext.LinkedEntities.filter(function (l) {
            return OrderfolioQueries.CompareOrderfolioItemLookup(orderfolioItem.CompoundKey, l.Source);
        });
        var linkedEntities = [];
        for (var linkIdx = 0; linkIdx < entityLinks.length; linkIdx++) {
            var link = entityLinks[linkIdx];
            if (link.IsInvalid && !buildForOrder) {
                continue;
            }
            var linkTarget = this.BuildLinkTarget(link, decomposeContext, buildForOrder);
            if (Utilities.IsNotDefined(linkTarget)) {
                continue;
            }
            var existingLink = LodashUtilities.Find(linkedEntities, function (l) { return l.LinkTypeID === link.LinkTypeID; });
            if (Utilities.IsDefined(existingLink)) {
                existingLink.Links.push(linkTarget);
            }
            else {
                var orderfolioItemSource = { OrderItemSource: link.OrderEntityLinkItemSource, PortfolioItemSource: link.PortfolioEntityLinkItemSource };
                var entityLinkAction = (buildForOrder) ? (OrderActions.Modify) : (undefined);
                var entityLink = new EntityLink({
                    LinkTypeID: link.LinkTypeID,
                    Links: [linkTarget],
                    Action: entityLinkAction,
                    ItemSource: (buildForOrder) ? (this.GetOrderItemSource(orderfolioItemSource)) : (this.GetPortfolioItemSource(orderfolioItemSource))
                });
                linkedEntities.push(entityLink);
            }
        }
        return linkedEntities;
    };
    /**
     * Builds a link target from a compiled entity link
     * @param {CsTypes.SourceToTargetEntityLink} link The compiled entity link
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {boolean} buildForOrder If we are building for an order
     * @returns {LinkTarget} The link target
     */
    OrderCandidateResponseBuilder.prototype.BuildLinkTarget = function (link, decomposeContext, buildForOrder) {
        var _this = this;
        var includeTarget = function (action) {
            return (buildForOrder && Utilities.IsDefined(action)) || (!buildForOrder && _this.IncludePortfolioValueGivenMergedAction(action));
        };
        var linkAction = (buildForOrder) ? (OrderfolioQueries.OrderActionForMergedAction(link.LinkAction)) : (link.LinkAction);
        if (!includeTarget(linkAction)) {
            return undefined;
        }
        var portfolioItemID = this.GetPortfolioItemForLink(link, decomposeContext);
        var orderfolioItemSource = { OrderItemSource: link.OrderLinkItemSource, PortfolioItemSource: link.PortfolioLinkItemSource };
        var linkTarget = {
            PortfolioItemID: portfolioItemID,
            Action: linkAction,
            ChangeType: undefined,
            ItemSource: (buildForOrder) ? (this.GetOrderItemSource(orderfolioItemSource)) : (this.GetPortfolioItemSource(orderfolioItemSource)),
            DecomposeGenID: link.DecomposeGenID
        };
        return linkTarget;
    };
    /**
     * Gets the portfolio item ID for an entity link
     * @param {CsTypes.SourceToTargetEntityLink} link The source to target link
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {string}
     */
    OrderCandidateResponseBuilder.prototype.GetPortfolioItemForLink = function (link, decomposeContext) {
        var portfolioItemID;
        if (Utilities.IsDefined(link.Target)) {
            var targetOrderfolioItem = decomposeContext.Orderfolio[link.Target.Key][link.Target.Index];
            portfolioItemID = targetOrderfolioItem.PortfolioItemId;
        }
        else {
            // Happens if the target the entity link points to is not in the order request
            // Therefore we just put out what was there originally
            portfolioItemID = link.PortfolioItemID;
        }
        return portfolioItemID;
    };
    /**
     * Apply the MergedAction truth table for an PortfolioItem
     * See truth table for MergedAction in the Visio diagram
     * @param {string} mergedAction the mergedAction to decipher
     * @returns {boolean} true if value associated with action should be included in Portfolio
     */
    OrderCandidateResponseBuilder.prototype.IncludePortfolioValueGivenMergedAction = function (mergedAction) {
        var includeValue = false;
        // See truth table for MergedAction
        switch (mergedAction) {
            case MergedActions.AddExisting:
            case MergedActions.SkipExisting:
            case MergedActions.AddMissing:
                includeValue = true;
                break;
            case MergedActions.DeleteExisting:
            case MergedActions.DeleteMissing:
                includeValue = false;
                break;
        }
        return includeValue;
    };
    /**
     * Get the item source for an item in the order
     * @param {CsOrderfolioItemSource} item The item to look at
     * @returns {string} The item source
     */
    OrderCandidateResponseBuilder.prototype.GetOrderItemSource = function (item) {
        return (Utilities.IsDefined(item.OrderItemSource, true)) ? (item.OrderItemSource) : (item.PortfolioItemSource);
    };
    /**
     * Get the item source for an item in the portfolio
     * @param {CsOrderfolioItemSource} item The item to look at
     * @returns {string} The item source
     */
    OrderCandidateResponseBuilder.prototype.GetPortfolioItemSource = function (item) {
        return (Utilities.IsDefined(item.PortfolioItemSource, true)) ? (item.PortfolioItemSource) : (item.OrderItemSource);
    };
    /**
     * Get the order item action for an orderfolio item
     * @param {CsTypes.OrderfolioItem} ofItem The orderfolio item
     * @param {OrderItem} parent The parent order item
     * @returns {string}
     */
    OrderCandidateResponseBuilder.prototype.GetOrderItemAction = function (ofItem, parent) {
        if (Utilities.IsDefined(ofItem.Action, true)) {
            return ofItem.Action;
        }
        if (Utilities.IsDefined(parent) && parent.ItemAction === OrderActions.Delete) {
            return OrderActions.Delete;
        }
        return undefined;
    };
    /**
     * Builds validation errors using the error context
     * @returns {Array<ValidationError>} validation errors recorded in error context
     */
    OrderCandidateResponseBuilder.prototype.BuildValidationErrors = function () {
        return this._errorContext.GetValidationErrorsForResponse();
    };
    return OrderCandidateResponseBuilder;
}());
module.exports = OrderCandidateResponseBuilder;

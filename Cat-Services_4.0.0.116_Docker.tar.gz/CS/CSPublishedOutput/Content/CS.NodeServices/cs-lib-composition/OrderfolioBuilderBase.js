"use strict";
var Utilities = require("../cs-lib-utilities/Utilities");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("./OrderfolioQueries");
var OrderfolioBuilderBase = /** @class */ (function () {
    function OrderfolioBuilderBase(errorContext, requestId) {
        this._errorContext = errorContext;
        this._requestId = requestId;
    }
    /**
     * Gets the item source using the primary and secondary items
     * Written like this for most reusability
     * If we are getting an ItemSource for an OrderItem then Order is primary and PortfolioItem is secondary
     * If we are getting an ItemSource for a PortfolioItem then PortfolioItem is primary and OrderItem is secondary
     * @param {CsTypes.ItemSourceObject} primaryItemSource The first item to check for item source
     * @param {CsTypes.ItemSourceObject} secondaryItemSource The second item to check for the item source
     * @param {CsTypes.ItemSourceObject} parent The parent object to check for the item source
     * @returns {string}
     */
    OrderfolioBuilderBase.prototype.GetItemSource = function (primaryItemSource, secondaryItemSource, parent) {
        var itemSource = undefined;
        if (Utilities.IsDefined(primaryItemSource) && Utilities.IsDefined(primaryItemSource.ItemSource, true)) {
            itemSource = OrderfolioQueries.GetItemSource(primaryItemSource, this._requestId);
        }
        else if (Utilities.IsNotDefined(itemSource) && Utilities.IsDefined(secondaryItemSource) && Utilities.IsDefined(secondaryItemSource.ItemSource, true)) {
            itemSource = OrderfolioQueries.GetItemSource(secondaryItemSource, this._requestId);
        }
        else {
            itemSource = OrderfolioQueries.GetItemSource(undefined, this._requestId, parent);
        }
        return itemSource;
    };
    /**
     * Validates the property action against the order item action
     * @param  {string}  orderfolioItemAction The orderfolio action
     * @param  {string}  propertyAction       The property action
     * @return {boolean}                      True if the order action is valid, otherwise false
     */
    OrderfolioBuilderBase.prototype.ValidatePropertyActionAgainstOrderItem = function (orderfolioItemAction, propertyAction) {
        switch (orderfolioItemAction) {
            case OrderActions.Add:
                return propertyAction === OrderActions.Modify;
            case OrderActions.Delete:
                return propertyAction === OrderActions.Modify || propertyAction === OrderActions.Delete;
            default:
                return true;
        }
    };
    /**
     * Validates the value action against the order item action
     * @param  {string} orderfolioItemAction The orderfolio action
     * @param  {string} valueAction          The value action
     * @return {[boolean]}                   True if the value action is valid, otherwise false
     */
    OrderfolioBuilderBase.prototype.ValidateValueActionAgainstOrderItem = function (orderfolioItemAction, valueAction) {
        switch (orderfolioItemAction) {
            case OrderActions.Add:
                return valueAction === OrderActions.Add;
            case OrderActions.Delete:
                return valueAction === OrderActions.Delete;
            default:
                return true;
        }
    };
    /**
     * Validates the value action against the property action
     * @param  {string} propertyAction The property action
     * @param  {string} valueAction    The value action
     * @return {[boolean]}             True if the value action is valid, otherwise false
     */
    OrderfolioBuilderBase.prototype.ValidateValueActionAgainstProperty = function (propertyAction, valueAction) {
        switch (propertyAction) {
            case OrderActions.Delete:
                return valueAction === OrderActions.Delete;
            case OrderActions.Replace:
                return valueAction === OrderActions.Add;
            default:
                return true;
        }
    };
    return OrderfolioBuilderBase;
}());
module.exports = OrderfolioBuilderBase;

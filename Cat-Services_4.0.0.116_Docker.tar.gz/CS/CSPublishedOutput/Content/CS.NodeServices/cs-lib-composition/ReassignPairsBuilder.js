"use strict";
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var ReassignPair = require("../cs-lib-types/BusinessEntities/ReassignPair");
var ReassignPairsResult = require("../cs-lib-types/BusinessEntities/ReassignPairsResult");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
* Class creates matching pairs of reassign & reassigned order entities and provides helper methods to find pairs
*/
var ReassignPairsBuilder = /** @class */ (function () {
    function ReassignPairsBuilder() {
    }
    /**
    * Match each reassign item in the order to its equivalent reassigned/reassignedUpdate item in the same order
    * @param {Array<IOrderItem>)} orderItems
    * @returns {ReassignPairsResult}
    */
    ReassignPairsBuilder.prototype.BuildReassignPairs = function (orderItems) {
        Logger.debug(0, "Reassign", "Finding Reassign Pairs");
        var reassignPairsResult = new ReassignPairsResult();
        // Create a list of reassign and reassigned Items
        var listItems = function (orderItems) {
            orderItems.forEach(function (orderItem) {
                switch (orderItem.ItemAction) {
                    case OrderActions.Reassign:
                        Logger.debug(1, "Reassign", "OrderItem with a PortfolioID of " + orderItem.PortfolioItemID + " has Reassign action", { OrderItem: orderItem });
                        reassignPairsResult.ReassignItems.push(orderItem);
                        break;
                    case OrderActions.Reassigned:
                    case OrderActions.ReassignedUpdate:
                        Logger.debug(1, "Reassign", "OrderItem with a PortfolioID of " + orderItem.PortfolioItemID + " has Reassigned or ReassignedUpdate action", { OrderItem: orderItem });
                        reassignPairsResult.ReassignedItems.push(orderItem);
                        break;
                }
                if (orderItem.ChildOrderItems && orderItem.ChildOrderItems.length > 0) {
                    listItems(orderItem.ChildOrderItems);
                }
            });
        };
        listItems(orderItems);
        // Attempt to pair up the reassign and reassigned items
        reassignPairsResult.ReassignItems.forEach(function (reassignItem) {
            /**
            * We need to check the Number of OrderItems matching with EntityID present in the list specially in the scenario when the particular entity
            * can appear more than once bacause of cardinality. In these scenarios PortfolioItemID is used as second matching criteria to create reassign
            * pairs
            */
            var orderItemCount = ReassignPairsBuilder.NumberOfOrderItemsWithMatchingEntityID(reassignPairsResult.ReassignedItems, reassignItem.EntityID);
            var reassignedItem;
            if (orderItemCount > 1) {
                reassignedItem = LodashUtilities.Find(reassignPairsResult.ReassignedItems, function (reassignedItem) {
                    return (reassignedItem.EntityID === reassignItem.EntityID && reassignedItem.PortfolioItemID === reassignItem.PortfolioItemID);
                });
            }
            else {
                reassignedItem = LodashUtilities.Find(reassignPairsResult.ReassignedItems, function (reassignedItem) {
                    return reassignedItem.EntityID === reassignItem.EntityID;
                });
            }
            if (reassignedItem) {
                Logger.debug(1, "Reassign", "Found pair for entity: " + reassignItem.PortfolioItemID, {
                    ReassignItem: reassignItem,
                    ReassignedItem: reassignedItem
                });
                reassignPairsResult.ReassignPairs.push(ReassignPairsBuilder.BuildReassignPair(reassignItem, reassignedItem));
            }
        });
        return reassignPairsResult;
    };
    /**
    * Creates a reassign pair from two order items, one reassign item and a matching reassigned item
    * @param {IOrderItem} reassignItem
    * @param {IOrderItem} reassignedItem
    * @returns {ReassignPair}
    */
    ReassignPairsBuilder.BuildReassignPair = function (reassignItem, reassignedItem) {
        // Duplicate the PortfolioItemID from the reassignItem to the reassignedItem
        // This is used to ensure the items can be matched in the ordercandidate
        reassignedItem.PortfolioItemID = reassignItem.PortfolioItemID;
        return new ReassignPair(reassignItem.EntityID, reassignItem.PortfolioItemID, reassignItem, reassignedItem);
    };
    /**
    * Find the matching reassign item for a reassigned item
    * @param {Array<ReassignPair>} reassignPairs
    * @param {string} entityID
    * @returns ReassignPair
    */
    ReassignPairsBuilder.FindReassignPair = function (reassignPairs, entityID, portfolioItemID) {
        /**
        * We need to check the Number of OrderItems matching with EntityID present in the list specially in the scenario when the particular entity
        * can appear more than once bacause of cardinality. In these scenarios PortfolioItemID is used as second matching criteria to find reassign
        * pairs
        */
        var orderItemCount = ReassignPairsBuilder.NumberOfOrderItemsWithMatchingEntityID(reassignPairs, entityID);
        if (orderItemCount > 1 && Utilities.IsDefined(portfolioItemID)) {
            return LodashUtilities.Find(reassignPairs, function (pair) {
                return (pair.EntityID === entityID && pair.PortfolioItemID === portfolioItemID);
            });
        }
        return LodashUtilities.Find(reassignPairs, function (pair) { return pair.EntityID === entityID; });
    };
    /**
    * Find the number of Orderitems with matching EntityID present in the given list
    * @param {Array<orderItems>} It can be reassigneditem list or reassignpair list
    * @param {string} entityID
    * @returns Count of matching OrderItem with EntityID
    */
    ReassignPairsBuilder.NumberOfOrderItemsWithMatchingEntityID = function (orderItems, entityId) {
        var count = 0;
        orderItems.forEach(function (value) {
            if (value.EntityID === entityId) {
                count++;
            }
        });
        return count;
    };
    return ReassignPairsBuilder;
}());
module.exports = ReassignPairsBuilder;

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ProductCandidateResponse = require("../cs-lib-types/CPQ-BusinessEntities/ProductCandidateResponse");
var PricingOrderCandidateResponseBuilder = require("./PricingOrderCandidateResponseBuilder");
var Utilities = require("../cs-lib-utilities/Utilities");
var ProductCandidateResponseBuilder = require("./ProductCandidateResponseBuilder");
/**
 * A class responsible for building a ProductCandidateResponse with pricing elements from a set of DecomposeContexts
 * Synonyms: unflatten, inflate, pump,
 */
var PricingProductCandidateResponseBuilder = /** @class */ (function (_super) {
    __extends(PricingProductCandidateResponseBuilder, _super);
    function PricingProductCandidateResponseBuilder(errorContext) {
        var _this = _super.call(this, errorContext) || this;
        _this._pricingResponseBuilder = new PricingOrderCandidateResponseBuilder(errorContext);
        return _this;
    }
    /**
     * Build a ProductCandidateResponse from an array of DecomposeContexts.
     * Adds everything but ValidationErrors which is done by Error service
     * @param {DecomposeContextCollection} order the DecomposeContexts which comprise the order
     * @param {CsErrorContext} errorContext the CsErrorContext to use to record any errors.
     * @returns {OrderCandidateResponse}
     */
    PricingProductCandidateResponseBuilder.prototype.Build = function (compiledOrder) {
        var response = new ProductCandidateResponse();
        // unflatten an OrderCandidateResponse
        var orderResponse = this._pricingResponseBuilder.Build(compiledOrder, true);
        response.ValidationErrors = orderResponse.ValidationErrors;
        if (compiledOrder.length < 1) {
            return response;
        }
        var candidate = orderResponse.CustomerPortfolio.AffectedPortfolioItems[0];
        _super.prototype.RemoveItemSource.call(this, candidate);
        // pick out the bits we want
        response.CreationDate = Utilities.DateString(orderResponse.ActivationDate);
        response.ProductCandidate = candidate;
        return response;
    };
    return PricingProductCandidateResponseBuilder;
}(ProductCandidateResponseBuilder));
module.exports = PricingProductCandidateResponseBuilder;

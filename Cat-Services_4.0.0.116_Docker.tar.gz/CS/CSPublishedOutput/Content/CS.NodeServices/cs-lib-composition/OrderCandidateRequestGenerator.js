"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var CustomerPortfolio = require("../cs-lib-types/BusinessEntities/CustomerPortfolio");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderCandidate = require("../cs-lib-types/BusinessEntities/OrderCandidate");
var OrderCandidateRequest = require("../cs-lib-types/BusinessEntities/OrderCandidateRequest");
var OrderItem = require("../cs-lib-types/BusinessEntities/OrderItem");
var PortfolioItem = require("../cs-lib-types/BusinessEntities/PortfolioItem");
var UserDefinedCharacteristicValue = require("../cs-lib-types/BusinessEntities/UserDefinedCharacteristicValue");
var UserDefinedCharacteristicUse = require("../cs-lib-types/BusinessEntities/UserDefinedCharacteristicUse");
var Utilities = require("../cs-lib-utilities/Utilities");
// ReSharper disable InconsistentNaming
/**
 * A class responsible for building the necessary orderCandidateRequest to take an entity into a new state
 */
var OrderCandidateRequestGenerator = /** @class */ (function () {
    /**
     * Creates a new instance of the OrderCandidateRequestGenerator
     * @param {OrdergenerationRequest} orderGenerationrequest the orderGenerationRequest that contains the old and new version of the entity
     */
    function OrderCandidateRequestGenerator(orderGenerationrequest, errorContext) {
        this._candidatesAreIdentical = null;
        this._orderGenerationRequest = orderGenerationrequest;
        this._errorContext = errorContext;
    }
    Object.defineProperty(OrderCandidateRequestGenerator.prototype, "CandidatesAreIdentical", {
        /**
         * Gets a value that indicates if the candidates are identical.
         */
        get: function () {
            //we need to generate an order to establish whether the candidates are identical or not.
            //so if we have not done so already, then do it now.
            if (this._candidatesAreIdentical === null) {
                this.GenerateOrder();
            }
            if (this._errorContext.HasBreakingErrors) {
                return false;
            }
            return this._candidatesAreIdentical;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * Generates an order candidate request that would take the 'oldCandidate' to the 'newCandidate' (oldCandidate and newCandidate are passed into this object in the orderGenerationRequest)
     * @returns {OrderCandidateRequest} callBack
     */
    OrderCandidateRequestGenerator.prototype.GenerateOrder = function () {
        this._candidatesAreIdentical = true;
        var oldCandidate = this._orderGenerationRequest.OldCandidate;
        var newCandidate = this._orderGenerationRequest.NewCandidate;
        var orderCandidateRequest = new OrderCandidateRequest();
        if (oldCandidate.ID !== newCandidate.ID) {
            this._errorContext.RaiseCsError(400, ErrorCode.Interpret.CannotModifyRootItem, null);
            return null;
        }
        var activationDate = this._orderGenerationRequest.ActivationDate;
        orderCandidateRequest.ID = Utilities.CreateID();
        orderCandidateRequest.ActivationDate = Utilities.IsDefined(activationDate) ? activationDate : Utilities.ParseDateFromString(Date.now().toString());
        orderCandidateRequest.CustomerPortfolio = this.CreateCustomerPortfolioFromProductCandidate(oldCandidate);
        orderCandidateRequest.OrderCandidate = new OrderCandidate();
        orderCandidateRequest.OrderCandidate.OrderID = Utilities.CreateID();
        var rootOrderItem = this.CreateOrderItemForCandidate(oldCandidate, OrderActions.Update);
        this.GenerateRootOrderItem(rootOrderItem, oldCandidate, newCandidate);
        orderCandidateRequest.OrderCandidate.OrderItems.push(rootOrderItem);
        this.GenerateChildOrderItems(rootOrderItem.ChildOrderItems, oldCandidate.ChildEntities, newCandidate.ChildEntities);
        this.UpdateActionHierarchy(rootOrderItem);
        this.PruneOrder(rootOrderItem);
        // If the candidates are identical then remove the order items that were generated. The generation process creates order items
        // with Actions based on the differences between the product candidates as it traverses the hierarchy.
        orderCandidateRequest.OrderCandidate.OrderItems = this._candidatesAreIdentical ? [] : orderCandidateRequest.OrderCandidate.OrderItems;
        return orderCandidateRequest;
    };
    /**
     * Generates the necessary attributes on the root level order item
     * @param   {OrderItem} rootOrderItem The root-level order item to append attributes to
     * @param   {ProductCandidate} oldCandidate The old product candidate attributes
     * @param   {ProductCandidate} newCandidate The new product candidate attributes
     */
    OrderCandidateRequestGenerator.prototype.GenerateRootOrderItem = function (rootOrderItem, oldCandidate, newCandidate) {
        this.GenerateCharacteristicOrderItems(rootOrderItem, oldCandidate.CharacteristicUses, newCandidate.CharacteristicUses);
        this.GenerateUDCOrderItems(rootOrderItem, oldCandidate.ConfiguredValues, newCandidate.ConfiguredValues);
        this.GenerateOrdersForRateAttributes(rootOrderItem, oldCandidate.RateAttributes, newCandidate.RateAttributes);
        this.GenerateOrderItemEntityLinks(rootOrderItem, oldCandidate.LinkedEntities, newCandidate.LinkedEntities);
    };
    /**
    * Generates the necessary child order items for the supplied child entities
    * @param {Array<OrderItem>} childOrderItems the child order items list that any generated order items should be appended to
    * @param {Array<ProductCandidate>} oldChildEntities the child entities from the old candidate
    * @param {Array<ProductCandidate>} newChildEntities the child entities from the new candidate
    */
    OrderCandidateRequestGenerator.prototype.GenerateChildOrderItems = function (childOrderItems, oldChildEntities, newChildEntities) {
        this.TraverseOldCandidate(childOrderItems, oldChildEntities, newChildEntities);
        this.TraverseNewCandidate(childOrderItems, oldChildEntities, newChildEntities);
    };
    /**
   * Traverses the old candidate and Generates the necessary child order items to take ensure the old child entities end up in the state of the new child entities
   * @param {Array<OrderItem>} childOrderItems the child order items list that any generated order items should be appended to
   * @param {Array<ProductCandidate>} oldChildEntities the child entities from the old candidate
   * @param {Array<ProductCandidate>} newChildEntities the child entities from the new candidate
   */
    OrderCandidateRequestGenerator.prototype.TraverseOldCandidate = function (childOrderItems, oldChildEntities, newChildEntities) {
        if (Utilities.IsNotDefined(oldChildEntities, true)) {
            return;
        }
        for (var c = 0; c < oldChildEntities.length; c++) {
            var oldChildEntity = oldChildEntities[c];
            var orderItem = this.CreateOrderItemForCandidate(oldChildEntity, null);
            var matchingEntities = newChildEntities.filter(function (childEntity) { return childEntity.ID === oldChildEntity.ID; });
            var matchingNewChildEntity = matchingEntities && matchingEntities.length > 0 ? matchingEntities[0] : null;
            if (!matchingNewChildEntity) {
                orderItem.ItemAction = OrderActions.Delete;
                this.GenerateCharacteristicOrderItems(orderItem, oldChildEntity.CharacteristicUses, []);
                this.GenerateUDCOrderItems(orderItem, oldChildEntity.ConfiguredValues, []);
                this.GenerateOrdersForRateAttributes(orderItem, oldChildEntity.RateAttributes, []);
                this.GenerateOrderItemEntityLinks(orderItem, oldChildEntity.LinkedEntities, []);
                this._candidatesAreIdentical = false;
                childOrderItems.push(orderItem);
            }
            else {
                orderItem.ItemAction = OrderActions.Update;
                childOrderItems.push(orderItem);
            }
            var childrenOfMatchingNewChildEntity = matchingNewChildEntity ? matchingNewChildEntity.ChildEntities : [];
            this.TraverseOldCandidate(orderItem.ChildOrderItems, oldChildEntity.ChildEntities, childrenOfMatchingNewChildEntity);
        }
    };
    /**
    * Traverses the new candidate and Generates the necessary child order items to take ensure the old child entities end up in the state of the new child entities
    * @param {Array<OrderItem>} childOrderItems the child order items list that any generated order items should be appended to
    * @param {Array<ProductCandidate>} oldChildEntities the child entities from the old candidate
    * @param {Array<ProductCandidate>} newChildEntities the child entities from the new candidate
    */
    OrderCandidateRequestGenerator.prototype.TraverseNewCandidate = function (childOrderItems, oldChildEntities, newChildEntities) {
        if (Utilities.IsNotDefined(newChildEntities, true)) {
            return;
        }
        for (var c = 0; c < newChildEntities.length; c++) {
            var newChildEntity = newChildEntities[c];
            var matchingOldEntities = oldChildEntities.filter(function (childEntity) { return childEntity.ID === newChildEntity.ID; });
            var matchingOldChildEntity = matchingOldEntities && matchingOldEntities.length > 0 ? matchingOldEntities[0] : null;
            var existingOrderItems = childOrderItems.filter(function (exOrderItem) { return exOrderItem.PortfolioItemID === newChildEntity.ID; });
            var orderItemForEntity = existingOrderItems && existingOrderItems.length > 0 ? existingOrderItems[0] : null;
            if (!matchingOldChildEntity) {
                var orderItem = this.CreateOrderItemForCandidate(newChildEntity, OrderActions.Add);
                childOrderItems.push(orderItem);
                orderItemForEntity = orderItem;
                this._candidatesAreIdentical = false;
                this.GenerateCharacteristicOrderItems(orderItem, [], newChildEntity.CharacteristicUses);
                this.GenerateUDCOrderItems(orderItem, [], newChildEntity.ConfiguredValues);
                this.GenerateOrdersForRateAttributes(orderItem, [], newChildEntity.RateAttributes);
                this.GenerateOrderItemEntityLinks(orderItem, [], newChildEntity.LinkedEntities);
            }
            else {
                var charUsesOnOldChildEntity = matchingOldChildEntity.CharacteristicUses && matchingOldChildEntity.CharacteristicUses.length > 0 ? matchingOldChildEntity.CharacteristicUses : [];
                var udcsOnOldChildEntity = matchingOldChildEntity.ConfiguredValues && matchingOldChildEntity.ConfiguredValues.length > 0 ? matchingOldChildEntity.ConfiguredValues : [];
                var rateAttributesOnOldEntity = matchingOldChildEntity.RateAttributes && matchingOldChildEntity.RateAttributes.length > 0 ? matchingOldChildEntity.RateAttributes : [];
                var entityLinksOnOldEntity = matchingOldChildEntity.LinkedEntities && matchingOldChildEntity.LinkedEntities.length > 0 ? matchingOldChildEntity.LinkedEntities : [];
                this.GenerateCharacteristicOrderItems(orderItemForEntity, charUsesOnOldChildEntity, newChildEntity.CharacteristicUses);
                this.GenerateUDCOrderItems(orderItemForEntity, udcsOnOldChildEntity, newChildEntity.ConfiguredValues);
                this.GenerateOrdersForRateAttributes(orderItemForEntity, rateAttributesOnOldEntity, newChildEntity.RateAttributes);
                this.GenerateOrderItemEntityLinks(orderItemForEntity, entityLinksOnOldEntity, newChildEntity.LinkedEntities);
            }
            var childrenOfMatchingOldChildEntity = matchingOldChildEntity ? matchingOldChildEntity.ChildEntities : [];
            this.TraverseNewCandidate(orderItemForEntity.ChildOrderItems, childrenOfMatchingOldChildEntity, newChildEntity.ChildEntities);
        }
    };
    /**
     * Generates the necessary order actions for the characteristic uses on the supplied old and new version of the entity
     * @param {OrderItem} orderItem the order item that the char use order items should be appended to
     * @param {Array<CharacteristicUse>} oldCharacterteristicUses the characteristic uses that exist on the old version of the entity
     * @param {Array<CharacteristicUse>} newCharacterteristicUses the characteristic uses that exist on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.GenerateCharacteristicOrderItems = function (orderItem, oldCharacterteristicUses, newCharacterteristicUses) {
        this.IterateOldCharacteristicUses(orderItem, oldCharacterteristicUses, newCharacterteristicUses);
        this.IterateNewCharacteristicUses(orderItem, oldCharacterteristicUses, newCharacterteristicUses);
    };
    /**
     * Generates the necessary order actions for the user defined characteristic uses on the supplied old and new version of the entity
     * @param {OrderItem} orderItem the order item that the udc order items should be appended to
     * @param {Array<UserDefinedCharacteristicUse>} oldUDCs the user defined characteristic uses that exist on the old version of the entity
     * @param {Array<UserDefinedCharacteristicUse>} newUDCs the user defined characteristic uses that exist on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.GenerateUDCOrderItems = function (orderItem, oldUDCs, newUDCs) {
        this.IterateOldUDCs(orderItem, oldUDCs, newUDCs);
        this.IterateNewUDCs(orderItem, oldUDCs, newUDCs);
    };
    /**
     * Generates the necessary order actions for the rate attributes
     * @param {OrderItem} orderItem the order item to append any rate attribute order to
     * @param {Array<RateAttribute>} oldRateAttributes the rate attributes on the old version of the entity
     * @param {Array<RateAttribute>} newRateAttributes the rate attributes on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.GenerateOrdersForRateAttributes = function (orderItem, oldRateAttributes, newRateAttributes) {
        var attributesAlreadyHandled = [];
        for (var or = 0; or < oldRateAttributes.length; or++) {
            var oldRateAttribute = oldRateAttributes[or];
            var oldRateAttributeOnOrder = LodashUtilities.CloneDeep(oldRateAttribute);
            var matchingNewAttributes = newRateAttributes.filter(function (newAttr) { return newAttr.Name === oldRateAttribute.Name && newAttr.Value === oldRateAttribute.Value; });
            var matchingNewAttribute = matchingNewAttributes && matchingNewAttributes.length > 0 ? matchingNewAttributes[0] : null;
            if (!matchingNewAttribute) {
                this._candidatesAreIdentical = false;
                oldRateAttributeOnOrder.Action = OrderActions.Delete;
                orderItem.RateAttributes.push(oldRateAttributeOnOrder);
                continue;
            }
            attributesAlreadyHandled.push(matchingNewAttribute);
        }
        for (var nr = 0; nr < newRateAttributes.length; nr++) {
            var newRateAttribute = newRateAttributes[nr];
            if (attributesAlreadyHandled.indexOf(newRateAttribute) !== -1) {
                continue;
            }
            var matchingOldAttributes = oldRateAttributes.filter(function (oldAttr) { return oldAttr.Name === newRateAttribute.Name && oldAttr.Value === newRateAttribute.Value; });
            var matchingOldAttribute = matchingOldAttributes && matchingOldAttributes.length > 0 ? matchingOldAttributes[0] : null;
            if (!matchingOldAttribute) {
                this._candidatesAreIdentical = false;
                var newRateAttributeOnOrder = LodashUtilities.CloneDeep(newRateAttribute);
                newRateAttributeOnOrder.Action = OrderActions.Add;
                orderItem.RateAttributes.push(newRateAttributeOnOrder);
            }
        }
    };
    /**
     * Generates the necessary order actions for entity links
     * @param   {OrderItem} orderItem the order item to append any entity link to
     * @param   {Array<EntityLink>} oldEntityLinks the entity links on the old version of the entity
     * @param   {Array<EntityLink>} newEntityLinks the entity links on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.GenerateOrderItemEntityLinks = function (orderItem, oldEntityLinks, newEntityLinks) {
        this.IterateOldEntityLinks(orderItem, oldEntityLinks, newEntityLinks);
        this.IterateNewEntityLinks(orderItem, oldEntityLinks, newEntityLinks);
    };
    /**
     * Iterates through entity links on the old order item and generates the necessary update/delete actions
     * @param   {OrderItem} orderItem the order item to append any entity link to
     * @param   {Array<EntityLink>} oldEntityLinks the entity links on the old version of the entity
     * @param   {Array<EntityLink>} newEntityLinks the entity links on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.IterateOldEntityLinks = function (orderItem, oldEntityLinks, newEntityLinks) {
        for (var c = 0; c < oldEntityLinks.length; c++) {
            var oldLink = oldEntityLinks[c];
            var linkOnOrder = LodashUtilities.CloneDeep(oldLink);
            orderItem.LinkedEntities.push(linkOnOrder);
            var matchingLinks = newEntityLinks.filter(function (newLink) { return newLink.LinkTypeID === oldLink.LinkTypeID; });
            var matchingNewLink = matchingLinks && matchingLinks.length > 0 ? matchingLinks[0] : null;
            if (!matchingNewLink) {
                linkOnOrder.Action = OrderActions.Delete;
                linkOnOrder.Links.forEach(function (link) { link.Action = OrderActions.Delete; });
                this._candidatesAreIdentical = false;
            }
            else {
                linkOnOrder.Links = [];
                linkOnOrder.Action = OrderActions.NoChange;
                var targetsOnOldLink = oldLink.Links;
                var targetsOnNewLink = matchingNewLink.Links;
                this.IterateOldEntityLinkTargets(linkOnOrder, targetsOnOldLink, targetsOnNewLink);
            }
        }
    };
    /**
     * Iterates through entity links on the new order item and generates the necessary add actions
     * @param   {OrderItem} orderItem the order item to append any entity link to
     * @param   {Array<EntityLink>} oldEntityLinks the entity links on the old version of the entity
     * @param   {Array<EntityLink>} newEntityLinks the entity links on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.IterateNewEntityLinks = function (orderItem, oldEntityLinks, newEntityLinks) {
        for (var c = 0; c < newEntityLinks.length; c++) {
            var newLink = newEntityLinks[c];
            var matchingLinks = oldEntityLinks.filter(function (oldLink) { return oldLink.LinkTypeID === newLink.LinkTypeID; });
            var matchingOldLink = matchingLinks && matchingLinks.length > 0 ? matchingLinks[0] : null;
            var linkOnOrder;
            if (!matchingOldLink) {
                linkOnOrder = LodashUtilities.CloneDeep(newLink);
                this._candidatesAreIdentical = false;
                linkOnOrder.Action = OrderActions.Modify;
                linkOnOrder.Links.forEach(function (link) { link.Action = OrderActions.Add; });
                orderItem.LinkedEntities.push(linkOnOrder);
            }
            else {
                linkOnOrder = orderItem.LinkedEntities.filter(function (link) { return link.LinkTypeID === newLink.LinkTypeID; })[0];
                var targetsOnOldLink = matchingOldLink.Links;
                var targetsOnNewLink = newLink.Links;
                linkOnOrder.Action = OrderActions.NoChange;
                this.IterateNewEntityLinkTargets(linkOnOrder, targetsOnOldLink, targetsOnNewLink);
            }
        }
    };
    /**
     * Iterates through targets on entity links belonging to an old entity and generates the necessary update/delete actions
     * @param   {EntityLink} linkOnOrder the entity link to append any link targets to
     * @param   {LinkTarget[]} oldTargets the entity link targets on the old version of the entity link
     * @param   {LinkTarget[]} newTargets the entity link targets on the new version of the entity link
     */
    OrderCandidateRequestGenerator.prototype.IterateOldEntityLinkTargets = function (linkOnOrder, oldTargets, newTargets) {
        for (var c = 0; c < oldTargets.length; c++) {
            var oldTarget = oldTargets[c];
            var targetOnOrder = LodashUtilities.CloneDeep(oldTarget);
            var matchingTargets = newTargets.filter(function (newTarget) { return newTarget.PortfolioItemID === oldTarget.PortfolioItemID; });
            var matchingTargetOnNewLink = matchingTargets && matchingTargets.length > 0 ? matchingTargets[0] : null;
            if (matchingTargetOnNewLink) {
                continue;
            }
            targetOnOrder.Action = OrderActions.Delete;
            linkOnOrder.Action = OrderActions.Modify;
            linkOnOrder.Links.push(targetOnOrder);
            this._candidatesAreIdentical = false;
        }
    };
    /**
     * Iterates through targets on entity links belonging to a new entity and generates the necessary add actions
     * @param   {EntityLink} linkOnOrder the entity link to append any link targets to
     * @param   {LinkTarget[]} oldTargets the entity link targets on the old version of the entity link
     * @param   {LinkTarget[]} newTargets the entity link targets on the new version of the entity link
     */
    OrderCandidateRequestGenerator.prototype.IterateNewEntityLinkTargets = function (linkOnOrder, oldTargets, newTargets) {
        for (var c = 0; c < newTargets.length; c++) {
            var newTarget = newTargets[c];
            var targetOnOrder = LodashUtilities.CloneDeep(newTarget);
            var matchingTargets = oldTargets.filter(function (oldTarget) { return oldTarget.PortfolioItemID === newTarget.PortfolioItemID; });
            var matchingTargetOnOldLink = matchingTargets && matchingTargets.length > 0 ? matchingTargets[0] : null;
            if (matchingTargetOnOldLink) {
                continue;
            }
            targetOnOrder.Action = OrderActions.Add;
            linkOnOrder.Action = OrderActions.Modify;
            linkOnOrder.Links.push(targetOnOrder);
            this._candidatesAreIdentical = false;
        }
    };
    /**
    /*Iterates the list of new UDCs and generates the necessary add order items (update/delete items are handled in a separate method)
    * @param {OrderItem} orderItem the order item to append the char use add order actions to
    * @param {Array<ConfiguredValueUse>} oldUDCs the UDCs on the old version of the entity
    * @param {Array<ConfiguredValueUse>} newUDCs the UDCs on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateNewUDCs = function (orderItem, oldUDCs, newUDCs) {
        for (var c = 0; c < newUDCs.length; c++) {
            var newUDC = newUDCs[c];
            var matchingUdcs = oldUDCs.filter(function (oldUDC) {
                return (oldUDC.CharacteristicID === newUDC.CharacteristicID && oldUDC.UseArea === newUDC.UseArea) ||
                    (Utilities.IsDefined(oldUDC.UseID) && Utilities.IsDefined(newUDC.UseID) && oldUDC.UseID === newUDC.UseID);
            });
            var matchingOldUDC = matchingUdcs && matchingUdcs.length > 0 ? matchingUdcs[0] : null;
            var udcOnOrder;
            if (!matchingOldUDC) {
                // UserDefinedCharacteristicUse and ConfiguredValueUse are not compatible, so set properties individually
                var charValues = [];
                charValues = newUDC.Value.map(function (val) {
                    return new UserDefinedCharacteristicValue({
                        ValueDetail: val.ValueDetail,
                        Action: OrderActions.Add,
                        Value: val.Value,
                        NotAvailable: undefined,
                        ChangeType: undefined,
                        ItemSource: undefined
                    });
                });
                udcOnOrder = new UserDefinedCharacteristicUse({
                    UseID: newUDC.UseID,
                    UseArea: newUDC.UseArea,
                    CharacteristicID: newUDC.CharacteristicID,
                    Value: charValues,
                    Action: OrderActions.Modify
                });
                this._candidatesAreIdentical = false;
                udcOnOrder.Value.forEach(function (udcVal) { udcVal.Action = OrderActions.Add; });
                orderItem.ConfiguredValues.push(udcOnOrder);
            }
            else {
                udcOnOrder = orderItem.ConfiguredValues.filter(function (confVal) {
                    return ((confVal.CharacteristicID === newUDC.CharacteristicID && confVal.UseArea === newUDC.UseArea)
                        || (Utilities.IsDefined(confVal.UseID) && Utilities.IsDefined(newUDC.UseID) && confVal.UseID === newUDC.UseID));
                })[0];
                var valuesOnOldCharUse = matchingOldUDC.Value;
                var valuesOnNewCharUse = newUDC.Value;
                udcOnOrder.Action = OrderActions.NoChange;
                this.IterateNewUDCValues(udcOnOrder, valuesOnOldCharUse, valuesOnNewCharUse);
            }
        }
    };
    /* Iterates the list of old UDCs and generates the necessary delete / update order items (add items are handled in a separate method)
    * @param {OrderItem} orderItem the order item to append the UDC delete order actions to
    * @param {Array<ConfiguredValueUse>} oldUDCs the UDCs on the old version of the entity
    * @param {Array<ConfiguredValueUse>} newUDCs the UDCs on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateOldUDCs = function (orderItem, oldUDCs, newUDCs) {
        for (var c = 0; c < oldUDCs.length; c++) {
            var oldUDC = oldUDCs[c];
            // UserDefinedCharacteristicUse and ConfiguredValueUse are not compatible, so set properties individually
            var charValues = [];
            charValues = oldUDC.Value.map(function (val) {
                return new UserDefinedCharacteristicValue({
                    ValueDetail: val.ValueDetail,
                    Action: OrderActions.Add,
                    Value: val.Value,
                    NotAvailable: undefined,
                    ChangeType: undefined,
                    ItemSource: undefined
                });
            });
            var udcOnOrder = new UserDefinedCharacteristicUse({
                UseID: oldUDC.UseID,
                UseArea: oldUDC.UseArea,
                CharacteristicID: oldUDC.CharacteristicID,
                Value: charValues,
                Action: null
            });
            orderItem.ConfiguredValues.push(udcOnOrder);
            var matchingUDCs = newUDCs.filter(function (newUDC) { return newUDC.CharacteristicID === oldUDC.CharacteristicID; });
            var matchingNewUDC = matchingUDCs && matchingUDCs.length > 0 ? matchingUDCs[0] : null;
            if (!matchingNewUDC) {
                // We should never delete a ConfiguredValue
                udcOnOrder.Action = OrderActions.Modify;
                udcOnOrder.Value.forEach(function (charVal) { charVal.Action = OrderActions.Delete; });
                this._candidatesAreIdentical = false;
            }
            else {
                udcOnOrder.Value = [];
                udcOnOrder.Action = OrderActions.NoChange;
                var valuesOnOldUDC = oldUDC.Value;
                var valuesOnNewUDC = matchingNewUDC.Value;
                this.IterateOldUDCValues(udcOnOrder, valuesOnOldUDC, valuesOnNewUDC);
            }
        }
    };
    /**
    * Iterates the list of new UDC values and generates the necessary add order items (delete items are handled in a separate method)
    * @param {UserDefinedCharacteristicUse} udcOnOrder the udc on the order to append the add udc value order items to
    * @param {Array<ConfiguredValue>} valuesOnOldUDC the udc values on the udc that exist on the old version of the entity
    * @param {Array<ConfiguredValue>} valuesOnNewUDC the udc values on the udc that exist on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateNewUDCValues = function (udcOnOrder, valuesOnOldUDC, valuesOnNewUDC) {
        for (var j = 0; j < valuesOnNewUDC.length; j++) {
            var newUDCValue = valuesOnNewUDC[j];
            var matchingValues = valuesOnOldUDC.filter(function (oldUdcValue) { return oldUdcValue.Value === newUDCValue.Value; });
            var matchingValueOnOldUDC = matchingValues && matchingValues.length > 0 ? matchingValues[0] : null;
            if (matchingValueOnOldUDC) {
                continue;
            }
            // UserDefinedCharacteristicValue and ConfiguredValue are not compatible, so set properties individually
            var udcValueOnOrder = new UserDefinedCharacteristicValue({
                Value: newUDCValue.Value,
                ValueDetail: newUDCValue.ValueDetail,
                Action: OrderActions.Add,
                NotAvailable: undefined,
                ChangeType: undefined,
                ItemSource: undefined
            });
            udcOnOrder.Value.push(udcValueOnOrder);
            udcOnOrder.Action = OrderActions.Modify;
            this._candidatesAreIdentical = false;
        }
    };
    /**
     * Iterates the list of new UDC values and generates the necessary delete order items (delete items are handled in a separate method)
     * @param {UserDefinedCharacteristicUse} charUseOnOrder the char use on the order to append the delete char value order items to
     * @param {Array<ConfiguredValue>} valuesOnOldUDC the udc values on the udc that exist on the old version of the entity
     * @param {Array<ConfiguredValue>} valuesOnNewUDC the udc values on the udc that exist on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.IterateOldUDCValues = function (charUseOnOrder, valuesOnOldUDC, valuesOnNewUDC) {
        for (var j = 0; j < valuesOnOldUDC.length; j++) {
            var oldUDCValue = valuesOnOldUDC[j];
            var matchingValues = valuesOnNewUDC.filter(function (newValue) { return newValue.Value === oldUDCValue.Value; });
            var matchingValueOnNewUDC = matchingValues && matchingValues.length > 0 ? matchingValues[0] : null;
            if (matchingValueOnNewUDC) {
                continue;
            }
            // UserDefinedCharacteristicValue and ConfiguredValue are not compatible, so set properties individually
            var udcValueOnOrder = new UserDefinedCharacteristicValue({
                Value: oldUDCValue.Value,
                ValueDetail: oldUDCValue.ValueDetail,
                Action: OrderActions.Delete,
                NotAvailable: undefined,
                ChangeType: undefined,
                ItemSource: undefined
            });
            charUseOnOrder.Value.push(udcValueOnOrder);
            charUseOnOrder.Action = OrderActions.Modify;
            this._candidatesAreIdentical = false;
        }
    };
    /**
    * Iterates the list of new char uses and generates the necessary add order items (update / delete items are handled in a separate method)
    * @param {OrderItem} orderItem the order item to append the char use add order actions to
    * @param {Array<CharacteristicUse>} oldCharacterteristicUses the char uses on the old version of the entity
    * @param {Array<CharacteristicUse>} newCharacterteristicUses the char uses on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateNewCharacteristicUses = function (orderItem, oldCharacterteristicUses, newCharacterteristicUses) {
        for (var c = 0; c < newCharacterteristicUses.length; c++) {
            var newCharacteristicUse = newCharacterteristicUses[c];
            var matchingUses = oldCharacterteristicUses.filter(function (oldCharUse) {
                return ((oldCharUse.CharacteristicID === newCharacteristicUse.CharacteristicID && oldCharUse.UseArea === newCharacteristicUse.UseArea)
                    || (Utilities.IsDefined(oldCharUse.UseID) && Utilities.IsDefined(newCharacteristicUse.UseID)) && oldCharUse.UseID === newCharacteristicUse.UseID);
            });
            var matchingOldCharacteristicUse = matchingUses && matchingUses.length > 0 ? matchingUses[0] : null;
            var charUseOnOrder;
            if (!matchingOldCharacteristicUse) {
                charUseOnOrder = LodashUtilities.CloneTargetOnly(newCharacteristicUse);
                this._candidatesAreIdentical = false;
                charUseOnOrder.Action = OrderActions.Modify;
                charUseOnOrder.Value.forEach(function (charVal) { charVal.Action = OrderActions.Add; });
                orderItem.CharacteristicUses.push(charUseOnOrder);
            }
            else {
                charUseOnOrder = orderItem.CharacteristicUses.filter(function (charUse) {
                    return charUse.CharacteristicID === newCharacteristicUse.CharacteristicID &&
                        (Utilities.IsDefined(charUse.UseArea) && Utilities.IsDefined(newCharacteristicUse.UseArea)) &&
                        charUse.UseArea === newCharacteristicUse.UseArea;
                })[0];
                var valuesOnOldCharUse = matchingOldCharacteristicUse.Value;
                var valuesOnNewCharUse = newCharacteristicUse.Value;
                charUseOnOrder.Action = OrderActions.NoChange;
                this.IterateNewCharacteristicValues(charUseOnOrder, valuesOnOldCharUse, valuesOnNewCharUse);
            }
        }
    };
    /**
    * Iterates the list of old char uses and generates the necessary update / delete order items (add items are handled in a separate method)
    * @param {OrderItem} orderItem the order item to append the char use delete order actions to
    * @param {Array<CharacteristicUse>} oldCharacterteristicUses the char uses on the old version of the entity
    * @param {Array<CharacteristicUse>} newCharacterteristicUses the char uses on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateOldCharacteristicUses = function (orderItem, oldCharacterteristicUses, newCharacterteristicUses) {
        for (var c = 0; c < oldCharacterteristicUses.length; c++) {
            var oldCharacteristicUse = oldCharacterteristicUses[c];
            var charUseOnOrder = LodashUtilities.CloneDeep(oldCharacteristicUse);
            charUseOnOrder.Value = [];
            orderItem.CharacteristicUses.push(charUseOnOrder);
            var matchingUses = newCharacterteristicUses.filter(function (newCharUse) {
                return ((newCharUse.CharacteristicID === oldCharacteristicUse.CharacteristicID && newCharUse.UseArea === oldCharacteristicUse.UseArea)
                    || (Utilities.IsDefined(newCharUse.UseID) && Utilities.IsDefined(oldCharacteristicUse.UseID)) && newCharUse.UseID === oldCharacteristicUse.UseID);
            });
            var matchingNewCharacteristicUse = matchingUses && matchingUses.length > 0 ? matchingUses[0] : null;
            if (!matchingNewCharacteristicUse) {
                charUseOnOrder.Action = OrderActions.Delete;
                charUseOnOrder.Value.forEach(function (charVal) {
                    charVal.Action = OrderActions.Delete;
                });
                this._candidatesAreIdentical = false;
            }
            else {
                charUseOnOrder.Action = OrderActions.NoChange;
                var valuesOnOldCharUse = oldCharacteristicUse.Value;
                var valuesOnNewCharUse = matchingNewCharacteristicUse.Value;
                this.IterateOldCharacteristicValues(charUseOnOrder, valuesOnOldCharUse, valuesOnNewCharUse);
            }
        }
    };
    /**
    * Iterates the list of new char values and generates the necessary add order items (delete items are handled in a separate method)
    * @param {CharacteristicUse} charUseOnOrder the char use on the order to append the add char value order items to
    * @param {Array<CharacteristicValue>} valuesOnOldCharUse the char values on the char use that exist on the old version of the entity
    * @param {Array<CharacteristicValue>} valuesOnNewCharUse the char values on the char use that exist on the new version of the entity
    */
    OrderCandidateRequestGenerator.prototype.IterateNewCharacteristicValues = function (charUseOnOrder, valuesOnOldCharUse, valuesOnNewCharUse) {
        for (var j = 0; j < valuesOnNewCharUse.length; j++) {
            var newCharValue = valuesOnNewCharUse[j];
            var charValueOnOrder = LodashUtilities.CloneDeep(newCharValue);
            var matchingValues = valuesOnOldCharUse.filter(function (oldValue) { return oldValue.ValueID === newCharValue.ValueID; });
            var matchingValueOnOldCharUse = matchingValues && matchingValues.length > 0 ? matchingValues[0] : null;
            if (matchingValueOnOldCharUse) {
                continue;
            }
            charValueOnOrder.Action = OrderActions.Add;
            charUseOnOrder.Value.push(charValueOnOrder);
            charUseOnOrder.Action = OrderActions.Modify;
            this._candidatesAreIdentical = false;
        }
    };
    /**
     * Iterates the list of old char values and generates the necessary delete order items (add items are handled in a separate method)
     * @param {CharacteristicUse} charUseOnOrder the char use on the order to append the delete char value order items to
     * @param {Array<CharacteristicValue>} valuesOnOldCharUse the char values on the char use that exist on the old version of the entity
     * @param {Array<CharacteristicValue>} valuesOnNewCharUse the char values on the char use that exist on the new version of the entity
     */
    OrderCandidateRequestGenerator.prototype.IterateOldCharacteristicValues = function (charUseOnOrder, valuesOnOldCharUse, valuesOnNewCharUse) {
        for (var j = 0; j < valuesOnOldCharUse.length; j++) {
            var oldCharValue = valuesOnOldCharUse[j];
            var charValueOnOrder = LodashUtilities.CloneDeep(oldCharValue);
            var matchingValues = valuesOnNewCharUse.filter(function (newValue) { return newValue.ValueID === oldCharValue.ValueID; });
            var matchingValueOnNewCharUse = matchingValues && matchingValues.length > 0 ? matchingValues[0] : null;
            if (matchingValueOnNewCharUse) {
                continue;
            }
            charValueOnOrder.Action = OrderActions.Delete;
            charUseOnOrder.Value.push(charValueOnOrder);
            charUseOnOrder.Action = OrderActions.Modify;
            this._candidatesAreIdentical = false;
        }
    };
    /**
     * Create an order item for the supplied product candidate, using the supplied order action
     * @param {ProductCandidate} productCandidate the candidate to use to create the order item
     * @param {string} orderAction the order action to set on the order item
     * @returns {OrderItem} the newly created order item
     */
    OrderCandidateRequestGenerator.prototype.CreateOrderItemForCandidate = function (productCandidate, orderAction) {
        var orderItem = new OrderItem();
        orderItem.EntityID = productCandidate.EntityID;
        orderItem.ItemAction = orderAction;
        orderItem.PortfolioItemID = productCandidate.ID;
        orderItem.ID = Utilities.CreateID();
        return orderItem;
    };
    /**
     * Creates a customer portfolio from the supplied product candidate
     * @param {ProductCandidate} productCandidate the product candidate to use to create the customer portfolio
     * @returns {CustomerPortfolio} the newly created customer portfolio
     */
    OrderCandidateRequestGenerator.prototype.CreateCustomerPortfolioFromProductCandidate = function (productCandidate) {
        var customerPortfolio = new CustomerPortfolio();
        var rootPortfolioItem = this.CreatePortfolioItemForCandidate(productCandidate);
        this.CreateChildPortfolioItemsForCandidates(productCandidate.ChildEntities, rootPortfolioItem.ChildEntities);
        customerPortfolio.PortfolioItems.push(rootPortfolioItem);
        return customerPortfolio;
    };
    /**
     * Creates a portfolio item for the supplied product candidate
     * @param {ProductCandidate} candidate the product candidate to use to create a portfolio item
     * @returns {PortfolioItem} the newly created portfolio item
     */
    OrderCandidateRequestGenerator.prototype.CreatePortfolioItemForCandidate = function (candidate) {
        var portfolioItem = new PortfolioItem();
        portfolioItem.EntityID = candidate.EntityID;
        portfolioItem.ID = candidate.ID;
        portfolioItem.ItemAction = undefined;
        // JB; CS-3107
        // PortfolioItems and their properties cannot have Actions, set to undefined
        for (var cu = 0; cu < candidate.CharacteristicUses.length; cu++) {
            var charUse = LodashUtilities.CloneDeep(candidate.CharacteristicUses[cu]);
            charUse.Action = undefined;
            for (var i = 0; i < charUse.Value.length; i++) {
                charUse.Value[i].Action = undefined;
            }
            portfolioItem.CharacteristicUses.push(charUse);
        }
        for (var cv = 0; cv < candidate.ConfiguredValues.length; cv++) {
            var confValUse = LodashUtilities.CloneDeep(candidate.ConfiguredValues[cv]);
            confValUse.Action = undefined;
            for (var i = 0; i < confValUse.Value.length; i++) {
                confValUse.Value[i].Action = undefined;
            }
            portfolioItem.ConfiguredValues.push(confValUse);
        }
        for (var ra = 0; ra < candidate.RateAttributes.length; ra++) {
            var rateAttribute = LodashUtilities.CloneDeep(candidate.RateAttributes[ra]);
            rateAttribute.Action = undefined;
            portfolioItem.RateAttributes.push(rateAttribute);
        }
        for (var lk = 0; lk < candidate.LinkedEntities.length; lk++) {
            var linkedEntity = LodashUtilities.CloneDeep(candidate.LinkedEntities[lk]);
            linkedEntity.Action = undefined;
            for (var i = 0; i < linkedEntity.Links.length; i++) {
                linkedEntity.Links[i].Action = undefined;
            }
            portfolioItem.LinkedEntities.push(linkedEntity);
        }
        return portfolioItem;
    };
    /**
     * Creates portfolio items for each of the supplied child candidates
     * @param {Array<ProductCandidate>} childCandidates the child candidates to create portfolio items for
     * @param {Array<PortfolioItem>} portfolioChildEntities the array of portfolio items that any newly created portfolio items should be pushed into
     */
    OrderCandidateRequestGenerator.prototype.CreateChildPortfolioItemsForCandidates = function (childCandidates, portfolioChildEntities) {
        for (var c = 0; c < childCandidates.length; c++) {
            var childCandidate = childCandidates[c];
            var childPortfolioItem = this.CreatePortfolioItemForCandidate(childCandidate);
            portfolioChildEntities.push(childPortfolioItem);
            if (Utilities.IsDefined(childCandidate.ChildEntities, true)) {
                this.CreateChildPortfolioItemsForCandidates(childCandidate.ChildEntities, childPortfolioItem.ChildEntities);
            }
        }
    };
    /**
     * Recurse through the order and update the actions of entities which have child entities or properties involved in a change to the portfolio
     * @param {OrderItem} orderItem the order item to set an action on
     */
    OrderCandidateRequestGenerator.prototype.UpdateActionHierarchy = function (orderItem) {
        var _this = this;
        if (orderItem.ItemAction === OrderActions.Add || orderItem.ItemAction === OrderActions.Delete) {
            return;
        }
        this.PruneUnchangedCharacteristicUses(orderItem.CharacteristicUses);
        this.PruneUnchangedUserDefinedCharacteristicUses(orderItem.ConfiguredValues);
        this.PruneUnchangedRateAttributes(orderItem.RateAttributes);
        this.PruneUnchangedEntityLinks(orderItem.LinkedEntities);
        orderItem.ChildOrderItems.forEach(function (child) {
            _this.UpdateActionHierarchy(child);
        });
        // Check children of this order item
        var childrenUpdated = orderItem.ChildOrderItems.some(function (child) {
            return child.ItemAction !== OrderActions.NoChange;
        });
        if (childrenUpdated) {
            orderItem.ItemAction = OrderActions.Update;
            return;
        }
        // Check the characteristic uses of this order item
        var propertiesUpdated = orderItem.CharacteristicUses.some(function (charUse) {
            return charUse.Action !== OrderActions.NoChange;
        });
        // Check the UDCs of this order item
        if (!propertiesUpdated) {
            propertiesUpdated = orderItem.ConfiguredValues.some(function (confValue) {
                return confValue.Action !== OrderActions.NoChange;
            });
        }
        // Check the rate attributes of this order item
        if (!propertiesUpdated) {
            propertiesUpdated = orderItem.RateAttributes.some(function (ra) {
                return ra.Action !== OrderActions.NoChange;
            });
        }
        // Check the entity links of this order item
        if (!propertiesUpdated) {
            propertiesUpdated = orderItem.LinkedEntities.some(function (link) {
                return link.Action !== OrderActions.NoChange;
            });
        }
        orderItem.ItemAction = propertiesUpdated ? OrderActions.Update : OrderActions.NoChange;
    };
    /**
     * Removes order items which have a "NoChange" item action
     * @param {OrderItem} orderItem the order item to check
     */
    OrderCandidateRequestGenerator.prototype.PruneOrder = function (orderItem) {
        var _this = this;
        var invalidOrderItemsByAction = [];
        // Get the indexes of invalid children of this order item
        orderItem.ChildOrderItems.forEach(function (child) {
            if (child.ItemAction === OrderActions.NoChange) {
                invalidOrderItemsByAction.push(child);
            }
        });
        // Remove the invalid children from the order item
        invalidOrderItemsByAction.forEach(function (invalidChild) {
            orderItem.ChildOrderItems.splice(orderItem.ChildOrderItems.indexOf(invalidChild), 1);
        });
        // Recurse through remaining children of the order item
        orderItem.ChildOrderItems.forEach(function (child) {
            _this.PruneOrder(child);
        });
    };
    /**
     * Remove characteristic uses from order items if no changes are being made to the characteristic use or its values
     * @param   {Array<CharacteristicUse>} characteristicUses the characteristic uses to check and remove from
     */
    OrderCandidateRequestGenerator.prototype.PruneUnchangedCharacteristicUses = function (characteristicUses) {
        var _this = this;
        var unusedCharUses = characteristicUses.filter(function (use) { return !_this.ActionIsEffective(use.Action) && use.Value.length < 1; });
        unusedCharUses.forEach(function (unusedCharUse) {
            characteristicUses.splice(characteristicUses.indexOf(unusedCharUse), 1);
        });
    };
    /**
     * Removes user defined characteristics from order items if no changes are being made to the characteristic use or its values
     * @param   {Array<UserDefinedCharacteristicUse>} userDefChars the user defined characteristics to check and remove from
     */
    OrderCandidateRequestGenerator.prototype.PruneUnchangedUserDefinedCharacteristicUses = function (userDefChars) {
        var _this = this;
        var unusedUDCs = userDefChars.filter(function (use) { return !_this.ActionIsEffective(use.Action) && use.Value.length < 1; });
        unusedUDCs.forEach(function (unusedUDC) {
            userDefChars.splice(userDefChars.indexOf(unusedUDC), 1);
        });
    };
    /**
     * Removes rate attributes from order items if no changes are being made to the rate attribute
     * @param   {Array<RateAttribute>} rateAttributes the rate attributes to check and remove
     */
    OrderCandidateRequestGenerator.prototype.PruneUnchangedRateAttributes = function (rateAttributes) {
        var _this = this;
        var unusedRAs = rateAttributes.filter(function (ra) { return !_this.ActionIsEffective(ra.Action); });
        unusedRAs.forEach(function (unusedRA) {
            rateAttributes.splice(rateAttributes.indexOf(unusedRA), 1);
        });
    };
    /**
     * Removes entity links from order items if no changes are being made to the entity link or its targets
     * @param   {Array<EntityLink>} entityLinks the entity links to check and remove from
     */
    OrderCandidateRequestGenerator.prototype.PruneUnchangedEntityLinks = function (entityLinks) {
        var _this = this;
        var unusedLinks = entityLinks.filter(function (link) { return !_this.ActionIsEffective(link.Action) && link.Links.length < 1; });
        unusedLinks.forEach(function (unusedLink) {
            entityLinks.splice(entityLinks.indexOf(unusedLink), 1);
        });
    };
    /**
     * Checks whether an action on an order entity will have a definite effect on the customer portfolio
     * @param   {string} action the action to check
     * @returns {boolean}
     */
    OrderCandidateRequestGenerator.prototype.ActionIsEffective = function (action) {
        if (Utilities.IsNotDefined(action, true)) {
            return false;
        }
        return (action === OrderActions.Add || action === OrderActions.Delete);
    };
    return OrderCandidateRequestGenerator;
}());
module.exports = OrderCandidateRequestGenerator;

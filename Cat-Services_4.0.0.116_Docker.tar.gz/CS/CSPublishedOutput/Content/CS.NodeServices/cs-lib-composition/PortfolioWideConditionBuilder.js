"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var CompiledSpecificationQueries = require("./CompiledSpecificationQueries");
var RuleScope = require("../cs-lib-constants/RuleScope");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class that builds portfolio wide conditions for mapping and compatibility rules
 */
var PortfolioWideConditionBuilder = /** @class */ (function () {
    function PortfolioWideConditionBuilder() {
    }
    /**
     * compiles all the portfolio wide compatibility rules in the supplied decompose contexts
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts that contain the compatibility rules
     */
    PortfolioWideConditionBuilder.prototype.CompilePortfolioWideCompatibilityRules = function (decomposeContexts) {
        var _this = this;
        // There is a lot of scanning here, that happens for every call.
        // This could probably be cached per root item and composed when needed.
        decomposeContexts.forEach(function (decomposeContext) {
            decomposeContext.CompiledSpec.CompatibilityRules.forEach(function (compatibilityRule) {
                // Only interested in Portfolio Scope rules
                if (compatibilityRule.RuleScope !== RuleScope.Portfolio) {
                    return;
                }
                // If Portfolio wide rules are ignored (ie for ProductCandidates) remove the conditions
                if (decomposeContext.IgnorePortfolioWideRules) {
                    CompiledSpecificationQueries.ClearRuleConditionCollection(compatibilityRule.Conditions);
                    return;
                }
                var conditionPaths = CompiledSpecificationQueries.AllRuleConditions(compatibilityRule.Conditions);
                // Filter only conditions scoped to "Portfolio" to get targets
                conditionPaths = conditionPaths.filter(function (path) { return path.Scope === RuleScope.Portfolio; });
                conditionPaths.forEach(function (condition) {
                    for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                        var targetPathItem = condition.TargetPaths[targetPath];
                        targetPathItem.Targets = _this.GetTargetsForPath(decomposeContexts, condition, targetPathItem);
                    }
                });
            });
        });
    };
    /**
     * compiles all the portfolio wide mapping rules in the supplied decompose contexts
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts that contain the mapping rules
     */
    PortfolioWideConditionBuilder.prototype.CompilePortfolioWideMappingRules = function (decomposeContexts) {
        var _this = this;
        // There is a lot of scanning here, that happens for every call.
        // This could probably be cached per root item and composed when needed.
        for (var decomposeContextIdx = 0; decomposeContextIdx < decomposeContexts.length; decomposeContextIdx++) {
            var decomposeContext = decomposeContexts[decomposeContextIdx];
            for (var mappingRuleIdx = 0; mappingRuleIdx < decomposeContext.CompiledSpec.MappingRules.length; mappingRuleIdx++) {
                var mappingRule = decomposeContext.CompiledSpec.MappingRules[mappingRuleIdx];
                if (!Utilities.IsDefined(mappingRule.RuleConditionScope) || mappingRule.RuleConditionScope !== RuleScope.Portfolio) {
                    continue;
                }
                var conditionPaths = CompiledSpecificationQueries.AllRuleConditions(mappingRule.Conditions);
                conditionPaths = conditionPaths.filter(function (path) { return path.Scope === RuleScope.Portfolio; });
                conditionPaths.forEach(function (condition) {
                    for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                        var targetPathItem = condition.TargetPaths[targetPath];
                        targetPathItem.Targets = _this.GetTargetsForPath(decomposeContexts, condition, targetPathItem);
                    }
                });
            }
        }
    };
    /**
     * Gets the targets for the supplied entity path using the supplied decompose contexts
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts to look through to find the item
     * @param {CsTypes.Condition} condition the object that contains the path / value id that we are looking for
     * @returns {Array<CsTypes.ItemTarget>} an array of item targets that satisfy the supplied entity path
     */
    PortfolioWideConditionBuilder.prototype.GetTargetsForPath = function (decomposeContexts, condition, targetPathItem) {
        var _this = this;
        var itemTargets = [];
        if (condition.Scope !== RuleScope.Portfolio) {
            return itemTargets;
        }
        for (var decomposeIdx = 0; decomposeIdx < decomposeContexts.length; decomposeIdx++) {
            var decomposeContext = decomposeContexts[decomposeIdx];
            var pathLookup;
            var isValuePath = (Utilities.IsDefined(targetPathItem.ValueId, true))
                || (Utilities.IsDefined(targetPathItem.UseId, true))
                || (Utilities.IsDefined(targetPathItem.LinkTypeID, true));
            pathLookup = (isValuePath) ? (decomposeContext.CompiledSpec.GuidPathToUuidLookup) : (decomposeContext.CompiledSpec.BusinessIdPathToUuidLookup);
            Object.keys(pathLookup).forEach(function (path) {
                //if the path does not end with the path we are looking for then move onto the next path
                if (!Utilities.StringEndsWith(path, targetPathItem.EntityPath, true)) {
                    return;
                }
                var uuid = pathLookup[path];
                if (Utilities.IsDefined(targetPathItem.LinkTypeID, true)) {
                    uuid = _this.GetEntityLinkSourceUuid(decomposeContext, uuid, targetPathItem.LinkTypeID);
                    // If we can't find the uuid for the source then this target doesn't apply
                    if (Utilities.IsNotDefined(uuid, true)) {
                        return;
                    }
                }
                var itemTarget = {
                    DecomposeContextIndex: decomposeIdx,
                    Key: uuid
                };
                itemTargets.push(itemTarget);
            });
        }
        return itemTargets;
    };
    /**
     * Get the uuid for the entity link source, if we cannot find it then return undefined to indicate that this condition target cannot be added
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.Uuid} uuid The uuid of the entity that has the entity link
     * @param {string} linkTypeId The link type ID of the entity link
     * @returns {CsTypes.Uuid}
     */
    PortfolioWideConditionBuilder.prototype.GetEntityLinkSourceUuid = function (decomposeContext, uuid, linkTypeId) {
        var linkDefinitions = decomposeContext.CompiledSpec.EntityLinkDefinitions[uuid];
        if (Utilities.IsNotDefined(linkDefinitions, true)) {
            return undefined;
        }
        //we should only find 1 definition in the spec with this relation type id
        var matchingDefinitions = linkDefinitions.filter(function (linkDef) {
            return linkDef.Id === linkTypeId;
        });
        if (Utilities.IsNotDefined(matchingDefinitions, true)) {
            return undefined;
        }
        return matchingDefinitions[0].Source;
    };
    return PortfolioWideConditionBuilder;
}());
module.exports = PortfolioWideConditionBuilder;

"use strict";
/// <reference types="node" />
///<reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var CompiledSpecificationQueries = require("../cs-lib-composition/CompiledSpecificationQueries");
var DateStatus = require("../cs-lib-constants/DateStatus");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RuleConditionType = require("../cs-lib-constants/RuleConditionType");
var RuleScope = require("../cs-lib-constants/RuleScope");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * A class that contains methods for validating compatibility rules and raising validation errors if necessary
 */
var CompatibilityRuleMarker = /** @class */ (function () {
    /**
     * @constructor
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts that contain the compatibility rules to validate
     * @param {CsErrorContext} errorContext the error context in which to raise any errors
     *
     */
    function CompatibilityRuleMarker(decomposeContexts, errorContext) {
        this._decomposeContexts = decomposeContexts;
        this._errorContext = errorContext;
        this._notAvailableEntities = [];
        this._notAvailableValues = [];
    }
    /**
     * Executes all the compatibility rules in the supplied decompose contexts
     */
    CompatibilityRuleMarker.prototype.IdentifyNotAvailable = function () {
        var _this = this;
        this._decomposeContexts.forEach(function (decomposeContext, decomposeIndex) {
            // Don't execute rules for root entities that have not been affected or have been deleted
            if (!OrderfolioQueries.IsRootOrderfolioItemInAffectedPortfolio(decomposeContext.Orderfolio)) {
                Logger.debug(0, "MarkCompatibility", "Compatibility Rule on Root not applied");
                return;
            }
            decomposeContext.CompiledSpec.CompatibilityRules.forEach(function (compatibilityRule) {
                Logger.debug(0, "MarkCompatibility", "Started Processing Compatibility Rule - " + compatibilityRule.Name, {
                    Name: compatibilityRule.Name,
                    ID: compatibilityRule.ID
                });
                if (compatibilityRule.RuleScope === RuleScope.Portfolio && decomposeContext.IgnorePortfolioWideRules) {
                    Logger.debug(1, "MarkCompatibility", "Rule ignored as Portfolio rules are set to be ignored ", { Name: compatibilityRule.Name, ID: compatibilityRule.ID });
                    return;
                }
                // Do not apply the rule if the order date falls outside the rule's applicable date range
                if (!OrderfolioQueries.RuleDateCriteriaIsMet(compatibilityRule.StartDate, compatibilityRule.EndDate, decomposeContext.ActivationDate)) {
                    Logger.debug(1, "MarkCompatibility", "Rule ignored as its date is out of range", {
                        ID: compatibilityRule.ID,
                        RuleStartDate: compatibilityRule.StartDate,
                        RuleEndDate: compatibilityRule.EndDate,
                        ActivationDate: decomposeContext.ActivationDate
                    });
                    return;
                }
                // Fire for each instance of the container entity
                var containerEntities = decomposeContext.Orderfolio[compatibilityRule.EntityUuid];
                if (Utilities.IsNotDefined(containerEntities, true)) {
                    Logger.debug(1, "MarkCompatibility", "Rule ignored as it could not find Entity Uuid " + compatibilityRule.EntityUuid + " in the orderfolio", {
                        Name: compatibilityRule.Name,
                        ID: compatibilityRule.ID,
                        EntityUuid: compatibilityRule.EntityUuid
                    });
                    return;
                }
                containerEntities.forEach(function (containerEntity) {
                    Logger.debug(1, "MarkCompatibility", "Processing OrderfolioItem for key - " + containerEntity.CompoundKey.Key);
                    // If the action for the container entity is delete then we do not fire the rule
                    // If the action is undefined (nochange) then we will fire the rule, as we know our parent is in the affected portfolio
                    // The check for that is above with IsRootOrderfolioItemInAffectedPortfolio
                    if (Utilities.IsDefined(containerEntity.Action) && containerEntity.Action === OrderActions.Delete) {
                        Logger.debug(2, "MarkCompatibility", "Orderfolio action is 'Delete' therefore rule is not fired", {
                            Name: compatibilityRule.Name,
                            ID: compatibilityRule.ID,
                            EntityUuid: compatibilityRule.EntityUuid,
                            PortfolioItemId: containerEntity.PortfolioItemId,
                            Action: containerEntity.Action
                        });
                        return;
                    }
                    _this.IdentifyItemsToMarkNotAvailable(compatibilityRule, decomposeIndex, containerEntity);
                });
            });
        });
        this.MarkNotAvailableEntities();
        this.MarkNotAvailableValues();
    };
    /**
     * Validate the conditions in the supplied RuleConditionCollection and identify what to mark as not available
     * All conditions must evaluate to true in order for the message to be displayed, the reverse of Mapping Rule conditions
     * @param {CsTypes.CompatibilityRule} conditions the The compatibility rule that contains the rule collection to evaluate
     * @param {CsTypes.OrderfolioItem} containerEntity The entity that contains the rule
     * @return True if all conditions are true, otherwise false
     */
    CompatibilityRuleMarker.prototype.IdentifyItemsToMarkNotAvailable = function (compatibilityRule, currentDecomposeIndex, containerEntity) {
        var _this = this;
        if (containerEntity.IsInvalid) {
            Logger.debug(2, "MarkCompatibility", "Orderfolio is invalid", {
                OrderfolioID: containerEntity.EntityId,
                OrderfolioValidity: containerEntity.IsInvalid
            });
            return;
        }
        var conditions = compatibilityRule.Conditions;
        // All paths can be treated the same here, so concatenate the conditions and process
        var conditionFilters = [
            { ConditionType: RuleConditionType.Entity, Exists: true },
            { ConditionType: RuleConditionType.Value, Exists: true }
        ];
        var conditionPaths = CompiledSpecificationQueries.FilterConditions(conditions, conditionFilters);
        if (conditionPaths.length === 0) {
            Logger.debug(2, "MarkCompatibility", "No condition found", { SubType: "ConditionsPaths", conditionPath: conditionPaths, ruleID: compatibilityRule.ID });
            return;
        }
        var pathsThatExist = [];
        var pathsThatDontExist = [];
        var pathTargetsThatExist = [];
        //In a product candidate scope, itself is counted as a path that exists
        if (compatibilityRule.RuleScope === RuleScope.ProductCandidate) {
            if (conditionPaths[0].ConditionType === RuleConditionType.Entity) {
                var pathTarget = {
                    EntityPath: "",
                    Targets: [],
                    Action: undefined,
                    RawValue: "",
                    AnyEmpty: false
                };
                pathTargetsThatExist.push(pathTarget);
                pathsThatExist.push({
                    ConditionType: conditionPaths[0].ConditionType,
                    ExpectedEmptyValue: conditionPaths[0].ExpectedEmptyValue,
                    TargetPaths: pathTargetsThatExist,
                    ExistsCondition: conditionPaths[0].ExistsCondition,
                    MatchAny: true,
                    FurtherScope: conditionPaths[0].FurtherScope
                });
                Logger.debug(2, "MarkCompatibility", "Target Exist as Compatibility Rule Scope is a Product Candidate and first condition type is an Entity", {
                    CompatibilityRuleScope: compatibilityRule.RuleScope,
                    CompatibilityRuleConditionType: RuleConditionType.Entity,
                    ConditionType: conditionPaths[0].ConditionType,
                    ExistsCondition: conditionPaths[0].ExistsCondition,
                    ExpectedEmptyValue: conditionPaths[0].ExpectedEmptyValue
                });
            }
        }
        var conditionsValidForRuleToBeApplied = true;
        conditionPaths.forEach(function (condition) {
            Logger.debug(2, "MarkCompatibility", "Processing Conditon", {
                Condition: condition
            });
            for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
                Logger.debug(2, "MarkCompatibility", "Processing Conditon - " + condition.Name, {
                    ConditionType: condition.ConditionType,
                    EntityPath: targetPath,
                    Scope: condition.Scope
                });
                if (!conditionsValidForRuleToBeApplied) {
                    Logger.debug(3, "MarkCompatibility", "Condition is not valid for rule to be applied", {
                        ConditionType: condition.ConditionType,
                        ruleID: compatibilityRule.ID
                    });
                    return;
                } // if any conditions are inapplicable, there's no point in continuing to assess the other conditions
                var validTargets = condition.TargetPaths[targetPath].Targets.filter(function (target) {
                    var targetDecomposeContext = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? _this._decomposeContexts[currentDecomposeIndex] : _this._decomposeContexts[target.DecomposeContextIndex];
                    var targetOrderfolioItems = targetDecomposeContext.Orderfolio[target.Key];
                    if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
                        var targetDates = targetDecomposeContext.CompiledSpec.EntityDates[target.Key];
                        if (Utilities.IsNotDefined(targetDates)) {
                            return false;
                        }
                        return targetDates.DateStatus === DateStatus.Available || targetDates.DateStatus === DateStatus.NoLongerAvailable;
                    }
                    return !targetOrderfolioItems[0].IsInvalid;
                });
                if (validTargets.length === 0) {
                    Logger.debug(3, "MarkCompatibility", "There are no valid targets for this condition");
                    conditionsValidForRuleToBeApplied = false;
                    return;
                }
                Logger.debug(3, "MarkCompatibility", "Processing condition targets");
                if (validTargets.length === 0) {
                    conditionsValidForRuleToBeApplied = false;
                    return;
                }
                var oneTargetExists = _this.AtLeastOneTargetExists(condition, validTargets, currentDecomposeIndex, containerEntity);
                if (oneTargetExists) {
                    pathsThatExist.push(condition);
                }
                else {
                    pathsThatDontExist.push(condition);
                }
            }
        });
        // Only set NotAvailable if there are already existing paths and the paths that dont exist is 1
        // This is the condition which will fail the compatibility rule if it proceeds
        if (!conditionsValidForRuleToBeApplied || pathsThatExist.length === 0 || pathsThatDontExist.length !== 1) {
            Logger.debug(2, "MarkCompatibility", "Condition Not valid for rules to be applied due to one of the following:", {
                ApplyRuleFlag: conditionsValidForRuleToBeApplied,
                ExistingTargets: "Existing Targets must be 0, you have" + pathsThatExist.length,
                NoExistingTargets: "Non Existing Targets must be 1, you have" + pathsThatDontExist.length
            });
            return;
        }
        var pathThatDoesntExist = pathsThatDontExist[0];
        Logger.debug(2, "MarkCompatibility", "Ready to apply 'Not Available' tagging for missing target", { pathThatDoesntExist: pathThatDoesntExist });
        switch (pathThatDoesntExist.ConditionType) {
            case RuleConditionType.Entity:
                this.RecordNotAvailableEntitiesForCondition(pathThatDoesntExist, compatibilityRule, currentDecomposeIndex, containerEntity);
                break;
            case RuleConditionType.Value:
                this.RecordNotAvailableValuesForCondition(pathThatDoesntExist, compatibilityRule, currentDecomposeIndex, containerEntity);
                break;
            default:
                break;
        }
    };
    /**
     * Record any Not Available Entities for a condition which has been identified as a possible source
     * of incompatibility. These are only viable if the condition's AutoCreate parent exists in the decomposeContext
     * @param {CsTypes.Condition} condition the condition which is being recorded
     * @param {CsTypes.CompatibilityRule} compatibilityRule the compatibility rule the condition belongs to
     * @param {number} currentDecomposeIndex the index number of the decomposeContext which contains the condition
     */
    CompatibilityRuleMarker.prototype.RecordNotAvailableEntitiesForCondition = function (condition, compatibilityRule, currentDecomposeIndex, containerEntity) {
        var _this = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            var targets = condition.TargetPaths[targetPath].Targets;
            // For each target, Check if Trigger parent exists, If it does, or undefined, enter a NotAvailable
            targets.forEach(function (target) {
                Logger.debug(2, "MarkCompatibility", "Recording Not Available Entities For Condition's targets", { target: target });
                var targetDecomposeContextIndex = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? currentDecomposeIndex : target.DecomposeContextIndex;
                var sortKey = targetDecomposeContextIndex.toString() + '-' + target.AutoCreateTriggerParentUuid.toString() + '-' + target.AutoCreateTriggerUuid;
                var notAvailableItem = {
                    SortKey: sortKey,
                    DecomposeContextIndex: targetDecomposeContextIndex,
                    TargetUuid: target.AutoCreateTriggerUuid,
                    TargetParentUuid: target.AutoCreateTriggerParentUuid,
                    CompatibilityRuleId: compatibilityRule.ID,
                    ConditionScope: condition.Scope,
                    ErrorMessage: compatibilityRule.ErrorMessage,
                    ContainerCompoundKey: containerEntity.CompoundKey
                };
                if (Utilities.IsNotDefined(target.AutoCreateTriggerParentUuid)) {
                    // If no trigger parent Uuid is defined, then it is the root which exists, so flag
                    _this._notAvailableEntities.push(notAvailableItem);
                    Logger.debug(3, "MarkCompatibility", "Added 'Not Available Item' for root ", { notAvailableItem: notAvailableItem });
                }
                else {
                    // Else, the trigger parent has to exist in the target decompose context
                    //       so the trigger entity can be added
                    var targetDecomposeContext = _this._decomposeContexts[targetDecomposeContextIndex];
                    var parentOrderfolioItems = targetDecomposeContext.Orderfolio[target.AutoCreateTriggerParentUuid];
                    if (Utilities.IsDefined(parentOrderfolioItems, true)) {
                        //  parent exists so this is entirely possible
                        _this._notAvailableEntities.push(notAvailableItem);
                        Logger.debug(3, "MarkCompatibility", "Added 'Not Available Item' for parent orderfolio item with key " + target.AutoCreateTriggerParentUuid, { notAvailableItem: notAvailableItem });
                    }
                    else {
                        Logger.debug(3, "MarkCompatibility", "Not Available Item' not added as TargetParentUuid not specified or parent orderfolio doesn't exist", { notAvailableItem: notAvailableItem });
                    }
                }
            });
        }
    };
    /**
     * Record any Not Available Characteristic Values for a condition which has been identified as a possible
     * source of incompatibility. These are only viable if the condition's target exists in the decomposeContext
     * @param {CsTypes.Condition} condition the condition which is being recorded
     * @param {CsTypes.CompatibilityRule} compatibilityRule the compatibility rule the condition belongs to
     * @param {number} currentDecomposeIndex the index number of the decomposeContext which contains the condition
     */
    CompatibilityRuleMarker.prototype.RecordNotAvailableValuesForCondition = function (condition, compatibilityRule, currentDecomposeIndex, containerEntity) {
        var _this = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            var targetPathItem = condition.TargetPaths[targetPath];
            var targets = targetPathItem.Targets;
            // For each target, Check if Trigger parent exists, If it does, or undefined, enter a NotAvailable
            targets.forEach(function (target) {
                Logger.debug(3, "MarkCompatibility", "Recording Not Available Values For Condition's targets", { target: target });
                // The target Uuid has to exist before any Not Available values can be recorded
                var targetDecomposeContextIndex = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? currentDecomposeIndex : target.DecomposeContextIndex;
                var targetDecomposeContext = _this._decomposeContexts[targetDecomposeContextIndex];
                var targetOrderfolioItems = targetDecomposeContext.Orderfolio[target.Key.toString()];
                if (Utilities.IsDefined(targetOrderfolioItems, true)) {
                    var sortKey = targetDecomposeContextIndex.toString() + '-' + target.Key.toString() + '-' + targetPathItem.UseId;
                    if (Utilities.IsDefined(targetPathItem.ValueId, true)) {
                        sortKey = sortKey + '-' + targetPathItem.ValueId;
                    }
                    var notAvailableItem = {
                        SortKey: sortKey,
                        DecomposeContextIndex: targetDecomposeContextIndex,
                        TargetUuid: target.Key.toString(),
                        UseId: targetPathItem.UseId,
                        ValueId: targetPathItem.ValueId,
                        CompatibilityRuleId: compatibilityRule.ID,
                        ConditionScope: condition.Scope,
                        ErrorMessage: compatibilityRule.ErrorMessage,
                        ContainerCompoundKey: containerEntity.CompoundKey
                    };
                    _this._notAvailableValues.push(notAvailableItem);
                    Logger.debug(4, "MarkCompatibility", "Added 'Not Available Item' for root ", { notAvailableItem: notAvailableItem });
                }
                else {
                    Logger.debug(4, "MarkCompatibility", "Item not added as there was no Orderfolio with key " + target.key, { target: target });
                }
            });
        }
    };
    /**
     * Create and mark any entities identified as NotAvailable
     */
    CompatibilityRuleMarker.prototype.MarkNotAvailableEntities = function () {
        var _this = this;
        Logger.debug(1, "MarkCompatibility", "Processing Entities to me marked as 'Not Available'");
        // Function to mark a single entity
        var markNotAvailableEntity = function (notAvailableEntity) {
            Logger.debug(2, "MarkCompatibility", "Started Marking Entity", notAvailableEntity);
            var decomposeContext = _this._decomposeContexts[notAvailableEntity.DecomposeContextIndex];
            var parentUuid = Utilities.ValueOrDefault(notAvailableEntity.TargetParentUuid, '1');
            var parentOrderfolioItems = decomposeContext.Orderfolio[parentUuid];
            // If we have a scope of Child ensure that we only look at children underneath the instance of the container entity
            if (notAvailableEntity.ConditionScope === RuleScope.Child) {
                Logger.debug(3, "MarkCompatibility", "Attaining Child Orderfolio Items that contain key - " + notAvailableEntity.ContainerCompoundKey.Key, notAvailableEntity);
                parentOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(notAvailableEntity.ContainerCompoundKey, parentOrderfolioItems, decomposeContext);
            }
            // Add the NotAvailable Child to all applicable parents
            parentOrderfolioItems.forEach(function (parentOrderfolioItem) {
                Logger.debug(3, "MarkCompatibility", "Adding NotAvailable to Orderfolio Item - " + parentOrderfolioItem.CompoundKey.Key, notAvailableEntity);
                _this.AddChildToOrderfolio(decomposeContext, parentOrderfolioItem, notAvailableEntity);
            });
        };
        if (Utilities.IsNotDefined(this._notAvailableEntities, true)) {
            Logger.debug(2, "MarkCompatibility", "No Entities to be marked");
            return;
        }
        // Remove any duplicates & generate the not available items
        var uniqueNotAvailableEntities = this.DistinctTargetEntities(this._notAvailableEntities);
        Logger.debug(2, "MarkCompatibility", "Created distinct list of entites that will be marked", uniqueNotAvailableEntities);
        uniqueNotAvailableEntities.forEach(markNotAvailableEntity);
    };
    /**
     * Create and mark any characteristic values identified as not available
     */
    CompatibilityRuleMarker.prototype.MarkNotAvailableValues = function () {
        var _this = this;
        Logger.debug(1, "MarkCompatibility", "Processing Values to me marked at 'Not Available'");
        // Function to mark a single value
        var markNotAvailableValue = function (notAvailableValue) {
            Logger.debug(2, "MarkCompatibility", "Started Marking Value", notAvailableValue);
            var decomposeContext = _this._decomposeContexts[notAvailableValue.DecomposeContextIndex];
            var orderfolioItems = decomposeContext.Orderfolio[notAvailableValue.TargetUuid.toString()];
            // If we have a scope of Child ensure that we only look at children underneath the instance of the container entity
            if (notAvailableValue.ConditionScope === RuleScope.Child) {
                Logger.debug(3, "MarkCompatibility", "Attaining Child Orderfolio Items that contain ket - " + notAvailableValue.ContainerCompoundKey.Key, notAvailableValue);
                orderfolioItems = OrderfolioQueries.FilterChildrenToParent(notAvailableValue.ContainerCompoundKey, orderfolioItems, decomposeContext);
            }
            // Add Values to all applicable orderfolio Items
            orderfolioItems.forEach(function (orderfolioItem) {
                Logger.debug(3, "MarkCompatibility", "Adding Characteristic use and value to an orderfolio - " + orderfolioItem.CompoundKey.Key, notAvailableValue);
                _this.AddCharacteristicUseAndValue(orderfolioItem, notAvailableValue);
            });
        };
        if (Utilities.IsNotDefined(this._notAvailableValues, true)) {
            Logger.debug(2, "MarkCompatibility", "No Values to be marked");
            return;
        }
        // Remove any duplicates & generate the not available values
        var uniqueNotAvailableValues = this.DistinctTargetEntities(this._notAvailableValues);
        Logger.debug(2, "MarkCompatibility", "Created distinct list of values that will be marked", uniqueNotAvailableValues);
        uniqueNotAvailableValues.forEach(markNotAvailableValue);
    };
    /**
     * Add a characteristic use and value to an orderfolio item and decorate them with
     * the NotAvailable compatibility error message
     * @param {CsTypes.OrderfolioItem} orderfolioItem the OrderfolioItem where the CharacteristicUse and Value should be added
     * @param {INotAvailableOrderfolioItem} notAvailableValue holds the information about the char use and value and compatibility info
     */
    CompatibilityRuleMarker.prototype.AddCharacteristicUseAndValue = function (orderfolioItem, notAvailableValue) {
        // Make sure there is an array to accept our characteristic
        if (Utilities.IsNotDefined(orderfolioItem.CharacteristicUses)) {
            orderfolioItem.CharacteristicUses = [];
        }
        var itemSource = OrderfolioQueries.GetGeneratedItemSource(this._decomposeContexts[0].OrderRequestId);
        // Does characteristicUse exist, create one if not and put into array
        var charUseToDecorate = LodashUtilities.Find(orderfolioItem.CharacteristicUses, function (c) { return c.UseId === notAvailableValue.UseId; });
        Logger.debug(4, "MarkCompatibility", "Attempt to find characteristicUse to mark", charUseToDecorate);
        if (Utilities.IsNotDefined(charUseToDecorate)) {
            charUseToDecorate = {
                UseId: notAvailableValue.UseId,
                Values: [],
                Action: MergedActions.AddMissing,
                OrderItemSource: itemSource,
                PortfolioItemSource: itemSource
            };
            orderfolioItem.CharacteristicUses.push(charUseToDecorate);
            Logger.debug(4, "MarkCompatibility", "Did not find a characteristicUse, therefore create one and put into orderfolio", charUseToDecorate);
        }
        // If there is no value on the not available item the whole use is not available
        // Otherwise create the value and add it to the Values array
        if (Utilities.IsNotDefined(notAvailableValue.ValueId, true)) {
            charUseToDecorate.NotAvailable = notAvailableValue.ErrorMessage;
            Logger.debug(4, "MarkCompatibility", "Marked characteristicUse with error message as the item to me marked has as ID", notAvailableValue);
        }
        else {
            Logger.debug(4, "MarkCompatibility", "Looking for Characteristic Value to mark", notAvailableValue);
            this.AddCharacteristicValueToUse(charUseToDecorate, notAvailableValue);
        }
    };
    /**
     * Add a characteristic value to a characteristic use and decorate them with the NotAvailable compatibility error message
     * @param {CsTypes.CharacteristicUse} characteristicUse the Characteristic Use to add the value to
     * @param {INotAvailableOrderfolioItem} notAvailableValue holds the information about the char use and value and compatibility info
     */
    CompatibilityRuleMarker.prototype.AddCharacteristicValueToUse = function (characteristicUse, notAvailableValue) {
        if (Utilities.IsNotDefined(characteristicUse.Values)) {
            characteristicUse.Values = [];
        }
        // Does the char value exist already - this shouldn't happen because it should have failed a compatibility rule
        var charValueToDecorate = LodashUtilities.Find(characteristicUse.Values, function (v) { return v.Value === notAvailableValue.ValueId; });
        Logger.debug(5, "MarkCompatibility", "Attempt to look for characteristic value with ID - " + notAvailableValue.ValueId, charValueToDecorate);
        if (Utilities.IsNotDefined(charValueToDecorate)) {
            charValueToDecorate = {
                Value: notAvailableValue.ValueId,
                Action: MergedActions.AddMissing,
                ItemSource: OrderfolioQueries.GetGeneratedItemSource(this._decomposeContexts[0].OrderRequestId)
            };
            characteristicUse.Values.push(charValueToDecorate);
            Logger.debug(5, "MarkCompatibility", "Did not find a characteristic value, therefore create one", charValueToDecorate);
        }
        // Add the ErrorMessage
        charValueToDecorate.NotAvailable = notAvailableValue.ErrorMessage;
        Logger.debug(5, "MarkCompatibility", "Marked characteristic value with error message as the item to me marked has as ID", notAvailableValue);
    };
    /**
     * Method searches the supplied decompose contexts to check if at least 1 of the supplied conditions->targets exist
     * @param {CsTypes.Condition} condition the condition that contains the target info
     * @param {CsTypes.ItemTarget[]} validTargets a list of targets that are said to be valid by being within the date of the order
     * @param {number} currentDecomposeIndex the decompose index that the function will look in
     * @param {CsTypes.OrderfolioItem} containerEntity the entity that contains the compatibility rule
     * @param {string} ruleScope the scope of the given compatibility rule
     * @returns {boolean} a value indicating if at least 1 of the valid targets exists in the orderfolio
     */
    CompatibilityRuleMarker.prototype.AtLeastOneTargetExists = function (condition, validTargets, currentDecomposeIndex, containerEntity) {
        var _this = this;
        return validTargets.some(function (target) {
            Logger.debug(4, "MarkCompatibility", "Processing target with key " + target.Key, target);
            var targetDecomposeContext = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? _this._decomposeContexts[currentDecomposeIndex] : _this._decomposeContexts[target.DecomposeContextIndex];
            var targetOrderfolioItems = targetDecomposeContext.Orderfolio[target.Key];
            if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
                Logger.debug(5, "MarkCompatibility", "No Orderfolio Items with key of " + target.Key + " found for this target", target);
                return false;
            }
            if (condition.Scope === RuleScope.Child) {
                // If we have a scope of child ensure that we only look at children underneath the instance of the container entity
                targetOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(containerEntity.CompoundKey, targetOrderfolioItems, targetDecomposeContext);
                Logger.debug(5, "MarkCompatibility", "Condition is of scope 'Child', therefore finding child orderfolio items", target);
                if (Utilities.IsNotDefined(targetOrderfolioItems, true)) {
                    Logger.debug(6, "MarkCompatibility", "No Child Orderfolio Items found for this target", target);
                    return false;
                }
            }
            // We have found an entity, so depending on condition type
            switch (condition.ConditionType) {
                case RuleConditionType.Entity:
                    Logger.debug(5, "MarkCompatibility", "Target Exists", function () { return (_this.LogMappedContext(condition, targetOrderfolioItems)); });
                    return true;
                case RuleConditionType.Value:
                    return _this.ValueExistsOnOrderfolioItems(condition, targetOrderfolioItems);
                default:
                    Logger.debug(5, "MarkCompatibility", "No Target Exists", function () { return (_this.LogMappedContext(condition, targetOrderfolioItems)); });
                    // Condition not checked here (shouldn't be here) return false
                    return false;
            }
        });
    };
    /**
    * Apply logging for mapped context
    * @param {CsTypes.ItemPath} targetOrderfolioItems The condition that contains the target info
    * @param {CsTypes.OrderfolioItem[]} targetOrderfolioItems The targetOrderfolioItems to be evaluated against
    */
    CompatibilityRuleMarker.prototype.LogMappedContext = function (condition, targetOrderfolioItems) {
        return {
            Condition: condition,
            TargetOrderfolioItem: {
                Entities: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.EntityId; }),
                CharacteristicUses: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.CharacteristicUses; }),
                UserDefinedCharacteristics: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.UserDefinedCharacteristics; })
            }
        };
    };
    /**
     * Method checks the characteristic uses on the supplied orderfolio items for the presence of a value
     * @param {CsTypes.Condition} condition the condition containing the UseId and ValueId to check
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the orderfolio to search through
     * @returns {boolean} a value indicating if the valueId was found on at least one of the orderfolio items
     */
    CompatibilityRuleMarker.prototype.ValueExistsOnOrderfolioItems = function (condition, orderfolioItems) {
        var _this = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            var targetPathItem = condition.TargetPaths[targetPath];
            var useId = targetPathItem.UseId;
            var valueId = targetPathItem.ValueId;
            var valueIsNotDefined = Utilities.IsNotDefined(valueId, true);
            return orderfolioItems.some(function (orderfolioItem) {
                return orderfolioItem.CharacteristicUses.some(function (charUse) {
                    if (charUse.UseId !== useId) {
                        Logger.debug(4, "MarkCompatibility", "No Target Exists", function () { return (_this.LogMappedContext(condition, orderfolioItems)); });
                        return false;
                    }
                    if (valueIsNotDefined) {
                        Logger.debug(4, "MarkCompatibility", "Target Exists", function () { return (_this.LogMappedContext(condition, orderfolioItems)); });
                        return true;
                    }
                    return charUse.Values.some(function (charValue) { return charValue.Value === valueId; });
                });
            });
        }
    };
    /**
     * Adds the child item specified by the mapping action to the orderfolio
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsTypes.OrderfolioItem} parentOrderfolioItem The parent orderfolio item to which the child should be added
     * @param {INotAvailableOrderfolioItem} notAvailableItem holds all the information about the item to add along with compatibility rule info
     */
    CompatibilityRuleMarker.prototype.AddChildToOrderfolio = function (decomposeContext, parentOrderfolioItem, notAvailableItem) {
        // Clone out the template
        var targetKey = notAvailableItem.TargetUuid;
        var childOrderfolioItem = LodashUtilities.Clone(decomposeContext.CompiledSpec.EntityTemplateLookup[targetKey], true);
        if (Utilities.IsNotDefined(childOrderfolioItem)) {
            Logger.debug(4, "MarkCompatibility", "Did not mark item as Orderfolio item" + targetKey + "Was not found in the decompose context");
            return;
        }
        // Set Values
        childOrderfolioItem.OrderItemId = Utilities.CreateID().toLowerCase();
        childOrderfolioItem.PortfolioItemId = Utilities.CreateID().toLowerCase();
        childOrderfolioItem.EntityUniqueCode = childOrderfolioItem.OrderItemId;
        childOrderfolioItem.OrderItemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
        childOrderfolioItem.PortfolioItemSource = childOrderfolioItem.OrderItemSource;
        childOrderfolioItem.NotAvailable = notAvailableItem.ErrorMessage;
        Logger.debug(4, "MarkCompatibility", "Set values for OrderfolioItem", childOrderfolioItem);
        // Add Child to Orderfolio
        var existingOrderfolioSet = decomposeContext.Orderfolio[targetKey];
        if (Utilities.IsDefined(existingOrderfolioSet, true)) {
            childOrderfolioItem.CompoundKey.Index = existingOrderfolioSet.length;
            existingOrderfolioSet.push(childOrderfolioItem);
            Logger.debug(5, "MarkCompatibility", "OrderfolioItem added to existing OrderfolioSet of key " + targetKey, childOrderfolioItem);
        }
        else {
            childOrderfolioItem.CompoundKey.Index = 0;
            decomposeContext.Orderfolio[targetKey] = [childOrderfolioItem];
            Logger.debug(5, "MarkCompatibility", "OrderfolioItem added to decompose contexts Orderfolio set of key " + targetKey, childOrderfolioItem);
        }
        var parentKey = parentOrderfolioItem.CompoundKey.Key + "-" + parentOrderfolioItem.CompoundKey.Index;
        var childKey = childOrderfolioItem.CompoundKey.Key + "-" + childOrderfolioItem.CompoundKey.Index;
        // Update parent -> child table
        if (Utilities.IsNotDefined(decomposeContext.ParentToChildTable[parentKey])) {
            decomposeContext.ParentToChildTable[parentKey] = [childOrderfolioItem.CompoundKey];
        }
        else {
            decomposeContext.ParentToChildTable[parentKey].push(childOrderfolioItem.CompoundKey);
        }
        Logger.debug(4, "MarkCompatibility", "Updated Parent To Child Table with key " + parentKey + " with Orderfolio key " + childOrderfolioItem.CompoundKey.Key);
        // Update child -> parent table
        decomposeContext.ChildToParentTable[childKey] = parentOrderfolioItem.CompoundKey;
        Logger.debug(4, "MarkCompatibility", "Updated Child To Parent Table with key " + childKey + " with Orderfolio key " + parentOrderfolioItem.CompoundKey.Key);
        // Update the action of the parent and its ancestors
        OrderfolioQueries.EnsureActionHierarchy(decomposeContext, parentOrderfolioItem);
    };
    /**
     * Get only the distinct entries in the an array of INotAvailableOrderfolioItem based
     * on the SortKey and the scope of the Rule.
     * With non Child scoped rule only the first instance of the SortKey is kept. For Child
     * scoped rules all instances are kept.
     * @param  {Array<INotAvailableOrderfolioItem>} notAvailableEntities the array to reduce
     * @return {Array<INotAvailableOrderfolioItem>} A filtered array
     */
    CompatibilityRuleMarker.prototype.DistinctTargetEntities = function (notAvailableEntities) {
        if (Utilities.IsNotDefined(notAvailableEntities, true)) {
            Logger.debug(2, "MarkCompatibility", "No Entities to mark as 'Not Available'");
            return [];
        }
        // First get only entities affected by non Child (i.e. PC) scoped rule
        // If there are duplicates only the first instance is kept.
        // Separate Child scoped items at the same time
        var pcScopedKeys = [];
        var childScopedEntities = [];
        var distinctEntities = notAvailableEntities.filter(function (entity) {
            if (entity.ConditionScope === RuleScope.Child) {
                childScopedEntities.push(entity);
                return false;
            }
            if (pcScopedKeys.indexOf(entity.SortKey) !== -1) {
                return false;
            }
            pcScopedKeys.push(entity.SortKey);
            return true;
        });
        // Then add all Child scoped entities that are not covered by a PC scoped rule
        // Here all children are kept as they can target specific instances
        // TODO: (AG) This needs to be cleverer such that a not available item that is also
        //       created by a child scoped compatibility rule which resides further up the tree
        //       AND is on the same branch (i.e. uuid-index is a direct parent of ContainerCompoundKey)
        //       as the rule container that is being tested then it will trump it and the entity being
        //       tested should be discarded/ignored.
        notAvailableEntities.forEach(function (entity) {
            if (entity.ConditionScope !== RuleScope.Child
                || pcScopedKeys.indexOf(entity.SortKey) !== -1) {
                return;
            }
            distinctEntities.push(entity);
        });
        return distinctEntities;
    };
    return CompatibilityRuleMarker;
}());
module.exports = CompatibilityRuleMarker;

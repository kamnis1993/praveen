"use strict";
/// <reference types="node" />
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var CompatibilityRuleMarker = require("./CompatibilityRuleMarker");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var Inferrer = require("../cs-inference/Inferrer");
var ProductCandidateResponseBuilder = require("../cs-lib-composition/ProductCandidateResponseBuilder");
var Validate = require("../cs-validate/Validate");
var Interactive = /** @class */ (function () {
    function Interactive() {
    }
    /**
     * Marks any items which are incompatible with the supplied ProductCandidate in the request
     */
    Interactive.prototype.MarkPossibleIncompatibilities = function (request, compiledSpecs, callback) {
        var _this = this;
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(BoundaryConditionConstants.Commercial, errorContext);
        decomposeContextBuilder.BuildFromProductCandidate(request, compiledSpecs, function (decomposeContexts) {
            var decomposeResponse = _this.PerformDecomposition(decomposeContexts, errorContext);
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            var decomposeResponseType = 'ProductCandidateResponse';
            return callback(null, ConverterUtils.OrderSingularize(decomposeResponse)); // decomposeResponseType
        });
    };
    /**
     * Performs the decomposition process on the array of decompose contexts
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts The decompose contexts
     * @param {CsErrorContext} errorContext THe error context
     * @param {any} unflatten The function used to unflatten the decompose contexts
     * @returns {any}
     */
    Interactive.prototype.PerformDecomposition = function (decomposeContexts, errorContext) {
        // Infer
        decomposeContexts.forEach(function (context, dci) {
            Inferrer.InferOrderfolioItemsForSingleContext(context);
        });
        // Apply standard compatibility rules
        new Validate().ApplyCompatibilityRules(decomposeContexts, errorContext);
        if (errorContext.HasBreakingErrors) {
            return null;
        }
        // Mark not available items for compatibility Rules
        var notAvailableMarker = new CompatibilityRuleMarker(decomposeContexts, errorContext);
        notAvailableMarker.IdentifyNotAvailable();
        // D-09071 Make a copy of Validation errors so and raised by ResponseBuilder can be ignored
        // NOTE: If group cardninality validation is removed from the ResponseBuilder
        //       this step may not be needed any longer
        var markCompatibilityErrorsForResponse = errorContext.GetValidationErrorsForResponse();
        // Unflatten, possibly including extra validation
        var builder = new ProductCandidateResponseBuilder(errorContext);
        var decomposeResponse = builder.Build(decomposeContexts);
        if (errorContext.HasBreakingErrors) {
            return null;
        }
        // D-09071: Ignore any group cardinality errors that were raised by the ResponseBuilder
        // NOTE: If group cardninality validation is removed from the ResponseBuilder
        //       this step may not be needed any longer
        decomposeResponse.ValidationErrors = markCompatibilityErrorsForResponse;
        return decomposeResponse;
    };
    return Interactive;
}());
module.exports = Interactive;

"use strict";
var decimal = require("jsdecimal");
var ChargeTypes = require("../cs-lib-constants/ChargeTypes");
var CostTypes = require("../cs-lib-constants/CostTypes");
var InterimRate = require("./InternalPricingTypes/InterimRate");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityQueries = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RateTypes = require("../cs-lib-constants/RateTypes");
var Utilities = require("../cs-lib-utilities/Utilities");
/** Contains methods for both cost and charge functions */
var PricingUtilities = /** @class */ (function () {
    function PricingUtilities() {
    }
    /**
    * Determines whether a item action on a cost/charge/discount is invalid (can't have rates applied) based on the item action and charge type
    * @param {string} ItemAction The item action on the entity
    * @param {string} entityType The type of enttiy (e.g. Non-recurring, recurring)
    * @returns {boolean}
    */
    PricingUtilities.IsItemActionInvalidForEntityType = function (itemAction, entityType) {
        var supportedTypes = [
            ChargeTypes.NonRecurringCharge,
            ChargeTypes.RecurringCharge,
            ChargeTypes.StandaloneNonRecurringCharge,
            ChargeTypes.StandaloneRecurringCharge,
            ChargeTypes.NonRecurringCostBasedCharge,
            ChargeTypes.RecurringCostBasedCharge,
            CostTypes.RecurringCost,
            CostTypes.NonRecurringCost,
            CostTypes.StandaloneRecurringCost,
            CostTypes.StandaloneNonRecurringCost
        ];
        if (!LodashUtilities.Contains(supportedTypes, entityType)) {
            return true;
        }
        if (itemAction === OrderActions.Add) {
            return false;
        }
        // A reassigned entity should only be priced once; prevent the pricing of any pricing entities with the action "reassign"
        else if (itemAction === OrderActions.Delete ||
            itemAction === OrderActions.Reassign) {
            return true;
        }
        // Else the checks for actions of Update, NoChange, Reassigned and ReassignedUpdate are the same
        else if (entityType === ChargeTypes.RecurringCharge ||
            entityType === ChargeTypes.StandaloneRecurringCharge ||
            entityType === CostTypes.RecurringCost ||
            entityType === CostTypes.StandaloneRecurringCost) {
            return false;
        }
        else if (entityType === ChargeTypes.NonRecurringCharge ||
            entityType === ChargeTypes.StandaloneNonRecurringCharge ||
            entityType === CostTypes.NonRecurringCost ||
            entityType === CostTypes.StandaloneNonRecurringCost) {
            return true;
        }
        else if (entityType === ChargeTypes.NonRecurringCostBasedCharge ||
            entityType === ChargeTypes.RecurringCostBasedCharge) {
            return false;
        }
        else {
            return true;
        }
    };
    /**
     * Filters out rates according to valid rate dates & rating attributes
     * @param {Date} orderActivationDate The activation/creation date on the order or product candidate
     * @param {CsTypes.RateInfo[]} specRates The possible rates on a charge
     * @param {CsTypes.RateAttribute[]} rateAttributes The rate attributes passed in from an order
     * @param {CsTypes.Dictionary<string[]} exclusiveRateAttributeValues Rate attribute values which are not available in the case of a blank entry
     * @returns {CsTypes.RateInfo[]}
     */
    PricingUtilities.FilterRates = function (orderActivationDate, specRates, rateAttributes, exclusiveRateAttributeValues, rateActivationDate, rateId) {
        // Structure the rate attributes from the order for better checking with spec rate attributes:
        var rateAttributesOnOrder = PricingUtilities.OrderRateAttributeToSpecRateAttributeFormat(rateAttributes);
        Logger.debug(50, "Pricing", "Filtering rates based on rate attributes", { SubType: "RateAttributes", RateAttributesOnEntity: rateAttributesOnOrder });
        if (specRates === undefined) {
            return null;
        }
        var filteredSpecRates = specRates.filter(function (specRate) {
            // if rate activation dates are assigned we want to check these against the order/rate activation date passed in
            if (Utilities.IsDefined(specRate.ActivationStartDate) || Utilities.IsDefined(specRate.ActivationEndDate)) {
                var activationDate = Utilities.IsDefined(rateActivationDate) ? rateActivationDate : orderActivationDate;
                // need to check the activation date versus both date bands
                // but we have to check them separately, missing an ActivationEndDate doesnt mean use the EndDate in its place
                // as they are fundamentally different things
                if (!Utilities.IsDateValidForDateRange(activationDate, specRate.ActivationStartDate, specRate.ActivationEndDate)
                    || !Utilities.IsDateValidForDateRange(activationDate, specRate.StartDate, specRate.EndDate)) {
                    Logger.debug(60, "Pricing", "Rate invalid due to date mismatch", { SubType: "DateInfo", RateId: specRate.RateGuid, ActivationDate: activationDate, RateStartDate: specRate.StartDate, RateEndDate: specRate.EndDate });
                    return false;
                }
            }
            else {
                if (!Utilities.IsDateValidForDateRange(orderActivationDate, specRate.StartDate, specRate.EndDate)) {
                    Logger.debug(60, "Pricing", "Rate invalid due to date mismatch", { SubType: "DateInfo", RateId: specRate.RateGuid, ActivationDate: orderActivationDate, RateStartDate: specRate.StartDate, RateEndDate: specRate.EndDate });
                    return false;
                }
            }
            return true;
        });
        return filteredSpecRates.filter(function (specRate) {
            // If we have a rate Id override, then the only filter that matters is whether the rate guid matches the provided Id
            if (Utilities.IsDefined(rateId, true)) {
                if (specRate.RateGuid === rateId) {
                    return true;
                }
                return false;
            }
            var rateAttributesOnSpec = specRate.RateAttributes;
            if (LodashUtilities.IsEmpty(rateAttributesOnSpec) && LodashUtilities.IsEmpty(rateAttributesOnOrder)) {
                return true;
            }
            else if (LodashUtilities.IsEmpty(rateAttributesOnOrder)) {
                // If there is only a single rate on the spec, whether or not rate attributes are provided on the spec
                // is irrelevant as the rate is unambiguous if we have no rate attributes on the request
                if (filteredSpecRates.length === 1) {
                    return true;
                }
                Logger.debug(60, "Pricing", "Rate invalid as no rate attributes are on order but multiple specification rates exist - could not filter");
                return false;
            }
            var matchesAllRatingAttributes = Object.keys(rateAttributesOnOrder).every(function (rateAttributeOnOrderKey) {
                var orderRateAttributeValue = rateAttributesOnOrder[rateAttributeOnOrderKey];
                var specRateAttributeValues = rateAttributesOnSpec[rateAttributeOnOrderKey];
                // If no values are defined on the specification rate entry for this rate attribute, the entry is blank.
                // Blank entries are considered to be any value that has not already been specified by another rate row.
                // Use the collection of excluded values - those which *have* already been specified by another rate row -
                // to identify whether this value may be matched by a blank entry.
                if (Utilities.IsNotDefined(specRateAttributeValues)) {
                    var specRateAttributeExcludedValues_1 = exclusiveRateAttributeValues[rateAttributeOnOrderKey];
                    // If a spec rate is defined with a blank value, and there are no excluded values - i.e. no value has ever been set
                    // against this rate attribute in the collection of rates - then any input value (or no value at all) is valid.
                    // Essentially, treat this rate attribute as if it doesn't exist, because all values are valid
                    if (Utilities.IsNotDefined(specRateAttributeExcludedValues_1, true)) {
                        return true;
                    }
                    return !specRateAttributeExcludedValues_1.some(function (specRateAttributeExcludedValue) {
                        var orderMatchOnExcludedValues = specRateAttributeExcludedValue.toLowerCase() === orderRateAttributeValue.toLowerCase();
                        if (orderMatchOnExcludedValues) {
                            Logger.debug(60, "Pricing", "Rate invalid as match on unavailable rate attribute values", { SubType: "Comparison", RateId: specRate.RateGuid, OrderRateAttribute: orderRateAttributeValue, ExcludedValues: specRateAttributeExcludedValues_1 });
                        }
                        return orderMatchOnExcludedValues;
                    });
                }
                var orderMatchOnPermittedValues = specRateAttributeValues.some(function (specRateAttributeValue) {
                    return (specRateAttributeValue.toLowerCase() === orderRateAttributeValue.toLowerCase());
                });
                if (!orderMatchOnPermittedValues) {
                    Logger.debug(60, "Pricing", "Rate invalid as no match found on rate attribute values", { SubType: "RateAttribute", RateId: specRate.RateGuid, OrderRateAttribute: orderRateAttributeValue, PermittedValues: specRateAttributeValues });
                }
                return orderMatchOnPermittedValues;
            });
            return matchesAllRatingAttributes;
        });
    };
    /**
     * Structures the rate attributes on an order to the same as the rate attributes on a spec
     * @param {CsTypes.RateAttribute[]} orderRateAttributes The rate attributes from the orderfolio
     * @returns {CsTypes.Dictionary<string>} - Similar structure to on rate attributes on spec but a singular value
     */
    PricingUtilities.OrderRateAttributeToSpecRateAttributeFormat = function (orderRateAttributes) {
        var rateAttributes = {};
        orderRateAttributes.forEach(function (orderRateAttribute) {
            if (orderRateAttribute.Action !== MergedActions.DeleteExisting &&
                orderRateAttribute.Action !== MergedActions.DeleteMissing) {
                rateAttributes[orderRateAttribute.Name] = (orderRateAttribute.Value);
            }
        });
        return rateAttributes;
    };
    /**
     * Calculates the rate information as an interim rate and adds spec rate attributes not provided in the request to the orderfolio item
     * @param {CsTypes.OrderfolioItem} chargeOrCost the orderfolio item to calculate the rate for
     * @param {CsTypes.RateInfo} applicableRate the specification rate details
     * @param {CsTypes.CostBasedCalculations} costBasedCalculation any calculations done using costs for cost based charges
     * @return {interimRate} interimRate the calculated rate
     */
    PricingUtilities.CalculateOrderfolioItemRate = function (chargeOrCost, applicableRate, costBasedCalculation, valueOverride) {
        var rate = {
            ID: applicableRate.RateGuid,
            Type: applicableRate.Type,
            StartDate: applicableRate.StartDate,
            EndDate: applicableRate.EndDate,
            Value: undefined,
            ActivationStartDate: Utilities.IsDefined(applicableRate.ActivationStartDate) ? applicableRate.ActivationStartDate : null,
            ActivationEndDate: Utilities.IsDefined(applicableRate.ActivationEndDate) ? applicableRate.ActivationEndDate : null
        };
        var interimRate = new InterimRate();
        var unitPricingRate = Utilities.IsDefined(applicableRate.UnitPricingRates);
        var costBasedRate = Utilities.IsDefined(costBasedCalculation);
        // If we have a value override, the calculation is vastly simplified
        if (Utilities.IsDefined(valueOverride, true)) {
            var value = new decimal(valueOverride);
            // If the value override is set against a unit-based rate, the override is assumed to apply per unit, so multiply
            // the override value by the number of units
            if (unitPricingRate) {
                value = value.mul(chargeOrCost.UnitQuantity);
            }
            rate.Value = value.toFloat();
        }
        else if (costBasedRate) // cost based charge rate
         {
            // collection.reduce is used to isolate individual properties on a collection of objects and accumulate the result.
            // Here, we are using it to isolate and sum the totals for price and cost, by isolating the ResultValue (total price) of each marked up cost,
            // and the CostValue (pre-markup cost) of each cost, and apply those to the Rate.
            rate.CostValue = costBasedCalculation.CostBasedMarkup.reduce(function (a, b) { return a + b.CostValue; }, 0);
            if (applicableRate.Aggregate) {
                rate.Value = new decimal(rate.CostValue).add(costBasedCalculation.AggregateMarkupValue).toFloat();
            }
            else {
                rate.Value = costBasedCalculation.CostBasedMarkup.reduce(function (a, b) { return a + b.ResultValue; }, 0);
            }
            rate.CostBasedCalculations = costBasedCalculation;
        }
        else if (unitPricingRate) // unit based rate
         {
            rate.Value = PricingUtilities.CalculateUnitBasedRateValue(chargeOrCost.UnitQuantity, applicableRate);
        }
        else // simple rate
         {
            rate.Value = applicableRate.Value;
        }
        interimRate.Rate = rate;
        interimRate.OrderfolioKey = chargeOrCost.CompoundKey;
        return interimRate;
    };
    /**
     * Sets the unit quantity on the pricing entity, if it is not already set
     * @param decomposeContext The decompose context
     * @param entityCountInfo Information to identify
     * @param chargeOrCost The orderfolio item whose unit quantity will be updated
     */
    PricingUtilities.CalculateUnitQuantityFromEntityCountInfo = function (decomposeContext, entityCountInfo, chargeOrCost) {
        if (chargeOrCost.UnitQuantity !== undefined) {
            return;
        }
        if (entityCountInfo !== undefined) {
            var entityCount = 0;
            entityCountInfo.Entities.forEach(function (entity) {
                var orderfolioItems = decomposeContext.Orderfolio[entity.Uuid];
                if (Utilities.IsNotDefined(orderfolioItems, true)) {
                    return;
                }
                orderfolioItems.forEach(function (decomposeItem) {
                    if (Utilities.IsNotDefined(entity.AllowedActions)) {
                        if (decomposeItem.Action === OrderActions.Delete || decomposeItem.Action === OrderActions.Reassign) {
                            return;
                        }
                        entityCount++;
                        return;
                    }
                    entity.AllowedActions.forEach(function (action) {
                        if (action === decomposeItem.Action) {
                            entityCount++;
                        }
                    });
                });
            });
            chargeOrCost.UnitQuantity = entityCount;
        }
    };
    /**
     * Adds rate attributes present in the spec that were not passed in on the request, where a rate could be unambiguously determined
     * @param {CsTypes.OrderfolioItem} charge The orderfolio item charge that rate attributes will be added to
     * @param {CsTypes.Dictionary<Array<string>>} applicableRateAttributes The rate attributes from the rate which was applied to this charge
     */
    PricingUtilities.PopulateMissingRateAttributes = function (chargeOrCost, applicableRateAttributes) {
        var existingRateAttributes = chargeOrCost.RatingAttributes;
        Object.keys(applicableRateAttributes).forEach(function (rateAttributeKey) {
            // Get all the values from the specification matching the rate attribute key
            var applicableRateAttributeValues = applicableRateAttributes[rateAttributeKey];
            // Add any missing rate attributes to the charge
            applicableRateAttributeValues.forEach(function (rateAttributeValue) {
                var existingRateAttributeValue = existingRateAttributes.find(function (rateAttribute) {
                    return rateAttribute.Name === rateAttributeKey && rateAttribute.Value === rateAttributeValue;
                });
                if (existingRateAttributeValue === undefined) {
                    console.log(rateAttributeKey + ", " + rateAttributeValue);
                    var rateAttributeToAdd = {
                        Name: rateAttributeKey,
                        Value: rateAttributeValue,
                        Action: MergedActions.AddMissing,
                        OrderItemSource: undefined,
                        PortfolioItemSource: undefined
                    };
                    chargeOrCost.RatingAttributes.push(rateAttributeToAdd);
                }
                else {
                    // If the rate attribute was deleted by the calling service, but is valid for the rate, correct to AddExisting
                    if (existingRateAttributeValue.Action === MergedActions.DeleteExisting || existingRateAttributeValue.Action === MergedActions.DeleteMissing) {
                        existingRateAttributeValue.Action = MergedActions.AddExisting;
                    }
                }
            });
        });
    };
    /**
     * Provides a calculated total value for unit based rates
     * @param {number} unitQuantity the quantity to use to calculate the unit based rate total
     * @param {CsTypes.RateInfo} applicableRate the unit based rate to compare the quantity to
     */
    PricingUtilities.CalculateUnitBasedRateValue = function (unitQuantity, applicableRate) {
        switch (applicableRate.RateType) {
            case RateTypes.Threshold:
                return PricingUtilities.CalculateThresholdRateTotal(unitQuantity, applicableRate.UnitPricingRates, applicableRate.PerUnit);
            case RateTypes.Tiered:
                return PricingUtilities.CalculateTieredRateTotal(unitQuantity, applicableRate.UnitPricingRates, applicableRate.PerUnit);
            default:
                // Shouldn't need a validation error here, as we should never get here unless the compiled spec has errors
                return 0;
        }
    };
    /**
     * Provides a calculated total value for threshold rates
     * @param {number} unitQuantity the quantity to use to calculate the threshold band used
     * @param {CsTypes.UnitRate[]} thresholdBands the threshold rate bands to compare the quantity to
     * @param {boolean} pricePerUnit
     */
    PricingUtilities.CalculateThresholdRateTotal = function (unitQuantity, thresholdBands, pricePerUnit) {
        var thresholdTotal;
        var orderedThresholdBands = thresholdBands.sort(function (a, b) { return a.Threshold - b.Threshold; });
        // If we have 0 unitQty and we're not pricing per unit, shortcut to return the value of the first threshold
        if (unitQuantity === 0 && !pricePerUnit && orderedThresholdBands.length > 0) {
            thresholdTotal = new decimal(orderedThresholdBands[0].Value);
            return thresholdTotal.toFloat();
        }
        var thresholdToUse = undefined;
        // We will use only one threshold band - the band with the highest threshold which is not exceeded by the unit quantity
        for (var thresholdIndex = 0; thresholdIndex < thresholdBands.length; thresholdIndex++) {
            var currentThreshold = orderedThresholdBands[thresholdIndex];
            if (currentThreshold.Threshold > unitQuantity) {
                break;
            }
            thresholdToUse = currentThreshold;
        }
        // If we couldn't find a threshold value to apply, return unpriced
        // TODO: should this validate or become an ignored charge?
        if (Utilities.IsNotDefined(thresholdToUse)) {
            return 0;
        }
        // Convert numbers to decimal before calculating to preserve precision
        var quantity = new decimal(unitQuantity);
        var thresholdRate = new decimal(thresholdToUse.Value);
        // Now we have the band we should use, simply multiply the unit quantity by the rate provided on the threshold band
        if (pricePerUnit) {
            thresholdTotal = quantity.mul(thresholdRate);
        }
        else {
            thresholdTotal = thresholdRate;
        }
        return thresholdTotal.toFloat();
    };
    /**
     * @param {number} unitQty the quantity to use to calculate the tiered bands used
     * @param {CsTypes.UnitRate[]} tieredBands the tiered rate bands to compare the quantity to
     * @param {boolean} pricePerUnit
     */
    PricingUtilities.CalculateTieredRateTotal = function (unitQty, tieredBands, pricePerUnit) {
        var total = new decimal(0);
        //Sort the bands by threshold from lowest to highest
        var orderedTierBands = tieredBands.sort(function (a, b) { return a.Threshold - b.Threshold; });
        //highest threshold will not have a "Threshold" value as there is no upperlimit
        //Find this threshold
        var unboundedBand = LodashUtilities.Find(orderedTierBands, function (x) {
            return Utilities.IsNotDefined(x.Threshold);
        });
        //Splice at the index of the highest threshold and then push it onto the end of the array
        //2nd parameter how many units to splice, so 1 in this case
        var openTierBand = orderedTierBands.splice(orderedTierBands.indexOf(unboundedBand), 1)[0];
        orderedTierBands.push(openTierBand);
        // If we have 0 unitQty and we're not pricing per unit, shortcut to return the value of the first tier
        if (unitQty === 0 && !pricePerUnit && orderedTierBands.length > 0) {
            total = new decimal(orderedTierBands[0].Value);
            return total.toFloat();
        }
        var unitsAccountedFor = 0;
        // For each band, we need to keep track of how many units have been priced, how many units may be included in the current band,
        // and a running total of the rate and quantity of units priced thus far
        for (var tierIndex = 0; tierIndex < orderedTierBands.length; tierIndex++) {
            // If we have accounted for as many units as required, stop pricing
            if (unitsAccountedFor === unitQty) {
                break;
            }
            var currentTier = orderedTierBands[tierIndex];
            // The maximum number of units this band is responsible for pricing
            var maximumBandQty = void 0;
            var unitsUnaccountedFor = unitQty - unitsAccountedFor;
            if (currentTier.Threshold === undefined) {
                //If .Threshold is undefined then the current tier is the top threshold
                //so this threshold will deal with all remaining units
                maximumBandQty = unitsUnaccountedFor;
            }
            else {
                //If not in the top threshold
                //calculate different between the .Threshoold and the current unitsAccountedFor
                maximumBandQty = currentTier.Threshold - unitsAccountedFor;
            }
            //this tier will now either deal with all remaining units
            //or exactly enough units so that UnitsAccountedFor == currentTier.Threshold
            var bandQuantity = new decimal(Math.min(maximumBandQty, unitsUnaccountedFor));
            var tierRate = new decimal(currentTier.Value);
            var tierTotal = void 0;
            if (pricePerUnit) {
                tierTotal = tierRate.mul(bandQuantity);
            }
            else {
                tierTotal = tierRate;
            }
            total = total.add(tierTotal);
            // Increment the units we have accounted for, using the number of units this band priced
            unitsAccountedFor += bandQuantity.toFloat();
        }
        return total.toFloat();
    };
    /**
     * Given a set of instances of an entity link in a decompose context, returns the instances which have the given item instance as either a source or a target
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.EntityLink} targetEntityLink the entity link whose instances will be checked
     * @param {CsTypes.OrderfolioItem} orderfolioItem the item to filter by
     * @param {CsTypes.EntityLinkSourceTargetDescendents[]} linkedEntitiesToOrderfolioItem the filtered collection of entity link instances
     */
    PricingUtilities.FilterEntityLinkInstances = function (decomposeContext, targetEntityLink, orderfolioItem, linkedEntitiesToOrderfolioItem) {
        // For each instance of the entity link, get sources and targets and their descendents.
        OrderfolioLinkedEntityQueries.GetByEntityLink(decomposeContext.LinkedEntities, targetEntityLink).forEach(function (entityLink) {
            var sourceTargetDescendentsForLinkInstance = OrderfolioLinkedEntityQueries.GetLinkedOrderfolioItemCollection(entityLink, decomposeContext);
            if (sourceTargetDescendentsForLinkInstance.TargetDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(orderfolioItem.CompoundKey)) > -1 ||
                sourceTargetDescendentsForLinkInstance.SourceDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(orderfolioItem.CompoundKey)) > -1) {
                // If the item is contained within either the source or target descendents of the entity link instance, return the instance
                linkedEntitiesToOrderfolioItem.push(sourceTargetDescendentsForLinkInstance);
            }
        });
    };
    /**
     * Creates a set of EntityLinkSourceTargetDescendents for an implied link between orderfolio items and a common parent
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.ImpliedLink} impliedLink the implied link to build descendents for
     * @param {CsTypes.OrderfolioItem} orderfolioItem the item to filter by
     * @param {CsTypes.EntityLinkSourceTargetDescendents[]} linkedEntitiesToOrderfolioItem the filtered collection of entity link instances
     */
    PricingUtilities.RetrieveInstancesByImpliedLink = function (decomposeContext, impliedLink, orderfolioItem, linkedEntitiesToOrderfolioItem) {
        // retrieve the uuid of the targeted item and the common parent
        var uuid = orderfolioItem.CompoundKey.Key === impliedLink.Target ? impliedLink.Source : impliedLink.Target;
        var commonParent = OrderfolioQueries.FindParentForChild(impliedLink.CommonParent, orderfolioItem.CompoundKey, decomposeContext);
        // fetch all entities by uuid
        var orderfolioItems = decomposeContext.Orderfolio[uuid.toString()];
        if (Utilities.IsNotDefined(orderfolioItems)) {
            return;
        }
        // filter matching items to only use those which share a common parent
        var validItems = orderfolioItems.filter(function (item) {
            var itemParent = OrderfolioQueries.FindParentForChild(impliedLink.CommonParent, item.CompoundKey, decomposeContext);
            return itemParent.Key === commonParent.Key && itemParent.Index === commonParent.Index;
        });
        if (validItems.length < 1) {
            return;
        }
        // Utilise the SourceToTargetEntityLink structure so implied links and entity links can be handled by a common code pathway
        var sourceToTargetEntityLinks = [];
        validItems.forEach(function (item) {
            sourceToTargetEntityLinks.push({
                LinkTypeID: undefined,
                PortfolioItemID: undefined,
                EntityLinkAction: undefined,
                Source: orderfolioItem.CompoundKey,
                Target: item.CompoundKey,
                ExpectedSource: orderfolioItem.CompoundKey.Key,
                ExpectedTarget: item.CompoundKey.Key,
                LinkAction: undefined,
                IsMulti: false,
                IsUnique: false,
                TargetIsDependent: false,
                IsInvalid: false,
                OrderEntityLinkItemSource: undefined,
                PortfolioEntityLinkItemSource: undefined,
                OrderLinkItemSource: undefined,
                PortfolioLinkItemSource: undefined
            });
        });
        // For each instance of the entity link, get sources and targets and their descendents (for implied links, there shouldn't be any descendents)
        sourceToTargetEntityLinks.forEach(function (entityLink) {
            var sourceTargetDescendentsForLinkInstance = OrderfolioLinkedEntityQueries.GetLinkedOrderfolioItemCollection(entityLink, decomposeContext);
            linkedEntitiesToOrderfolioItem.push(sourceTargetDescendentsForLinkInstance);
        });
    };
    /**
     * Validates a rate detail and builds a result highlighting any validation issues and returns the detail results in a shared/usable format
     * @param {CsTypes.RateDetail} rateDetail
     * @returns {CsTypes.ValidatedRateDetail}
     */
    PricingUtilities.ValidateRateDetail = function (rateDetail) {
        var result = {
            IsUsableRateDetail: true,
            HasValidRateActivationDate: true,
            RateActivationDate: undefined,
            HasValidRateOverride: false,
            RateIdOverride: undefined,
            ValueOverride: undefined
        };
        // if undefined return true, there is no override
        if (Utilities.IsNotDefined(rateDetail)
            || (Utilities.IsNotDefined(rateDetail.RateActivationDate)
                && Utilities.IsNotDefined(rateDetail.RateIdOverride)
                && Utilities.IsNotDefined(rateDetail.ValueOverride))) {
            result.IsUsableRateDetail = false;
            return result;
        }
        // In the following checks, it is valid for a rate activation date to be undefined, but not valid for
        // a rate Id override to be undefined. This is because, if the rateDetail object is defined, then something
        // inside it must be defined for it to be usable, and as we check rate activation date first, we can accept
        // it is not invalid for it to be unset - if it were not valid, we would use this flag to raise an error.
        // Check the date is valid
        if (Utilities.IsDefined(rateDetail.RateActivationDate)) {
            if (!Utilities.IsValidDate(rateDetail.RateActivationDate)) {
                result.HasValidRateActivationDate = false;
                return result;
            }
            // Set the date
            result.RateActivationDate = rateDetail.RateActivationDate;
        }
        // Check the rate id override is valid
        if (Utilities.IsNotDefined(rateDetail.RateIdOverride)
            || Utilities.IsNotDefined(rateDetail.ValueOverride)
            || !Utilities.IsNumeric(rateDetail.ValueOverride)) {
            result.HasValidRateOverride = false;
            return result;
        }
        else {
            result.HasValidRateOverride = true;
            result.RateIdOverride = rateDetail.RateIdOverride;
            result.ValueOverride = rateDetail.ValueOverride;
            return result;
        }
    };
    return PricingUtilities;
}());
module.exports = PricingUtilities;

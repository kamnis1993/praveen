"use strict";
/// <reference path="../../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
var ChargeTypes = require("../../cs-lib-constants/ChargeTypes");
var CostTypes = require("../../cs-lib-constants/CostTypes");
var OrderActions = require("../../cs-lib-constants/OrderActions");
var ChargeOrderActionUtilities = /** @class */ (function () {
    function ChargeOrderActionUtilities() {
    }
    /**
    * Determine whether each charge associated with a CBD needs to have a calulated price in this order
    * @param {any} chargesToDiscount
    * @param {CsTypes.TargetAdjustment} targetAdjustment
    * @return {any[]} filtered chargesToDiscount
    */
    ChargeOrderActionUtilities.CheckChargeOrderStates = function (chargesToDiscount, targetAdjustment) {
        // Remove charges not in a valid state
        var filteredChargesToDiscount = [];
        chargesToDiscount.forEach(function (charge) {
            var validCharge = false;
            // Recurring Charges need to be priced on all Actions except Reassign and Delete
            if (charge.ChargeType === ChargeTypes.RecurringCharge || charge.ChargeType === ChargeTypes.StandaloneRecurringCharge || charge.ChargeType === ChargeTypes.RecurringCostBasedCharge) {
                validCharge = ChargeOrderActionUtilities.DiscountApplicableToRecurring(charge.ChargeAction);
            }
            else {
                // NonRecurring Charges only priced on Add action
                validCharge = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(charge.ChargeAction);
            }
            // CostBasedChages can be noChange but have a Cost they target be Add, meaning the CBC has to be repriced
            if (charge.ChargeType === ChargeTypes.NonRecurringCostBasedCharge || charge.ChargeType === ChargeTypes.RecurringCostBasedCharge) {
                // No need to check the costActions if the CBC is already going to be priced
                if (!validCharge) {
                    validCharge = ChargeOrderActionUtilities.DiscountApplicableToCBC(charge.CBCCostActions);
                }
            }
            if (validCharge) {
                // Charge needs to be priced so add to filtered result
                filteredChargesToDiscount.push(charge);
            }
            else {
                // Charge is not in a state where it will be priced so add to UnalteredTargets
                targetAdjustment.UnalteredTargets.push({ ID: charge.ID, Reason: "DiscountNotApplicableToChargeState" });
            }
        });
        return filteredChargesToDiscount;
    };
    /**
     * Checks if the order action of the recurring charge/cost is valid for the discount to be applied
     * @param {string} state
     * @return {boolean}
     */
    ChargeOrderActionUtilities.DiscountApplicableToRecurring = function (state, type) {
        // RecurringCharges are priced in multiple situations
        if (state === OrderActions.Add
            || state === OrderActions.Update
            || state === OrderActions.Reassigned
            || state === OrderActions.ReassignedUpdate
            || state === OrderActions.NoChange) {
            return true;
        }
        else {
            if (type && (type === CostTypes.RecurringCost || type === CostTypes.StandaloneRecurringCost) && state === OrderActions.Delete) {
                return true;
            }
            return false;
        }
    };
    /**
     * Checks if the order action of the nonRecurring charge/cost is valid for the discount to be applied
     * @param {string} chargeState
     * @return {boolean}
     */
    ChargeOrderActionUtilities.DiscountApplicableToNonRecurring = function (state) {
        // NonRecurring Charges are only priced once, when they are added to an order
        if (state === OrderActions.Add) {
            return true;
        }
        else {
            return false;
        }
    };
    /**
     * Checks if the order action of the costs affected by a CBC cause the CBC to be priced
     * @param {any[]} costDetails
     * @return {boolean}
     */
    ChargeOrderActionUtilities.DiscountApplicableToCBC = function (costDetails) {
        var priceCBC = false;
        costDetails.forEach(function (detail) {
            // Once boolean is true it cant go back to false again
            // If one cost is priceable then we have to reprice the CBC
            if (!priceCBC) {
                if (detail.Type === CostTypes.RecurringCost || detail.Type === CostTypes.StandaloneRecurringCost) {
                    priceCBC = ChargeOrderActionUtilities.DiscountApplicableToRecurring(detail.Action, detail.Type);
                }
                else if (detail.Type === CostTypes.NonRecurringCost || detail.Type === CostTypes.StandaloneNonRecurringCost) {
                    priceCBC = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(detail.Action);
                }
            }
        });
        return priceCBC;
    };
    return ChargeOrderActionUtilities;
}());
module.exports = ChargeOrderActionUtilities;

"use strict";
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
var OrderOfExecutionUtilities = /** @class */ (function () {
    function OrderOfExecutionUtilities() {
    }
    /**
     * Iterate over discounts and collect their order of execution values
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {number[]} ordOfExecutionValues
     * @return {number[]}
     */
    OrderOfExecutionUtilities.GatherOrderOfExecValues = function (discountLookups, ordOfExecutionValues) {
        // Store all order of execution values
        Object.keys(discountLookups.DiscountUuidToRateInfo).forEach(function (discountUuid) {
            if (discountLookups.DiscountUuidToRateInfo[discountUuid][0] === undefined) {
                return;
            }
            if (discountLookups.DiscountUuidToRateInfo[discountUuid][0].OrderOfExecution) {
                ordOfExecutionValues.push(discountLookups.DiscountUuidToRateInfo[discountUuid][0].OrderOfExecution);
            }
        });
        if (ordOfExecutionValues) {
            // Values may be out of order
            ordOfExecutionValues.sort();
            // Remove any duplicates to prevent discounts being run multiple times
            for (var x = 0; x < ordOfExecutionValues.length; x++) {
                for (var y = 0; y < ordOfExecutionValues.length; y++) {
                    if (y !== x) {
                        if (ordOfExecutionValues[x] === ordOfExecutionValues[y]) {
                            ordOfExecutionValues.splice(x, 1);
                        }
                    }
                }
            }
        }
        return ordOfExecutionValues;
    };
    /**
     * Gather array of all adjustment types at the given ordOfExecution value
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {number[]} ordOfExecutionValues
     * @param {number} iterator
     * @return {string[]}
     */
    OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution = function (discountLookups, ordOfExecutionValues, iterator) {
        var counter = 0;
        var adjustmentTypes = [];
        // How many discounts have a given OrdOfExecutionValue e.g. 1
        Object.keys(discountLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
            if (discountLookups.DiscountUuidToRateInfo[discountUuid][0] === undefined) {
                return;
            }
            if (discountLookups.DiscountUuidToRateInfo[discountUuid][0].OrderOfExecution === ordOfExecutionValues[iterator]) {
                counter++;
            }
        });
        // If more than one adjustment to run at this level
        // Gather their adjustment types and discount targets
        if (counter > 1) {
            Object.keys(discountLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
                if (discountLookups.DiscountUuidToRateInfo[discountUuid][0] === undefined) {
                    return;
                }
                if (Utilities.IsNotDefined(discountLookups.DiscountUuidToRateInfo[discountUuid][0].ChargeAdjustments, true)) {
                    return;
                }
                if (Utilities.IsNotDefined(discountLookups.DiscountUuidToRateInfo[discountUuid][0].TargetedCharges, true)) {
                    return;
                }
                discountLookups.DiscountUuidToRateInfo[discountUuid][0].ChargeAdjustments.forEach(function (adjustment) {
                    if (adjustment.AdjustmentType) {
                        discountLookups.DiscountUuidToRateInfo[discountUuid][0].TargetedCharges.forEach(function (target) {
                            adjustmentTypes.push({ Target: target.ChargeUuid, AdjustmentType: adjustment.AdjustmentType });
                        });
                    }
                });
            });
        }
        return adjustmentTypes;
    };
    /**
     * Check if the given adjustments contain multiple adjustment types (flat, percentage, absolute)
     * @param {string[]} listOfAdjustments
     * @return {boolean}
     */
    OrderOfExecutionUtilities.MultipleAdjustmentTypes = function (listOfAdjustments) {
        var multipleTypes = false;
        if (Utilities.IsNotDefined(listOfAdjustments, true)) {
            return multipleTypes;
        }
        var groupedAdjustments = LodashUtilities.GroupByCallback(listOfAdjustments, function (adj) {
            return adj.Target;
        });
        // Multiple Absolute adjustments cannot be applied together as this will result in an ambiguous calculation
        // The name of MultipleTypes is a little misleading in this instance
        // As there may just be multiple Absolute adjustments
        Object.keys(groupedAdjustments).some(function (key) {
            var adjustmentsForTarget = LodashUtilities.Pluck(groupedAdjustments[key], "AdjustmentType");
            var uniqueAdjustmentsForTarget = LodashUtilities.Uniq(adjustmentsForTarget);
            var absoluteFound = LodashUtilities.Contains(adjustmentsForTarget, "Absolute");
            if (absoluteFound) {
                multipleTypes = true;
            }
            if (uniqueAdjustmentsForTarget.length > 1) {
                multipleTypes = true;
            }
            return multipleTypes;
        });
        return multipleTypes;
    };
    /**
     * Check all adjustments at higher OrderOfExecution and search for an Absolute adjustment
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {number[]} ordOfExecutionValues
     * @param {number} iterator
     * @return {boolean}
     */
    OrderOfExecutionUtilities.HigherAbsoluteExists = function (discountLookups, ordOfExecutionValues, iterator, absoluteDiscounts) {
        var higherAbsoluteExists = false;
        Object.keys(discountLookups.DiscountUuidToRateInfo).forEach(function (discountUuid) {
            if (discountLookups.DiscountUuidToRateInfo[discountUuid][0].OrderOfExecution > ordOfExecutionValues[iterator]) {
                discountLookups.DiscountUuidToRateInfo[discountUuid][0].ChargeAdjustments.forEach(function (adjustment) {
                    if (adjustment.AdjustmentType === "Absolute") {
                        absoluteDiscounts.push(discountUuid);
                        higherAbsoluteExists = true;
                    }
                });
            }
        });
        return higherAbsoluteExists;
    };
    /**
     * Determine if multiple adjustment types are present at a single order of execution
     * @param {boolean} exclusiveDiscountPresent
     * @param {CsTypes.DiscountLookups} newLookups
     * @param {boolean} multipleAdjustmentsAtSameOrdOfExec
     * @param {number[]} ordOfExecutionValues
     * @param {number} i
     */
    OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent = function (exclusiveDiscountPresent, newLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i) {
        if (exclusiveDiscountPresent) {
            // create lookups copy to store exclusive rates
            var exclusiveLookups_1 = LodashUtilities.CloneDeep(newLookups);
            // Perform calculations for exclusive discounts only
            // So remove any discount that is not exclusive
            Object.keys(newLookups.DiscountUuidToRateInfo).forEach(function (discountUuid) {
                if (newLookups.DiscountUuidToRateInfo[discountUuid][0].IsExclusive.toString() !== "true") {
                    delete exclusiveLookups_1.DiscountUuidToDiscountInfo[discountUuid];
                    delete exclusiveLookups_1.DiscountUuidToRateInfo[discountUuid];
                }
            });
            // Determine what adjustment types were dealing with
            // And if there are multiple of the same type
            var adjustmentTypes = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(exclusiveLookups_1, ordOfExecutionValues, i);
            multipleAdjustmentsAtSameOrdOfExec = OrderOfExecutionUtilities.MultipleAdjustmentTypes(adjustmentTypes);
        }
        else {
            // Gather all adjustmentTypes at this OrdOfExecution value
            // Then check if there are multiple of the same type
            // If there are this will cause an ambiguous calculation to occur
            var adjustmentTypes = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(newLookups, ordOfExecutionValues, i);
            multipleAdjustmentsAtSameOrdOfExec = OrderOfExecutionUtilities.MultipleAdjustmentTypes(adjustmentTypes);
        }
        return multipleAdjustmentsAtSameOrdOfExec;
    };
    /**
     * Find the lowest OrderOfExecution value amongst exclusive discounts
     * @param {CsTypes.DiscountLookups} discountLookups
     */
    OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution = function (discountLookups) {
        var firstExclusiveOrdOfExecValue;
        Object.keys(discountLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
            // Amongst Exclusive discounts, find the lowest order of executions
            // As we will only apply discounts at this OrdOfExec
            var rateInfo = discountLookups.DiscountUuidToRateInfo[discountUuid][0];
            if (rateInfo.IsExclusive.toString() === "true" && (!firstExclusiveOrdOfExecValue || firstExclusiveOrdOfExecValue > rateInfo.OrderOfExecution)) {
                firstExclusiveOrdOfExecValue = rateInfo.OrderOfExecution;
            }
        });
        return firstExclusiveOrdOfExecValue;
    };
    return OrderOfExecutionUtilities;
}());
module.exports = OrderOfExecutionUtilities;

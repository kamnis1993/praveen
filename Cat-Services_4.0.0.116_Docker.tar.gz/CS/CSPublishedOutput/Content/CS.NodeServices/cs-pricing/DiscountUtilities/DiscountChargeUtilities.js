"use strict";
/// <reference path="../../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
var ChargeOrderActionUtilities = require("./ChargeOrderActionUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
/**
* Class provides methods for filtering, sorting and finding charges for discounts
*/
var DiscountChargeUtilities = /** @class */ (function () {
    function DiscountChargeUtilities() {
    }
    /**
     * Sort the charges, based on the adjustment settings
     * @param {any} chargesToDiscount
     * @param {CsTypes.AdjustmentInfo} adjustment
     */
    DiscountChargeUtilities.ApplyAdjustmentSorting = function (chargesToDiscount, adjustment) {
        // Note. If adjustment.MostExpensiveFirst is undefined, no sort will be applied.
        // Any previous sort applied to the chargesToDiscount will still apply.
        // If the user has not specified a sort order, we cannot guarantee which charges will be discounted!  This is by design.
        if (Utilities.IsDefined(adjustment.MostExpensiveFirst)) {
            if (Utilities.ParseAsBoolean(adjustment.MostExpensiveFirst, false)) {
                // Sort by Most Expensive first
                chargesToDiscount.sort(function (chargeA, chargeB) {
                    return chargeB.RateValue - chargeA.RateValue;
                });
            }
            else {
                // Sort by Least Expensive first
                chargesToDiscount.sort(function (chargeA, chargeB) {
                    return chargeA.RateValue - chargeB.RateValue;
                });
            }
        }
        return chargesToDiscount;
    };
    /**
     * Filter the charges, removing any charges where the rate cannot be determined
     * @param {any} chargesToDiscount
     * @param {InterimRate[]} interimRates
     * @param {CsTypes.TargetAdjustment} targetAdjustment the target adjustment to update
     */
    DiscountChargeUtilities.RemoveAmbiguousCharges = function (chargesToDiscount, interimRates, targetAdjustment) {
        var filteredTargets = [];
        chargesToDiscount.forEach(function (charge) {
            // Get the interim rate for the current charge
            var interimRate = DiscountChargeUtilities.GetRateForCharge(interimRates, charge);
            if (Utilities.IsNotDefined(interimRate)) {
                // Could not determine a rate for the current charge
                targetAdjustment.UnalteredTargets.push({ ID: charge.ID, Reason: "AmbiguousChargeRate" });
            }
            else {
                filteredTargets.push(charge);
            }
        });
        return filteredTargets;
    };
    /**
     * Filter the charges, based on the adjustment settings
     * @param {any} chargesToDiscount
     * @param {CsTypes.AdjustmentInfo} adjustment
     * @param {CsTypes.TargetAdjustment} targetAdjustment the target adjustment to update
     */
    DiscountChargeUtilities.FilterByMaximumTargets = function (chargesToDiscount, adjustment, targetAdjustment) {
        if (Utilities.IsNotDefined(adjustment.MaxTargets)) {
            return chargesToDiscount;
        }
        var filteredTargets = [];
        // Only discount the maximum number of targetted charges as defined on the discount adjustment
        chargesToDiscount.forEach(function (charge) {
            if (filteredTargets.length < adjustment.MaxTargets) {
                filteredTargets.push(charge);
            }
            else {
                // Add all other charges as unaltered targets
                targetAdjustment.UnalteredTargets.push({ ID: charge.ID, Reason: "Filtered" });
            }
        });
        return filteredTargets;
    };
    /**
     * Filter the charges, based on the adjustment settings
     * @param {any} chargesToDiscount
     * @param {CsTypes.AdjustmentInfo} adjustment
     * @param {CsTypes.TargetAdjustment} targetAdjustment the target adjustment to update
     */
    DiscountChargeUtilities.FilterByMinimumTargets = function (chargesToDiscount, adjustment, targetAdjustment) {
        if (Utilities.IsNotDefined(adjustment.MinTargetsRequired)) {
            return chargesToDiscount;
        }
        // Count how many charges are being targeted
        var chargeCounter = 0;
        chargesToDiscount.forEach(function (charge) {
            chargeCounter++;
        });
        // Check if there are enough targets
        if (chargeCounter < adjustment.MinTargetsRequired) {
            chargesToDiscount.forEach(function (charge) {
                // Add all charges as unaltered targets
                targetAdjustment.UnalteredTargets.push({ ID: charge.ID, Reason: "Filtered" });
            });
            chargesToDiscount = [];
        }
        return chargesToDiscount;
    };
    /**
     * Return the rate applicable to a specific charge
     * @param {InterimRate[]} interimRates
     * @param {any} charge
     */
    DiscountChargeUtilities.GetRateForCharge = function (interimRates, charge) {
        var result = interimRates.filter(function (rate) {
            return rate.OrderfolioKey === charge.OrderfolioKey;
        });
        if (Utilities.IsDefined(result) && result.length > 0) {
            // Only return the first rate
            return result[0];
        }
        return undefined;
    };
    /**
     * Only return charges appropriate for the given adjustment
     * @param {any} chargesToDiscount
     * @param {CsTypes.AdjustmentInfo} adjustment
     */
    DiscountChargeUtilities.GetChargesForAdjustment = function (chargesToDiscount, adjustment) {
        var adjustmentCharges = [];
        // ChargeLinkID and AdjustmentGuid link the adjustment and charge
        chargesToDiscount.forEach(function (charge) {
            if (charge.ChargeLinkID === adjustment.AdjustmentGuid) {
                adjustmentCharges.push(charge);
            }
        });
        return adjustmentCharges;
    };
    /**
     * Applies filters to charges targeted by a discount
     * @param   {any} chargesToDiscount the charges targeted by the discount
     * @param   {CsTypes.AdjustmentInfo} adjustment the adjustment being applied to the charge from the specification
     * @param   {CsTypes.TargetAdjustment} targetAdjustment the discount adjustment details
     * @param   {InterimRate[]} interimRates the collection of interim rates which contain charge rate values
     */
    DiscountChargeUtilities.ApplyChargeFilters = function (chargesToDiscount, adjustment, targetAdjustment, interimRates) {
        // The order of these matters, do not change them without investigating the consequences!
        chargesToDiscount = ChargeOrderActionUtilities.CheckChargeOrderStates(chargesToDiscount, targetAdjustment);
        // Will remove any charges with missing rate attributes
        // Test 7.5 for example
        chargesToDiscount = DiscountChargeUtilities.RemoveAmbiguousCharges(chargesToDiscount, interimRates, targetAdjustment);
        chargesToDiscount = DiscountChargeUtilities.FilterByMinimumTargets(chargesToDiscount, adjustment, targetAdjustment);
        chargesToDiscount = DiscountChargeUtilities.ApplyAdjustmentSorting(chargesToDiscount, adjustment);
        chargesToDiscount = DiscountChargeUtilities.FilterByMaximumTargets(chargesToDiscount, adjustment, targetAdjustment);
        return chargesToDiscount;
    };
    return DiscountChargeUtilities;
}());
module.exports = DiscountChargeUtilities;

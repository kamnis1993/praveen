"use strict";
var decimal = require("jsdecimal");
var Logger = require("../../cs-logging/Logger");
var PricingUtilities = require("../PricingUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
var DiscountSetupUtilities = /** @class */ (function () {
    function DiscountSetupUtilities() {
    }
    /**
     * RecurringCharges by default do not contain AdjustmentTotal and OriginalTotal fields, so add them
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @return {void}
     */
    DiscountSetupUtilities.AddAdjustAndOrigTotalsToRecurring = function (interimSummary, interimRootItemSummary) {
        interimSummary.RecurringCharges.forEach(function (period) {
            period.AdjustmentTotal = new decimal(0);
            period.OriginalTotal = new decimal(0);
        });
        interimRootItemSummary.RecurringCharges.forEach(function (period) {
            period.AdjustmentTotal = new decimal(0);
            period.OriginalTotal = new decimal(0);
        });
    };
    /**
     * Build object to contain orginalTotals values for interimSummary and interimRootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @param {number[]} ordOfExecutionValues
     * @return {object}
     */
    DiscountSetupUtilities.BuildOriginalValuesObject = function (interimSummary, interimRootItemSummary) {
        var originalNRTotal = new decimal(interimSummary.NonRecurringCharges.MinimumTotal);
        var originalNRRootItemTotal = new decimal(interimRootItemSummary.NonRecurringCharges.MinimumTotal);
        var recurringOriginalTotals = [];
        var recurringOriginalRootItemTotals = [];
        for (var x = 0; x < interimSummary.RecurringCharges.length; x++) {
            recurringOriginalTotals[x] = new decimal(interimSummary.RecurringCharges[x].MinimumTotal);
        }
        for (var x = 0; x < interimRootItemSummary.RecurringCharges.length; x++) {
            recurringOriginalRootItemTotals[x] = new decimal(interimRootItemSummary.RecurringCharges[x].MinimumTotal);
        }
        var originalValues = { NonRecurring: {}, Recurring: {} };
        originalValues.NonRecurring = {
            OriginalTotal: originalNRTotal,
            OriginalRootItemTotal: originalNRRootItemTotal
        };
        originalValues.Recurring = {
            OriginalTotal: recurringOriginalTotals,
            OriginalRootItemTotal: recurringOriginalRootItemTotals
        };
        return originalValues;
    };
    /**
     * Gather the Uuid of every discount in the lookups
     * @param {any[]} discountIDs
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {CsTypes.DecomposeContext} decomposeContext
     */
    DiscountSetupUtilities.GatherDiscountUuids = function (discountIDs, discountLookups, orderfolio) {
        // Check if the Uuid in the lookups exists in the orderfolio
        Object.keys(discountLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
            // Check that the discount is actually present in the orderfolio
            if (Utilities.IsNotDefined(orderfolio[discountUuid])) {
                var discountGuid = discountLookups.DiscountUuidToDiscountInfo[discountUuid].DiscountGuid;
                Logger.debug(0, "Pricing", "Discount " + discountGuid + " at Uuid " + discountUuid + " not found in orderfolio", { Type: "Pricing", SubType: "Discounts" });
                return;
            }
            // Add the discount Uuid to the gathered IDs
            discountIDs.push(orderfolio[discountUuid][0].CompoundKey.Key);
        });
        return discountIDs;
    };
    /**
     * Delete any Discount from the Lookups if it is not present in the orderfolio
     * @param {CsTypes.DiscountLookups} newLookups
     * @param {any[]} discountIDs
     */
    DiscountSetupUtilities.RemoveMissingOrderfolioDiscounts = function (newLookups, discountIDs) {
        Object.keys(newLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
            var cannotFind = true;
            for (var i = 0; i < discountIDs.length; i++) {
                if (discountUuid === discountIDs[i]) {
                    cannotFind = false;
                }
            }
            if (cannotFind) {
                delete newLookups.DiscountUuidToDiscountInfo[discountUuid];
                delete newLookups.DiscountUuidToRateInfo[discountUuid];
            }
        });
        return newLookups;
    };
    /**
     * Reduce all discounts in the orderfolio down to a single rate
     * @param {CsTypes.DiscountLookups} newLookups
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     */
    DiscountSetupUtilities.ConsolidateOrderfolioRates = function (newLookups, decomposeContext) {
        Object.keys(newLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
            var discountRates = newLookups.DiscountUuidToRateInfo[discountUuid];
            var discountInfo = newLookups.DiscountUuidToDiscountInfo[discountUuid];
            var orderfolioDiscounts = decomposeContext.Orderfolio[discountUuid];
            orderfolioDiscounts.forEach(function (discount) {
                var filteredDiscountRates = (PricingUtilities.FilterRates(decomposeContext.ActivationDate, discountRates, discount.RatingAttributes, discountInfo.ExclusiveRateAttributeValues));
                if (Utilities.IsNotDefined(filteredDiscountRates, true) || (filteredDiscountRates.length !== 1)) {
                    return;
                }
                newLookups.DiscountUuidToRateInfo[discountUuid] = filteredDiscountRates;
            });
        });
        return newLookups;
    };
    return DiscountSetupUtilities;
}());
module.exports = DiscountSetupUtilities;

"use strict";
var Utilities = require("../../cs-lib-utilities/Utilities");
var IsExclusiveUtilities = /** @class */ (function () {
    function IsExclusiveUtilities() {
    }
    /**
     * Check if any of the discounts are marked as exclusive
     * @param {CsTypes.DiscountLookups} discountLookups
     * @return {boolean}
     */
    IsExclusiveUtilities.ContainsExclusiveDiscount = function (discountLookups) {
        var containsExclusiveDiscount = false;
        if (discountLookups) {
            Object.keys(discountLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
                var currentRates = discountLookups.DiscountUuidToRateInfo[discountUuid][0];
                if (Utilities.IsDefined(currentRates)) {
                    if (currentRates.IsExclusive.toString() === "true") {
                        containsExclusiveDiscount = true;
                    }
                }
            });
        }
        return containsExclusiveDiscount;
    };
    /**
     * Check if the Absolute adjustments are not exclusive, in the event we have at least one exclusive discount
     * @param {CsTypes.DiscountLookups} newLookups
     * @param {number[]} absoluteDiscounts
     * @param {any} discountUuid
     * @param {boolean} higherAbsoluteExists
     */
    IsExclusiveUtilities.CheckIfAbsoluteIsExclusive = function (newLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists) {
        for (var x = 0; x < absoluteDiscounts.length; x++) {
            if (newLookups.DiscountUuidToRateInfo[absoluteDiscounts[x]][0] !== newLookups.DiscountUuidToRateInfo[discountUuid][0]) {
                // If the absolute discount is not exclusive, and the discount being processed is, then we do not need to worry about the discount being overwritten
                if (newLookups.DiscountUuidToRateInfo[discountUuid][0].IsExclusive.toString() === "true" && newLookups.DiscountUuidToRateInfo[absoluteDiscounts[x]][0].IsExclusive.toString() === "false") {
                    higherAbsoluteExists = false;
                }
            }
        }
        return higherAbsoluteExists;
    };
    return IsExclusiveUtilities;
}());
module.exports = IsExclusiveUtilities;

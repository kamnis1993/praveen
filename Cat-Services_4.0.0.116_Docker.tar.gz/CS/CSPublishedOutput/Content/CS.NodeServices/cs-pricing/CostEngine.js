"use strict";
/// <reference path="../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
var decimal = require("jsdecimal");
var CostTypes = require("../cs-lib-constants/CostTypes");
var IgnoredCostParams = require("./InternalPricingTypes/IgnoredCostParams");
var IgnoredReasonTypes = require("../cs-lib-constants/IgnoredReasonTypes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var PricingUtilities = require("./PricingUtilities");
var Utilities = require("../cs-lib-utilities/Utilities");
/** Contains methods for cost functions */
var CostEngine = /** @class */ (function () {
    function CostEngine() {
    }
    /**
     * Appends rates to costs and populates the pricing summary with rate information
     * @param {CsTypes.CostLookups} costLookups compiled spec information about the costs for this request
     * @param {CsTypes.DecomposeContext} decomposeContext the decomposed request to populate with cost rates
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     */
    CostEngine.PopulateCostRates = function (costLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        // logging populate cost rates
        Object.keys(costLookups.CostUuidToCostInfo).forEach(function (costUuid) {
            var costInfo = costLookups.CostUuidToCostInfo[costUuid];
            var costRates = costLookups.CostUuidToRateInfo[costUuid] || [];
            var orderfolioCosts = decomposeContext.Orderfolio[costUuid];
            if (Utilities.IsNotDefined(orderfolioCosts, true)) {
                Logger.debug(10, "Pricing", "Compiled spec cost '" + costInfo.Name + "' either found no match in the orderfolio or had no rates");
                return;
            }
            orderfolioCosts.forEach(function (cost) {
                var ignoredCostParams = new IgnoredCostParams();
                // A reassigned entity should only be priced once; the following prevents the pricing of any pricing entities with the action "reassign"
                if (cost.Action === OrderActions.Reassign) {
                    return;
                }
                Logger.debug(10, "Pricing", "Pricing cost " + cost.EntityUniqueCode);
                // Excluded costs shouldn't be priced
                if (cost.IsExcludedCost) {
                    CostEngine.CreateIgnoredCost(cost, undefined, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    return;
                }
                if (PricingUtilities.IsItemActionInvalidForEntityType(cost.Action, cost.CostType)) {
                    Logger.debug(20, "Pricing", "The item action on the cost is invalid for pricing", { Subtype: "CostAction", CostAction: cost.Action });
                    return;
                }
                // Originally this existed as an earlier check, but this prevented excluded entities from being caught (as they have no rates).
                // It's not recorded as an ignored entity
                if (Utilities.IsNotDefined(costRates, true)) {
                    Logger.debug(20, "Pricing", "Compiled spec charge '" + costInfo.Name + "' either found no match in the orderfolio or had no rates");
                    return;
                }
                // Get rate override details if they exist
                var validatedRateDetail = PricingUtilities.ValidateRateDetail(cost.RateDetail);
                if (validatedRateDetail.IsUsableRateDetail) {
                    // check for a rateActivation date
                    // if its defined but isnt valid then we ignore the charge
                    if (!validatedRateDetail.HasValidRateActivationDate) {
                        ignoredCostParams = new IgnoredCostParams();
                        ignoredCostParams.InvalidRateActivationDate = true;
                        CostEngine.CreateIgnoredCost(cost, undefined, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                        return;
                    }
                    // If we are missing a rate guid, value, or the value is non-numeric, ignore the entity
                    if (Utilities.IsNotDefined(validatedRateDetail.RateActivationDate)
                        && !validatedRateDetail.HasValidRateOverride) {
                        ignoredCostParams = new IgnoredCostParams();
                        ignoredCostParams.RateDetailIncorrectDefinition = true;
                        CostEngine.CreateIgnoredCost(cost, undefined, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                        return;
                    }
                }
                var rateAttributesExist = cost.RatingAttributes.some(function (ra) { return (ra.Action !== MergedActions.DeleteExisting && ra.Action !== MergedActions.DeleteMissing); });
                if (validatedRateDetail.HasValidRateOverride && rateAttributesExist) {
                    ignoredCostParams = new IgnoredCostParams();
                    ignoredCostParams.RateOverrideRateAttributeMismatch = true;
                    CostEngine.CreateIgnoredCost(cost, undefined, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    return;
                }
                var filteredCostRates = PricingUtilities.FilterRates(decomposeContext.ActivationDate, costRates, cost.RatingAttributes, costInfo.ExclusiveRateAttributeValues, validatedRateDetail.RateActivationDate, validatedRateDetail.RateIdOverride);
                if (Utilities.IsNotDefined(filteredCostRates, true) || filteredCostRates.length !== 1) {
                    ignoredCostParams = new IgnoredCostParams();
                    CostEngine.CreateIgnoredCost(cost, filteredCostRates, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    return;
                }
                var unambiguousRate = filteredCostRates[0];
                if (Utilities.IsNotDefined(unambiguousRate, true)) {
                    ignoredCostParams = new IgnoredCostParams();
                    CostEngine.CreateIgnoredCost(cost, filteredCostRates, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    return;
                }
                var isUnitRate = Utilities.IsDefined(unambiguousRate.UnitPricingRates);
                if (isUnitRate) {
                    // If unit quantity is already set we'll fast exit without doing any work in here
                    PricingUtilities.CalculateUnitQuantityFromEntityCountInfo(decomposeContext, unambiguousRate.EntityCountInfo, cost);
                }
                if (isUnitRate && Utilities.IsNotDefined(cost.UnitQuantity)) {
                    ignoredCostParams = new IgnoredCostParams();
                    ignoredCostParams.NoUnitRate = true;
                    CostEngine.CreateIgnoredCost(cost, filteredCostRates, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    return;
                }
                Logger.debug(30, "Pricing", "Calculating cost using rate data", { Subtype: "RateInfo", RateInfo: unambiguousRate, RateDetail: validatedRateDetail });
                var interimCostRate = PricingUtilities.CalculateOrderfolioItemRate(cost, unambiguousRate, undefined, validatedRateDetail.ValueOverride);
                interimRates.push(interimCostRate);
                // We can safely update missing rate attributes here, as there are no points ahead at which we
                // can alter them
                PricingUtilities.PopulateMissingRateAttributes(cost, unambiguousRate.RateAttributes);
                // Unit based rates mean that the rate info from the complied spec needs to be updated with the total calculated value.
                // This covers both simple rates and unit based rates having different ways of representing values in the specification.
                var summaryRate = Object.create(unambiguousRate);
                summaryRate.Value = interimCostRate.Rate.Value;
                CostEngine.UpdateCostSummary(summaryRate, costInfo, interimRootItemSummary);
                CostEngine.UpdateCostSummary(summaryRate, costInfo, interimSummary);
            });
        });
    };
    /**
     * Updates the cost summary with the rate provided
     * @param {CsTypes.RateInfo} rate The rate to add to the cost summary
     * @param {CsTypes.CostInfo} costInfo The object containing the cost information
     * @param {InterimSummary} costSummary The cost summary to update
     */
    CostEngine.UpdateCostSummary = function (rate, costInfo, costSummary) {
        var costValue = new decimal(rate.Value);
        if (costInfo.CostType === CostTypes.RecurringCost || costInfo.CostType === CostTypes.StandaloneRecurringCost) {
            CostEngine.UpdateRecurringCostTotal(costSummary.RecurringCosts, costValue, costInfo.Periodicity);
        }
        else {
            var nonRecurringCosts = costSummary.NonRecurringCosts;
            var finalTotal = nonRecurringCosts.FinalTotal;
            nonRecurringCosts.MinimumTotal = nonRecurringCosts.MinimumTotal.add(costValue);
            nonRecurringCosts.FinalTotal = finalTotal.add(costValue);
        }
    };
    /**
     * Updates the totals for the recurring costs for the specified period
     * @param {PricingInformation[]} recurringCosts The existing recurring costs
     * @param {decimal} costValue The cost value to add
     * @param {string} periodicity The periodicity
     */
    CostEngine.UpdateRecurringCostTotal = function (recurringCosts, costValue, periodicity) {
        var selectedPeriod = LodashUtilities.Find(recurringCosts, function (p) { return p.Name === periodicity; });
        if (Utilities.IsNotDefined(selectedPeriod)) {
            recurringCosts.push({ Name: periodicity, MinimumTotal: costValue, FinalTotal: costValue });
        }
        else {
            selectedPeriod.MinimumTotal = selectedPeriod.MinimumTotal.add(costValue);
            if (selectedPeriod.FinalTotal !== "N/A") {
                var finalTotal = selectedPeriod.FinalTotal;
                selectedPeriod.FinalTotal = finalTotal.add(costValue);
            }
        }
    };
    /**
     * Creates an ignored charge entry in the pricing summary
     * @param {CsTypes.OrderfolioItem} cost the request cost to ignore
     * @param {Array<CsTypes.RateInfo>} filteredCostRates specification cost rates after filtering by date and rate attribute
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.CostInfo} costInfo specification info about the cost
     * @param {IgnoredCostParams} ignoredCostParams the reasons for the cost to be ignored
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     */
    CostEngine.CreateIgnoredCost = function (cost, filteredCostRates, decomposeContext, costInfo, ignoredCostParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        var ignoredCostDetails = CostEngine.CreateIgnoredCostDetails(cost, filteredCostRates, decomposeContext, ignoredCostParams);
        CostEngine.UpdateIgnoredCosts(ignoredCostDetails, grandSummary, costInfo, interimSummary.RecurringCosts);
        CostEngine.UpdateIgnoredCosts(ignoredCostDetails, rootItemSummary.ItemSummary, costInfo, interimRootItemSummary.RecurringCosts);
        Logger.debug(30, "Pricing", "Ignored cost", { Type: "Pricing", Subtype: "ignoredCost", ignoredCost_ID: ignoredCostDetails.ID, IgnoredCost_Reason: ignoredCostDetails.Reason });
        return;
    };
    /**
     * Checks for cases in which the user should be informed that this cost has been ignored
     * @param {CsTypes.OrderfolioItem} cost The cost in the order
     * @param {CsTypes.RateInfo[]} filteredCostRates A filtered set of the rates containing only the applicable rates
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose request to populate with cost rates
     * @param {IgnoredCostParams} params
     * @returns {IIgnoredCost}
     */
    CostEngine.CreateIgnoredCostDetails = function (cost, filteredCostRates, decomposeContext, params) {
        var parentOrderfolioLookup = decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(cost.CompoundKey)];
        var costParent = undefined;
        if (Utilities.IsDefined(parentOrderfolioLookup)) {
            costParent = decomposeContext.Orderfolio[parentOrderfolioLookup.Key.toString()][parentOrderfolioLookup.Index];
        }
        if (cost.IsExcludedCost) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "Excluded", IgnoredReasonTypes.CostExcluded);
        }
        else if (cost.IsInvalid) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "OutdatedCost", IgnoredReasonTypes.ExpiredCost);
        }
        else if (params.RateDetailIncorrectDefinition) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "InvalidRateOverride", IgnoredReasonTypes.InvalidRateOverride);
        }
        else if (params.RateOverrideRateAttributeMismatch) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "InvalidRateOverride", IgnoredReasonTypes.RateAttributeAmbiguity);
        }
        else if (params.NoSpecRate) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "AmbiguousRates", IgnoredReasonTypes.NoRateOnCost);
        }
        else if (params.InvalidRateActivationDate) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "InvalidRateActivationDate", IgnoredReasonTypes.InvalidRateActivationDate);
        }
        else if (Utilities.IsDefined(filteredCostRates) && filteredCostRates.length < 1) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "AmbiguousRates", IgnoredReasonTypes.NoValidRate);
        }
        else if (Utilities.IsDefined(filteredCostRates) && filteredCostRates.length > 1) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "AmbiguousRates", IgnoredReasonTypes.MultipleAmbiguousRates);
        }
        else if (params.NoUnitRate) {
            return CostEngine.CreateIgnoredCostDetail(cost, costParent, "AmbiguousUnitQuantity", IgnoredReasonTypes.AmbiguousUnitQuantity);
        }
        return undefined;
    };
    /**
     * Reasons as to why the ignored costs has occured
     * @param  {CsTypes.OrderfolioItem} cost The cost in the order
     * @param  {CsTypes.OrderfolioItem} costParent The cost parent in the order
     * @param  {string} reason The reason of the ignored cost details
     * @param  {string} reasonDescription The ignored cost reason as to why the ignored cost occured
     * @return IIgnoredCost
     */
    CostEngine.CreateIgnoredCostDetail = function (cost, costParent, reason, reasonDescription) {
        return {
            ID: cost.EntityUniqueCode,
            Reason: reason,
            ReasonDetails: {
                EntityID: cost.EntityId,
                ParentEntityUniqueCode: costParent.EntityUniqueCode,
                ParentEntityID: costParent.EntityId,
                Description: reasonDescription
            }
        };
    };
    /**
     * Updates the ignored costs in a price summary and if it's an ambiguous rate sets the final totals for RC and NRC as not applicable
     * @param {IIgnoredCost} ignoredCost The ignored cost
     * @param {ISummary} grandSummary The grand summary on the pricing summary object
     * @param {CsTypes.CostInfo} costInfo The current cost spec information
     * @param {PricingInformation[]} recurringCosts The array of recurring costs that are being built up
     */
    CostEngine.UpdateIgnoredCosts = function (ignoredCost, itemSummary, costInfo, recurringCosts) {
        itemSummary.IgnoredCosts.push(ignoredCost);
        if (ignoredCost.Reason === "AmbiguousRates") {
            if (costInfo.CostType === CostTypes.NonRecurringCost) {
                itemSummary.NonRecurringCosts.FinalTotal = "N/A";
            }
            else if (costInfo.CostType === CostTypes.RecurringCost) {
                var periodicity_1 = costInfo.Periodicity;
                var ignoredPeriod = LodashUtilities.Find(recurringCosts, function (p) { return p.Name === periodicity_1; });
                if (Utilities.IsNotDefined(ignoredPeriod)) {
                    recurringCosts.push({ Name: periodicity_1, MinimumTotal: new decimal(0), FinalTotal: "N/A" });
                }
                else {
                    ignoredPeriod.FinalTotal = "N/A";
                }
            }
        }
    };
    return CostEngine;
}());
module.exports = CostEngine;

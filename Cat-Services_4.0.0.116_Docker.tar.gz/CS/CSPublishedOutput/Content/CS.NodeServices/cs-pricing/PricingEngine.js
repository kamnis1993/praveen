"use strict";
/// <reference path="../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
var CandidateType = require("../cs-lib-constants/CandidateType");
var ChargeEngine = require("./ChargeEngine");
var CostEngine = require("./CostEngine");
var DiscountEngine = require("./DiscountEngine");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var InterimSummary = require("./InternalPricingTypes/InterimSummary");
var Logger = require("../cs-logging/Logger");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var Period = require("../cs-lib-types/CPQ-BusinessEntities/Pricing/Period");
var PriceSummary = require("../cs-lib-types/CPQ-BusinessEntities/Pricing/PriceSummary");
var RootItemSummary = require("../cs-lib-types/CPQ-BusinessEntities/Pricing/RootItemSummary");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Class that adds rate information to the product candidate
 */
var PricingEngine = /** @class */ (function () {
    /**
     * Creates a new instance of the pricing engine
     * @param   {CsErrorContext} errorContext the error context to use when applying pricing
     */
    function PricingEngine(errorContext) {
        this._errorContext = errorContext;
    }
    /**
     * Builds a pricing object for the given candidate type (applies rates to charges and constructs a pricing summary)
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts The array of decompose contexts
     * @param {string} candidateType The candidate type to build (Order|Product)
     * @param {(result: Pricing) => void)} callback Called when the pricing object has been build passing the built pricing object
     */
    PricingEngine.prototype.BuildPricingObject = function (decomposeContexts, candidateType, callback) {
        var pricing;
        switch (candidateType) {
            case CandidateType.Order:
                pricing = {
                    PriceSummary: new PriceSummary(),
                    ActivationDate: undefined,
                    OrderCandidate: undefined,
                    CustomerPortfolio: undefined
                };
                break;
            case CandidateType.Product:
                pricing = {
                    PriceSummary: new PriceSummary(),
                    CreationDate: undefined,
                    ProductCandidate: undefined
                };
                break;
            default:
                this._errorContext.RaiseCsError(400, ErrorCode.BadData.UnsupportedChargeType);
                return callback(undefined);
        }
        var interimSummary = new InterimSummary();
        this.PopulateRateInformation(pricing.PriceSummary, decomposeContexts, interimSummary);
        callback(pricing);
    };
    /**
     * Populates the rate information into both the grand summary and for each root item summary
     * @param {IPriceSummary} priceSummary The price summary on the response Pricing object
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts The array of decompose contexts
     * @param {InterimSummary} interimSummary The summary of all charges and costs
     */
    PricingEngine.prototype.PopulateRateInformation = function (priceSummary, decomposeContexts, interimSummary) {
        var _this = this;
        var grandSummary = priceSummary.GrandSummary;
        var rootItemSummaries = priceSummary.RootItemSummary;
        // 1. Calculate rates for each cost and charge present in the decompose context, and store in an interim object
        // 2. When a decompose context has all its costs and charges accounted for, add them to a root item summary
        // 3. Calculate final totals in a grand summary
        decomposeContexts.forEach(function (decomposeContext) {
            var compiledSpec = decomposeContext.CompiledSpec;
            var chargeLookups = compiledSpec.ChargeLookups;
            var costLookups = compiledSpec.CostLookups;
            var discountLookups = compiledSpec.DiscountLookups;
            var interimRates = [];
            var applicableLegacyDiscounts = [];
            var rootEntityUniqueCode = OrderfolioQueries.GetRootOrderfolioEntityUniqueCode(decomposeContext.Orderfolio);
            if (Utilities.IsNotDefined(rootEntityUniqueCode)) {
                return;
            }
            Logger.debug(0, "Pricing", "Pricing context with root entity " + rootEntityUniqueCode);
            var rootItemSummary = new RootItemSummary(rootEntityUniqueCode);
            var interimRootItemSummary = new InterimSummary();
            // Create cost info
            CostEngine.PopulateCostRates(costLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            // CRITICAL: Costs must be populated before charges, as cost rates are used to determine values for cost based charges. Do not move charge rate
            // population before cost rates have been determined
            // IN ADDITION: Discounts depends upon Charges so must go after them. Do not move discount rate population before charges!
            // Create charge info
            ChargeEngine.PopulateChargeRates(chargeLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            // Create cost based charge info
            ChargeEngine.PopulateCostBasedChargeRates(chargeLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            // Create charge based discount info
            DiscountEngine.PopulateChargeBasedDiscountRates(discountLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            // Adds any calculated rates to the orderfolio
            _this.UpdateOrderfolioRates(decomposeContext, interimRates);
            // Create a list of Applicable Legacy Discounts and updates them to the order folio.
            DiscountEngine.GetApplicableDiscounts(decomposeContext, applicableLegacyDiscounts);
            _this.UpdateOrderFolioApplicableDiscounts(decomposeContext, applicableLegacyDiscounts);
            // Add cost and charge rates to the pricing summary for this decompose context
            _this.AddCostsAndChargesToPriceSummary(interimRootItemSummary, rootItemSummary.ItemSummary);
            rootItemSummaries.push(rootItemSummary);
        });
        // Once all cost and charge rates are calculated, populate the grand summary for the entire request
        this.AddCostsAndChargesToPriceSummary(interimSummary, grandSummary);
    };
    /**
     * Copies calculated rates from the interim object to the orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context currently being processed
     * @param {Array<InterimRate>} interimRates the collection of interim rates to copy details from
     */
    PricingEngine.prototype.UpdateOrderfolioRates = function (decomposeContext, interimRates) {
        interimRates.forEach(function (interimRate) {
            var costOrCharge = decomposeContext.Orderfolio[interimRate.OrderfolioKey.Key.toString()][interimRate.OrderfolioKey.Index];
            costOrCharge.Rate = interimRate.Rate;
        });
    };
    /**
     * Copy the applicable discounts on to the ApplicableDiscounts field of either the Source or Recipient orderfolio item
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {Array<ApplicableDiscountItem>} applicableLegacyDiscounts
     */
    PricingEngine.prototype.UpdateOrderFolioApplicableDiscounts = function (decomposeContext, applicableLegacyDiscounts) {
        applicableLegacyDiscounts.forEach(function (applicableDiscountItem) {
            applicableDiscountItem.ApplicableDiscounts.forEach(function (applicableDiscounts) {
                var orderfolios = decomposeContext.Orderfolio[applicableDiscounts.FullGuidPathUuid];
                orderfolios.forEach(function (orderfolio) {
                    if (orderfolio.ApplicableDiscounts === undefined) {
                        orderfolio.ApplicableDiscounts = new Array();
                    }
                    orderfolio.ApplicableDiscounts.push(applicableDiscounts);
                });
            });
        });
    };
    /**
     * Adds the local interimSummary (JSDecimal) object numbers into the given itemSummary (or grand summary)
     * @param {InterimSummary} interimSummary The interim summary
     * @param {ISummary} itemSummary The root item or grand summary
     */
    PricingEngine.prototype.AddCostsAndChargesToPriceSummary = function (interimSummary, itemSummary) {
        // First, add non-recurring costs and charges
        // All totals have been calculated, so we just need to convert them to a number
        itemSummary.NonRecurringCharges.MinimumTotal = interimSummary.NonRecurringCharges.MinimumTotal.toFloat();
        itemSummary.NonRecurringCharges.AdjustmentTotal = interimSummary.NonRecurringCharges.AdjustmentTotal.toFloat();
        itemSummary.NonRecurringCharges.OriginalTotal = interimSummary.NonRecurringCharges.OriginalTotal.toFloat();
        itemSummary.NonRecurringCosts.MinimumTotal = interimSummary.NonRecurringCosts.MinimumTotal.toFloat();
        if (itemSummary.NonRecurringCharges.FinalTotal !== "N/A") {
            var finalTotal = interimSummary.NonRecurringCharges.FinalTotal;
            itemSummary.NonRecurringCharges.FinalTotal = finalTotal.toFloat();
        }
        if (itemSummary.NonRecurringCosts.FinalTotal !== "N/A") {
            var finalTotal = interimSummary.NonRecurringCosts.FinalTotal;
            itemSummary.NonRecurringCosts.FinalTotal = finalTotal.toFloat();
        }
        // Next, add recurring cost and charge periods
        // Charge periods
        itemSummary.RecurringCharges.Periods = interimSummary.RecurringCharges.map(function (ci) {
            var finalTotal;
            if (ci.FinalTotal === "N/A") {
                finalTotal = ci.FinalTotal;
            }
            else {
                finalTotal = ci.FinalTotal;
                finalTotal = finalTotal.toFloat();
            }
            return new Period(ci.Name, ci.MinimumTotal.toFloat(), finalTotal, ci.AdjustmentTotal.toFloat(), ci.OriginalTotal.toFloat());
        });
        // Cost periods
        itemSummary.RecurringCosts.Periods = interimSummary.RecurringCosts.map(function (ci) {
            var finalTotal;
            if (ci.FinalTotal === "N/A") {
                finalTotal = ci.FinalTotal;
            }
            else {
                finalTotal = ci.FinalTotal;
                finalTotal = finalTotal.toFloat();
            }
            return new Period(ci.Name, ci.MinimumTotal.toFloat(), finalTotal);
        });
    };
    return PricingEngine;
}());
module.exports = PricingEngine;

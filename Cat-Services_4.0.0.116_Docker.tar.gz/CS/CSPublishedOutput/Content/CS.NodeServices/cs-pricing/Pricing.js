"use strict";
/// <reference types="node" />
///<reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var CandidateType = require("../cs-lib-constants/CandidateType");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var Decompose = require("../cs-decompose/Decompose");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var Logger = require("../cs-logging/Logger");
var PricingEngine = require("./PricingEngine");
var PricingOrderCandidateResponseBuilder = require("../cs-lib-composition/PricingOrderCandidateResponseBuilder");
var PricingProductCandidateResponseBuilder = require("../cs-lib-composition/PricingProductCandidateResponseBuilder");
var PricingResponse = require("../cs-lib-types/CPQ-BusinessEntities/Pricing/PricingResponse");
var Pricing = /** @class */ (function () {
    function Pricing() {
    }
    Pricing.prototype.PriceForProductCandidate = function (request, compiledSpec, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(BoundaryConditionConstants.Commercial, errorContext);
        Logger.debug(0, "Pricing", "Starting Product Candidate Pricing");
        decomposeContextBuilder.BuildFromProductCandidate(request, compiledSpec, function (decomposeContexts) {
            var pricingEngine = new PricingEngine(errorContext);
            pricingEngine.BuildPricingObject(decomposeContexts, CandidateType.Product, function (pricing) {
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                Logger.debug(0, "Pricing", "Building product candidate response", { SubType: "productCandidateResponse" });
                var productCandidateResponseBuilder = new PricingProductCandidateResponseBuilder(errorContext);
                var productCandidateResponse = productCandidateResponseBuilder.Build(decomposeContexts);
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                pricing.ProductCandidate = productCandidateResponse.ProductCandidate;
                pricing.CreationDate = productCandidateResponse.CreationDate;
                var pricingResponse = new PricingResponse();
                pricingResponse.Pricing = pricing;
                if (errorContext.HasBadDataError) {
                    return callback(errorContext.GetBadDataErrorsResponse(), null);
                }
                return callback(null, ConverterUtils.OrderSingularize(pricingResponse)); // Schemas.PricingProductCandidate
            });
        });
    };
    Pricing.prototype.PriceForOrderCandidate = function (request, compiledSpecs, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(BoundaryConditionConstants.Commercial, errorContext);
        Logger.debug(0, "Pricing", "Starting Order Candidate Pricing");
        decomposeContextBuilder.BuildFromOrderCandidateRequest(request, compiledSpecs, function (decomposeContexts) {
            var pricingEngine = new PricingEngine(errorContext);
            pricingEngine.BuildPricingObject(decomposeContexts, CandidateType.Order, function (pricing) {
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                Logger.debug(0, "Pricing", "Building order candidate response", { SubType: "orderCandidateResponse" });
                var orderCandidateResponseBuilder = new PricingOrderCandidateResponseBuilder(errorContext);
                var orderCandidateResponse = orderCandidateResponseBuilder.Build(decomposeContexts);
                pricing.CustomerPortfolio = orderCandidateResponse.CustomerPortfolio;
                pricing.OrderCandidate = orderCandidateResponse.OrderCandidate;
                pricing.ActivationDate = orderCandidateResponse.ActivationDate;
                var pricingResponse = new PricingResponse();
                pricingResponse.Pricing = pricing;
                if (errorContext.HasBadDataError) {
                    return callback(errorContext.GetBadDataErrorsResponse(), null);
                }
                return callback(null, ConverterUtils.OrderSingularize(pricingResponse)); // Schemas.PricingOrderCandidate
            });
        });
    };
    Pricing.prototype.PriceForPartialProductCandidate = function (request, compiledSpec, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(BoundaryConditionConstants.Commercial, errorContext);
        Logger.debug(0, "Pricing", "Starting Partial Product Candidate Pricing");
        decomposeContextBuilder.BuildFromProductCandidate(request, compiledSpec, function (decomposeContexts) {
            new Decompose().PerformDecomposeProcess("ProductCandidate", decomposeContexts, errorContext, function (error, result) {
                if (errorContext.HasBreakingErrors) {
                    return callback(errorContext.ProcessError, null);
                }
                var pricingEngine = new PricingEngine(errorContext);
                pricingEngine.BuildPricingObject(decomposeContexts, CandidateType.Product, function (pricing) {
                    if (errorContext.HasProcessError) {
                        return callback(errorContext.ProcessError, null);
                    }
                    Logger.debug(0, "Pricing", "Building product candidate response", { SubType: "productCandidateResponse" });
                    var productCandidateResponseBuilder = new PricingProductCandidateResponseBuilder(errorContext);
                    var productCandidateResponse = productCandidateResponseBuilder.Build(decomposeContexts);
                    if (errorContext.HasProcessError) {
                        return callback(errorContext.ProcessError, null);
                    }
                    pricing.ProductCandidate = productCandidateResponse.ProductCandidate;
                    pricing.CreationDate = productCandidateResponse.CreationDate;
                    var pricingResponse = new PricingResponse();
                    pricingResponse.Pricing = pricing;
                    if (errorContext.HasBadDataError) {
                        return callback(errorContext.GetBadDataErrorsResponse(), null);
                    }
                    return callback(null, ConverterUtils.OrderSingularize(pricingResponse)); // Schemas.PricingProductCandidate
                });
            });
        });
    };
    return Pricing;
}());
module.exports = Pricing;

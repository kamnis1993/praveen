"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var ChargeOrderActionUtilities = require("../DiscountUtilities/ChargeOrderActionUtilities");
var CostTypes = require("../../cs-lib-constants/CostTypes");
var OrderActions = require("../../cs-lib-constants/OrderActions");
describe("The ChargeOrderAction Utilities", function () {
    describe("CheckChargeOrderStates method", function () {
        var targetAdjustment = {
            Targets: [],
            UnalteredTargets: [],
            ID: undefined,
            LinkID: undefined,
            Type: undefined,
            Amount: 0,
            Description: undefined,
            MostExpensiveFirst: undefined,
            MaxTargets: undefined,
            MinTargetsRequired: undefined,
        };
        it("should filter out any Charges that should not be priced", function (done) {
            targetAdjustment.UnalteredTargets = [];
            var fakeChargesToDiscount = [
                {
                    "ID": "oi_nrc1",
                    "ChargeType": "NonRecurringCharge",
                    "ChargeAction": "update"
                },
                {
                    "ID": "oi_nrc4",
                    "ChargeType": "NonRecurringCharge",
                    "ChargeAction": "update"
                },
                {
                    "ID": "pfi_nrc3",
                    "ChargeType": "NonRecurringCharge",
                    "ChargeAction": "nochange"
                }
            ];
            var result = ChargeOrderActionUtilities.CheckChargeOrderStates(fakeChargesToDiscount, targetAdjustment);
            chai.expect(result.length).to.equal(0);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets[0].ID).to.equal("oi_nrc1");
            chai.expect(targetAdjustment.UnalteredTargets[0].Reason).to.equal("DiscountNotApplicableToChargeState");
            chai.expect(targetAdjustment.UnalteredTargets[1].ID).to.equal("oi_nrc4");
            chai.expect(targetAdjustment.UnalteredTargets[1].Reason).to.equal("DiscountNotApplicableToChargeState");
            chai.expect(targetAdjustment.UnalteredTargets[2].ID).to.equal("pfi_nrc3");
            chai.expect(targetAdjustment.UnalteredTargets[2].Reason).to.equal("DiscountNotApplicableToChargeState");
            done();
        });
        it("should filter include valid charges in the result", function (done) {
            targetAdjustment.UnalteredTargets = [];
            var fakeChargesToDiscount = [
                {
                    "ID": "oi_nrc1",
                    "ChargeType": "NonRecurringCharge",
                    "ChargeAction": "add"
                }
            ];
            var result = ChargeOrderActionUtilities.CheckChargeOrderStates(fakeChargesToDiscount, targetAdjustment);
            chai.expect(result.length).to.equal(1);
            chai.expect(result.toString()).to.equal(fakeChargesToDiscount.toString());
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(0);
            done();
        });
    });
    describe("PriceRecurring method", function () {
        it("should return True for an Add state", function (done) {
            var testAction = OrderActions.Add;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True for an Update state", function (done) {
            var testAction = OrderActions.Update;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True for a Reassigned state", function (done) {
            var testAction = OrderActions.Reassigned;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True for a ReassignedUpdate state", function (done) {
            var testAction = OrderActions.ReassignedUpdate;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True for a NoChange state", function (done) {
            var testAction = OrderActions.NoChange;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False for a Reassign state", function (done) {
            var testAction = OrderActions.Reassign;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for a Delete state", function (done) {
            var testAction = OrderActions.Delete;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return True for a Delete state if it is on a Recurring Cost", function (done) {
            var testAction = OrderActions.Delete;
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction, CostTypes.RecurringCost);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False for an invalid state", function (done) {
            var testAction = "hwthwntrwtwh";
            var result = ChargeOrderActionUtilities.DiscountApplicableToRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
    });
    describe("PriceNonRecurring method", function () {
        it("should return True for an Add state", function (done) {
            var testAction = OrderActions.Add;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False for a Delete state", function (done) {
            var testAction = OrderActions.Delete;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for an Update state", function (done) {
            var testAction = OrderActions.Update;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for a Reassign state", function (done) {
            var testAction = OrderActions.Reassign;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for a Reassigned state", function (done) {
            var testAction = OrderActions.Reassigned;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for a ReassignedUpdate state", function (done) {
            var testAction = OrderActions.ReassignedUpdate;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for a NoChange state", function (done) {
            var testAction = OrderActions.NoChange;
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False for an invalid state", function (done) {
            var testAction = "hwthwntrwtwh";
            var result = ChargeOrderActionUtilities.DiscountApplicableToNonRecurring(testAction);
            chai.expect(result).to.equal(false);
            done();
        });
    });
    describe("PriceCBC method", function () {
        it("should return True if any of the CostDetails is Add with a NonRecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.Add,
                    Type: CostTypes.NonRecurringCost
                },
                {
                    Action: OrderActions.Update,
                    Type: CostTypes.NonRecurringCost
                },
                {
                    Action: OrderActions.Delete,
                    Type: CostTypes.NonRecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False if none of the CostDetails is Add with a NonRecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.Update,
                    Type: CostTypes.NonRecurringCost
                },
                {
                    Action: OrderActions.Delete,
                    Type: CostTypes.NonRecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return True if any of the CostDetails is Add or Update with a RecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.Add,
                    Type: CostTypes.RecurringCost
                },
                {
                    Action: OrderActions.Update,
                    Type: CostTypes.RecurringCost
                },
                {
                    Action: OrderActions.Delete,
                    Type: CostTypes.RecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True if one of the CostDetails is Update with a RecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.Update,
                    Type: CostTypes.RecurringCost
                },
                {
                    Action: OrderActions.Delete,
                    Type: CostTypes.RecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return True if one of the CostDetails is NoChange with a RecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.NoChange,
                    Type: CostTypes.RecurringCost
                },
                {
                    Action: OrderActions.Delete,
                    Type: CostTypes.RecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False if none of the CostDetails are Add/Update/Reassigned/ReassignedUpdate/NoChange with a RecurringCost", function (done) {
            var fakeCostDetails = [
                {
                    Action: OrderActions.Reassign,
                    Type: CostTypes.RecurringCost
                },
                {
                    Action: OrderActions.Reassign,
                    Type: CostTypes.RecurringCost
                }
            ];
            var result = ChargeOrderActionUtilities.DiscountApplicableToCBC(fakeCostDetails);
            chai.expect(result).to.equal(false);
            done();
        });
    });
});

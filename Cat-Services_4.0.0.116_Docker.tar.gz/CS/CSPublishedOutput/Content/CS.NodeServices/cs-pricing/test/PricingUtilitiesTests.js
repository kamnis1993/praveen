"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var PricingUtilities = require("../PricingUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
describe("The Pricing Utilities", function () {
    describe("The FilterRates method", function () {
        var fakeRateAttributes = [
            {
                "Name": "Region",
                "Value": "a3daad04-05a6-41d9-9a93-75305afe666e",
                "Action": "AddMissing",
                "OrderItemSource": "Existing:ORQ001",
                "PortfolioItemSource": "Existing:ORQ001"
            }
        ];
        var fakeExclusiveRateAttributesValues = {
            "Region": [
                "a3daad04-05a6-41d9-9a93-75305afe666e",
                "46e013f3-07d6-57a6-4215-f56510b1ae7d"
            ]
        };
        it("should filter a rate not in the chosen date", function (done) {
            var fakeDate = new Date("2010-02-20T00:00:00.000Z");
            var fakeSpecRates = [
                {
                    "RateGuid": "ad214b3a-4b89-406c-a51a-ec62831d6b4b",
                    "StartDate": "2017-02-20T00:00:00.000Z",
                    "Value": 20,
                    "Type": "NR_Cost_Region",
                    "RateAttributes": {
                        "Region": [
                            "a3daad04-05a6-41d9-9a93-75305afe666e"
                        ]
                    },
                    "RateType": "Simple"
                }
            ];
            var result = PricingUtilities.FilterRates(fakeDate, fakeSpecRates, fakeRateAttributes, fakeExclusiveRateAttributesValues);
            chai.expect(result).to.be.empty;
            done();
        });
        it("should filter a rate that does not match the provided rate attribute", function (done) {
            var fakeDate = new Date("2017-02-20T00:00:00.000Z");
            var fakeSpecRates = [
                {
                    "RateGuid": "81e5409e-03d6-446f-b678-2e6420df6b91",
                    "StartDate": "2017-02-20T00:00:00.000Z",
                    "Value": 15,
                    "Type": "NR_Cost_Region",
                    "RateAttributes": {
                        "Region": [
                            "46e013f3-07d6-57a6-4215-f56510b1ae7d"
                        ]
                    },
                    "RateType": "Simple"
                }
            ];
            var result = PricingUtilities.FilterRates(fakeDate, fakeSpecRates, fakeRateAttributes, fakeExclusiveRateAttributesValues);
            chai.expect(result).to.be.empty;
            done();
        });
        it("should correctly filter down to a single rate", function (done) {
            var fakeDate = new Date("2017-02-20T00:00:00.000Z");
            var fakeSpecRates = [
                {
                    "RateGuid": "ad214b3a-4b89-406c-a51a-ec62831d6b4b",
                    "StartDate": "2017-02-20T00:00:00.000Z",
                    "Value": 20,
                    "Type": "NR_Cost_Region",
                    "RateAttributes": {
                        "Region": [
                            "a3daad04-05a6-41d9-9a93-75305afe666e"
                        ]
                    },
                    "RateType": "Simple"
                },
                {
                    "RateGuid": "81e5409e-03d6-446f-b678-2e6420df6b91",
                    "StartDate": "2017-02-20T00:00:00.000Z",
                    "Value": 15,
                    "Type": "NR_Cost_Region",
                    "RateAttributes": {
                        "Region": [
                            "46e013f3-07d6-57a6-4215-f56510b1ae7d"
                        ]
                    },
                    "RateType": "Simple"
                }
            ];
            var expectedRate = {
                "RateGuid": "ad214b3a-4b89-406c-a51a-ec62831d6b4b",
                "StartDate": "2017-02-20T00:00:00.000Z",
                "Value": 20,
                "Type": "NR_Cost_Region",
                "RateAttributes": {
                    "Region": [
                        "a3daad04-05a6-41d9-9a93-75305afe666e"
                    ]
                },
                "RateType": "Simple"
            };
            var result = PricingUtilities.FilterRates(fakeDate, fakeSpecRates, fakeRateAttributes, fakeExclusiveRateAttributesValues);
            chai.expect(result[0].RateGuid).to.equal(expectedRate.RateGuid);
            chai.expect(result[0].StartDate).to.equal(expectedRate.StartDate);
            chai.expect(result[0].Value).to.equal(expectedRate.Value);
            chai.expect(result[0].RateAttributes.Region).to.not.be.undefined;
            chai.expect(result[0].RateAttributes.Region.length).to.equal(1);
            chai.expect(result[0].RateAttributes.Region[0]).to.equal(expectedRate.RateAttributes.Region[0]);
            done();
        });
        it("Should correctly detect and use RateActivationDates", function (done) {
            var fakeDate = new Date("2019-06-20T00:00:00.000Z");
            var fakeSpecRates = [
                {
                    "RateGuid": "ad214b3a-4b89-406c-a51a-ec62831d6b4b",
                    "StartDate": "2019-02-20T00:00:00.000Z",
                    "Value": 20,
                    "Type": "NR_Cost_Region",
                    "RateType": "Simple",
                    "RateAttributes": {},
                    "ActivationStartDate": "2019-01-01"
                },
                {
                    "RateGuid": "81e5409e-03d6-446f-b678-2e6420df6b91",
                    "StartDate": "2019-02-20T00:00:00.000Z",
                    "Value": 15,
                    "Type": "NR_Cost_Region",
                    "RateType": "Simple",
                    "RateAttributes": {},
                    "ActivationStartDate": "2020-01-01"
                }
            ];
            var expectedRate = {
                "RateGuid": "ad214b3a-4b89-406c-a51a-ec62831d6b4b",
                "StartDate": "2019-02-20T00:00:00.000Z",
                "Value": 20,
                "Type": "NR_Cost_Region",
                "RateType": "Simple",
                "ActivationStartDate": "2019-01-01"
            };
            var result = PricingUtilities.FilterRates(fakeDate, fakeSpecRates, [], {}, fakeDate);
            chai.expect(result[0].RateGuid).to.equal(expectedRate.RateGuid);
            chai.expect(result[0].StartDate).to.equal(expectedRate.StartDate);
            chai.expect(result[0].Value).to.equal(expectedRate.Value);
            chai.expect(result[0].ActivationStartDate).to.equal(expectedRate.ActivationStartDate);
            done();
        });
    });
    describe("The CalculateOrderfolioItemRate method", function () {
        it("should correctly calculate a simple rate from an Orderfolio Item and rate info", function (done) {
            // Simple charge rate
            var fakeOrderfolioItem = {
                "CompoundKey": {
                    "Key": "6",
                    "Index": 0
                },
                "EntityId": "7f2542bb-7d5e-47a3-be10-3e36c6b61778",
                "EntityUniqueCode": "charge_a",
                "PortfolioItemId": "charge_a",
                "OrderItemId": "charge_a",
                "OrderItemSource": "Existing:ORQ001",
                "PortfolioItemSource": "Existing:ORQ001",
                "Action": "add",
                "CharacteristicUses": [],
                "UserDefinedCharacteristics": [],
                "RatingAttributes": [],
                "HasTechnicalChildrenInSpec": false,
                "IsInvalid": false,
                "IsExcludedCharge": false,
                "IsExcludedCost": false,
                "IsExcludedDiscount": false,
                "ChargeType": "RecurringCharge",
                "ExactType": "Generic_RC_Template",
                "Periodicity": "Monthly",
                "ItemAdded": true,
                "IsAdditionalCharge": false
            };
            var fakeRate = {
                "RateGuid": "07cbf15e-c1ad-45f8-a493-583b857496fd",
                "StartDate": "2016-04-01T00:00:00.000Z",
                "Value": 500,
                "Type": "RC_Flat",
                "RateAttributes": {},
                "RateType": "Simple"
            };
            var expectedRate = {
                "OrderfolioKey": {
                    "Key": "6",
                    "Index": 0
                },
                "Rate": { "ID": "07cbf15e-c1ad-45f8-a493-583b857496fd",
                    "Type": "RC_Flat",
                    "StartDate": "2016-04-01T00:00:00.000Z",
                    "EndDate": undefined,
                    "Value": 500
                }
            };
            var result = PricingUtilities.CalculateOrderfolioItemRate(fakeOrderfolioItem, fakeRate);
            chai.expect(result.OrderfolioKey.Key).to.equal(expectedRate.OrderfolioKey.Key);
            chai.expect(result.OrderfolioKey.Index).to.equal(expectedRate.OrderfolioKey.Index);
            chai.expect(result.Rate.Type).to.equal(expectedRate.Rate.Type);
            chai.expect(result.Rate.StartDate).to.equal(expectedRate.Rate.StartDate);
            chai.expect(result.Rate.Value).to.equal(expectedRate.Rate.Value);
            done();
        });
    });
    describe("The CalculateUnitBasedRateValue method", function () {
        // Threshold rates
        it("should correctly calculate a Threshold rate from an Orderfolio Item and rate info", function (done) {
            var fakeQuantity = 7;
            var fakeRate = {
                "RateGuid": "2f83ac63-8903-42b7-b831-268adc842702",
                "StartDate": "2017-05-09T00:00:00.000Z",
                "Type": "BasicThresholdRate",
                "RateAttributes": {},
                "RateType": "Threshold",
                "UnitPricingRates": [
                    {
                        "Threshold": 11,
                        "Value": 15
                    },
                    {
                        "Threshold": 0,
                        "Value": 20
                    },
                    {
                        "Threshold": 6,
                        "Value": 18
                    }
                ],
                "PerUnit": false
            };
            var result = PricingUtilities.CalculateUnitBasedRateValue(fakeQuantity, fakeRate);
            chai.expect(result).to.equal(18);
            done();
        });
        it("should correctly calculate a Threshold PerUnit rate from an Orderfolio Item and rate info", function (done) {
            var fakeQuantity = 7;
            var fakeRate = {
                "RateGuid": "2f83ac63-8903-42b7-b831-268adc842702",
                "StartDate": "2017-05-09T00:00:00.000Z",
                "Type": "BasicThresholdRate",
                "RateAttributes": {},
                "RateType": "Threshold",
                "UnitPricingRates": [
                    {
                        "Threshold": 11,
                        "Value": 15
                    },
                    {
                        "Threshold": 0,
                        "Value": 20
                    },
                    {
                        "Threshold": 6,
                        "Value": 18
                    }
                ],
                "PerUnit": true
            };
            var result = PricingUtilities.CalculateUnitBasedRateValue(fakeQuantity, fakeRate);
            // PerUnit so 7 x 18 = 236
            chai.expect(result).to.equal(126);
            done();
        });
        // Tiered rates
        it("should correctly calculate a Tiered rate from an Orderfolio Item and rate info", function (done) {
            var fakeQuantity = 7;
            var fakeRate = {
                "RateGuid": "a15c3bb3-917a-4ec8-94ca-6d5d333780b4",
                "StartDate": "2017-06-02T00:00:00.000Z",
                "Type": "BasicTieredRate",
                "RateAttributes": {},
                "RateType": "Tiered",
                "UnitPricingRates": [
                    {
                        "Threshold": undefined,
                        "Value": 10
                    },
                    {
                        "Threshold": 10,
                        "Value": 12
                    },
                    {
                        "Threshold": 5,
                        "Value": 15
                    }
                ],
                "PerUnit": false
            };
            var result = PricingUtilities.CalculateUnitBasedRateValue(fakeQuantity, fakeRate);
            chai.expect(result).to.equal(27);
            done();
        });
        it("should correctly calculate a Tiered PerUnitrate from an Orderfolio Item and rate info", function (done) {
            var fakeQuantity = 7;
            var fakeRate = {
                "RateGuid": "a15c3bb3-917a-4ec8-94ca-6d5d333780b4",
                "StartDate": "2017-06-02T00:00:00.000Z",
                "Type": "BasicTieredRate",
                "RateAttributes": {},
                "RateType": "Tiered",
                "UnitPricingRates": [
                    {
                        "Threshold": undefined,
                        "Value": 10
                    },
                    {
                        "Threshold": 10,
                        "Value": 12
                    },
                    {
                        "Threshold": 5,
                        "Value": 15
                    }
                ],
                "PerUnit": true
            };
            var result = PricingUtilities.CalculateUnitBasedRateValue(fakeQuantity, fakeRate);
            chai.expect(result).to.equal(99);
            done();
        });
    });
    describe("The ValidateRateDetail method", function () {
        it("should return false for undefined RateDetail", function (done) {
            var rateDetail = undefined;
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.false;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for null RateDetail", function (done) {
            var rateDetail = null;
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.false;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for empty RateDetail", function (done) {
            var rateDetail = {};
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.false;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return false for null RateActivationDate", function (done) {
            var rateDetail = { RateActivationDate: null };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.false;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for invalid RateActivationDate with false for HasValidRateActivationDate", function (done) {
            // An invalid date is actually a usable override
            var rateDetail = { RateActivationDate: new Date("2019-13-32") };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.false;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for valid RateActivationDate with true for HasValidRateActivationDate", function (done) {
            var rateDetail = { RateActivationDate: new Date("2019-10-10") };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(Utilities.DateString(result.RateActivationDate)).to.equal("2019-10-10");
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for undefined RateId with valid valueOverride but with false for HasValidRateOverride", function (done) {
            var rateDetail = {
                RateActivationDate: undefined,
                RateIdOverride: undefined,
                ValueOverride: "10"
            };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for valid RateId with undefined valueOverride but with false for HasValidRateOverride", function (done) {
            var rateDetail = {
                RateActivationDate: undefined,
                RateIdOverride: "1",
                ValueOverride: undefined
            };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for valid RateId with invalid valueOverride but with false for HasValidRateOverride", function (done) {
            var rateDetail = {
                RateActivationDate: undefined,
                RateIdOverride: "1",
                ValueOverride: "NOT_A_NUMBER"
            };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.false;
            chai.expect(result.RateIdOverride).to.be.undefined;
            chai.expect(result.ValueOverride).to.be.undefined;
            done();
        });
        it("should return true for valid RateId with valid valueOverride and with true for HasValidRateOverride", function (done) {
            var rateDetail = {
                RateActivationDate: undefined,
                RateIdOverride: "1",
                ValueOverride: "10"
            };
            var result = PricingUtilities.ValidateRateDetail(rateDetail);
            chai.expect(result).not.to.be.undefined;
            chai.expect(result.IsUsableRateDetail).to.be.true;
            chai.expect(result.HasValidRateActivationDate).to.be.true;
            chai.expect(result.RateActivationDate).to.be.undefined;
            chai.expect(result.HasValidRateOverride).to.be.true;
            chai.expect(result.RateIdOverride).to.equal("1");
            chai.expect(result.ValueOverride).to.equal("10");
            done();
        });
    });
});

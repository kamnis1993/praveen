"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var DiscountSetupUtilities = require("../DiscountUtilities/DiscountSetupUtilities");
var InterimSummary = require("../InternalPricingTypes/InterimSummary");
var PricingInformation = require("../InternalPricingTypes/PricingInformation");
var decimal = require("jsdecimal");
describe("The DiscountSetup Utilities", function () {
    var flatAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Flat",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var percentageAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Percentage",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var absoluteAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Absolute",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var fakeLookups = { DiscountUuidToRateInfo: {}, DiscountUuidToDiscountInfo: {} };
    fakeLookups.DiscountUuidToDiscountInfo["1"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["1"] = [];
    fakeLookups.DiscountUuidToRateInfo["1"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["2"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["2"] = [];
    fakeLookups.DiscountUuidToRateInfo["2"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["3"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["3"] = [];
    fakeLookups.DiscountUuidToRateInfo["3"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["4"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["4"] = [];
    fakeLookups.DiscountUuidToRateInfo["4"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    var interimSummary = new InterimSummary();
    interimSummary.RecurringCharges.push(new PricingInformation());
    interimSummary.RecurringCharges.push(new PricingInformation());
    var interimRootItemSummary = new InterimSummary();
    interimRootItemSummary.RecurringCharges.push(new PricingInformation());
    interimRootItemSummary.RecurringCharges.push(new PricingInformation());
    var orderfolio = fs.readFileSync('cs-pricing/test/files/Orderfolio.json', { encoding: 'utf8' });
    var fakeOrderfolio = JSON.parse(orderfolio);
    describe("AddAdjustAndOrigTotalsToRecurring method", function () {
        it("should return the interimSummary and interimRootItemSummary with AdjustmentTotal and OriginalTotal added", function (done) {
            DiscountSetupUtilities.AddAdjustAndOrigTotalsToRecurring(interimSummary, interimRootItemSummary);
            chai.expect(interimSummary.RecurringCharges[0]).to.haveOwnProperty("AdjustmentTotal");
            chai.expect(interimSummary.RecurringCharges[0]).to.haveOwnProperty("OriginalTotal");
            chai.expect(interimSummary.RecurringCharges[1]).to.haveOwnProperty("AdjustmentTotal");
            chai.expect(interimSummary.RecurringCharges[1]).to.haveOwnProperty("OriginalTotal");
            chai.expect(interimRootItemSummary.RecurringCharges[0]).to.haveOwnProperty("AdjustmentTotal");
            chai.expect(interimRootItemSummary.RecurringCharges[0]).to.haveOwnProperty("OriginalTotal");
            chai.expect(interimRootItemSummary.RecurringCharges[1]).to.haveOwnProperty("AdjustmentTotal");
            chai.expect(interimRootItemSummary.RecurringCharges[1]).to.haveOwnProperty("OriginalTotal");
            done();
        });
    });
    describe("BuildOriginalValuesObject method", function () {
        it("should return the OriginalValues object with the correct values", function (done) {
            interimSummary.NonRecurringCharges.MinimumTotal = new decimal(10);
            interimSummary.NonRecurringCharges.FinalTotal = new decimal(10);
            interimSummary.RecurringCharges[0].MinimumTotal = new decimal(20);
            interimSummary.RecurringCharges[0].FinalTotal = new decimal(20);
            interimSummary.RecurringCharges[1].MinimumTotal = new decimal(30);
            interimSummary.RecurringCharges[1].FinalTotal = new decimal(30);
            interimRootItemSummary.NonRecurringCharges.MinimumTotal = new decimal(40);
            interimRootItemSummary.NonRecurringCharges.FinalTotal = new decimal(40);
            interimRootItemSummary.RecurringCharges[0].MinimumTotal = new decimal(50);
            interimRootItemSummary.RecurringCharges[0].FinalTotal = new decimal(50);
            interimRootItemSummary.RecurringCharges[1].MinimumTotal = new decimal(60);
            interimRootItemSummary.RecurringCharges[1].FinalTotal = new decimal(60);
            var result = DiscountSetupUtilities.BuildOriginalValuesObject(interimSummary, interimRootItemSummary);
            chai.expect(result.NonRecurring.OriginalTotal).to.deep.equal(new decimal(10));
            chai.expect(result.NonRecurring.OriginalRootItemTotal).to.deep.equal(new decimal(40));
            chai.expect(result.Recurring.OriginalTotal).to.deep.equal([new decimal(20), new decimal(30)]);
            chai.expect(result.Recurring.OriginalRootItemTotal).to.deep.equal([new decimal(50), new decimal(60)]);
            done();
        });
    });
    describe("GatherDiscountUuids method", function () {
        it("should return an array with the correct Uuids", function (done) {
            var IDs = [];
            DiscountSetupUtilities.GatherDiscountUuids(IDs, fakeLookups, fakeOrderfolio);
            // Discount Uuids are defined in fakeLookups and fakeOrderfolio
            // fakeLookups contains 1,2,3,4 as discounts, Orderfolio contains 3,
            //4 as discounts, 5 as a charge and 6 as a package
            chai.expect(IDs[0]).to.equal('3');
            chai.expect(IDs[1]).to.equal('4');
            done();
        });
    });
    describe("RemoveMissingOrderfolioDiscounts method", function () {
        it("should remove any discounts that aren't in the orderfolio from the Lookups", function (done) {
            var IDs = ["3", "4"];
            var result = DiscountSetupUtilities.RemoveMissingOrderfolioDiscounts(fakeLookups, IDs);
            // 1 and 2 are not in the IDs so they will be removed from fakeLookups
            chai.expect(fakeLookups.DiscountUuidToDiscountInfo["3"].DiscountGuid).to.equal('abc');
            chai.expect(fakeLookups.DiscountUuidToDiscountInfo["4"].DiscountGuid).to.equal('abc');
            chai.expect(fakeLookups.DiscountUuidToDiscountInfo["1"]).to.be.undefined;
            chai.expect(fakeLookups.DiscountUuidToDiscountInfo["2"]).to.be.undefined;
            chai.expect(fakeLookups.DiscountUuidToRateInfo["1"]).to.be.undefined;
            chai.expect(fakeLookups.DiscountUuidToRateInfo["2"]).to.be.undefined;
            done();
        });
        it("should not alter the lookups if there are no missing Discounts", function (done) {
            var IDs = ["5", "6"];
            var result = DiscountSetupUtilities.RemoveMissingOrderfolioDiscounts(fakeLookups, IDs);
            chai.expect(result).to.equal(fakeLookups);
            done();
        });
    });
});

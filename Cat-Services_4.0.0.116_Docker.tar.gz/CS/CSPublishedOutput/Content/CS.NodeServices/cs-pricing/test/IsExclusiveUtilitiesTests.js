"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var IsExclusiveUtilities = require("../DiscountUtilities/IsExclusiveUtilities");
describe("The OrderOfExecution Utilities", function () {
    var flatAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Flat",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var percentageAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Percentage",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var absoluteAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Absolute",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var fakeLookups = { DiscountUuidToRateInfo: {}, DiscountUuidToDiscountInfo: {} };
    fakeLookups.DiscountUuidToDiscountInfo["1"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["1"] = [];
    fakeLookups.DiscountUuidToRateInfo["1"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["2"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["2"] = [];
    fakeLookups.DiscountUuidToRateInfo["2"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["3"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["3"] = [];
    fakeLookups.DiscountUuidToRateInfo["3"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["4"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["4"] = [];
    fakeLookups.DiscountUuidToRateInfo["4"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    describe("ContainsExclusiveDiscount method", function () {
        it("should return True if any of the discounts is exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["4"][0].IsExclusive = false;
            var result = IsExclusiveUtilities.ContainsExclusiveDiscount(fakeLookups);
            chai.expect(result).to.equal(true);
            done();
        });
        it("should return False if none of the discounts are exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["4"][0].IsExclusive = false;
            var result = IsExclusiveUtilities.ContainsExclusiveDiscount(fakeLookups);
            chai.expect(result).to.equal(false);
            done();
        });
        it("should return False if discountLookups is undefined", function (done) {
            var result = IsExclusiveUtilities.ContainsExclusiveDiscount(undefined);
            chai.expect(result).to.equal(false);
            done();
        });
    });
    describe("CheckIfAbsoluteIsExclusive method", function () {
        it("should return False if a higher Absolute adjustment exists but is not Exclusive, while an earlier adjustment is Exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = absoluteAdjustment;
            var absoluteDiscounts = [2];
            var discountUuid = "1";
            var higherAbsoluteExists = true;
            higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(fakeLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
            chai.expect(higherAbsoluteExists).to.equal(false);
            done();
        });
        it("should return True if a higher Absolute adjustment exists and there are no Exclusive discounts", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = absoluteAdjustment;
            var absoluteDiscounts = [2];
            var discountUuid = "1";
            var higherAbsoluteExists = true;
            higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(fakeLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
            chai.expect(higherAbsoluteExists).to.equal(true);
            done();
        });
        it("should return the entered value of higherAbsoluteExists if there are no discounts", function (done) {
            var extraFakeLookups = { DiscountUuidToRateInfo: {}, DiscountUuidToDiscountInfo: {} };
            var absoluteDiscounts = [];
            var discountUuid = "1";
            var higherAbsoluteExists = undefined;
            higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(extraFakeLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
            chai.expect(higherAbsoluteExists).to.equal(undefined);
            done();
        });
        it("should return False if a non Exclusive higher Absolute exists and multiple earlier adjustments exist, but only one is exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 5;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 2;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["4"][0].OrderOfExecution = 3;
            fakeLookups.DiscountUuidToRateInfo["4"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["4"][0].ChargeAdjustments[0] = flatAdjustment;
            var absoluteDiscounts = [1];
            var discountUuid = "4";
            var higherAbsoluteExists = true;
            higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(fakeLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
            chai.expect(higherAbsoluteExists).to.equal(false);
            done();
        });
        it("should return False if there are no absolute discounts", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            var absoluteDiscounts = [];
            var discountUuid = "2";
            var higherAbsoluteExists = false;
            higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(fakeLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
            chai.expect(higherAbsoluteExists).to.equal(false);
            done();
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var OrderOfExecutionUtilities = require("../DiscountUtilities/OrderOfExecutionUtilities");
describe("The OrderOfExecution Utilities", function () {
    var flatAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Flat",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var targetedCharge = {
        ChargeUuid: "1",
        ChargeLinkID: "",
        EntityLinkReference: null,
        ImpliedLink: null
    };
    var percentageAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Percentage",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var absoluteAdjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Absolute",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var fakeLookups = { DiscountUuidToRateInfo: {}, DiscountUuidToDiscountInfo: {} };
    fakeLookups.DiscountUuidToDiscountInfo["1"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["1"] = [];
    fakeLookups.DiscountUuidToRateInfo["1"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["2"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["2"] = [];
    fakeLookups.DiscountUuidToRateInfo["2"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["3"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["3"] = [];
    fakeLookups.DiscountUuidToRateInfo["3"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    fakeLookups.DiscountUuidToDiscountInfo["4"] = {
        DiscountGuid: "abc",
        ExactType: "abc",
        DiscountType: "abc",
        IsExcludedDiscount: false,
        ExclusiveRateAttributeValues: {}
    };
    fakeLookups.DiscountUuidToRateInfo["4"] = [];
    fakeLookups.DiscountUuidToRateInfo["4"][0] = {
        RateGuid: "8f62f054-fc73-42c0-9435-abee287b1664",
        StartDate: "2017-10-18T00:00:00.000Z",
        RateAttributes: {},
        Type: "Simple_CBD_Rate",
        OrderOfExecution: 1,
        IsExclusive: false,
        ChargeAdjustments: []
    };
    describe("GatherOrderOfExecValues method", function () {
        it("should collect the OrderOfExecution value from all discounts, removing any duplicates, and sort them into ascending order", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 95;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 5;
            fakeLookups.DiscountUuidToRateInfo["4"][0].OrderOfExecution = 1;
            var storageArray = [];
            storageArray = OrderOfExecutionUtilities.GatherOrderOfExecValues(fakeLookups, storageArray);
            chai.expect(storageArray[0]).to.equal(1);
            chai.expect(storageArray[1]).to.equal(5);
            chai.expect(storageArray[2]).to.equal(95);
            done();
        });
        it("should return nothing if no OrderOfExecution values exist", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = null;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = null;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = null;
            fakeLookups.DiscountUuidToRateInfo["4"][0].OrderOfExecution = null;
            var storageArray = [];
            storageArray = OrderOfExecutionUtilities.GatherOrderOfExecValues(fakeLookups, storageArray);
            chai.expect(storageArray[0]).to.equal(undefined);
            done();
        });
        it("should correctly filter out duplicate OrderOfExecution values", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["4"][0].OrderOfExecution = 1;
            var storageArray = [];
            storageArray = OrderOfExecutionUtilities.GatherOrderOfExecValues(fakeLookups, storageArray);
            chai.expect(storageArray[0]).to.equal(1);
            chai.expect(storageArray[1]).to.equal(undefined);
            done();
        });
    });
    describe("AdjustmentTypesAtOrderOfExecution method", function () {
        it("should return all adjustment types for a given OrderOfExecution value", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["2"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["3"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges.unshift(targetedCharge);
            fakeLookups.DiscountUuidToRateInfo["2"][0].TargetedCharges.unshift(targetedCharge);
            fakeLookups.DiscountUuidToRateInfo["3"][0].TargetedCharges.unshift(targetedCharge);
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            storageArray[2] = fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution;
            var outputArray = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(fakeLookups, storageArray, 0);
            chai.expect(outputArray[0].AdjustmentType).to.equal("Flat");
            chai.expect(outputArray[1].AdjustmentType).to.equal("Percentage");
            chai.expect(outputArray[2].AdjustmentType).to.equal("Absolute");
            done();
        });
        it("should return nothing if no adjustments are present at that OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges.unshift(targetedCharge);
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            storageArray[2] = fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution;
            var outputArray = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(fakeLookups, storageArray, 5);
            chai.expect(outputArray[0]).to.equal(undefined);
            done();
        });
        it("should contain any duplicated adjustmentTypes, as these are required", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges.unshift(targetedCharge);
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges.unshift(targetedCharge);
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            var outputArray = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(fakeLookups, storageArray, 0);
            chai.expect(outputArray[0].AdjustmentType).to.equal("Flat");
            chai.expect(outputArray[1].AdjustmentType).to.equal("Flat");
            done();
        });
        it("should return an empty array if Adjustments are missing their types", function (done) {
            var noTypeAdjustment = {
                AdjustmentGuid: "1",
                AdjustmentType: null,
                ExactType: "",
                Amount: "",
                Description: "",
                MostExpensiveFirst: false,
                MaxTargets: undefined,
                MinTargetsRequired: undefined
            };
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = noTypeAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = noTypeAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = noTypeAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges = [];
            fakeLookups.DiscountUuidToRateInfo["1"][0].TargetedCharges.unshift(targetedCharge);
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            storageArray[2] = fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution;
            var outputArray = OrderOfExecutionUtilities.AdjustmentTypesAtOrderOfExecution(fakeLookups, storageArray, 0);
            chai.expect(outputArray[0]).to.equal(undefined);
            done();
        });
    });
    describe("MultipleAdjustmentTypes method", function () {
        it("should return true if multiple adjustment types are present", function (done) {
            var storageArray = [];
            storageArray.push({ Target: "1", AdjustmentType: "Flat" });
            storageArray.push({ Target: "1", AdjustmentType: "Percentage" });
            var multiTypes = OrderOfExecutionUtilities.MultipleAdjustmentTypes(storageArray);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return true if multiple absolute adjustments are present", function (done) {
            var storageArray = [];
            storageArray.push({ Target: "1", AdjustmentType: "Absolute" });
            storageArray.push({ Target: "1", AdjustmentType: "Absolute" });
            var multiTypes = OrderOfExecutionUtilities.MultipleAdjustmentTypes(storageArray);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return false if only one type of adjustment is present", function (done) {
            var storageArray = [];
            storageArray.push({ Target: "1", AdjustmentType: "Flat" });
            storageArray.push({ Target: "1", AdjustmentType: "Flat" });
            var multiTypes = OrderOfExecutionUtilities.MultipleAdjustmentTypes(storageArray);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return false if no adjustments are present", function (done) {
            var storageArray = [];
            var multiTypes = OrderOfExecutionUtilities.MultipleAdjustmentTypes(storageArray);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return false if array is undefined", function (done) {
            var storageArray = undefined;
            var multiTypes = OrderOfExecutionUtilities.MultipleAdjustmentTypes(storageArray);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
    });
    describe("HigherAbsoluteExists method", function () {
        it("should return true if an Absolute adjustment exists at a higher OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[2] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            var absoluteDiscounts = [];
            var laterAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(fakeLookups, storageArray, 0, absoluteDiscounts);
            chai.expect(laterAbsoluteExists).to.equal(true);
            done();
        });
        it("should return false if no Absolute adjustment exists at a higher OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            var absoluteDiscounts = [];
            var laterAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(fakeLookups, storageArray, 0, absoluteDiscounts);
            chai.expect(laterAbsoluteExists).to.equal(false);
            done();
        });
        it("should return false if no adjustments exist", function (done) {
            var storageArray = [];
            storageArray[0] = fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution;
            storageArray[1] = fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution;
            var absoluteDiscounts = [];
            var laterAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(fakeLookups, storageArray, 0, absoluteDiscounts);
            chai.expect(laterAbsoluteExists).to.equal(false);
            done();
        });
        it("should return false if no OrdOfExecution values exist", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            var storageArray = [];
            var absoluteDiscounts = [];
            var laterAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(fakeLookups, storageArray, 0, absoluteDiscounts);
            chai.expect(laterAbsoluteExists).to.equal(false);
            done();
        });
        it("should return false if no adjustments and OrderOfExecution values exist", function (done) {
            var storageArray = [];
            var absoluteDiscounts = [];
            var laterAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(fakeLookups, storageArray, 0, absoluteDiscounts);
            chai.expect(laterAbsoluteExists).to.equal(false);
            done();
        });
    });
    describe("DetermineMultipleAdjustmentsPresent method", function () {
        it("should return True if a Flat and %age are both present at the same OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            var exclusiveDiscountPresent = false;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return False if a Flat and Flat are both present at the same OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = false;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return True if a Flat and %age are both present at the same OrderOfExecution and both are Exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = true;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return False if a Flat and Flat are both present at the same OrderOfExecution and both are Exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = true;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return False if a Flat and %age are both present at the same OrderOfExecution and only one is Exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = true;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return True if an Absolute and Absolute are both present at the same OrderOfExecution", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = false;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return False if no discounts are present at the OrderOfExecution value provided", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = absoluteAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 7;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 5;
            var exclusiveDiscountPresent = false;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(20);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return True if there are two Flat adjustments and a Percentage adjustment, but one of the Flats is not Exclusive, while the rest are", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = true;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(true);
            done();
        });
        it("should return False if there are two Flat adjustments and a Percentage adjustment, both the Flats are exclusive but the percentage is not", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].ChargeAdjustments[0] = flatAdjustment;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["3"][0].ChargeAdjustments[0] = percentageAdjustment;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 1;
            var exclusiveDiscountPresent = true;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, fakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
        it("should return False if there are no Discounts", function (done) {
            var extraFakeLookups = { DiscountUuidToRateInfo: {}, DiscountUuidToDiscountInfo: {} };
            var exclusiveDiscountPresent = false;
            var multipleAdjustmentsAtSameOrdOfExec;
            var ordOfExecutionValues = [];
            ordOfExecutionValues.push(1);
            var i = 0;
            var multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, extraFakeLookups, multipleAdjustmentsAtSameOrdOfExec, ordOfExecutionValues, i);
            chai.expect(multiTypes).to.equal(false);
            done();
        });
    });
    describe("GetFirstExclusiveOrderOfExecution method", function () {
        it("should return 1 if there are two Exclusive discounts with OrderOfExecution values of 1 and 1", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            var result = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(fakeLookups);
            chai.expect(result).to.equal(1);
            done();
        });
        it("should return 1 if there are two Exclusive discounts with OrderOfExecution values of 1 and 2", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            var result = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(fakeLookups);
            chai.expect(result).to.equal(1);
            done();
        });
        it("should return 10 if there are three Exclusive discounts with OrderOfExecution values of 30, 10 and 17", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 30;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 10;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 17;
            var result = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(fakeLookups);
            chai.expect(result).to.equal(10);
            done();
        });
        it("should return 2 if there are three discounts with OrderOfExecution values of 1, 2 and 3 but the discount with OrdOfExec 1 is not Exclusive", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 2;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = true;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 3;
            var result = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(fakeLookups);
            chai.expect(result).to.equal(2);
            done();
        });
        it("should return undefined if there are no Exclusive discounts", function (done) {
            fakeLookups.DiscountUuidToRateInfo["1"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["1"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["2"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["2"][0].OrderOfExecution = 1;
            fakeLookups.DiscountUuidToRateInfo["3"][0].IsExclusive = false;
            fakeLookups.DiscountUuidToRateInfo["3"][0].OrderOfExecution = 1;
            var result = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(fakeLookups);
            chai.expect(result).to.equal(undefined);
            done();
        });
    });
});

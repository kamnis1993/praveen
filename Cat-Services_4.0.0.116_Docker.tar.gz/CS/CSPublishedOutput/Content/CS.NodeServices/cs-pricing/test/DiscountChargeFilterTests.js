"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var DiscountChargeUtilities = require("../DiscountUtilities/DiscountChargeUtilities");
describe("The Discount Charge Filter", function () {
    var adjustment = {
        AdjustmentGuid: "1",
        AdjustmentType: "Flat",
        ExactType: "",
        Amount: "",
        Description: "",
        MostExpensiveFirst: false,
        MaxTargets: undefined,
        MinTargetsRequired: undefined
    };
    var targetAdjustment = {
        Targets: [],
        UnalteredTargets: [],
        ID: undefined,
        LinkID: undefined,
        Type: undefined,
        Amount: 0,
        Description: undefined,
        MostExpensiveFirst: undefined,
        MaxTargets: undefined,
        MinTargetsRequired: undefined,
    };
    describe("ApplyAdjustmentSorting method", function () {
        it("should sort the charges by RateValue ascending if MostExpensiveFirst is false", function (done) {
            var unsortedCharges = [
                { ChargeLinkID: "2", RateValue: 10 },
                { ChargeLinkID: "1", RateValue: 12 },
                { ChargeLinkID: "3", RateValue: 8 }
            ];
            adjustment.MostExpensiveFirst = false;
            var sortedCharges = DiscountChargeUtilities.ApplyAdjustmentSorting(unsortedCharges, adjustment);
            chai.expect(sortedCharges[0].ChargeLinkID).to.equal("3");
            chai.expect(sortedCharges[1].ChargeLinkID).to.equal("2");
            chai.expect(sortedCharges[2].ChargeLinkID).to.equal("1");
            done();
        });
        it("should sort the charges by RateValue ascending if MostExpensiveFirst is true", function (done) {
            var unsortedCharges = [
                { ChargeLinkID: "2", RateValue: 10 },
                { ChargeLinkID: "1", RateValue: 12 },
                { ChargeLinkID: "3", RateValue: 8 }
            ];
            adjustment.MostExpensiveFirst = true;
            var sortedCharges = DiscountChargeUtilities.ApplyAdjustmentSorting(unsortedCharges, adjustment);
            chai.expect(sortedCharges[0].ChargeLinkID).to.equal("1");
            chai.expect(sortedCharges[1].ChargeLinkID).to.equal("2");
            chai.expect(sortedCharges[2].ChargeLinkID).to.equal("3");
            done();
        });
        it("should not sort the charges if MostExpensiveFirst is not set", function (done) {
            var unsortedCharges = [
                { ChargeLinkID: "2", RateValue: 10 },
                { ChargeLinkID: "1", RateValue: 12 },
                { ChargeLinkID: "3", RateValue: 8 }
            ];
            adjustment.MostExpensiveFirst = undefined;
            var sortedCharges = DiscountChargeUtilities.ApplyAdjustmentSorting(unsortedCharges, adjustment);
            chai.expect(sortedCharges[0].ChargeLinkID).to.equal("2");
            chai.expect(sortedCharges[1].ChargeLinkID).to.equal("1");
            chai.expect(sortedCharges[2].ChargeLinkID).to.equal("3");
            done();
        });
    });
    describe("FilterByMaximumTargets method", function () {
        var chargesToDiscount = [
            { ChargeLinkID: "1", RateValue: 200, ID: "pf_1" },
            { ChargeLinkID: "2", RateValue: 210, ID: "pf_2" },
            { ChargeLinkID: "3", RateValue: 290, ID: "pf_3" }
        ];
        it("should return only 1 charge if MaxTargets is 1, other charges should be marked as filtered", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MaxTargets = 1;
            var filteredCharges = DiscountChargeUtilities.FilterByMaximumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(1);
            chai.expect(filteredCharges[0].ChargeLinkID).to.equal("1");
            chai.expect(filteredCharges[1]).to.be.undefined;
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(2);
            chai.expect(targetAdjustment.UnalteredTargets[0].ID).to.equal("pf_2");
            chai.expect(targetAdjustment.UnalteredTargets[0].Reason).to.equal("Filtered");
            chai.expect(targetAdjustment.UnalteredTargets[1].ID).to.equal("pf_3");
            chai.expect(targetAdjustment.UnalteredTargets[1].Reason).to.equal("Filtered");
            done();
        });
        it("should return only 2 charges if MaxTargets is 2, other charges should be marked as filtered", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MaxTargets = 2;
            var filteredCharges = DiscountChargeUtilities.FilterByMaximumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(2);
            chai.expect(filteredCharges[0].ChargeLinkID).to.equal("1");
            chai.expect(filteredCharges[1].ChargeLinkID).to.equal("2");
            chai.expect(filteredCharges[2]).to.be.undefined;
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(1);
            chai.expect(targetAdjustment.UnalteredTargets[0].ID).to.equal("pf_3");
            chai.expect(targetAdjustment.UnalteredTargets[0].Reason).to.equal("Filtered");
            done();
        });
        it("should return all charges if MaxTargets is not set", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MaxTargets = undefined;
            var filteredCharges = DiscountChargeUtilities.FilterByMaximumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(0);
            done();
        });
    });
    describe("FilterByMinimumTargets method", function () {
        var chargesToDiscount = [
            { ChargeLinkID: "1", RateValue: 200, ID: "pf_1" },
            { ChargeLinkID: "2", RateValue: 210, ID: "pf_2" },
            { ChargeLinkID: "3", RateValue: 290, ID: "pf_3" }
        ];
        it("should return all charges if MinTargets is set and met", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MinTargetsRequired = 2;
            var filteredCharges = DiscountChargeUtilities.FilterByMinimumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(0);
            done();
        });
        it("should return no charges if MinTargets is set but not met", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MinTargetsRequired = 4;
            var filteredCharges = DiscountChargeUtilities.FilterByMinimumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(0);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(3);
            done();
        });
        it("should return all charges if MinTargets is not set", function (done) {
            targetAdjustment.UnalteredTargets = [];
            adjustment.MinTargetsRequired = undefined;
            var filteredCharges = DiscountChargeUtilities.FilterByMinimumTargets(chargesToDiscount, adjustment, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(0);
            done();
        });
    });
    describe("RemoveAmbiguousCharges method", function () {
        var chargesToDiscount = [
            { ChargeLinkID: "1", RateValue: 200, ID: "pf_1", OrderfolioKey: "1" },
            { ChargeLinkID: "2", RateValue: 210, ID: "pf_2", OrderfolioKey: "2" },
            { ChargeLinkID: "3", RateValue: 290, ID: "pf_3", OrderfolioKey: "3" }
        ];
        it("should return no charges, when no rates are defined", function (done) {
            var interimRates = [];
            targetAdjustment.UnalteredTargets = [];
            var filteredCharges = DiscountChargeUtilities.RemoveAmbiguousCharges(chargesToDiscount, interimRates, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(0);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets[0].ID).to.equal("pf_1");
            chai.expect(targetAdjustment.UnalteredTargets[0].Reason).to.equal("AmbiguousChargeRate");
            chai.expect(targetAdjustment.UnalteredTargets[1].ID).to.equal("pf_2");
            chai.expect(targetAdjustment.UnalteredTargets[1].Reason).to.equal("AmbiguousChargeRate");
            chai.expect(targetAdjustment.UnalteredTargets[2].ID).to.equal("pf_3");
            chai.expect(targetAdjustment.UnalteredTargets[2].Reason).to.equal("AmbiguousChargeRate");
            done();
        });
        it("should return all charges, when all rates are defined", function (done) {
            var interimRates = [
                { OrderfolioKey: "1", Rate: { ID: "Rate1", Value: 10 } },
                { OrderfolioKey: "2", Rate: { ID: "Rate2", Value: 12 } },
                { OrderfolioKey: "3", Rate: { ID: "Rate3", Value: 14 } }
            ];
            targetAdjustment.UnalteredTargets = [];
            var filteredCharges = DiscountChargeUtilities.RemoveAmbiguousCharges(chargesToDiscount, interimRates, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(3);
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(0);
            done();
        });
        it("should return only the first 2 charges when there is no rate defined for the 3rd, the 3rd charge should be marked as ambiguous", function (done) {
            var interimRates = [
                { OrderfolioKey: "1", Rate: { ID: "Rate1", Value: 10 } },
                { OrderfolioKey: "2", Rate: { ID: "Rate2", Value: 12 } }
            ];
            targetAdjustment.UnalteredTargets = [];
            var filteredCharges = DiscountChargeUtilities.RemoveAmbiguousCharges(chargesToDiscount, interimRates, targetAdjustment);
            chai.expect(filteredCharges.length).to.equal(2);
            chai.expect(filteredCharges[0].ChargeLinkID).to.equal("1");
            chai.expect(filteredCharges[1].ChargeLinkID).to.equal("2");
            chai.expect(targetAdjustment.UnalteredTargets.length).to.equal(1);
            chai.expect(targetAdjustment.UnalteredTargets[0].ID).to.equal("pf_3");
            chai.expect(targetAdjustment.UnalteredTargets[0].Reason).to.equal("AmbiguousChargeRate");
            done();
        });
    });
    describe("GetInterimRateForCharge method", function () {
        var interimRates = [
            { OrderfolioKey: "1", Rate: { ID: "Rate1", Value: 10 } },
            { OrderfolioKey: "2", Rate: { ID: "Rate2", Value: 12 } },
            { OrderfolioKey: "3", Rate: { ID: "Rate3", Value: 14 } }
        ];
        it("should return the first rate matching the charge orderfoliokey", function (done) {
            var charge = { ChargeLinkID: "2", RateValue: 210, ID: "pf_2", OrderfolioKey: "2" };
            var result = DiscountChargeUtilities.GetRateForCharge(interimRates, charge);
            chai.expect(result.Rate.ID).to.equal("Rate2");
            chai.expect(result.Rate.Value).to.equal(12);
            done();
        });
        it("should return undefined if no rates match the charge", function (done) {
            var charge = { ChargeLinkID: "5", RateValue: 210, ID: "pf_5", OrderfolioKey: "5" };
            var result = DiscountChargeUtilities.GetRateForCharge(interimRates, charge);
            chai.expect(result).to.be.undefined;
            done();
        });
    });
});

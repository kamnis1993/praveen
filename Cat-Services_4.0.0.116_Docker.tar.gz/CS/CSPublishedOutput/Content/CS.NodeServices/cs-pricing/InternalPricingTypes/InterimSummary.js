"use strict";
var PricingInformation = require("./PricingInformation");
/**
 * Internal class used to calculate the recurring and non recurring charge and cost totals
 * This class is required because we need to use jsdecimal to add decimals together accurately
 * When all the calculation is complete the result will be converted to a number so it can be put in the response
 */
var InterimSummary = /** @class */ (function () {
    function InterimSummary() {
        this.NonRecurringCharges = new PricingInformation();
        this.RecurringCharges = [];
        this.NonRecurringCosts = new PricingInformation();
        this.RecurringCosts = [];
    }
    return InterimSummary;
}());
module.exports = InterimSummary;

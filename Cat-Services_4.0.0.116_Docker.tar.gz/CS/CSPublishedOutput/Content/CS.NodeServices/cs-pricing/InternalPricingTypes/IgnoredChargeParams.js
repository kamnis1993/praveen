"use strict";
/**
* Class provides a structure to hold parameter options for ignored charges.
*/
var IgnoredChargeParams = /** @class */ (function () {
    function IgnoredChargeParams() {
        this.NoEntityLinksToCharge = false;
        this.MissingCostRate = false;
        this.NoValidCosts = false;
        this.EntityLinkId = undefined;
        this.NoSpecRate = false;
        this.NoUnitRate = false;
        this.RateDetailIncorrectDefinition = false;
        this.RateOverrideRateAttributeMismatch = false;
        this.InvalidRateActivationDate = false;
    }
    return IgnoredChargeParams;
}());
module.exports = IgnoredChargeParams;

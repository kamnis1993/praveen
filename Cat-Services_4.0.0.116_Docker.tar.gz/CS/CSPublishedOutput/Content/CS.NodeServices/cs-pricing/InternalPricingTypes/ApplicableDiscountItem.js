"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/OrderfolioTypes.d.ts" />
/**
* Class provides a structure to hold details for Applicable Discounts aka Legacy Discounts.
*/
var ApplicableDiscountItem = /** @class */ (function () {
    function ApplicableDiscountItem() {
        this.OrderfolioKey = undefined;
        this.ApplicableDiscounts = undefined;
    }
    return ApplicableDiscountItem;
}());
module.exports = ApplicableDiscountItem;

"use strict";
/**
* Class provides a structure to hold parameter options for ignored discounts.
*/
var IgnoredDiscountParams = /** @class */ (function () {
    function IgnoredDiscountParams() {
        this.NoEntityLinksToDiscount = false;
        this.MissingChargeRate = false;
        this.NoValidCharges = false;
        this.EntityLinkId = undefined;
        this.NoSpecRate = false;
        this.NoUnitRate = false;
    }
    return IgnoredDiscountParams;
}());
module.exports = IgnoredDiscountParams;

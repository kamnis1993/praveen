"use strict";
/// <reference path="../../cs-lib-types/CompiledTypes/OrderfolioTypes.d.ts" />
/**
* Class provides a structure to hold details for a calculated rate.
*/
var InterimRate = /** @class */ (function () {
    function InterimRate() {
        this.OrderfolioKey = undefined;
        this.Rate = undefined;
    }
    return InterimRate;
}());
module.exports = InterimRate;

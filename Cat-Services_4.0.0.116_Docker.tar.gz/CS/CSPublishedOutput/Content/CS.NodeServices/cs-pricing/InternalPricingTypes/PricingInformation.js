"use strict";
var decimal = require("jsdecimal");
/**
 * Internal class used to store information about recurring charges or costs
 */
var PricingInformation = /** @class */ (function () {
    function PricingInformation() {
        this.MinimumTotal = new decimal(0);
        this.FinalTotal = new decimal(0);
        this.AdjustmentTotal = new decimal(0);
        this.OriginalTotal = new decimal(0);
    }
    return PricingInformation;
}());
module.exports = PricingInformation;

"use strict";
/**
* Class provides a structure to hold parameter options for ignored charges.
*/
var IgnoredCostParams = /** @class */ (function () {
    function IgnoredCostParams() {
        this.NoSpecRate = false;
        this.RateDetailIncorrectDefinition = false;
        this.RateOverrideRateAttributeMismatch = false;
        this.InvalidRateActivationDate = false;
        this.NoUnitRate = false;
    }
    return IgnoredCostParams;
}());
module.exports = IgnoredCostParams;

"use strict";
/// <reference path="../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
/// <reference path="../cs-lib-types/CompiledTypes/OrderfolioTypes.d.ts" />
var decimal = require("jsdecimal");
var AdjustmentTypes = require("../cs-lib-constants/AdjustmentTypes");
var ChargeTypes = require("../cs-lib-constants/ChargeTypes");
var DiscountChargeUtilities = require("./DiscountUtilities/DiscountChargeUtilities");
var DiscountSetupUtilities = require("./DiscountUtilities/DiscountSetupUtilities");
var IgnoredDiscountParams = require("./InternalPricingTypes/IgnoredDiscountParams");
var IsExclusiveUtilities = require("./DiscountUtilities/IsExclusiveUtilities");
var IgnoredReasonTypes = require("../cs-lib-constants/IgnoredReasonTypes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var ApplicableDiscountItem = require("./InternalPricingTypes/ApplicableDiscountItem");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var OrderOfExecutionUtilities = require("./DiscountUtilities/OrderOfExecutionUtilities");
var PricingUtilities = require("./PricingUtilities");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
* Class provides methods for calculating and applying discounts for pricing
*/
var DiscountEngine = /** @class */ (function () {
    function DiscountEngine() {
    }
    /**
     * Processes all discounts and updates the pricing summaries
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @param {Array<InterimRate>} interimRates
     */
    DiscountEngine.PopulateChargeBasedDiscountRates = function (discountLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        // Summary for recurring charges doesnt have adjustment and orignal values so initialise them to 0
        DiscountSetupUtilities.AddAdjustAndOrigTotalsToRecurring(interimSummary, interimRootItemSummary);
        if (!DiscountEngine.DiscountsPresent(discountLookups)) {
            return;
        }
        // Build object to contain original values prior to any adjustments
        var originalValues = DiscountSetupUtilities.BuildOriginalValuesObject(interimSummary, interimRootItemSummary);
        // Collect the Uuids of all discounts in discountLookups
        var discountIDs = [];
        discountIDs = DiscountSetupUtilities.GatherDiscountUuids(discountIDs, discountLookups, decomposeContext.Orderfolio);
        var newLookups = LodashUtilities.CloneDeep(discountLookups);
        // Delete any discounts info that is not present in the orderfolio
        newLookups = DiscountSetupUtilities.RemoveMissingOrderfolioDiscounts(newLookups, discountIDs);
        // Filter rates so for features such as IsExclusive and OrdOfExec we always deal with the correct rate
        newLookups = DiscountSetupUtilities.ConsolidateOrderfolioRates(newLookups, decomposeContext);
        // Store all order of execution values
        var ordOfExecutionValues = [];
        ordOfExecutionValues = OrderOfExecutionUtilities.GatherOrderOfExecValues(newLookups, ordOfExecutionValues);
        // Determine if there is at least one Exclusive discount
        // if there is at least one, any discount that is not exclusive must not apply
        var exclusiveDiscountPresent = IsExclusiveUtilities.ContainsExclusiveDiscount(newLookups);
        var uuidsProcessed = [];
        var _loop_1 = function (i) {
            var multiTypes;
            // Determine if Multiple Adjustments are present
            // This has to depend on whether or not we have an exclusive discountUuid
            // if we have a flat and a percentage but one is exclusive we dont flag multiple types are present
            // As the non exclusive isnt applied
            multiTypes = OrderOfExecutionUtilities.DetermineMultipleAdjustmentsPresent(exclusiveDiscountPresent, newLookups, multiTypes, ordOfExecutionValues, i);
            var firstExclusiveOrdOfExecValue = OrderOfExecutionUtilities.GetFirstExclusiveOrderOfExecution(newLookups);
            Object.keys(newLookups.DiscountUuidToDiscountInfo).forEach(function (discountUuid) {
                var discountInfo = discountLookups.DiscountUuidToDiscountInfo[discountUuid];
                // If the customer has not defined any charges to apply this discount against, don't try to process it.
                if (Utilities.IsNotDefined(newLookups.DiscountUuidToRateInfo[discountUuid][0].ChargeAdjustments, true)) {
                    Logger.debug(10, "Pricing", "Compiled spec discount at UUID '" + discountInfo.Name + "' has no associated charges");
                    return;
                }
                // Check if higher absolute adjustment exists but if this discount is exclusive and the absolute one is not we can ignore it
                var isExclusive = newLookups.DiscountUuidToRateInfo[discountUuid][0].IsExclusive;
                var absoluteDiscounts = [];
                var higherAbsoluteExists = OrderOfExecutionUtilities.HigherAbsoluteExists(newLookups, ordOfExecutionValues, i, absoluteDiscounts);
                if (higherAbsoluteExists) {
                    // A higher absolute might exist and we have the Uuid for all absolute adjustments, check all of them (and their ordOfExe numbers) and see if any are exclusive
                    // If the current discount is exclusive and a later absolute is not set HigherAbsoluteExists back to false
                    higherAbsoluteExists = IsExclusiveUtilities.CheckIfAbsoluteIsExclusive(newLookups, absoluteDiscounts, discountUuid, higherAbsoluteExists);
                }
                if (newLookups.DiscountUuidToRateInfo[discountUuid][0].OrderOfExecution === ordOfExecutionValues[i]) {
                    uuidsProcessed.push(discountUuid);
                    var discountRates_1 = discountLookups.DiscountUuidToRateInfo[discountUuid] || [];
                    var orderfolioDiscounts = decomposeContext.Orderfolio[discountUuid];
                    if (Utilities.IsNotDefined(orderfolioDiscounts, true)) {
                        Logger.debug(10, "Pricing", "Compiled spec discount at UUID '" + discountInfo.Name + "' either found no match in the orderfolio or had no rates");
                        return;
                    }
                    orderfolioDiscounts.forEach(function (discount) {
                        DiscountEngine.PopulateChargeBasedDiscountRate(discount, decomposeContext, discountRates_1, discountInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates, multiTypes, exclusiveDiscountPresent, higherAbsoluteExists, firstExclusiveOrdOfExecValue);
                    });
                }
            });
        };
        for (var i = 0; i < ordOfExecutionValues.length; i++) {
            _loop_1(i);
        }
        // check which discountIDs have not been processed
        var missing = discountIDs.filter(function (item) { return uuidsProcessed.indexOf(item) < 0; });
        if (missing.length > 0) {
            DiscountEngine.ProcessInvalidDiscounts(missing, discountLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates, exclusiveDiscountPresent);
        }
        DiscountEngine.UpdateOriginalValues(originalValues, interimSummary, interimRootItemSummary);
    };
    /**
     * Pass each discount into PopulateCBDRate()
     * This will correctly create ignored discounts in the situation where no rates
     * or excluded discounts are used
     * @param {any[]} discountsToProcess
     * @param {CsTypes.DiscountLookups} discountLookups
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @param {InterimRate[]} interimRates
     * @param {boolean} exclusiveDiscountPresent
     */
    DiscountEngine.ProcessInvalidDiscounts = function (discountsToProcess, discountLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates, exclusiveDiscountPresent) {
        discountsToProcess.forEach(function (discountUuid) {
            var discountInfo = discountLookups.DiscountUuidToDiscountInfo[discountUuid];
            var discountRates = discountLookups.DiscountUuidToRateInfo[discountUuid] || [];
            var orderfolioDiscounts = decomposeContext.Orderfolio[discountUuid];
            if (Utilities.IsNotDefined(orderfolioDiscounts, true)) {
                Logger.debug(10, "Pricing", "Compiled spec discount '" + discountInfo.Name + "' either found no match in the orderfolio or had no rates");
                return;
            }
            orderfolioDiscounts.forEach(function (discount) {
                DiscountEngine.PopulateChargeBasedDiscountRate(discount, decomposeContext, discountRates, discountInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates, false, exclusiveDiscountPresent, false, 0);
            });
        });
    };
    /**
     * Processes a specific discount and updates the pricing summaries
     * @param {CsTypes.OrderfolioItem} discount
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {Array<CsTypes.RateInfo>} discountRates
     * @param {CsTypes.DiscountInfo} discountInfo
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @param {InterimSummary} originalSummary
     * @param {InterimSummary} originalRootItemSummary
     * @param {Array<InterimRate>} interimRates
     * @param {boolean} multiTypes
     * @param {boolean} isExclusive
     * @param {boolean} higherAbsoluteExists
     * @param {number} firstExclusiveOrdOfExecValue
     */
    DiscountEngine.PopulateChargeBasedDiscountRate = function (discount, decomposeContext, discountRates, discountInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates, multiTypes, isExclusive, higherAbsoluteExists, firstExclusiveOrdOfExecValue) {
        Logger.debug(10, "Pricing", "Pricing charge-based discount " + discount.EntityUniqueCode);
        if (!DiscountEngine.DiscountHasValidAction(discount)) {
            return;
        }
        var ignoredDiscountParams = new IgnoredDiscountParams();
        if (!DiscountEngine.DiscountIsValid(discount, discountRates, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary)) {
            return;
        }
        // Excluded discount shouldn't be priced
        if (discount.IsExcludedDiscount) {
            var ignoredDiscountParams_1 = new IgnoredDiscountParams();
            DiscountEngine.CreateIgnoredDiscount(discount, undefined, decomposeContext, discountInfo, ignoredDiscountParams_1, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // Originally this existed as an earlier check, but this prevented excluded entities from being caught (as they have no rates).
        // It's not recorded as an ignored entity
        if (Utilities.IsNotDefined(discountRates, true)) {
            Logger.debug(20, "Pricing", "Compiled spec discount '" + discountInfo.Name + "' either found no match in the orderfolio or had no rates");
            return;
        }
        var filteredDiscountRates = PricingUtilities.FilterRates(decomposeContext.ActivationDate, discountRates, discount.RatingAttributes, discountInfo.ExclusiveRateAttributeValues);
        if (Utilities.IsNotDefined(filteredDiscountRates, true) || filteredDiscountRates.length !== 1) {
            ignoredDiscountParams = new IgnoredDiscountParams();
            DiscountEngine.CreateIgnoredDiscount(discount, filteredDiscountRates, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var unambiguousRate = filteredDiscountRates[0];
        if (Utilities.IsNotDefined(unambiguousRate, true)) {
            ignoredDiscountParams = new IgnoredDiscountParams();
            DiscountEngine.CreateIgnoredDiscount(discount, filteredDiscountRates, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var chargesToDiscount = [];
        Logger.debug(20, "Pricing", "Retrieving charge targets");
        var adjustments = {
            RateID: unambiguousRate.RateGuid,
            TargetAdjustment: [],
            InvalidAdjustment: [],
            IsExclusive: unambiguousRate.IsExclusive,
            OrderOfExecution: unambiguousRate.OrderOfExecution,
            Description: unambiguousRate.DiscountDescription
        };
        // Also populates chargesToDiscount
        var discountIgnored = DiscountEngine.FindOrderfolioChargesForDiscount(chargesToDiscount, interimRates, unambiguousRate, decomposeContext, discount, discountInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, adjustments.InvalidAdjustment);
        if (discountIgnored) {
            return;
        }
        Logger.debug(30, "Pricing", "Calculating discount adjustments using rate data", { Subtype: "RateInfo", RateInfo: unambiguousRate });
        // We now have the details for the associated charges, so now the adjustments can be applied
        discount.TargetAdjustmentSet = DiscountEngine.UpdateInterimRates(discount, chargesToDiscount, interimRates, unambiguousRate, adjustments, multiTypes, isExclusive, higherAbsoluteExists, firstExclusiveOrdOfExecValue);
        PricingUtilities.PopulateMissingRateAttributes(discount, unambiguousRate.RateAttributes);
        // Get the chargeType of each portfolio item targetted by this discount
        var typeToTargetLookup = [];
        DiscountEngine.GetTargetChargeTypes(typeToTargetLookup, discount, decomposeContext.Orderfolio);
        for (var x = 0; x < typeToTargetLookup.length; x++) {
            DiscountEngine.UpdateChargeSummary(typeToTargetLookup[x], discountInfo, interimRootItemSummary);
            DiscountEngine.UpdateChargeSummary(typeToTargetLookup[x], discountInfo, interimSummary);
        }
    };
    /**
     * Applies discount adjustments to each applicable charge rate
     * @param {any[]} chargesToDiscount
     * @param {InterimRate[]} interimRates
     * @param {CsTypes.RateInfo} discountRate
     * @param {CsTypes.TargetAdjustmentSet} adjustments
     * @param {boolean} multiTypes
     * @param {boolean} isExclusive
     * @param {boolean} higherAbsoluteExists
     * @param {number} firstExclusiveOrdOfExecValue
     */
    DiscountEngine.UpdateInterimRates = function (discount, chargesToDiscount, interimRates, discountRate, adjustments, multiTypes, isExclusive, higherAbsoluteExists, firstExclusiveOrdOfExecValue) {
        if (Utilities.IsNotDefined(discountRate.ChargeAdjustments, true)) {
            Logger.debug(20, "Pricing", "No charge adjustments found", { SubType: "DiscountUniqueCode", DiscountUniqueCode: discount.EntityUniqueCode });
            return adjustments;
        }
        discountRate.ChargeAdjustments.forEach(function (adjustment) {
            // Create the adjustment details
            var targetAdjustment = {
                Targets: [],
                UnalteredTargets: [],
                ID: adjustment.AdjustmentGuid,
                LinkID: undefined,
                Type: adjustment.AdjustmentType,
                Amount: JSON.parse(adjustment.Amount),
                Description: adjustment.Description,
                MostExpensiveFirst: adjustment.MostExpensiveFirst,
                MaxTargets: adjustment.MaxTargets,
                MinTargetsRequired: adjustment.MinTargetsRequired
            };
            // reduce chargesToDiscount to charges related to the current adjustment
            var adjustmentCharges = DiscountChargeUtilities.GetChargesForAdjustment(chargesToDiscount, adjustment);
            // The order of these matters, do not change them about without investigating the consequences!
            adjustmentCharges = DiscountChargeUtilities.ApplyChargeFilters(adjustmentCharges, adjustment, targetAdjustment, interimRates);
            adjustmentCharges.forEach(function (adjustmentCharge) {
                // Is the charge applicable for this adjustment?
                if (adjustment.AdjustmentGuid !== adjustmentCharge.ChargeLinkID) {
                    return;
                }
                // Get the interim rate for the charge
                var interimRate = interimRates.filter(function (rate) {
                    return rate.OrderfolioKey === adjustmentCharge.OrderfolioKey;
                });
                if (interimRate.length === 0) {
                    // Create Unaltered Target
                    targetAdjustment.UnalteredTargets.push({ ID: adjustmentCharge.ID, Reason: "AmbiguousChargeRate" });
                    return;
                }
                // Multiple Adjustments are present of different types (or multiple absolute)
                // At a single OrdOfExec number
                if (multiTypes) {
                    targetAdjustment.UnalteredTargets.push({ ID: adjustmentCharge.ID, Reason: "AmbiguousCalculation" });
                    return;
                }
                // if IsExclusive is defined that means at least one Exclusive discount is exclusive
                // Then check if this particular discount is exclusive
                if (isExclusive) {
                    // Do not process any non-exclusive discounts
                    if (discountRate.IsExclusive.toString() !== "true") {
                        targetAdjustment.UnalteredTargets.push({ ID: adjustmentCharge.ID, Reason: "FilteredExclusive" });
                        return;
                    }
                    else if (discountRate.OrderOfExecution > firstExclusiveOrdOfExecValue) {
                        // If the rate is exclusive, but it has a higher OrdOfExec than another exclusive rate, then filter it
                        targetAdjustment.UnalteredTargets.push({ ID: adjustmentCharge.ID, Reason: "FilteredExclusive" });
                        return;
                    }
                }
                // An absolute adjustment exists at a higher order of execution value
                // So whatever value this adjustment would apply, it will be overwritten later
                if (higherAbsoluteExists) {
                    if (discountRate.OrderOfExecution !== firstExclusiveOrdOfExecValue) {
                        targetAdjustment.UnalteredTargets.push({ ID: adjustmentCharge.ID, Reason: "OveriddenAbsolute" });
                        return;
                    }
                }
                var rateToAdjust = interimRate[0].Rate;
                var discountValue = DiscountEngine.ApplyAdjustmentToInterimRate(rateToAdjust, discountRate, adjustment, targetAdjustment, adjustmentCharge);
                // Build the adjustmentItem that sits on the charge rate.
                var adjustmentItem = {
                    Amount: adjustment.Amount,
                    Source: {
                        ID: discount.EntityUniqueCode,
                        EntityID: discount.EntityId,
                        RateID: discountRate.RateGuid,
                        AdjustmentID: adjustment.AdjustmentGuid
                    },
                    Type: adjustment.AdjustmentType,
                    Value: discountValue,
                    IsExclusive: discountRate.IsExclusive,
                    OrderOfExecution: discountRate.OrderOfExecution,
                    DiscountDescription: discountRate.DiscountDescription,
                    AdjustmentDescription: adjustment.Description
                };
                rateToAdjust.RateAdjustment.AdjustmentItem.push(adjustmentItem);
            });
            adjustments.TargetAdjustment.push(targetAdjustment);
        });
        return adjustments;
    };
    /**
     * Applies the details of the discount adjustment to the charge's interim rate
     * @param {CsTypes.Rate} rateToAdjust the charge rate to update
     * @param {CsTypes.RateInfo} discountRate the spec discount rate to apply
     * @param {CsTypes.AdjustmentInfo} adjustment the details of the current adjustment to apply
     * @param {CsTypes.TargetAdjustment} targetAdjustment the details of the adjustment being applied to the charge
     * @param {any} chargeToDiscount the charge details
     */
    DiscountEngine.ApplyAdjustmentToInterimRate = function (rateToAdjust, discountRate, adjustment, targetAdjustment, chargeToDiscount) {
        var rateValue = new decimal(rateToAdjust.Value);
        // Set OriginalValue before changing anything
        if (Utilities.IsNotDefined(rateToAdjust.OriginalValue)) {
            rateToAdjust.OriginalValue = rateValue.toFloat();
        }
        var result;
        var discountAmount = new decimal(adjustment.Amount);
        var discountApplied = new decimal(0);
        // Calculate the discount adjustment value
        switch (adjustment.AdjustmentType) {
            case AdjustmentTypes.Flat:
                // Invert the discount value
                discountAmount = discountAmount.neg();
                result = rateValue.add(discountAmount);
                discountApplied = discountAmount;
                break;
            case AdjustmentTypes.Percentage:
                // Invert the discount value
                discountAmount = discountAmount.neg();
                var discountPercentage = discountAmount.div(100);
                discountApplied = rateValue.mul(discountPercentage);
                result = rateValue.add(discountApplied);
                break;
            case AdjustmentTypes.Absolute:
                // Do not invert the discount value until discount value applied has been calculated
                result = discountAmount;
                discountApplied = rateValue.sub(discountAmount).neg();
                break;
        }
        var discountValue = discountApplied.toFloat();
        // Update the interim rate value
        rateToAdjust.Value = result.toString();
        // Update the adjustment details
        if (Utilities.IsNotDefined(rateToAdjust.RateAdjustment)) {
            var rateAdjustment = {
                Total: 0,
                AdjustmentItem: []
            };
            rateToAdjust.RateAdjustment = rateAdjustment;
        }
        rateToAdjust.RateAdjustment.Total += discountValue;
        // Create details of the charge instance targeted by the discount
        var target = {
            ID: chargeToDiscount.ID,
            Value: discountValue
        };
        targetAdjustment.Targets.push(target);
        return discountValue;
    };
    /**
     * Updates the charge summary with the rate provided
     * @param {any} typeToTargetLookup contains the amount, type and periodicity of each charge
     * @param {CsTypes.DiscountInfo} discountInfo The object containing the charge information
     * @param {ChargeSummary} chargeSummary The charge summary to update
     */
    DiscountEngine.UpdateChargeSummary = function (typeToTargetLookup, discountInfo, chargeSummary) {
        var discountValue = new decimal(typeToTargetLookup.Amount);
        var chargeType = typeToTargetLookup.Type;
        var chargePeriodicity = typeToTargetLookup.Periodicity;
        if (chargeType === ChargeTypes.RecurringCharge ||
            chargeType === ChargeTypes.StandaloneRecurringCharge ||
            chargeType === ChargeTypes.RecurringCostBasedCharge) {
            DiscountEngine.UpdateRecurringCharges(chargeSummary, discountValue, chargePeriodicity);
        }
        else {
            DiscountEngine.UpdateNonRecurringCharges(chargeSummary, discountValue);
        }
    };
    /**
     * Add discountValue onto the recurring charges total
     * @param {InterimSummary} chargeSummary
     * @param {decimal} discountValue
     * @param {string} chargePeriodicity
     * @return {void}
     */
    DiscountEngine.UpdateRecurringCharges = function (chargeSummary, discountValue, chargePeriodicity) {
        var selectedPeriod = LodashUtilities.Find(chargeSummary.RecurringCharges, function (p) { return p.Name === chargePeriodicity; });
        selectedPeriod.MinimumTotal = selectedPeriod.MinimumTotal.add(discountValue);
        if (selectedPeriod.FinalTotal !== "N/A") {
            selectedPeriod.FinalTotal = (selectedPeriod.FinalTotal).add(discountValue);
        }
        selectedPeriod.AdjustmentTotal = selectedPeriod.AdjustmentTotal.add(discountValue);
    };
    /**
     * Add discountValue onto the nonrecurring charges total
     * @param {InterimSummary} chargeSummary
     * @param {decimal} discountValue
     * @return {void}
     */
    DiscountEngine.UpdateNonRecurringCharges = function (chargeSummary, discountValue) {
        var nonRecurringCharges = chargeSummary.NonRecurringCharges;
        var finalTotal = nonRecurringCharges.FinalTotal;
        nonRecurringCharges.MinimumTotal = nonRecurringCharges.MinimumTotal.add(discountValue);
        if (nonRecurringCharges.FinalTotal !== "N/A") {
            nonRecurringCharges.FinalTotal = finalTotal.add(discountValue);
        }
        nonRecurringCharges.AdjustmentTotal = nonRecurringCharges.AdjustmentTotal.add(discountValue);
    };
    /**
     * Returns all applicable charges in the orderfolio
     * @param {Array<any>} chargesToApply
     * @param {Array<InterimRate>} interimRates
     * @param {CsTypes.RateInfo} unambiguousRate
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {CsTypes.OrderfolioItem} discount
     * @param {CsTypes.DiscountInfo} discountInfo
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     * @param {CsTypes.InvalidItem[]} invalidAdjustments
     */
    DiscountEngine.FindOrderfolioChargesForDiscount = function (chargesToApply, interimRates, unambiguousRate, decomposeContext, discount, discountInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, invalidAdjustments) {
        var discountIgnored = false;
        if (Utilities.IsNotDefined(unambiguousRate.TargetedCharges)) {
            return discountIgnored;
        }
        unambiguousRate.TargetedCharges.every(function (targetedCharge) {
            // Retrieve the entity link from this target, if one exists
            var targetEntityLink = targetedCharge.EntityLinkReference;
            // Instantiate a new object to store any entities linked to or from this charge, identified by this target's entity link.
            // This will also store any children of entities linked in this way. The store will be keyed using the PortfolioItemID of the orderfolio entity link.
            var linkedEntitiesForTarget = [];
            // If this target has an entity link, build a store of entities which are linked and their descendents.
            // Use this store to identify if the charge itself is linked by this entity link.
            if (Utilities.IsDefined(targetEntityLink)) {
                // For each instance of the entity link, get sources and targets and their descendents.
                PricingUtilities.FilterEntityLinkInstances(decomposeContext, targetEntityLink, discount, linkedEntitiesForTarget);
                // Check whether the discount is targeted by any instance of the entity link before continuing
                if (linkedEntitiesForTarget.length < 1) {
                    invalidAdjustments.push({ ID: targetedCharge.ChargeLinkID, Reason: "MissingEntityLink" });
                    return true;
                }
            }
            else {
                var impliedLink = targetedCharge.ImpliedLink;
                PricingUtilities.RetrieveInstancesByImpliedLink(decomposeContext, impliedLink, discount, linkedEntitiesForTarget);
                // An implied link should always exist for the charge if an entity link was not explicitly defined. Therefore,
                // a charge cannot be ignored on the basis of not being targeted by an implied link.
            }
            var chargeTargets = decomposeContext.Orderfolio[targetedCharge.ChargeUuid.toString()];
            if (!chargeTargets) {
                return true;
            }
            chargeTargets.every(function (charge) {
                // only get charges in a valid action state
                var chargeAction = Utilities.ValueOrDefault(charge.Action, OrderActions.NoChange);
                if (!DiscountEngine.ChargeStateValidForChargeBasedDiscount(chargeAction)) {
                    return true;
                }
                // If using a costBasedCharge we need to check the state of any costs that it might target
                var costBasedChargeCostDetails = [];
                if (charge.ChargeType === ChargeTypes.NonRecurringCostBasedCharge) {
                    if (!DiscountEngine.CheckCBCCostTargetStates(decomposeContext.Orderfolio, decomposeContext.CompiledSpec.ChargeLookups, charge, costBasedChargeCostDetails)) {
                        return discountIgnored = true;
                    }
                }
                // Either an entity link or implied link will generate linked entities; however, the cost target may not
                // be linked by this charge
                if (!DiscountEngine.ChargeDiscountEntityLinked(linkedEntitiesForTarget, charge, discount)) {
                    return true;
                }
                var interimCharge = LodashUtilities.Find(interimRates, function (r) { return r.OrderfolioKey === charge.CompoundKey; });
                var chargeRate = Utilities.IsDefined(interimCharge) ? interimCharge.Rate : undefined;
                var chargeRateValue = Utilities.IsDefined(chargeRate) ? chargeRate.Value : 0;
                chargesToApply.push({ ChargeLinkID: targetedCharge.ChargeLinkID,
                    OrderfolioKey: charge.CompoundKey,
                    RateValue: chargeRateValue,
                    ID: charge.EntityUniqueCode,
                    EntityID: charge.EntityId,
                    ChargeType: charge.ChargeType,
                    ChargeAction: chargeAction,
                    CBCCostActions: costBasedChargeCostDetails });
                return true;
            });
            return true;
        });
        return discountIgnored;
    };
    /**
     * Checks if the order action of the charge is valid for the discount to be applied
     * @param {string} chargeState
     * @return {boolean}
     */
    DiscountEngine.ChargeStateValidForChargeBasedDiscount = function (chargeState) {
        return (chargeState === OrderActions.Add
            || chargeState === OrderActions.Update
            || chargeState === OrderActions.NoChange
            || chargeState === OrderActions.Reassigned
            || chargeState === OrderActions.ReassignedUpdate);
    };
    /**
     * Identifies whether a charge is linked to a discount by a given set of instances of an entity link
     * @param {CsTypes.EntityLinkSourceTargetDescendents[]} entityLinkInstances the instances of the entity link to use
     * @param {CsTypes.OrderfolioItem} charge the charge to check for linkage to the discount
     * @param {CsTypes.OrderfolioItem} discount the discount to be linked to
     */
    DiscountEngine.ChargeDiscountEntityLinked = function (entityLinkInstances, charge, discount) {
        for (var entityLinkInstancesIndex = 0; entityLinkInstancesIndex < entityLinkInstances.length; entityLinkInstancesIndex++) {
            var entityLinkInstance = entityLinkInstances[entityLinkInstancesIndex];
            var discountIsSource = entityLinkInstance.SourceDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(discount.CompoundKey)) > -1;
            // If the discount is the source of the entity link, check the targets for the charge;
            // else check the sources as the discount is the target
            var discountLinkedToCharge = discountIsSource ?
                entityLinkInstance.TargetDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(charge.CompoundKey)) > -1 :
                entityLinkInstance.SourceDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(charge.CompoundKey)) > -1;
            // If at least one entity link instance exists between the discount and the charge then they are linked. Do not continue to process.
            if (discountLinkedToCharge) {
                return true;
            }
        }
        return false;
    };
    /**
     * Determines whether the discount's action state is valid
     * @param {CsTypes.OrderfolioItem} discount the discount to check
     */
    DiscountEngine.DiscountHasValidAction = function (discount) {
        if (discount.Action === OrderActions.Delete ||
            discount.Action === OrderActions.Reassign) {
            Logger.debug(20, "Pricing", "The item action on the discount is invalid for pricing", { Subtype: "DiscountAction", ChargeAction: discount.Action });
            return false;
        }
        return true;
    };
    /**
     * Checks if the discount is valid
     * @param {CsTypes.OrderfolioItem} discount
     * @param {Array<CsTypes.RateInfo>} specDiscountRates
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {CsTypes.DiscountInfo} discountInfo
     * @param {IgnoredDiscountParams} ignoredDiscountParams
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     */
    DiscountEngine.DiscountIsValid = function (discount, specDiscountRates, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        if (specDiscountRates.length === 0) {
            ignoredDiscountParams.NoSpecRate = true;
            DiscountEngine.CreateIgnoredDiscount(discount, undefined, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return false;
        }
        if (discount.IsInvalid) {
            DiscountEngine.CreateIgnoredDiscount(discount, undefined, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return false;
        }
        return true;
    };
    /**
     * Create the details for the ignored discount on the pricing summary
     * @param {CsTypes.OrderfolioItem} discount
     * @param {Array<CsTypes.RateInfo>} filteredDiscountRates
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {CsTypes.DiscountInfo} discountInfo
     * @param {IgnoredDiscountParams} ignoredDiscountParams
     * @param {ISummary} grandSummary
     * @param {RootItemSummary} rootItemSummary
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     */
    DiscountEngine.CreateIgnoredDiscount = function (discount, filteredDiscountRates, decomposeContext, discountInfo, ignoredDiscountParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        var ignoredDiscountDetails = DiscountEngine.CreateIgnoredDiscountDetails(discount, filteredDiscountRates, decomposeContext, ignoredDiscountParams);
        DiscountEngine.UpdateIgnoredDiscounts(ignoredDiscountDetails, grandSummary, discountInfo, interimSummary.RecurringCharges);
        DiscountEngine.UpdateIgnoredDiscounts(ignoredDiscountDetails, rootItemSummary.ItemSummary, discountInfo, interimRootItemSummary.RecurringCharges);
        Logger.debug(20, "Pricing", "Ignored discount", { Subtype: "ignoredDiscount", ignoredDiscountDetails: ignoredDiscountDetails, filteredDiscountRates: filteredDiscountRates });
        return;
    };
    /**
     * Create the details for the ignored discount
     * @param {CsTypes.OrderfolioItem} discount
     * @param {CsTypes.RateInfo[]} filteredDiscountRates
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {IgnoredDiscountParams} params
     */
    DiscountEngine.CreateIgnoredDiscountDetails = function (discount, filteredDiscountRates, decomposeContext, params) {
        var parentOrderfolioLookup = decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(discount.CompoundKey)];
        var discountParent = undefined;
        if (Utilities.IsDefined(parentOrderfolioLookup)) {
            discountParent = decomposeContext.Orderfolio[parentOrderfolioLookup.Key.toString()][parentOrderfolioLookup.Index];
        }
        if (discount.IsExcludedDiscount) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "Excluded", IgnoredReasonTypes.DiscountExcluded);
        }
        else if (discount.IsInvalid) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "OutdatedDiscount", IgnoredReasonTypes.ExpiredDiscount);
        }
        else if (params.NoSpecRate) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "AmbiguousRates", IgnoredReasonTypes.NoRateOnDiscount);
        }
        else if (Utilities.IsDefined(filteredDiscountRates) && filteredDiscountRates.length < 1) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "AmbiguousRates", IgnoredReasonTypes.NoValidRate);
        }
        else if (Utilities.IsDefined(filteredDiscountRates) && filteredDiscountRates.length > 1) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "AmbiguousRates", IgnoredReasonTypes.MultipleAmbiguousRates);
        }
        else if (params.NoEntityLinksToDiscount) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "AmbiguousEntityLink", IgnoredReasonTypes.NoEntityLinksToDiscount, params.EntityLinkId);
        }
        else if (params.MissingChargeRate) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "AmbiguousReferencedChargeRate", IgnoredReasonTypes.MissingChargeRate);
        }
        else if (params.NoValidCharges) {
            return DiscountEngine.CreateIgnoredDiscountDetail(discount, discountParent, "NoValidReferencedCharges", IgnoredReasonTypes.NoValidChargeProvided);
        }
        return undefined;
    };
    /**
     * Create the details for the ignored discount
     * @param {CsTypes.OrderfolioItem} discount
     * @param {CsTypes.OrderfolioItem} discountParent
     * @param {string} reason
     * @param {string} reasonDescription
     * @param {string} entityLinkId
     */
    DiscountEngine.CreateIgnoredDiscountDetail = function (discount, discountParent, reason, reasonDescription, entityLinkId) {
        entityLinkId = entityLinkId || undefined;
        return {
            ID: discount.EntityUniqueCode,
            Reason: reason,
            ReasonDetails: {
                EntityID: discount.EntityId,
                ParentEntityUniqueCode: Utilities.IsNotDefined(discountParent) ? undefined : discountParent.EntityUniqueCode,
                ParentEntityID: Utilities.IsNotDefined(discountParent) ? undefined : discountParent.EntityId,
                Description: reasonDescription,
                EntityLinkID: entityLinkId
            }
        };
    };
    /**
     * Add the ignored discount to the pricing summary
     * @param {IIgnoredDiscount} ignoredDiscount
     * @param {ISummary} itemSummary
     * @param {CsTypes.DiscountInfo} discountInfo
     * @param {PricingInformation[]} recurringCharges
     */
    DiscountEngine.UpdateIgnoredDiscounts = function (ignoredDiscount, itemSummary, discountInfo, recurringCharges) {
        itemSummary.IgnoredDiscounts.push(ignoredDiscount);
    };
    /**
     * Decide whether to apply a FinalTotal value dependent on the reason for the ignored charge
     * @param {IIgnoredDiscount} ignoredDiscount the ignored discount
     */
    DiscountEngine.ApplyFinalTotal = function (ignoredDiscount) {
        if (["AmbiguousRates", "AmbiguousEntityLink", "AmbiguousReferencedChargeRate", "NoValidReferencedCharges"].indexOf(ignoredDiscount.Reason) > -1) {
            return false;
        }
        return true;
    };
    /**
     * Update originalTotal values on NonRecurringCharges and RecurringCharges
     * @param {any} originalValues
     * @param {InterimSummary} interimSummary
     * @param {InterimSummary} interimRootItemSummary
     */
    DiscountEngine.UpdateOriginalValues = function (originalValues, interimSummary, interimRootItemSummary) {
        // NonRecurring
        if (Utilities.IsDefined(interimSummary.NonRecurringCharges.AdjustmentTotal, true)) {
            interimSummary.NonRecurringCharges.OriginalTotal = originalValues.NonRecurring.OriginalTotal;
        }
        if (Utilities.IsDefined(interimRootItemSummary.NonRecurringCharges.AdjustmentTotal, true)) {
            interimRootItemSummary.NonRecurringCharges.OriginalTotal = originalValues.NonRecurring.OriginalRootItemTotal;
        }
        // Recurring
        for (var x = 0; x < interimSummary.RecurringCharges.length; x++) {
            if (Utilities.IsDefined(interimSummary.RecurringCharges[x]) && Utilities.IsDefined(interimSummary.RecurringCharges[x].AdjustmentTotal, true)) {
                interimSummary.RecurringCharges[x].OriginalTotal = originalValues.Recurring.OriginalTotal[x];
            }
            if (Utilities.IsDefined(interimRootItemSummary.RecurringCharges[x]) && Utilities.IsDefined(interimRootItemSummary.RecurringCharges[x].AdjustmentTotal, true)) {
                interimRootItemSummary.RecurringCharges[x].OriginalTotal = originalValues.Recurring.OriginalRootItemTotal[x];
            }
        }
    };
    /**
     * Add discountValue onto the nonrecurring charges total
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} orderfolio
     * @param {CsTypes.ChargeLookups} ChargeLookups
     * @param {CsTypes.OrderfolioItem} charge
     * @return {boolean}
     */
    DiscountEngine.CheckCBCCostTargetStates = function (orderfolio, ChargeLookups, charge, costBasedChargeCostActions) {
        var chargeUuid = charge.CompoundKey.Key;
        var chargeRateInfo = ChargeLookups.ChargeUuidToRateInfo[chargeUuid.toString()][0];
        var costUuids = [];
        var returnValue = true;
        // Collect Uuids of costs targeted by the costBasedCharge
        chargeRateInfo.TargetedCosts.forEach(function (cost) {
            costUuids.push(cost.CostUuid);
        });
        // Lookup action for each cost
        costUuids.forEach(function (Uuid) {
            var Cost = orderfolio[Uuid];
            Cost.forEach(function (cost) {
                if (Utilities.IsDefined(cost.Action)) {
                    costBasedChargeCostActions.push({ Action: cost.Action, Type: cost.CostType });
                    if (cost.Action === OrderActions.Update || cost.Action === OrderActions.Delete) {
                        returnValue = false;
                    }
                }
            });
        });
        return returnValue;
    };
    /**
     * Find the chargeType of each portfolioItem targetted by the discount
     * @param {any[]} typeToTargetLookup
     * @param {any} discount
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} Orderfolio
     */
    DiscountEngine.GetTargetChargeTypes = function (typeToTargetLookup, discount, Orderfolio) {
        if (Utilities.IsDefined(discount.TargetAdjustmentSet.TargetAdjustment)) {
            discount.TargetAdjustmentSet.TargetAdjustment.forEach(function (adjustment) {
                adjustment.Targets.forEach(function (target) {
                    // Push each of the targets onto our array, the ID and the amount
                    var lookup = { Type: undefined, ID: target.ID, Amount: target.Value, Periodicity: undefined };
                    typeToTargetLookup.push(lookup);
                });
            });
        }
        Object.keys(Orderfolio).forEach(function (Uuid) {
            // Check if this Uuid belongs to a charge
            if (Utilities.IsDefined(Orderfolio[Uuid][0].ChargeType)) {
                for (var x = 0; x < Orderfolio[Uuid].length; x++) {
                    for (var y = 0; y < typeToTargetLookup.length; y++) {
                        // If the IDs match, addon the charge type
                        if (Orderfolio[Uuid][x].EntityUniqueCode === typeToTargetLookup[y].ID) {
                            typeToTargetLookup[y].Type = Orderfolio[Uuid][x].ChargeType;
                            typeToTargetLookup[y].Periodicity = Orderfolio[Uuid][x].Periodicity;
                        }
                    }
                }
            }
        });
    };
    /**
 * Check if any discounts are present
 * @param  {CsTypes.DiscountLookups} discountLookups
 * @return {boolean}
 */
    DiscountEngine.DiscountsPresent = function (discountLookups) {
        if (Object.keys(discountLookups.DiscountUuidToDiscountInfo).length === 0 && Object.keys(discountLookups.DiscountUuidToRateInfo).length === 0) {
            return false;
        }
        else {
            return true;
        }
    };
    /**
     * Get the legacy discounts that apply to the orderfolio. Returns a list that we can process.
     * @param {CsTypes.DecomposeContext} decomposeContext
     * @param {Array<ApplicableDiscountItem>} applicableLegacyDiscounts
     */
    DiscountEngine.GetApplicableDiscounts = function (decomposeContext, applicableApplicableDiscounts) {
        var _this = this;
        var applicableDiscountsInfos = decomposeContext.CompiledSpec.ApplicableDiscountsInfos;
        applicableDiscountsInfos.forEach(function (ApplicableDiscountsInfo) {
            // Find out if we have this entry already in our array
            // If we don't, we will create a new one for the orderfolio
            var orderfolioApplicableDiscount = applicableApplicableDiscounts.filter(function (x) { return x.OrderfolioKey.Key === ApplicableDiscountsInfo.FullGuidPathUuid; })[0];
            var alreadyHaveDiscount = orderfolioApplicableDiscount !== undefined ? true : false;
            var ofDiscount = decomposeContext.Orderfolio[ApplicableDiscountsInfo.FullGuidPathUuid];
            if (ofDiscount !== undefined) {
                // Process the Recipient and Source charge
                orderfolioApplicableDiscount = _this.ProcessApplicableDiscountChargeRole(orderfolioApplicableDiscount, ApplicableDiscountsInfo.RecipientCharge, decomposeContext.Orderfolio, ofDiscount[0]);
                orderfolioApplicableDiscount = _this.ProcessApplicableDiscountChargeRole(orderfolioApplicableDiscount, ApplicableDiscountsInfo.SourceCharge, decomposeContext.Orderfolio, ofDiscount[0]);
            }
            // If we already have the applicableLegacyDiscount in the list, then there shouldn't be any need to push it again.
            if (!alreadyHaveDiscount && orderfolioApplicableDiscount !== undefined) {
                applicableApplicableDiscounts.push(orderfolioApplicableDiscount);
            }
        });
    };
    /**
     * Process the recipient and source charges and return ApplicableDiscountItem
     * @param {ApplicableDiscountItem} orderfolioLegacyDiscount
     * @param {CsTypes.ApplicableDiscount} chargeRole
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} orderfolios
     * @param {CsTypes.OrderfolioItem} ofDiscount
     */
    DiscountEngine.ProcessApplicableDiscountChargeRole = function (orderfolioLegacyDiscount, chargeRole, orderfolios, ofDiscount) {
        if (chargeRole === null || chargeRole === undefined) {
            return orderfolioLegacyDiscount;
        }
        var orderfolio = orderfolios[chargeRole.FullGuidPathUuid];
        if (Utilities.IsNotDefined(orderfolio, true)) {
            return orderfolioLegacyDiscount;
        }
        if (ofDiscount !== undefined) {
            chargeRole.DiscountCandidateId = ofDiscount.EntityUniqueCode;
        }
        if (orderfolioLegacyDiscount !== undefined) {
            orderfolioLegacyDiscount.ApplicableDiscounts.push(chargeRole);
        }
        else {
            orderfolioLegacyDiscount = new ApplicableDiscountItem();
            orderfolioLegacyDiscount.OrderfolioKey = orderfolio[0].CompoundKey;
            orderfolioLegacyDiscount.ApplicableDiscounts = new Array();
            orderfolioLegacyDiscount.ApplicableDiscounts.push(chargeRole);
        }
        return orderfolioLegacyDiscount;
    };
    return DiscountEngine;
}());
module.exports = DiscountEngine;

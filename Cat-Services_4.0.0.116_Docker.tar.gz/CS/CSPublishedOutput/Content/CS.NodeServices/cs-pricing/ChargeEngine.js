"use strict";
/// <reference path="../cs-lib-types/SpecEntities/PricingTemplateTypes.d.ts" />
var decimal = require("jsdecimal");
var ChargeTypes = require("../cs-lib-constants/ChargeTypes");
var IgnoredChargeParams = require("./InternalPricingTypes/IgnoredChargeParams");
var IgnoredReasonTypes = require("../cs-lib-constants/IgnoredReasonTypes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MarkupTypes = require("../cs-lib-constants/MarkupTypes");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var PricingUtilities = require("./PricingUtilities");
var Utilities = require("../cs-lib-utilities/Utilities");
/** Contains methods for charge functions */
var ChargeEngine = /** @class */ (function () {
    function ChargeEngine() {
    }
    /**
     * Appends rates to charges and populates the pricing summary with rate information
     * @param {CsTypes.ChargeLookups} chargeLookups compiled spec information about the charges for this request
     * @param {CsTypes.DecomposeContext} decomposeContext the decomposed request to populate with charge rates
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     * @param {Array<InterimRate>} interimChargeRates the collection of calculated rates for charges in the orderfolio
     */
    ChargeEngine.PopulateChargeRates = function (chargeLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        Object.keys(chargeLookups.ChargeUuidToChargeInfo).forEach(function (chargeUuid) {
            var chargeInfo = chargeLookups.ChargeUuidToChargeInfo[chargeUuid];
            var chargeRates = chargeLookups.ChargeUuidToRateInfo[chargeUuid] || [];
            var orderfolioCharges = decomposeContext.Orderfolio[chargeUuid];
            if (Utilities.IsNotDefined(orderfolioCharges, true)) {
                Logger.debug(10, "Pricing", "Compiled spec charge '" + chargeInfo.Name + "' either found no match in the orderfolio or had no rates");
                return;
            }
            if (Utilities.IsNotDefined(orderfolioCharges, true)) {
                return;
            }
            orderfolioCharges.forEach(function (charge) {
                ChargeEngine.PopulateChargeRate(charge, decomposeContext, chargeRates, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            });
        });
    };
    /**
     * Populates the charge rate
     * @param {CsTypes.OrderfolioItem} charge the charge to be populated with a rate
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {Array<CsTypes.RateInfo>} chargeRates the collection of specification rates for the charge
     * @param {CsTypes.ChargeInfo} chargeInfo compiled spec info for the charge
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     * @param {Array<InterimRate>} interimChargeRates the collection of calculated rates for charges in the orderfolio
     */
    ChargeEngine.PopulateChargeRate = function (charge, decomposeContext, chargeRates, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        if (charge.ChargeType === ChargeTypes.NonRecurringCostBasedCharge || charge.ChargeType === ChargeTypes.RecurringCostBasedCharge) {
            return;
        }
        Logger.debug(10, "Pricing", "Pricing simple charge " + charge.EntityUniqueCode);
        if (!ChargeEngine.ChargeHasValidAction(charge)) {
            return;
        }
        var ignoredChargeParams = new IgnoredChargeParams();
        if (!ChargeEngine.ChargeIsValid(charge, chargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary)) {
            return;
        }
        // Get rate override details if they exist
        var validatedRateDetail = PricingUtilities.ValidateRateDetail(charge.RateDetail);
        if (validatedRateDetail.IsUsableRateDetail) {
            // check for a rateActivation date
            // if its defined but isnt valid then we ignore the charge
            if (!validatedRateDetail.HasValidRateActivationDate) {
                ignoredChargeParams = new IgnoredChargeParams();
                ignoredChargeParams.InvalidRateActivationDate = true;
                ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                return;
            }
            // If we are missing a rate guid, value, or the value is non-numeric, ignore the entity
            if (Utilities.IsNotDefined(validatedRateDetail.RateActivationDate)
                && !validatedRateDetail.HasValidRateOverride) {
                ignoredChargeParams = new IgnoredChargeParams();
                ignoredChargeParams.RateDetailIncorrectDefinition = true;
                ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                return;
            }
        }
        var rateAttributesExist = charge.RatingAttributes.some(function (ra) { return (ra.Action !== MergedActions.DeleteExisting && ra.Action !== MergedActions.DeleteMissing); });
        if (validatedRateDetail.HasValidRateOverride && rateAttributesExist) {
            ignoredChargeParams = new IgnoredChargeParams();
            ignoredChargeParams.RateOverrideRateAttributeMismatch = true;
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // Excluded charges shouldn't be priced
        if (charge.IsExcludedCharge) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // Originally this existed as an earlier check, but this prevented excluded entities from being caught (as they have no rates).
        // It's not recorded as an ignored entity
        if (Utilities.IsNotDefined(chargeRates, true)) {
            Logger.debug(20, "Pricing", "Compiled spec charge '" + chargeInfo.Name + "' either found no match in the orderfolio or had no rates");
            return;
        }
        var filteredChargeRates = PricingUtilities.FilterRates(decomposeContext.ActivationDate, chargeRates, charge.RatingAttributes, chargeInfo.ExclusiveRateAttributeValues, validatedRateDetail.RateActivationDate, validatedRateDetail.RateIdOverride);
        if (Utilities.IsNotDefined(filteredChargeRates, true) || filteredChargeRates.length !== 1) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var unambiguousRate = filteredChargeRates[0];
        if (Utilities.IsNotDefined(unambiguousRate, true)) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var isUnitRate = Utilities.IsDefined(unambiguousRate.UnitPricingRates);
        if (isUnitRate) {
            // If unit quantity is already set we'll fast exit without doing any work in here
            PricingUtilities.CalculateUnitQuantityFromEntityCountInfo(decomposeContext, unambiguousRate.EntityCountInfo, charge);
        }
        if (isUnitRate && Utilities.IsNotDefined(charge.UnitQuantity)) {
            ignoredChargeParams = new IgnoredChargeParams();
            ignoredChargeParams.NoUnitRate = true;
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        Logger.debug(30, "Pricing", "Calculating charge using rate data", { Subtype: "RateInfo", RateInfo: unambiguousRate });
        var interimChargeRate = PricingUtilities.CalculateOrderfolioItemRate(charge, unambiguousRate, undefined, validatedRateDetail.ValueOverride);
        interimRates.push(interimChargeRate);
        // We can safely update missing rate attributes here, as there are no points ahead at which we
        // can alter them
        PricingUtilities.PopulateMissingRateAttributes(charge, unambiguousRate.RateAttributes);
        // Unit based rates mean that the rate info from the complied spec needs to be updated with the total calculated value.
        // This covers both simple rates and unit based rates having different ways of representing values in the specification.
        var summaryRate = Object.create(unambiguousRate);
        summaryRate.Value = interimChargeRate.Rate.Value;
        ChargeEngine.UpdateChargeSummary(summaryRate, chargeInfo, interimRootItemSummary);
        ChargeEngine.UpdateChargeSummary(summaryRate, chargeInfo, interimSummary);
    };
    /**
     * Appends rates to cost based charges and populates the pricing summary with rate information
     * @param {CsTypes.ChargeLookups} chargeLookups compiled spec information about the charges for this request
     * @param {CsTypes.DecomposeContext} decomposeContext the decomposed request to populate with charge rates
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     * @param {Array<InterimRate>} interimChargeRates the collection of calculated rates for charges in the orderfolio
     */
    ChargeEngine.PopulateCostBasedChargeRates = function (chargeLookups, decomposeContext, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        Object.keys(chargeLookups.ChargeUuidToChargeInfo).forEach(function (chargeUuid) {
            var chargeInfo = chargeLookups.ChargeUuidToChargeInfo[chargeUuid];
            var chargeRates = chargeLookups.ChargeUuidToRateInfo[chargeUuid] || [];
            var orderfolioCharges = decomposeContext.Orderfolio[chargeUuid];
            if (Utilities.IsNotDefined(orderfolioCharges, true)) {
                Logger.debug(10, "Pricing", "Compiled spec charge '" + chargeInfo.Name + "' either found no match in the orderfolio or had no rates");
                return;
            }
            orderfolioCharges.forEach(function (charge) {
                ChargeEngine.PopulateCostBasedChargeRate(charge, decomposeContext, chargeRates, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates);
            });
        });
    };
    /**
     * Populates the cost based charge rate
     * @param {CsTypes.OrderfolioItem} charge the charge to be populated with a rate
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {Array<CsTypes.RateInfo>} chargeRates the collection of specification rates for the charge
     * @param {CsTypes.ChargeInfo} chargeInfo compiled spec info for the charge
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     * @param {Array<InterimRate>} interimChargeRates the collection of calculated rates for charges in the orderfolio
     */
    ChargeEngine.PopulateCostBasedChargeRate = function (charge, decomposeContext, chargeRates, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary, interimRates) {
        if (charge.ChargeType !== ChargeTypes.NonRecurringCostBasedCharge && charge.ChargeType !== ChargeTypes.RecurringCostBasedCharge) {
            return;
        }
        Logger.debug(10, "Pricing", "Pricing cost-based charge " + charge.EntityUniqueCode);
        if (!ChargeEngine.ChargeHasValidAction(charge)) {
            return;
        }
        var ignoredChargeParams = new IgnoredChargeParams();
        if (!ChargeEngine.ChargeIsValid(charge, chargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary)) {
            return;
        }
        // Get rate override details if they exist
        // Get rate override details if they exist
        var validatedRateDetail = PricingUtilities.ValidateRateDetail(charge.RateDetail);
        if (validatedRateDetail.IsUsableRateDetail) {
            // Check for a rateActivation date
            // if its defined but isnt valid then we ignore the charge
            if (!validatedRateDetail.HasValidRateActivationDate) {
                ignoredChargeParams = new IgnoredChargeParams();
                ignoredChargeParams.InvalidRateActivationDate = true;
                ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                return;
            }
            // If we are missing a rate guid, value, or the value is non-numeric, ignore the entity
            if (Utilities.IsNotDefined(validatedRateDetail.RateActivationDate)
                && !validatedRateDetail.HasValidRateOverride) {
                ignoredChargeParams = new IgnoredChargeParams();
                ignoredChargeParams.RateDetailIncorrectDefinition = true;
                ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                return;
            }
        }
        var rateAttributesExist = charge.RatingAttributes.some(function (ra) { return (ra.Action !== MergedActions.DeleteExisting && ra.Action !== MergedActions.DeleteMissing); });
        if (validatedRateDetail.HasValidRateOverride && rateAttributesExist) {
            Logger.debug(20, "Pricing", "Compiled spec charge '" + chargeInfo.Name + "' either found no match in the orderfolio or had no rates");
            ignoredChargeParams = new IgnoredChargeParams();
            ignoredChargeParams.RateOverrideRateAttributeMismatch = true;
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // Excluded charges shouldn't be priced
        if (charge.IsExcludedCharge) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var filteredChargeRates = PricingUtilities.FilterRates(decomposeContext.ActivationDate, chargeRates, charge.RatingAttributes, chargeInfo.ExclusiveRateAttributeValues, validatedRateDetail.RateActivationDate, validatedRateDetail.RateIdOverride);
        if (Utilities.IsNotDefined(filteredChargeRates, true) || filteredChargeRates.length !== 1) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var unambiguousRate = filteredChargeRates[0];
        if (Utilities.IsNotDefined(unambiguousRate, true)) {
            ignoredChargeParams = new IgnoredChargeParams();
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        var isUnitRate = Utilities.IsDefined(unambiguousRate.UnitPricingRates, true);
        if (isUnitRate) {
            // If unit quantity is already set we'll fast exit without doing any work in here
            PricingUtilities.CalculateUnitQuantityFromEntityCountInfo(decomposeContext, unambiguousRate.EntityCountInfo, charge);
        }
        if (isUnitRate && Utilities.IsNotDefined(charge.UnitQuantity)) {
            ignoredChargeParams = new IgnoredChargeParams();
            ignoredChargeParams.NoUnitRate = true;
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // TODO: We can't just populate the rates. Now we've found an unambiguous rate, we need to harvest details from the associated costs
        var costsToApply = [];
        Logger.debug(20, "Pricing", "Retrieving cost targets", { SubType: "CostTargets" });
        var chargeIgnored = ChargeEngine.FindValidCostsForCharge(costsToApply, interimRates, unambiguousRate, decomposeContext, charge, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
        if (chargeIgnored) {
            return;
        }
        // If no costs were found which were applicable - i.e. because the costs were not in a valid state for the cost based charge -
        // do not continue processing, and do not create a rate against this charge
        if (Utilities.IsNotDefined(costsToApply, true)) {
            // A non-recurring cost based charge should not be added to ignored charges on the basis of no valid costs, if the charge did not
            // have an add action applied.
            if (charge.ChargeType === ChargeTypes.NonRecurringCostBasedCharge && charge.Action !== OrderActions.Add) {
                return;
            }
            // set ignoredChargeDetails (no applicable costs were found for this charge)
            var ignoredChargeParams_1 = new IgnoredChargeParams();
            ignoredChargeParams_1.NoValidCosts = true;
            ChargeEngine.CreateIgnoredCharge(charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams_1, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return;
        }
        // TODO: Once we've got details regarding the associated costs, we need to apply the markup in the CBC rate
        var costBasedMarkups = [];
        var unitBasedRateValue;
        if (isUnitRate) {
            PricingUtilities.CalculateUnitQuantityFromEntityCountInfo(decomposeContext, unambiguousRate.EntityCountInfo, charge);
            unitBasedRateValue = PricingUtilities.CalculateUnitBasedRateValue(charge.UnitQuantity, unambiguousRate);
        }
        var chargeTotal = ChargeEngine.CalculateChargeTotalFromCosts(costsToApply, costBasedMarkups, unambiguousRate, charge, isUnitRate, unitBasedRateValue);
        var aggregateMarkupValue = new decimal(0);
        if (unambiguousRate.Aggregate) {
            aggregateMarkupValue = ChargeEngine.AggregateCosts(chargeTotal, unambiguousRate, isUnitRate, unitBasedRateValue);
            chargeTotal = chargeTotal.add(aggregateMarkupValue);
        }
        var costBasedCalculationMarkupAmount = (isUnitRate) ? (unitBasedRateValue) : unambiguousRate.Value;
        var costBasedCalculation = {
            MarkupType: unambiguousRate.MarkupType,
            MarkupAmount: costBasedCalculationMarkupAmount,
            Aggregate: unambiguousRate.Aggregate ? unambiguousRate.Aggregate : false,
            AggregateMarkupValue: unambiguousRate.Aggregate ? aggregateMarkupValue.toFloat() : undefined,
            CostBasedMarkup: costBasedMarkups
        };
        Logger.debug(30, "Pricing", "Calculating charge using rate data", { Subtype: "RateInfo", RateInfo: unambiguousRate, CostBasedCalculations: costBasedCalculation });
        var interimChargeRate = PricingUtilities.CalculateOrderfolioItemRate(charge, unambiguousRate, costBasedCalculation, validatedRateDetail.ValueOverride);
        interimRates.push(interimChargeRate);
        // We can safely update missing rate attributes here, as there are no points ahead at which we
        // can alter them
        PricingUtilities.PopulateMissingRateAttributes(charge, unambiguousRate.RateAttributes);
        // Finally, we need to 'trick' the summary. It only cares about the charge used, so we will simply create a clone of the rate and replace its rate value
        // with the total marked up value of the costs, or the override value if overrides were used
        var summaryRate = Object.create(unambiguousRate);
        if (Utilities.IsDefined(validatedRateDetail.RateIdOverride, true)) {
            summaryRate.Value = new decimal(interimChargeRate.Rate.Value).toFloat();
        }
        else {
            summaryRate.Value = chargeTotal.toFloat();
        }
        ChargeEngine.UpdateChargeSummary(summaryRate, chargeInfo, interimRootItemSummary);
        ChargeEngine.UpdateChargeSummary(summaryRate, chargeInfo, interimSummary);
    };
    /**
     * Checks whether the charge is valid for pricing and creates ignored charge details for invalid charges
     * @param {CsTypes.OrderfolioItem} charge the charge to check
     * @param {Array<CsTypes.RateInfo>} specChargeRates the compiled specification rates
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.ChargeInfo} chargeInfo compiled specification details of the charge
     * @param {IgnoredChargeParams} ignoredChargeParams details about the ignored charge
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     */
    ChargeEngine.ChargeIsValid = function (charge, specChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        if (specChargeRates.length === 0) {
            ignoredChargeParams.NoSpecRate = true;
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return false;
        }
        if (charge.IsInvalid) {
            ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
            return false;
        }
        return true;
    };
    /**
     * Using the specification, finds costs targeted by the charge in the orderfolio which are valid for pricing
     * @param {Array<any>} costsToApply the collection of valid costs to be used for calculating the charge total
     * @param {CsTypes.RateInfo} unambiguousRate the charge rate to use
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.OrderfolioItem} charge the charge to use
     * @param {IIgnoredCharge} ignoredChargeDetails if the charge fails to find valid costs and is ignored, collects the details of the ignored charge
     * @param {CsTypes.ChargeInfo} chargeInfo compiled spec info about the charge
     * @param {ISummary} grandSummary the pricing summary for all decompose contexts
     * @param {RootItemSummary} rootItemSummary the pricing summary for the current decompose context
     * @param {InterimSummary} interimSummary the interim pricing summary for all decompose contexts
     * @param {InterimSummary} interimRootItemSummary the interim pricing summary for the current decompose context
     */
    ChargeEngine.FindValidCostsForCharge = function (costsToApply, interimRates, unambiguousRate, decomposeContext, charge, chargeInfo, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        var chargeIgnored = false;
        unambiguousRate.TargetedCosts.every(function (targetedCost) {
            // Retrieve the entity link from this target, if one exists
            var targetEntityLink = targetedCost.EntityLinkReference;
            // Instantiate a new object to store any entities linked to or from this charge, identified by this target's entity link.
            // This will also store any children of entities linked in this way. The store will be keyed using the PortfolioItemID of the orderfolio entity link.
            var linkedEntitiesForTarget = [];
            // If this target has an entity link, build a store of entities which are linked and their descendents.
            // Use this store to identify if the charge itself is linked by this entity link.
            if (Utilities.IsDefined(targetEntityLink)) {
                // For each instance of the entity link, get sources and targets and their descendents.
                PricingUtilities.FilterEntityLinkInstances(decomposeContext, targetEntityLink, charge, linkedEntitiesForTarget);
                // Check whether the charge is targeted by any instance of the entity link before continuing
                if (linkedEntitiesForTarget.length < 1) {
                    // set ignoredChargeDetails (no entity links were found for this charge)
                    var ignoredChargeParams = new IgnoredChargeParams();
                    ignoredChargeParams.NoEntityLinksToCharge = true;
                    ignoredChargeParams.EntityLinkId = targetEntityLink.Id;
                    ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    chargeIgnored = true;
                    return false;
                }
            }
            else {
                var impliedLink = targetedCost.ImpliedLink;
                PricingUtilities.RetrieveInstancesByImpliedLink(decomposeContext, impliedLink, charge, linkedEntitiesForTarget);
                // An implied link should always exist for the charge if an entity link was not explicitly defined. Therefore,
                // a charge cannot be ignored on the basis of not being targeted by an implied link.
            }
            var costTargets = decomposeContext.Orderfolio[targetedCost.CostUuid.toString()];
            if (!costTargets) {
                return true;
            }
            costTargets.every(function (cost) {
                // only get costs in a valid action state
                var costAction = Utilities.ValueOrDefault(cost.Action, OrderActions.NoChange);
                if (!ChargeEngine.CostStateValidForCostBasedCharge(costAction, charge.ChargeType)) {
                    return true;
                }
                // Either an entity link or implied link will generate linked entities; however, the cost target may not
                // be linked by this charge
                if (!ChargeEngine.CostChargeEntityLinked(linkedEntitiesForTarget, cost, charge)) {
                    return true;
                }
                var interimCost = LodashUtilities.Find(interimRates, function (r) { return r.OrderfolioKey === cost.CompoundKey; });
                var costRate = Utilities.IsDefined(interimCost) ? interimCost.Rate : undefined;
                // handle missing rate
                if (Utilities.IsNotDefined(costRate)) {
                    var ignoredChargeParams = new IgnoredChargeParams();
                    ignoredChargeParams.MissingCostRate = true;
                    ChargeEngine.CreateIgnoredCharge(charge, undefined, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary);
                    chargeIgnored = true;
                    return false;
                }
                costsToApply.push({ CostLinkID: targetedCost.CostLinkID, PortfolioItemID: cost.PortfolioItemId, RateValue: costRate.Value });
                return true;
            });
            return true;
        });
        return chargeIgnored;
    };
    /**
     * Uses all valid costs for the current charge to calculate the total charge value
     * @param {decimal} chargeTotal the total charge value
     * @param {Array<any>} costsToApply the collection of valid costs to use
     * @param {Array<CsTypes.CostBasedMarkup>} costBasedMarkups the details of how the charge total is reached
     * @param {CsTypes.RateInfo} unambiguousRate the charge specification rate to use
     * @param {CsTypes.OrderfolioItem} charge the orderfolio charge
     * @param {boolean} isUnitRate whether the charge rate is unit-based
     * @param {number} unitBasedRateValue the unit-based rate for the charge
     */
    ChargeEngine.CalculateChargeTotalFromCosts = function (costsToApply, costBasedMarkups, unambiguousRate, charge, isUnitRate, unitBasedRateValue) {
        var chargeTotal = new decimal(0);
        costsToApply.forEach(function (cost) {
            var baseValue = new decimal(cost.RateValue);
            var markupType = unambiguousRate.MarkupType;
            var markupAmount;
            if (unambiguousRate.Aggregate) {
                markupAmount = 0;
            }
            else {
                if (isUnitRate) {
                    markupAmount = unitBasedRateValue;
                }
                else {
                    markupAmount = unambiguousRate.Value;
                }
            }
            var markupValue;
            switch (markupType) {
                case MarkupTypes.Flat:
                    markupValue = new decimal(markupAmount);
                    break;
                case MarkupTypes.Percentage:
                    var markupPercentage = new decimal(markupAmount / 100);
                    markupValue = markupPercentage.mul(baseValue);
                    break;
            }
            var resultValue = baseValue.add(markupValue);
            chargeTotal = chargeTotal.add(resultValue);
            // TODO: round these values to 2 decimal places - can use jsdecimal, just need to figure out how
            var costBasedMarkup = {
                CostLinkID: cost.CostLinkID,
                CostPortfolioItemID: cost.PortfolioItemID,
                CostValue: baseValue.toFloat(),
                MarkupValue: markupValue.toFloat(),
                ResultValue: resultValue.toFloat()
            };
            costBasedMarkups.push(costBasedMarkup);
        });
        return chargeTotal;
    };
    /**
     * Sums the total value of costs contributing to a cost based charge and applies charge markup
     * @param   {decimal} chargeTotal the current charge total
     * @param   {CsTypes.RateInfo} unambiguousRate the rate to use
     * @param   {boolean} isUnitRate whether the rate is a unit rate
     * @param   {number} unitBasedRateValue the rate value if the rate is a unit rate
     */
    ChargeEngine.AggregateCosts = function (chargeTotal, unambiguousRate, isUnitRate, unitBasedRateValue) {
        var aggregateMarkupValue = new decimal(0);
        var baseValue = chargeTotal;
        var markupAmount;
        if (isUnitRate) {
            markupAmount = new decimal(unitBasedRateValue);
        }
        else {
            markupAmount = new decimal(unambiguousRate.Value);
        }
        switch (unambiguousRate.MarkupType) {
            case MarkupTypes.Flat:
                aggregateMarkupValue = markupAmount;
                break;
            case MarkupTypes.Percentage:
                var markupPercentage = new decimal(markupAmount.toFloat() / 100);
                aggregateMarkupValue = markupPercentage.mul(baseValue);
                break;
        }
        return aggregateMarkupValue;
    };
    /**
     * Determines whether the charge's action state is valid for pricing
     * @param   {CsTypes.OrderfolioItem} charge the charge to check
     */
    ChargeEngine.ChargeHasValidAction = function (charge) {
        if (PricingUtilities.IsItemActionInvalidForEntityType(charge.Action, charge.ChargeType)) {
            Logger.debug(20, "Pricing", "The item action on the charge is invalid for pricing", { Subtype: "ChargeAction", ChargeAction: charge.Action });
            return false;
        }
        return true;
    };
    /**
     * Updates the charge summary with the rate provided
     * @param {CsTypes.RateInfo} rate The rate to add to the charge summary
     * @param {CsTypes.ChargeInfo} chargeInfo The object containing the charge information
     * @param {ChargeSummary} chargeSummary The charge summary to update
     */
    ChargeEngine.UpdateChargeSummary = function (rate, chargeInfo, chargeSummary) {
        var chargeValue = new decimal(rate.Value);
        if (chargeInfo.ChargeType === ChargeTypes.RecurringCharge ||
            chargeInfo.ChargeType === ChargeTypes.StandaloneRecurringCharge ||
            chargeInfo.ChargeType === ChargeTypes.RecurringCostBasedCharge) {
            ChargeEngine.UpdateRecurringChargeTotal(chargeSummary.RecurringCharges, chargeValue, chargeInfo.Periodicity);
        }
        else {
            var nonRecurringCharges = chargeSummary.NonRecurringCharges;
            var finalTotal = nonRecurringCharges.FinalTotal;
            nonRecurringCharges.MinimumTotal = nonRecurringCharges.MinimumTotal.add(chargeValue);
            nonRecurringCharges.FinalTotal = finalTotal.add(chargeValue);
        }
    };
    /**
     * Updates the totals for the recurring charges for the specific period
     * @param {ChargeInformation[]} recurringCharges The existing recurring charges
     * @param {decimal} chargeValue The charge value to add
     * @param {string} periodicity The periodicity
     */
    ChargeEngine.UpdateRecurringChargeTotal = function (recurringCharges, chargeValue, periodicity) {
        var selectedPeriod = LodashUtilities.Find(recurringCharges, function (p) { return p.Name === periodicity; });
        if (Utilities.IsNotDefined(selectedPeriod)) {
            recurringCharges.push({ Name: periodicity, MinimumTotal: chargeValue, FinalTotal: chargeValue });
        }
        else {
            selectedPeriod.MinimumTotal = selectedPeriod.MinimumTotal.add(chargeValue);
            if (selectedPeriod.FinalTotal !== "N/A") {
                var finalTotal = selectedPeriod.FinalTotal;
                selectedPeriod.FinalTotal = finalTotal.add(chargeValue);
            }
        }
    };
    /**
     * Creates an ignored charge entry in the pricing summary
     * @param {CsTypes.OrderfolioItem} charge the request charge to ignore
     * @param {Array<CsTypes.RateInfo>} filteredChargeRates specification charge rates after filtering by date and rate attribute
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context
     * @param {CsTypes.ChargeInfo} chargeInfo specification info about the charge
     * @param {IgnoredChargeParams} ignoredChargeParams the reasons for the charge to be ignored
     * @param {ISummary} grandSummary the overall pricing summary for the entire request
     * @param {RootItemSummary} rootItemSummary the pricing summary for this decompose context
     * @param {InterimSummary} interimSummary the internal pricing summary for the entire request
     * @param {InterimSummary} interimRootItemSummary the internal pricing summary for this decompose context
     */
    ChargeEngine.CreateIgnoredCharge = function (charge, filteredChargeRates, decomposeContext, chargeInfo, ignoredChargeParams, grandSummary, rootItemSummary, interimSummary, interimRootItemSummary) {
        var ignoredChargeDetails = ChargeEngine.CreateIgnoredChargeDetails(charge, filteredChargeRates, decomposeContext, ignoredChargeParams);
        ChargeEngine.UpdateIgnoredCharges(ignoredChargeDetails, grandSummary, chargeInfo, interimSummary.RecurringCharges);
        ChargeEngine.UpdateIgnoredCharges(ignoredChargeDetails, rootItemSummary.ItemSummary, chargeInfo, interimRootItemSummary.RecurringCharges);
        Logger.debug(20, "Pricing", "Ignored charge", { Subtype: "ignoredCharge", ignoredChargeDetails: ignoredChargeDetails, filteredRates: filteredChargeRates });
        return;
    };
    /**
     * Checks for cases in which the user should be informed that this charge has been ignored
     * @param {CsTypes.OrderfolioItem} charge The charge in the order
     * @param {CsTypes.RateInfo[]} filteredChargeRates A filtered set of the rates containing only applicable rates
     * @param {CsTypes.DecomposeContext} decomposeContext The decomposed request to populate with charge rates
     * @param {boolean} noEntityLinksToCharge Checks if there is entity links to the charge
     * @param {boolean} missingCostRate Checks to see if the cost rates are missing
     * @param {boolean} noValidCosts Checks to see if the costs are valid
     * @param {boolean} entityLinkId The entity link ID
     * @param {boolean} noSpecRate Checks to see if there's a rate in the spec
     * @returns {IIgnoredCharge}
     */
    ChargeEngine.CreateIgnoredChargeDetails = function (charge, filteredChargeRates, decomposeContext, params) {
        var parentOrderfolioLookup = decomposeContext.ChildToParentTable[OrderfolioQueries.GetOrderfolioItemKey(charge.CompoundKey)];
        var chargeParent = undefined;
        if (Utilities.IsDefined(parentOrderfolioLookup)) {
            chargeParent = decomposeContext.Orderfolio[parentOrderfolioLookup.Key.toString()][parentOrderfolioLookup.Index];
        }
        if (charge.IsAdditionalCharge) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "TAdditionalChargeInheritor", IgnoredReasonTypes.AdditionalCharge);
        }
        else if (charge.IsExcludedCharge) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "Excluded", IgnoredReasonTypes.ChargeExcluded);
        }
        else if (charge.IsInvalid) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "OutdatedCharge", IgnoredReasonTypes.ExpiredCharge);
        }
        else if (params.NoSpecRate) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousRates", IgnoredReasonTypes.NoRateOnCharge);
        }
        else if (params.RateDetailIncorrectDefinition) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "InvalidRateOverride", IgnoredReasonTypes.InvalidRateOverride);
        }
        else if (params.RateOverrideRateAttributeMismatch) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "InvalidRateOverride", IgnoredReasonTypes.RateAttributeAmbiguity);
        }
        else if (Utilities.IsDefined(filteredChargeRates) && filteredChargeRates.length < 1) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousRates", IgnoredReasonTypes.NoValidRate);
        }
        else if (Utilities.IsDefined(filteredChargeRates) && filteredChargeRates.length > 1) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousRates", IgnoredReasonTypes.MultipleAmbiguousRates);
        }
        else if (params.NoEntityLinksToCharge) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousEntityLink", IgnoredReasonTypes.NoEntityLinkToCharge, params.EntityLinkId);
        }
        else if (params.MissingCostRate) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousReferencedCostRate", IgnoredReasonTypes.MissingCostRate);
        }
        else if (params.NoValidCosts) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "NoValidReferencedCosts", IgnoredReasonTypes.NoValidCostProvided);
        }
        else if (params.NoUnitRate) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "AmbiguousUnitQuantity", IgnoredReasonTypes.AmbiguousUnitQuantity);
        }
        else if (params.InvalidRateActivationDate) {
            return ChargeEngine.CreateIgnoredChargeDetail(charge, chargeParent, "InvalidRateActivationDate", IgnoredReasonTypes.InvalidRateActivationDate);
        }
        return undefined;
    };
    /**
     * Creates the ignored charge response item based on the specific change and the reason determined in CreateIgnoredChargeDetails
     * @param {CsTypes.OrderfolioItem} charge The charge in the order
     * @param {CsTypes.OrderfolioItem} chargeParent The parent of the charge in the order
     * @param {string} reason The reason code
     * @param {string} reasonDescription The reason description, from IgnoreReasonTypes
     * @param {string} entityLinkId The entity link id
     * @returns {IIgnoredCharge}
     */
    ChargeEngine.CreateIgnoredChargeDetail = function (charge, chargeParent, reason, reasonDescription, entityLinkId) {
        entityLinkId = entityLinkId || undefined;
        return {
            ID: charge.EntityUniqueCode,
            Reason: reason,
            ReasonDetails: {
                EntityID: charge.EntityId,
                ParentEntityUniqueCode: Utilities.IsNotDefined(chargeParent) ? undefined : chargeParent.EntityUniqueCode,
                ParentEntityID: Utilities.IsNotDefined(chargeParent) ? undefined : chargeParent.EntityId,
                Description: reasonDescription,
                EntityLinkID: entityLinkId
            }
        };
    };
    /**
     * Updates the ignored charges in a price summary and if it's an ambiguous rate sets the final totals for RC and NRC as not applicable
     * @param {IIgnoredCharge} ignoredCharge The ignored charge
     * @param {ISummary} grandSummary The grand summary on the pricing summary object
     * @param {CsTypes.ChargeInfo} chargeInfo The current charge spec information
     * @param {PricingInformation[]} recurringCharges The array of recurring charges that are being built up
     */
    ChargeEngine.UpdateIgnoredCharges = function (ignoredCharge, itemSummary, chargeInfo, recurringCharges) {
        itemSummary.IgnoredCharges.push(ignoredCharge);
        if (!ChargeEngine.ApplyFinalTotal(ignoredCharge)) {
            if ([ChargeTypes.NonRecurringCharge, ChargeTypes.NonRecurringCostBasedCharge].indexOf(chargeInfo.ChargeType) > -1) {
                itemSummary.NonRecurringCharges.FinalTotal = "N/A";
            }
            else if ([ChargeTypes.RecurringCharge, ChargeTypes.RecurringCostBasedCharge].indexOf(chargeInfo.ChargeType) > -1) {
                var periodicity = chargeInfo.Periodicity;
                var ignoredPeriod = LodashUtilities.Find(recurringCharges, function (p) { return p.Name === periodicity; });
                if (Utilities.IsNotDefined(ignoredPeriod)) {
                    recurringCharges.push({ Name: periodicity, MinimumTotal: new decimal(0), FinalTotal: "N/A" });
                }
                else {
                    ignoredPeriod.FinalTotal = "N/A";
                }
            }
        }
    };
    /**
     * Decide whether to apply a FinalTotal value dependent on the reason for the ignored charge
     * @param   {IIgnoredCharge} ignoredCharge the ignored charge
     */
    ChargeEngine.ApplyFinalTotal = function (ignoredCharge) {
        if (["AmbiguousRates", "AmbiguousEntityLink", "AmbiguousReferencedCostRate", "NoValidReferencedCosts", "AmbiguousUnitQuantity", "InvalidRateOverride"].indexOf(ignoredCharge.Reason) > -1) {
            return false;
        }
        return true;
    };
    /**
     * Determines whether a cost can be considered for markup by a cost based charge
     * @param   {string} costState the action state of the cost to be marked up
     * @param   {string} chargeType the type of cost based charge linked to the action
     * @returns {boolean}
     */
    ChargeEngine.CostStateValidForCostBasedCharge = function (costState, chargeType) {
        if (costState === OrderActions.Add
            || (chargeType === ChargeTypes.RecurringCostBasedCharge
                && (costState === OrderActions.Update
                    || costState === OrderActions.NoChange
                    || costState === OrderActions.Reassigned
                    || costState === OrderActions.ReassignedUpdate))) {
            return true;
        }
        return false;
    };
    /**
     * Identifies whether a cost is linked to a charge by a given set of instances of an entity link
     * @param   {CsTypes.EntityLinkSourceTargetDescendents[]} entityLinkInstances the instances of the entity link to use
     * @param   {CsTypes.OrderfolioItem} cost the cost to check for linkage to the charge
     * @param   {CsTypes.OrderfolioItem} charge the charge to be linked to
     */
    ChargeEngine.CostChargeEntityLinked = function (entityLinkInstances, cost, charge) {
        for (var entityLinkInstancesIndex = 0; entityLinkInstancesIndex < entityLinkInstances.length; entityLinkInstancesIndex++) {
            var entityLinkInstance = entityLinkInstances[entityLinkInstancesIndex];
            var chargeIsSource = entityLinkInstance.SourceDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(charge.CompoundKey)) > -1;
            // If the charge is the source of the entity link, check the targets for the cost;
            // else check the sources as the charge is the target
            var chargeLinkedToCost = chargeIsSource ?
                entityLinkInstance.TargetDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(cost.CompoundKey)) > -1 :
                entityLinkInstance.SourceDescendents.indexOf(OrderfolioQueries.GetOrderfolioItemKey(cost.CompoundKey)) > -1;
            // If at least one entity link instance exists between the charge and the cost then they are linked. Do not continue to process.
            if (chargeLinkedToCost) {
                return true;
            }
        }
        return false;
    };
    return ChargeEngine;
}());
module.exports = ChargeEngine;

"use strict";
var TBUtils = require("./TBUtils");
// Generates the requested OrderCandidate
var TBRequestOrderCandidate = /** @class */ (function () {
    function TBRequestOrderCandidate() {
    }
    /**
    * Main function to construct OrderCandidate assertion statements
    * @param {any} request - json request to process
    * @param {any} stream - file to be output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildRequestOrderCandidateAssertions = function (request, stream, aliases) {
        if (!request.OrderCandidate) {
            return;
        }
        TBUtils.WriteLine('# Request OrderCandidate', stream);
        TBUtils.WriteLine('And that "request" contains an "OrderCandidate"', stream);
        if (request.OrderCandidate.OrderID) {
            TBUtils.WriteLine('And that "OrderCandidate" has an "OrderID" of "' + request.OrderCandidate.OrderID + '"', stream);
        }
        TBUtils.WriteNewLine(stream);
        TBRequestOrderCandidate.BuildOrderItemAssertions(request.OrderCandidate, stream, aliases);
    };
    /**
    * Assert properties of an ordercandidate orderitem
    * @param {any} orderCandidate - oc from request
    * @param {any} stream - file to be output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildOrderItemAssertions = function (orderCandidate, stream, aliases) {
        if (!orderCandidate.OrderItem || orderCandidate.OrderItem.length === 0) {
            TBUtils.WriteLine('And that "OrderCandidate" does not contain any "OrderItem"', stream);
        }
        else {
            var orderItemTable = [];
            orderItemTable.push(['ParentContextName', 'ID', 'PortfolioItemID', 'EntityID', 'ItemAction', 'ContextName']);
            var childOrderItemTable = [];
            childOrderItemTable.push(['ParentContextName', 'ID', 'PortfolioItemID', 'EntityID', 'ItemAction', 'ContextName']);
            var charUseTable = [];
            charUseTable.push(['ParentContextName', 'CharacteristicID', 'UseArea', 'ContextName']);
            var charUseValueTable = [];
            charUseValueTable.push(['ParentContextName', 'ValueID', 'Action', 'ContextName']);
            var configuredValueTable = [];
            configuredValueTable.push(['ParentContextName', 'CharacteristicID', 'UseArea', 'ContextName']);
            var configuredValueValueTable = [];
            configuredValueValueTable.push(['ParentContextName', 'Value', 'Action', 'ContextName']);
            // Pass and fill arrays with properties of order items
            TBRequestOrderCandidate.BuildOrderItems('OrderCandidate', orderCandidate.OrderItem, orderItemTable, childOrderItemTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
            TBUtils.WriteLine('And the "OrderItem" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(orderItemTable, stream);
            // first value in array will be headers
            if (childOrderItemTable.length > 1) {
                TBUtils.WriteLine('And the "ChildOrderItem" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(childOrderItemTable, stream);
            }
            if (charUseTable.length > 1) {
                TBUtils.WriteLine('And the "CharacteristicUse" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(charUseTable, stream);
            }
            if (charUseValueTable.length > 1) {
                TBUtils.WriteLine('And the "Value" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(charUseValueTable, stream);
            }
            if (configuredValueTable.length > 1) {
                TBUtils.WriteLine('And the "ConfiguredValue" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(configuredValueTable, stream);
            }
            if (configuredValueValueTable.length > 1) {
                TBUtils.WriteLine('And the "Value" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(configuredValueValueTable, stream);
            }
        }
    };
    /**
    * Iterate over and store details of order items
    * @param {any} parentContext - parent of orderItems
    * @param {any} orderItems - any orderItems at the current oc level, maybe multiple
    * @param {any} childOrderItemTable - array to store details of childOrderItems
    * @param {any} charUseTable - array to store details of CharUse
    * @param {any} charUseValueTable - array to store details of CharUse values
    * @param {any} configuredValueTable - array to store details of configured values
    * @param {any} configuredValueValueTable - array to store details of configured value values
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildOrderItems = function (parentContext, orderItems, orderItemTable, childOrderItemTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases) {
        if (!orderItems) {
            return;
        }
        // TODO: Update this with aliases
        for (var i = 0; i < orderItems.length; i++) {
            var orderItem = orderItems[i];
            var contextName = TBUtils.AddContext(orderItem.ID);
            var alias = TBUtils.AddAlias(orderItem.ID, orderItem.EntityID, aliases);
            orderItemTable.push([
                parentContext, orderItem.ID, orderItem.PortfolioItemID || 'undefined', alias, orderItem.ItemAction || 'undefined', contextName
            ]);
            TBRequestOrderCandidate.BuildCharacteristicUses(contextName, orderItem, charUseTable, charUseValueTable, aliases);
            TBRequestOrderCandidate.BuildConfiguredValues(contextName, orderItem, configuredValueTable, configuredValueValueTable, aliases);
            if (orderItem.ChildOrderItem) {
                TBRequestOrderCandidate.BuildChildOrderItems(contextName, orderItem.ChildOrderItem, childOrderItemTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
            }
        }
    };
    /**
    * Iterate over and store details of child order items
    * @param {any} parentContext - name of parent of orderItems
    * @param {any} childOrderItems - any orderItems at the current oc level, maybe multiple
    * @param {any} childOrderItemTable - array to store details of childOrderItems
    * @param {any} charUseTable - array to store details of CharUse
    * @param {any} charUseValueTable - array to store details of CharUse values
    * @param {any} configuredValueTable - array to store details of configured values
    * @param {any} configuredValueValueTable - array to store details of configured value values
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildChildOrderItems = function (parentContext, childOrderItems, childOrderItemTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases) {
        if (!childOrderItems) {
            return;
        }
        // TODO: Update this with aliases
        for (var i = 0; i < childOrderItems.length; i++) {
            var childOrderItem = childOrderItems[i];
            var contextName = TBUtils.AddContext(childOrderItem.ID);
            var alias = TBUtils.AddAlias(childOrderItem.ID, childOrderItem.EntityID, aliases);
            childOrderItemTable.push([
                parentContext, childOrderItem.ID, childOrderItem.PortfolioItemID || 'undefined', alias, childOrderItem.ItemAction || 'undefined', contextName
            ]);
            // Build charUses and configValues for current childOrderItem
            TBRequestOrderCandidate.BuildCharacteristicUses(contextName, childOrderItem, charUseTable, charUseValueTable, aliases);
            TBRequestOrderCandidate.BuildConfiguredValues(contextName, childOrderItem, configuredValueTable, configuredValueValueTable, aliases);
            if (childOrderItem.ChildOrderItem) {
                TBRequestOrderCandidate.BuildChildOrderItems(contextName, childOrderItem.ChildOrderItem, childOrderItemTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
            }
        }
    };
    /**
    * Iterate over and store details of order items
    * @param {any} parentContext - name of parent of orderItems
    * @param {any} orderItem - current orderItem to be checked for charUses
    * @param {any} charUseTable - array to store details of CharUse
    * @param {any} charUseValueTable - array to store details of CharUse values
    * @param {any[]} aliases - list of all aliases
    * @param {string} reqType - requested type either OrderItem or PortfolioItem. Defaulted to order.
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildCharacteristicUses = function (parentContext, orderItem, charUseTable, charUseValueTable, aliases, reqType) {
        if (reqType === void 0) { reqType = "order"; }
        if (orderItem.CharacteristicUse && orderItem.CharacteristicUse.length > 0) {
            for (var cu = 0; cu < orderItem.CharacteristicUse.length; cu++, TBRequestOrderCandidate.ContextCharUseCount++) {
                var contextName = TBUtils.AddContext('CharUse_' + TBRequestOrderCandidate.ContextCharUseCount);
                var charUse = orderItem.CharacteristicUse[cu];
                var alias = TBUtils.AddAlias(contextName, charUse.CharacteristicID, aliases);
                charUseTable.push([parentContext, alias, charUse.UseArea, contextName]);
                if (charUse.Value && charUse.Value.length > 0) {
                    for (var cuv = 0; cuv < charUse.Value.length; cuv++, TBRequestOrderCandidate.ContextCharUseValueCount++) {
                        var charUseValue = charUse.Value[cuv];
                        var contextValueName = TBUtils.AddContext('CharUseValue_' + TBRequestOrderCandidate.ContextCharUseValueCount);
                        alias = TBUtils.GetAlias(charUseValue.ValueID, aliases);
                        if (reqType === "order") {
                            // ParentContext | ValueID  | Action  | ContextName
                            charUseValueTable.push([contextName, alias, charUseValue.Action, contextValueName]);
                        }
                        else // Portfolio type hence no action
                         {
                            // ParentContext | ValueID | ContextName
                            charUseValueTable.push([contextName, alias, contextValueName]);
                        }
                    }
                }
            }
        }
    };
    /**
    * Iterate over and store details of order items
    * @param {any} parentContext - parent of orderItems
    * @param {any} orderItems - current orderItem
    * @param {any} configuredValueTable - array to store details of configured values
    * @param {any} configuredValueValueTable - array to store details of configured value values
    * @param {any[]} aliases - list of all aliases
    * @param {string} reqType - requested type either OrderItem or PortfolioItem. Defaulted to order.
    * @returns {void}
    */
    TBRequestOrderCandidate.BuildConfiguredValues = function (parentContext, orderItem, configuredValueTable, configuredValueValueTable, aliases, reqType) {
        if (reqType === void 0) { reqType = "order"; }
        if (orderItem.ConfiguredValue && orderItem.ConfiguredValue.length > 0) {
            for (var cv = 0; cv < orderItem.ConfiguredValue.length; cv++, TBRequestOrderCandidate.ContextConfFactCount++) {
                var contextName = TBUtils.AddContext('ConfiguredValue_' + TBRequestOrderCandidate.ContextConfFactCount);
                var configuredValue = orderItem.ConfiguredValue[cv];
                var alias = TBUtils.AddAlias(contextName, configuredValue.CharacteristicID, aliases);
                configuredValueTable.push([
                    parentContext, alias, configuredValue.UseArea, contextName
                ]);
                if (configuredValue.Value && configuredValue.Value.length > 0) {
                    for (var cvv = 0; cvv < configuredValue.Value.length; cvv++, TBRequestOrderCandidate.ContextValueCount++) {
                        var configuredValueValue = configuredValue.Value[cvv];
                        var contextValueName = TBUtils.AddContext('Value_' + TBRequestOrderCandidate.ContextValueCount);
                        if (reqType === "order") {
                            // ParentContext | ValueID  | Action  | ContextName
                            configuredValueValueTable.push([contextName, configuredValueValue.Value, configuredValueValue.Action, contextValueName]);
                        }
                        else // Portfolio type hence no action
                         {
                            // ParentContext | ValueID | ContextName
                            configuredValueValueTable.push([contextName, configuredValueValue.Value, contextValueName]);
                        }
                    }
                }
            }
        }
    };
    // Counters for naming context name of char uses, Conf facts and it's values.
    TBRequestOrderCandidate.ContextCharUseCount = 0;
    TBRequestOrderCandidate.ContextCharUseValueCount = 0;
    TBRequestOrderCandidate.ContextConfFactCount = 0;
    TBRequestOrderCandidate.ContextValueCount = 0;
    return TBRequestOrderCandidate;
}());
module.exports = TBRequestOrderCandidate;

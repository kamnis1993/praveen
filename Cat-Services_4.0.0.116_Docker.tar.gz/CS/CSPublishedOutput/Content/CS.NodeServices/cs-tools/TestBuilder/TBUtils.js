"use strict";
// Utility class
// Primary function is to write to feature file
// Also handles Contexts and Aliases
var Utilities = require("../../cs-lib-utilities/Utilities");
var TBUtils = /** @class */ (function () {
    function TBUtils() {
    }
    /**
    * Outputs a given message to the output file
    * @param {any} message - The message to output
    * @param {any} stream - The file containing the output
    * @param {any} tabs - optional parameter if you want to further indent a line
    * @returns {void}
    */
    TBUtils.WriteLine = function (message, stream, tabs) {
        if (tabs == null) {
            // Indent 2 tabs by default
            tabs = 2;
        }
        var tabString = '';
        for (var i = 0; i < tabs; i++) {
            tabString += '    ';
        }
        stream.write(tabString + message + '\r\n');
    };
    /**
    * Outputs a blank line to the file
    * @param {any} stream - The file containing the output
    * @returns {void}
    */
    TBUtils.WriteNewLine = function (stream) {
        stream.write('\r\n');
    };
    /**
    * Outputs an array to the output file
    * @param {any} array - The array to output
    * @param {any} stream - The file containing the output
    * @returns {void}
    */
    TBUtils.WriteArrayTable = function (array, stream) {
        // Get the maximum width of any element from the array
        var widths = this.GetWidths(array);
        for (var l = 0; l < array.length; l++) {
            stream.write('            | ');
            for (var w = 0; w < array[l].length; w++) {
                var value = array[l][w];
                if (!value) {
                    value = 'undefined';
                }
                // Don't add a space on the last pipe, it messes up the formatting in Atom
                var pipe = (w === array[l].length - 1) ? ' |' : ' | ';
                stream.write(this.pad(value, widths[w]) + pipe);
            }
            this.WriteNewLine(stream);
        }
        this.WriteNewLine(stream);
    };
    /**
    * return the maximum width of each array column,
    * @param {any} array - The array to check
    * @returns {number[]} max width needed for each array column
    */
    TBUtils.GetWidths = function (array) {
        var widths = null;
        if (array.length > 0) {
            widths = [];
            //Iterate over every array element
            for (var l = 0; l < array.length; l++) {
                for (var w = 0; w < array[l].length; w++) {
                    // We need to correctly pad undefined/null values
                    if (array[l][w] === undefined || array[l][w] === null) {
                        array[l][w] = "undefined";
                    }
                    if (!array[l][w]) {
                        continue;
                    }
                    // non-strings wont be padded correctly
                    if (typeof array[l][w] !== 'string') {
                        array[l][w] = array[l][w].toString();
                    }
                    // if the length of the element is bigger than any of the previous
                    // elements, update the return value
                    var len = array[l][w].length;
                    if (!widths[w] || widths[w] < len) {
                        widths[w] = len;
                    }
                }
            }
        }
        return widths;
    };
    /**
    * Add spaces to the end of a value to correctly align all elements
    * @param {any} value - The value to pad
    * @param {any} length - the number of spaces to add
    * @returns {number} the padded value
    */
    TBUtils.pad = function (value, length) {
        var paddedValue = value;
        for (var i = 0; i < (length - value.length); i++) {
            paddedValue += ' ';
        }
        return paddedValue;
    };
    /**
    * Create context name
    * @param {string} name - value to turn into a context name
    * @returns {string} - new name
    */
    TBUtils.AddContext = function (name) {
        return "CN_" + name;
    };
    /**
    * Create an Alias for a given GUID
    * @param {any} name - name of alias to create
    * @param {any} value - GUID to create alias for
    * @param {any[]} aliases - all  existing aliases
    * @returns {any} - the allias to use for given values
    */
    TBUtils.AddAlias = function (name, value, aliases) {
        // If a value(GUID) already has an associated Alias, use that Alias
        var existingKey = this.GetAlias(value, aliases);
        if (existingKey !== null) {
            return existingKey;
        }
        // If an Alias exists with the given name
        // Increment nameCounter to create a Unique Alias name
        var existingName = this.GetAliasName(name, aliases);
        if (existingName !== null) {
            var nameCounter = 1;
            while (TBUtils.NameAlreadyPresent(existingName, aliases)) {
                // Trim the _1, _2 etc off the end, other wise we get Alias_xyz_1_2
                // Rather than Alias_xyz_2
                if (nameCounter > 1) {
                    existingName = existingName.substring(0, existingName.length - 2);
                }
                existingName = existingName + "_" + nameCounter;
                nameCounter++;
            }
            aliases.push([existingName, value]);
            return existingName;
        }
        name = "ALIAS_" + name;
        aliases.push([name, value]);
        return name;
    };
    /**
    * Check if a alias with a specificed name already exists
    * @param {any} name - name of alias to create
    * @param {any[]} aliases - all  existing aliases
    * @returns {boolean} true if name exists, false otherwise
    */
    TBUtils.NameAlreadyPresent = function (name, aliases) {
        // return true if the provided name is already an existing alias
        return aliases.some(function (x) { return x[0] === name; });
    };
    /**
    * Check if a Alias already exists for a GUID
    * @param {any} value - GUID to create alias for
    * @param {any[]} aliases - all  existing aliases
    * @returns {any} - the matching alias if it exists
    */
    TBUtils.GetAlias = function (value, aliases) {
        for (var i = 0; i < aliases.length; i++) {
            if (aliases[i][1] === value) {
                return aliases[i][0]; // return the key;
            }
        }
        return null;
    };
    /**
    * Create an Alias for a given name
    * @param {any} value - Name to check
    * @param {any[]} aliases - all  existing aliases
    * @returns {any} - return the name of the alias if it exists
    */
    TBUtils.GetAliasName = function (value, aliases) {
        for (var i = 0; i < aliases.length; i++) {
            if (aliases[i][0] === ('ALIAS_' + value)) {
                return aliases[i][0]; // return the name of the alias;
            }
        }
        return null;
    };
    /**
    * Create a string representation of todays date
    * @returns {string} - the date
    */
    TBUtils.TodaysDate = function () {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        var pad = '0';
        // Need leading 0, dd will give 3, we need 03
        // Same applies for month
        if (dd < 10) {
            var strDay = dd.toString();
            strDay = pad.concat(strDay);
        }
        if (mm < 10) {
            var strMonth = mm.toString();
            strMonth = pad.concat(strMonth);
        }
        // Build final string
        var final = yyyy + '-' + (strMonth || mm) + '-' + (strDay || dd);
        return final;
    };
    /**
    * Returns a singlular or array object as an array
    */
    TBUtils.AsArray = function (x) {
        if (!x) {
            return [];
        }
        if (Array.isArray(x)) {
            return x;
        }
        return [].concat.apply([], [x]);
    };
    /**
     * Takes a single string splits it and individually translates the values into their aliases
     * If they exist
     * Puts the string back together and returns it
     * @param input
     */
    TBUtils.TranslateValuesToAliases = function (input, aliases, delimiter) {
        var _this = this;
        if (delimiter === void 0) { delimiter = ','; }
        var split = input.split(/[/,]/);
        var newSplit = [];
        split.forEach(function (element) {
            console.log(element.toLowerCase());
            var alias = _this.GetAlias(element.toLowerCase(), aliases);
            console.log(alias);
            newSplit.push(Utilities.IsDefined(alias) ? alias : element);
        });
        return newSplit.join(delimiter);
    };
    return TBUtils;
}());
module.exports = TBUtils;

"use strict";
var TBRequestOrderCandidate = require("./TBRequestOrderCandidate");
var TBUtils = require("./TBUtils");
// Generates the requested Portfolio
var TBRequestPortfolio = /** @class */ (function () {
    function TBRequestPortfolio() {
    }
    /**
    * Main function to construct Customer Portfolio assertion statements
    * @param {any} request - json request to process
    * @param {any} stream - file to be output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestPortfolio.BuildRequestPortfolioAssertions = function (request, stream, aliases) {
        if (!request.CustomerPortfolio) {
            return;
        }
        TBUtils.WriteLine('# Request Portfolio', stream);
        TBUtils.WriteLine('And that "request" contains a "CustomerPortfolio"', stream);
        TBUtils.WriteNewLine(stream);
        if (!request.CustomerPortfolio.PortfolioItem || request.CustomerPortfolio.PortfolioItem.length <= 0) {
            TBUtils.WriteLine('And that "CustomerPortfolio" does not contain any "PortfolioItem"', stream);
            TBUtils.WriteNewLine(stream);
            return;
        }
        TBRequestPortfolio.BuildPortfolioItemAssertions('CustomerPortfolio', request.CustomerPortfolio.PortfolioItem, "PortfolioItem", stream, aliases);
    };
    /**
    * Check over top level portfolio item
    * @param {any} parentContext - parent of portfolio item
    * @param {any} portfolioItems - json portfolio item to be checked
    * @param {any} portfolioItemLabel - string "PortfolioItem"
    * @param {any} stream - file to be output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestPortfolio.BuildPortfolioItemAssertions = function (parentContext, portfolioItems, portFolioItemLabel, stream, aliases) {
        // Build arrays with headers to store data for each item
        var portfolioItemTable = [];
        portfolioItemTable.push(['ParentContextName', 'ID', 'EntityID', 'ItemSource', 'ContextName']);
        var childEntityTable = [];
        childEntityTable.push(['ParentContextName', 'ID', 'EntityID', 'ItemSource', 'ContextName']);
        var charUseTable = [];
        charUseTable.push(['ParentContextName', 'CharacteristicID', 'UseArea', 'ContextName']);
        var charUseValueTable = [];
        charUseValueTable.push(['ParentContextName', 'ValueID', 'ContextName']);
        var configuredValueTable = [];
        configuredValueTable.push(['ParentContextName', 'CharacteristicID', 'UseArea', 'ContextName']);
        var configuredValueValueTable = [];
        configuredValueValueTable.push(['ParentContextName', 'Value', 'ContextName']);
        TBRequestPortfolio.BuildPortFolioItems(parentContext, portfolioItems, portfolioItemTable, childEntityTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
        TBUtils.WriteLine('And the "' + portFolioItemLabel + '" contains only the following instances:', stream);
        TBUtils.WriteArrayTable(portfolioItemTable, stream);
        // Output a table if it has values inside of it
        // First value will be the headers defined early, so > 1 needed
        if (childEntityTable.length > 1) {
            TBUtils.WriteLine('And the "ChildEntity" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(childEntityTable, stream);
        }
        if (configuredValueTable.length > 1) {
            TBUtils.WriteLine('And the "ConfiguredValue" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(configuredValueTable, stream);
        }
        if (configuredValueValueTable.length > 1) {
            TBUtils.WriteLine('And the "Value" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(configuredValueValueTable, stream);
        }
        if (charUseTable.length > 1) {
            TBUtils.WriteLine('And the "CharacteristicUse" contains the following instances:', stream);
            TBUtils.WriteArrayTable(charUseTable, stream);
        }
        if (charUseValueTable.length > 1) {
            TBUtils.WriteLine('And the "Value" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(charUseValueTable, stream);
        }
    };
    /**
    * Iterate over and store details of portfolio items
    * @param {any} parentContext - parent of orderItems
    * @param {any} portfolioItems - any portfolio items at the current oc level, maybe multiple
    * @param {any} portfolioItemTable - array to store details of portfolio items
    * @param {any} childEntityTable - array to store details of childEntities
    * @param {any} charUseTable - array to store details of CharUse
    * @param {any} charUseValueTable - array to store details of CharUse values
    * @param {any} configuredValueTable - array to store details of configured values
    * @param {any} configuredValueValueTable - array to store details of configured value values
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestPortfolio.BuildPortFolioItems = function (parentContext, portfolioItems, portfolioItemTable, childEntityTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases) {
        if (!portfolioItems) {
            return;
        }
        // TODO: Update the EntityID and ContextName with aliases
        for (var i = 0; i < portfolioItems.length; i++) {
            var portfolioItem = portfolioItems[i];
            var contextName = TBUtils.AddContext(portfolioItem.ID);
            var alias = TBUtils.AddAlias(contextName, portfolioItem.EntityID, aliases);
            portfolioItemTable.push([parentContext, portfolioItem.ID, alias, portfolioItem.ItemSource || 'undefined', contextName]);
            TBRequestOrderCandidate.BuildConfiguredValues(contextName, portfolioItem, configuredValueTable, configuredValueValueTable, aliases, "Portfolio");
            TBRequestOrderCandidate.BuildCharacteristicUses(contextName, portfolioItem, charUseTable, charUseValueTable, aliases, "Portfolio");
            if (portfolioItem.ChildEntity) {
                TBRequestPortfolio.BuildChildEntityItems(contextName, portfolioItem.ChildEntity, childEntityTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
            }
        }
    };
    /**
    * Iterate over and store details of child entites
    * @param {any} parentContext - parent of orderItems
    * @param {any} childEntityItems - any portfolio items at the current oc level, maybe multiple
    * @param {any} childEntityTable - array to store details of childEntities
    * @param {any} charUseTable - array to store details of CharUse
    * @param {any} charUseValueTable - array to store details of CharUse values
    * @param {any} configuredValueTable - array to store details of configured values
    * @param {any} configuredValueValueTable - array to store details of configured value values
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequestPortfolio.BuildChildEntityItems = function (parentContext, childEntityItems, childEntityTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases) {
        if (!childEntityItems) {
            return;
        }
        // TODO: Update the EntityID and ContextName with aliases
        for (var i = 0; i < childEntityItems.length; i++) {
            var childEntityItem = childEntityItems[i];
            var contextName = TBUtils.AddContext(childEntityItem.ID);
            var alias = TBUtils.AddAlias(contextName, childEntityItem.EntityID, aliases);
            childEntityTable.push([
                parentContext, childEntityItem.ID, alias, childEntityItem.ItemSource || 'undefined', contextName
            ]);
            TBRequestOrderCandidate.BuildConfiguredValues(contextName, childEntityItem, configuredValueTable, configuredValueValueTable, aliases, "Portfolio");
            TBRequestOrderCandidate.BuildCharacteristicUses(contextName, childEntityItem, charUseTable, charUseValueTable, aliases, "Portfolio");
            if (childEntityItem.ChildEntity) {
                TBRequestPortfolio.BuildChildEntityItems(contextName, childEntityItem.ChildEntity, childEntityTable, charUseTable, charUseValueTable, configuredValueTable, configuredValueValueTable, aliases);
            }
        }
    };
    return TBRequestPortfolio;
}());
module.exports = TBRequestPortfolio;

"use strict";
var TBRequestOrderCandidate = require("./TBRequestOrderCandidate");
var TBRequestPortfolio = require("./TBRequestPortfolio");
var TBUtils = require("./TBUtils");
// Generates the API response
var TBResponse = /** @class */ (function () {
    function TBResponse() {
    }
    /**
    * Write out api call lines
    * @param {any} stream - file being output to
    * @param {string} requestUrl - api url e.g. find/productspecification
    * @returns {void}
    */
    TBResponse.BuildApiCall = function (stream, requestUrl) {
        TBUtils.WriteLine('# API Call', stream);
        TBUtils.WriteLine('When we make a POST request to "' + requestUrl + '" passing the "request" and storing the "response"', stream);
        TBUtils.WriteNewLine(stream);
    };
    /**
    * Hub function for response assertions
    * @param {any} statusCode - respone statusCode from CS
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponseAssertions = function (statusCode, response, stream, aliases) {
        TBUtils.WriteLine('Then the response code is "' + statusCode + '"', stream);
        TBUtils.WriteNewLine(stream);
        TBResponse.BuildValidationErrorAssertions(response, stream, aliases);
        TBResponse.BuildResponseOrderCandidateAssertions(response, stream, aliases);
        TBResponse.BuildResponsePortfolioAssertions(response, stream, aliases);
        TBResponse.BuildResponsePricingAssertions(response, stream, aliases);
    };
    /**
    * Write out validation errors if there are any
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildValidationErrorAssertions = function (response, stream, aliases) {
        TBUtils.WriteLine('# Validation Errors', stream);
        if (!response.ValidationError || response.ValidationError.length === 0) {
            TBUtils.WriteLine('And that "response" does not contain any validation errors', stream);
            return;
        }
        TBUtils.WriteLine('And the "ValidationError" on that "response" contains only the following instances:', stream);
        var validationErrorTable = [];
        validationErrorTable.push(['ErrorCode', 'EntityUniqueCode', 'EntityID']);
        for (var i = 0; i < response.ValidationError.length; i++) {
            var error = response.ValidationError[i];
            var alias = TBUtils.AddAlias("ValidationError_" + i, error.EntityID, aliases);
            validationErrorTable.push([error.ErrorCode, error.EntityUniqueCode, alias]);
        }
        TBUtils.WriteArrayTable(validationErrorTable, stream);
    };
    /**
    * Write out the response OrderCandidate, links into the request OC code as same structure and naming conventions
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @param {string} responseType - initially used to hold "Pricing" so pricing calls can be asserted, could be used for other types
    * @returns {void}
    */
    TBResponse.BuildResponseOrderCandidateAssertions = function (response, stream, aliases, responseType) {
        if (!response.OrderCandidate) {
            return;
        }
        TBUtils.WriteLine('# Response OrderCandidate', stream);
        if (!responseType) {
            var responseType = "response";
        }
        TBUtils.WriteLine('And that "' + responseType + '" contains an "OrderCandidate"', stream);
        TBUtils.WriteNewLine(stream);
        TBRequestOrderCandidate.BuildOrderItemAssertions(response.OrderCandidate, stream, aliases);
    };
    /**
    * Write out the response portfolio, links into the request OC code as same structure and naming conventions
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @param {string} responseType - initially used to hold "Pricing" so pricing calls can be asserted, could be used for other types
    * @returns {void}
    */
    TBResponse.BuildResponsePortfolioAssertions = function (response, stream, aliases, responseType) {
        if (!response.CustomerPortfolio) {
            return;
        }
        TBUtils.WriteLine('# Response Portfolio', stream);
        if (!responseType) {
            var responseType = "response";
        }
        TBUtils.WriteLine('And that "' + responseType + '" contains an "CustomerPortfolio"', stream);
        TBUtils.WriteNewLine(stream);
        if (!response.CustomerPortfolio.AffectedPortfolioItem || response.CustomerPortfolio.AffectedPortfolioItem.length <= 0) {
            TBUtils.WriteLine('And that "CustomerPortfolio" does not contain any "AffectedPortfolioItem"', stream);
            TBUtils.WriteNewLine(stream);
            return;
        }
        TBRequestPortfolio.BuildPortfolioItemAssertions('CustomerPortfolio', response.CustomerPortfolio.AffectedPortfolioItem, "AffectedPortfolioItem", stream, aliases);
    };
    /**
    * Hub for pricing response assertions, breaks off into multiple other functions
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponsePricingAssertions = function (response, stream, aliases) {
        if (!response.Pricing) {
            return;
        }
        // Headers
        TBResponse.BuildPricingHeaders(stream);
        // Ignored costs/charges
        TBResponse.BuildIgnoredAssertions("Charge", response.Pricing.PriceSummary.GrandSummary.IgnoredCharges, stream, aliases);
        TBResponse.BuildIgnoredAssertions("Cost", response.Pricing.PriceSummary.GrandSummary.IgnoredCosts, stream, aliases);
        // Only need an ignored call for discounts
        // the rest of the discount results are alterations to the recurring/nonrecurring charge data
        TBResponse.BuildIgnoredAssertions("Discount", response.Pricing.PriceSummary.GrandSummary.IgnoredDiscounts, stream, aliases);
        TBUtils.WriteNewLine(stream);
        // Recurring costs/charges
        TBResponse.BuildRecurringAssertions("Charge", response.Pricing.PriceSummary.GrandSummary.RecurringCharges, stream, aliases);
        TBResponse.BuildRecurringAssertions("Cost", response.Pricing.PriceSummary.GrandSummary.RecurringCosts, stream, aliases);
        // NonRecurring costs/charges
        TBResponse.BuildNonRecurringAssertions("Charge", response.Pricing.PriceSummary.GrandSummary.NonRecurringCharges, stream, aliases);
        TBResponse.BuildNonRecurringAssertions("Cost", response.Pricing.PriceSummary.GrandSummary.NonRecurringCosts, stream, aliases);
        // OrderCandidate + Rates
        TBResponse.BuildResponseOrderCandidateAssertions(response.Pricing, stream, aliases, "Pricing");
        if (response.Pricing.OrderCandidate && response.Pricing.OrderCandidate.OrderItem) {
            var discountValues_1 = {};
            TBResponse.BuildDiscountValues(discountValues_1);
            var rateTable_1 = [];
            rateTable_1.push(["ParentContext", "ID", "Value", "OriginalValue", "ContextName"]);
            response.Pricing.OrderCandidate.OrderItem.forEach(function (orderItem) {
                TBResponse.BuildResponseRateAssertions(orderItem, stream, aliases, rateTable_1, discountValues_1);
            });
            if (rateTable_1.length > 1) {
                TBUtils.WriteLine('And the "Rate" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(rateTable_1, stream);
            }
            TBResponse.WriteDiscountValues(discountValues_1, stream);
        }
        // Portfolio + Rates
        TBResponse.BuildResponsePortfolioAssertions(response.Pricing, stream, aliases, "Pricing");
        if (response.Pricing.CustomerPortfolio && response.Pricing.CustomerPortfolio.AffectedPortfolioItem) {
            var discountValues_2 = {};
            TBResponse.BuildDiscountValues(discountValues_2);
            var rateTable_2 = [];
            rateTable_2.push(["ParentContext", "ID", "Value", "OriginalValue", "ContextName"]);
            response.Pricing.CustomerPortfolio.AffectedPortfolioItem.forEach(function (portfolioItem) {
                TBResponse.BuildResponseRateAssertions(portfolioItem, stream, aliases, rateTable_2, discountValues_2);
            });
            if (rateTable_2.length > 1) {
                TBUtils.WriteLine('And the "Rate" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(rateTable_2, stream);
            }
            TBResponse.WriteDiscountValues(discountValues_2, stream);
        }
    };
    TBResponse.BuildDiscountValues = function (discountValues) {
        discountValues.rateAdjustments = [];
        discountValues.adjustmentItem = [];
        discountValues.Source = [];
        discountValues.targetAdjustmentSet = [];
        discountValues.targetAdjustments = [];
        discountValues.targets = [];
        discountValues.unalteredTargets = [];
        discountValues.ChargeAdjustmentCounter = 1;
        discountValues.AdjustmentItemCounter = 1;
        discountValues.TASCounter = 1;
        discountValues.rateAdjustments.push(['ParentContext', 'Total', 'ContextName']);
        discountValues.adjustmentItem.push(['ParentContext', 'Amount', 'Type', 'Value', 'IsExclusive', 'OrderOfExecution', 'DiscountDescription', 'AdjustmentDescription', 'ContextName']);
        discountValues.Source.push(['ParentContext', 'EntityID', 'ID', 'RateID', 'AdjustmentID']);
        discountValues.targetAdjustmentSet.push(['ParentContext', 'RateID', 'IsExclusive', 'OrderOfExecution', 'Description', 'ContextName']);
        discountValues.targetAdjustments.push(['ParentContext', 'ID', 'Type', 'Amount', 'Description', 'ContextName']);
        discountValues.targets.push(['ParentContext', 'ID', 'Value']);
        discountValues.unalteredTargets.push(['ParentContext', 'ID', 'Reason']);
    };
    TBResponse.WriteDiscountValues = function (discountValues, stream) {
        if (discountValues.rateAdjustments.length > 1) {
            TBUtils.WriteLine('And the "RateAdjustment" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.rateAdjustments, stream);
        }
        if (discountValues.adjustmentItem.length > 1) {
            TBUtils.WriteLine('And the "AdjustmentItem" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.adjustmentItem, stream);
        }
        if (discountValues.Source.length > 1) {
            TBUtils.WriteLine('And the "Source" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.Source, stream);
        }
        if (discountValues.targetAdjustmentSet.length > 1) {
            TBUtils.WriteLine('And the "TargetAdjustmentSet" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.targetAdjustmentSet, stream);
        }
        if (discountValues.targetAdjustments.length > 1) {
            TBUtils.WriteLine('And the "TargetAdjustment" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.targetAdjustments, stream);
        }
        if (discountValues.targets.length > 1) {
            TBUtils.WriteLine('And the "Targets" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.targets, stream);
        }
        if (discountValues.unalteredTargets.length > 1) {
            TBUtils.WriteLine('And the "UnalteredTargets" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(discountValues.unalteredTargets, stream);
        }
    };
    /**
    * Write out pricing headers
    * @param {any} stream - file being output to
    * @returns {void}
    */
    TBResponse.BuildPricingHeaders = function (stream) {
        TBUtils.WriteNewLine(stream);
        TBUtils.WriteLine('# Pricing', stream);
        TBUtils.WriteLine('And that "response" contains a "Pricing"', stream);
        TBUtils.WriteLine('And that "Pricing" contains a "PriceSummary"', stream);
        TBUtils.WriteLine('And that "PriceSummary" contains a "GrandSummary"', stream);
        TBUtils.WriteNewLine(stream);
    };
    /**
    * Build ignored assertions for costs and charges
    * @param {string} type - cost/charge
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildIgnoredAssertions = function (type, response, stream, aliases) {
        // IgnoredCharges/IgnoredCosts/IgnoredDiscounts
        var output = '"Ignored' + type + 's"';
        if (!response || response.length < 1) {
            TBUtils.WriteLine('And the ' + output + ' on that "GrandSummary" is empty', stream);
        }
        else {
            var IgnoredTable = [];
            IgnoredTable.push(['ParentContext', 'ID', 'Reason', 'ContextName', 'ReasonDetails.EntityID', 'ReasonDetails.ParentEntityID', 'ReasonDetails.ParentEntityUniqueCode']);
            for (var i = 0; i < response.length; i++) {
                var entity = response[i];
                var name;
                //Charge, Charge_1
                //Charge_0 is unnecessary
                if (i > 0) {
                    name = type + "_" + i;
                }
                else {
                    name = type;
                }
                // Build aliases and context
                var alias = TBUtils.AddAlias(name, entity.ID, aliases);
                var context = TBUtils.AddContext(name);
                var reasonEntityID = TBUtils.GetAlias(entity.ReasonDetails.EntityID, aliases);
                var reasonParentID = TBUtils.GetAlias(entity.ReasonDetails.ParentEntityID, aliases);
                IgnoredTable.push(["GrandSummary", alias, entity.Reason, context, reasonEntityID, reasonParentID, entity.ReasonDetails.ParentEntityUniqueCode]);
            }
            TBUtils.WriteLine('And that "GrandSummary" contains a ' + output, stream);
            TBUtils.WriteLine("And the " + output + " contains the following instances:", stream);
            TBUtils.WriteArrayTable(IgnoredTable, stream);
        }
    };
    /**
    * Build recurring assertions for costs and charges
    * @param {string} type - cost/charge
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildRecurringAssertions = function (type, response, stream, aliases) {
        var output = '"Recurring' + type + 's"';
        if (response.Period.length < 1) {
            TBUtils.WriteLine('And that "GrandSummary" contains a ' + output, stream);
            TBUtils.WriteLine('And the "Period" on that ' + output + ' is empty', stream);
        }
        else {
            TBUtils.WriteLine('And that "GrandSummary" contains a ' + output, stream);
            TBUtils.WriteLine('And that ' + output + ' contains a "Period"', stream);
            TBUtils.WriteLine('And that "Period" has the following properties:', stream);
            var RecurringTable = [];
            RecurringTable.push(['Property', 'Value']);
            for (var i = 0; i < response.Period.length; i++) {
                var period = response.Period[i];
                // Use the adjustment and original total fields if they exist
                if (period.AdjustmentTotal) {
                    RecurringTable.push(['MinimumTotal', period.MinimumTotal]);
                    RecurringTable.push(['FinalTotal', period.FinalTotal]);
                    RecurringTable.push(['AdjustmentTotal', period.AdjustmentTotal]);
                    RecurringTable.push(['OriginalTotal', period.OriginalTotal]);
                }
                else {
                    RecurringTable.push(['MinimumTotal', period.MinimumTotal]);
                    RecurringTable.push(['FinalTotal', period.FinalTotal]);
                }
            }
            TBUtils.WriteArrayTable(RecurringTable, stream);
        }
    };
    /**
    * Build nonrecurring assertions for costs and charges
    * @param {string} type - cost/charge
    * @param {any} response - response json object from CS
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildNonRecurringAssertions = function (type, response, stream, aliases) {
        var output = '"NonRecurring' + type + 's"';
        if (response.FinalTotal > 0) {
            TBUtils.WriteLine('And that "GrandSummary" contains a ' + output, stream);
            TBUtils.WriteLine('And that ' + output + ' has the following properties:', stream);
            var NonRecurringTable = [];
            NonRecurringTable.push(['Property', 'Value']);
            NonRecurringTable.push(["MinimumTotal", response.MinimumTotal]);
            NonRecurringTable.push(["FinalTotal", response.FinalTotal]);
            // TODO Check this is working for discounts
            if (response.AdjustmentTotal) {
                NonRecurringTable.push(["AdjustmentTotal", response.AdjustmentTotal]);
                NonRecurringTable.push(["OriginalTotal", response.OriginalTotal]);
            }
            TBUtils.WriteArrayTable(NonRecurringTable, stream);
        }
    };
    /**
    * Build assertions for rate attached to portfolio and OrderCandidate items
    * @param {any} item - json object
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponseRateAssertions = function (item, stream, aliases, rateTable, discountValues) {
        if (item.Rate) {
            var rate = item.Rate;
            var rateAlias = TBUtils.GetAlias(rate.ID, aliases);
            var alias = TBUtils.AddContext(item.ID);
            rateTable.push([alias, rateAlias, rate.Value, rate.OriginalValue, alias + "_Rate"]);
            // For ChargeBasedDiscount
            if (item.Rate.RateAdjustment) {
                TBResponse.BuildResponseDiscountAssertions(item.Rate.RateAdjustment, rateAlias, stream, aliases, discountValues, alias + "_Rate");
            }
            // For CostBasedCharges
            if (item.Rate.CostBasedCalculations) {
                TBResponse.BuildResponseCBCAssertions(item.Rate.CostBasedCalculations, rateAlias, stream, aliases);
            }
        }
        // Iterate over Portfolio/OrderCandidate
        if (item.ChildOrderItem) {
            TBUtils.AsArray(item.ChildOrderItem).forEach(function (child) {
                TBResponse.BuildResponseRateAssertions(child, stream, aliases, rateTable, discountValues);
            });
        }
        if (item.ChildEntity) {
            TBUtils.AsArray(item.ChildEntity).forEach(function (entity) {
                TBResponse.BuildResponseRateAssertions(entity, stream, aliases, rateTable, discountValues);
            });
        }
        // For ChargeBasedDiscount
        if (item.TargetAdjustmentSet) {
            TBResponse.BuildResponseDiscountAssertions(item, rateAlias, stream, aliases, discountValues, null);
        }
    };
    /**
    * Build assertions for ChargeBasedDiscount
    * @param {any} CBD - json object
    * @param {any} parentContext - name of parent item
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponseDiscountAssertions = function (CBD, parentContext, stream, aliases, discountValues, rateName) {
        if (CBD.AdjustmentItem) {
            var adjustmentContext_1 = 'ChargeAdjustment_' + discountValues.ChargeAdjustmentCounter;
            discountValues.ChargeAdjustmentCounter++;
            discountValues.rateAdjustments.push([rateName, CBD.Total, adjustmentContext_1]);
            TBUtils.AsArray(CBD.AdjustmentItem).forEach(function (item) {
                var itemContext = 'AdjustmentItem_' + discountValues.AdjustmentItemCounter;
                discountValues.AdjustmentItemCounter++;
                discountValues.adjustmentItem.push([adjustmentContext_1,
                    item.Amount,
                    item.Type,
                    item.Value,
                    item.IsExclusive,
                    item.OrderOfExecution,
                    item.DiscountDescription,
                    item.AdjustmentDescription,
                    itemContext]);
                var rateID = TBUtils.GetAlias(item.Source.RateID, aliases);
                var entityID = TBUtils.GetAlias(item.Source.EntityID, aliases);
                var adjustmentID = TBUtils.GetAlias(item.Source.AdjustmentID, aliases);
                discountValues.Source.push([itemContext,
                    entityID,
                    item.Source.ID,
                    rateID,
                    adjustmentID]);
            });
        }
        if (CBD.TargetAdjustmentSet) {
            var rateID = TBUtils.GetAlias(CBD.TargetAdjustmentSet.RateID, aliases);
            discountValues.targetAdjustmentSet.push([TBUtils.AddContext(CBD.ID),
                rateID,
                CBD.TargetAdjustmentSet.IsExclusive,
                CBD.TargetAdjustmentSet.OrderOfExecution,
                CBD.TargetAdjustmentSet.Description,
                "TargetAdjustmentSet_" + discountValues.TASCounter]);
            var adjustmentCounter_1 = 1;
            TBUtils.AsArray(CBD.TargetAdjustmentSet.TargetAdjustment).forEach(function (adjustment) {
                var adjustmentID = TBUtils.GetAlias(adjustment.ID, aliases);
                discountValues.targetAdjustments.push(["TargetAdjustmentSet_" + discountValues.TASCounter,
                    adjustmentID,
                    adjustment.Type,
                    adjustment.Amount.toString(),
                    adjustment.Description,
                    "SimpleAdjustment_" + discountValues.TASCounter + "_" + adjustmentCounter_1]);
                TBUtils.AsArray(adjustment.Targets).forEach(function (target) {
                    discountValues.targets.push(["SimpleAdjustment_" + discountValues.TASCounter + "_" + adjustmentCounter_1, target.ID, target.Value]);
                });
                TBUtils.AsArray(adjustment.UnalteredTargets).forEach(function (target) {
                    discountValues.unalteredTargets.push(["SimpleAdjustment_" + discountValues.TASCounter + "_" + adjustmentCounter_1, target.ID, target.Reason]);
                });
                adjustmentCounter_1++;
            });
            discountValues.TASCounter++;
        }
    };
    /**
    * Build assertions for CostBasedCharges
    * @param {any} CBC - json object
    * @param {any} parentContext - name of parent item
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponseCBCAssertions = function (CBC, parentContext, stream, aliases) {
        //Need to convert boolean value into a string so it can be asserted properly
        if (CBC.Aggregate === false) {
            CBC.Aggregate = "false";
        }
        else if (CBC.Aggregate === true) {
            CBC.Aggregate = "true";
        }
        var calculationTable = [];
        calculationTable.push(['Property', 'Value']);
        calculationTable.push(['MarkupType', CBC.MarkupType]);
        calculationTable.push(['MarkupAmount', CBC.MarkupAmount]);
        calculationTable.push(['Aggregate', CBC.Aggregate]);
        calculationTable.push(['AggregateMarkup', CBC.AggregateMarkup]);
        TBUtils.WriteLine('And that "Rate" contains a "CostBasedCalculations"', stream);
        TBUtils.WriteLine('And that "CostBasedCalculations" has the following properties:', stream);
        TBUtils.WriteArrayTable(calculationTable, stream);
        if (CBC.CostBasedMarkup) {
            TBUtils.AsArray(CBC.CostBasedMarkup).forEach(function (CBM) {
                TBResponse.BuildResponseCBMarkupAssertions(CBM, stream, aliases);
            });
        }
    };
    /**
    * Build assertions for CostBasedCharges markups
    * @param {any} CBM - json object
    * @param {any} stream - file being output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBResponse.BuildResponseCBMarkupAssertions = function (CBM, stream, aliases) {
        var cbmTable = [];
        var aliasName = CBM.CostPortfolioItemID + '_CostLink';
        var cbmAlias = TBUtils.AddAlias(aliasName, CBM.CostLinkID, aliases);
        cbmTable.push(['Property', 'Value']);
        cbmTable.push(['CostPortfolioItemID', CBM.CostPortfolioItemID]);
        cbmTable.push(['CostLinkID', cbmAlias]);
        cbmTable.push(['CostValue', CBM.CostValue]);
        cbmTable.push(['MarkupValue', CBM.MarkupValue]);
        cbmTable.push(['ResultValue', CBM.ResultValue]);
        TBUtils.WriteLine('And that "CostBasedCalculations" contains a "CostBasedMarkup"', stream);
        TBUtils.WriteLine('And that "CostBasedMarkup" has the following properties:', stream);
        TBUtils.WriteArrayTable(cbmTable, stream);
    };
    return TBResponse;
}());
module.exports = TBResponse;

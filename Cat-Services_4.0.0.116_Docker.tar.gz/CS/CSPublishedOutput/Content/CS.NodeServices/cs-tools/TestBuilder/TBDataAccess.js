"use strict";
var TBUtils = require("./TBUtils");
var http = require("http");
// Handles API requests to CS and presents the response back to the TestBuilder
var TBDataAccess = /** @class */ (function () {
    function TBDataAccess() {
    }
    /**
    * Make product spec call to CS
    * @param {any} entityGuid - Guid to get productSpec for
    * @param {any} callback
    * @returns {any} - ProductSpec
    */
    TBDataAccess.GetSpecification = function (entityGuid, callback) {
        console.log('Getting Specification: ' + entityGuid);
        this.GetData('/api/find/productspecification/guid/' + entityGuid, '', function (statusCode, response) {
            console.log('statusCode: ' + statusCode);
            if (statusCode !== 200 && statusCode !== 500) {
                console.log('response');
                console.log(JSON.stringify(response, null, 2));
                console.log('response');
                throw "An error occurred when reading the specification";
            }
            response = JSON.parse(response);
            return callback(response);
        });
    };
    /**
    * Make API call specified in test
    * @param {any} request - JSON request to process
    * @param {string} requestUrl - API url to call
    * @param {any} callback
    * @returns {any}
    */
    TBDataAccess.GetResponse = function (request, requestUrl, callback) {
        console.log('Getting Response');
        this.HydrateRequest(request); // Add any missing required fields
        this.PostData(requestUrl, JSON.stringify(request), function (statusCode, response) {
            console.log('statusCode: ' + statusCode);
            if (statusCode !== 200 && statusCode !== 500) {
                console.log('response');
                console.log(JSON.stringify(response, null, 2));
                console.log('response');
                console.log("An error occurred when making the API Call");
                return null;
            }
            response = JSON.parse(response);
            return callback(statusCode, response);
        });
    };
    /**
    * Fill in any required fields
    * @param {any} request json file to be used
    * @returns {any}
    */
    TBDataAccess.HydrateRequest = function (request) {
        // Assuming for now that this is an ordercandidate request
        // See AcceptanceTests/Helpers/JSONHydrator.ts
        if (request.OrderCandidate) {
            request.OrderCandidate.OrderID = request.OrderCandidate.OrderID || "ORQ001";
        }
        request.ID = request.ID || "ORQ001";
        request.ActivationDate = request.ActivationDate || TBUtils.TodaysDate();
        request.CreationDate = request.CreationDate || TBUtils.TodaysDate();
    };
    /**
    * Make API call to pull in specified data set
    * @param {any} datastorePath - full path to test data set
    * @param {any} callback
    * @returns {any} callback
    */
    TBDataAccess.RefreshData = function (datastorePath, callback) {
        console.log('Refreshing Data');
        this.PostData('/api/import', '{ "target": "' + datastorePath + '" }', function (statusCode, response) {
            if (statusCode !== 200) {
                console.log('response');
                console.log('Status Code: ' + statusCode);
                console.log(JSON.stringify(response, null, 2));
                console.log('response');
            }
            return callback();
        });
    };
    /**
    * Construct a get request
    * @param {any} path - API url to call
    * @param {any} request - JSON request to process
    * @param {any} callback
    * @returns {void}
    */
    TBDataAccess.GetData = function (path, request, callback) {
        var post_options = {
            host: 'localhost',
            port: "9003",
            path: path,
            method: "GET",
            headers: {
                "Host": "localhost:9003",
                "Accept": "application/json"
            }
        };
        var post_req = http.request(post_options, function (res) {
            var response = "";
            res.on("data", function (chunk) {
                response += chunk;
            });
            res.on("end", function () {
                return callback(res.statusCode, response);
            });
        });
        post_req.end();
    };
    /**
    * Construct a post request
    * @param {any} path - API url to call
    * @param {any} request - JSON request to process
    * @param {any} callback
    * @returns {void}
    */
    TBDataAccess.PostData = function (path, request, callback) {
        // Note the proxy settings for testing
        var post_options = {
            host: 'localhost',
            port: "9003",
            path: path,
            method: 'POST',
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
        };
        var post_req = http.request(post_options, function (res) {
            var response = '';
            res.on("data", function (chunk) {
                response += chunk;
            });
            res.on("end", function () {
                return callback(res.statusCode, response);
            });
        });
        post_req.write(request);
        post_req.end();
    };
    return TBDataAccess;
}());
module.exports = TBDataAccess;

"use strict";
var TBRequestOrderCandidate = require("./TBRequestOrderCandidate");
var TBRequestPortfolio = require("./TBRequestPortfolio");
var TBUtils = require("./TBUtils");
// Creates assertation statements relating to the JSON request
var TBRequest = /** @class */ (function () {
    function TBRequest() {
    }
    /**
    * Main function to construct request assertion statements
    * @param {any} request - json request to process
    * @param {string} feature - e.g. 'Pricing', 'Mapping'
    * @param {string} story - e.g. 'S1234'
    * @param {string} requestFileName - json request filename
    * @param {string} activationDate - todays date
    * @param {any} stream - file to be output to
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBRequest.BuildRequestAssertions = function (request, feature, story, requestFileName, activationDate, stream, aliases) {
        TBRequest.BuildRequestRootAssertions(request, feature, story, requestFileName, activationDate, stream);
        TBRequestOrderCandidate.BuildRequestOrderCandidateAssertions(request, stream, aliases);
        TBRequestPortfolio.BuildRequestPortfolioAssertions(request, stream, aliases);
    };
    /**
    * Build json request assertions
    * @param {any} request - json request to process
    * @param {string} feature - e.g. 'Pricing', 'Mapping'
    * @param {string} story - e.g. 'S1234'
    * @param {string} requestFileName - json request filename
    * @param {string} activationDate - todays date
    * @param {any} stream - file to be output to
    * @returns {void}
    */
    TBRequest.BuildRequestRootAssertions = function (request, feature, story, requestFileName, activationDate, stream) {
        TBUtils.WriteLine('# Request', stream);
        TBUtils.WriteLine('Given an "OrderCandidate" JSON request that is populated from "./features/' + feature + '/requests/' + story + '/' + requestFileName + '"', stream);
        TBUtils.WriteNewLine(stream);
        if (!request.ActivationDate && activationDate) {
            TBUtils.WriteLine('# The Activation date is set so the Package is end dated', stream);
            TBUtils.WriteLine('And I set the "ActivationDate" on that "request" to "' + activationDate + '"', stream);
            TBUtils.WriteNewLine(stream);
        }
        if (request.ID) {
            TBUtils.WriteLine('And that "request" has an "ID" of "' + request.ID + '"', stream);
            TBUtils.WriteNewLine(stream);
        }
        if (request.OriginalRequestID) {
            TBUtils.WriteLine('And that "request" has an "OriginalRequestID" of "' + request.OriginalRequestID + '"', stream);
            TBUtils.WriteNewLine(stream);
        }
        if (request.ActivationDate) {
            TBUtils.WriteLine('And that "request" has an "ActivationDate" of "' + request.ActivationDate + '"', stream);
            TBUtils.WriteNewLine(stream);
        }
        if (request.CreatedDate) {
            TBUtils.WriteLine('And that "request" has an "CreatedDate" of "' + request.CreatedDate + '"', stream);
            TBUtils.WriteNewLine(stream);
        }
    };
    return TBRequest;
}());
module.exports = TBRequest;

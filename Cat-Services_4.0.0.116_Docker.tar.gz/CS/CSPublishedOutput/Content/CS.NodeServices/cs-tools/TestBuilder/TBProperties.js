"use strict";
var TBUtils = require("./TBUtils");
//Contains methods to fill arrays with property headers for different entity types
var TBProperties = /** @class */ (function () {
    function TBProperties() {
    }
    TBProperties.BuildProperties = function (parentContext, entity, stream) {
        var values = [];
        TBUtils.WriteLine('And that "' + parentContext + '" has the following properties:', stream);
        this.BuildProductProperties(values, entity);
        TBUtils.WriteArrayTable(values, stream);
    };
    TBProperties.BuildCharUseProperties = function (commercialSpecCharValues, characteristicValues, characteristic_CharValueValues) {
        commercialSpecCharValues.Values.push(["ParentContext", "_meta.ID", "Min_Occurs", "Max_Occurs", "AvStart", "AvEnd", "ContextName"]);
        TBProperties.BuildPhaseCodeProperties(commercialSpecCharValues.CommPhaseValues, commercialSpecCharValues.TechPhaseValues);
        characteristicValues.push(["ParentContextName", "_meta.ID", "Name", "ContextName"]);
        characteristic_CharValueValues.push(["ParentContextName", "_meta.ID", "Value", "_meta.AvStart", "_meta.AvEnd"]);
    };
    TBProperties.BuildConfigurableFactProperties = function (configurableFacts, configurableFactCommPhaseValues, configurableFactTechPhaseValues, configurableFactValues) {
        configurableFacts.push(["ParentContext", "_meta.ID", "Min_Occurs", "Max_Occurs", "AvStart", "AvEnd", "ContextName"]);
        TBProperties.BuildPhaseCodeProperties(configurableFactCommPhaseValues, configurableFactTechPhaseValues);
        configurableFactValues.push(["ParentContext", "_meta.ID", "Name", "_meta.AvStart", "_meta.AvEnd"]);
    };
    TBProperties.BuildCompatibilityRulesProperties = function (compatibilityRuleValues) {
        compatibilityRuleValues.Values.push(['ParentContext', '_meta.ID', 'Name', 'ErrorMessage', 'ContextName']);
        TBProperties.BuildPhaseCodeProperties(compatibilityRuleValues.CommPhaseValues, compatibilityRuleValues.TechPhaseValues);
        TBProperties.BuildExistDataProperties(compatibilityRuleValues.ExistsData);
        TBProperties.BuildExistDataProperties(compatibilityRuleValues.NotExistsData, false);
        TBProperties.BuildEntToStaticCountProperties(compatibilityRuleValues.EntToStaticCount);
        TBProperties.BuildEntToEntCountProperties(compatibilityRuleValues.EntToEntCount);
        TBProperties.BuildEntToUDCCountProperties(compatibilityRuleValues.EntToUDCCount);
    };
    TBProperties.BuildCardinalityRulesProperties = function (RuleValues) {
        RuleValues.Values.push(['ParentContext', '_meta.ID', 'Rule_Description', 'Minimum_Child_Elements', 'Maximum_Child_Elements', 'ContextName']);
        TBProperties.BuildPhaseCodeProperties(RuleValues.CommPhaseValues, RuleValues.TechPhaseValues);
    };
    TBProperties.BuildRelationshipPhaseProperties = function (array) {
        array.Values.push(['ParentContext', 'Product.Element_Guid', 'Min_Occurs', 'Max_Occurs', 'ContextName']);
        TBProperties.BuildPhaseCodeProperties(array.CommPhaseValues, array.TechPhaseValues);
    };
    TBProperties.BuildEntityLinkValuesProperties = function (entityLinkValues) {
        entityLinkValues.Values.push(["ParentContext", "_meta.ID", "Name", "ContextName"]);
        TBProperties.BuildPhaseCodeProperties(entityLinkValues.CommPhaseValues, entityLinkValues.TechPhaseValues);
    };
    TBProperties.BuildPhaseCodeProperties = function (commArray, techArray) {
        commArray.push(['ParentContext', '_meta.ID', 'Name', 'CSCode']);
        techArray.push(['ParentContext', '_meta.ID', 'Name', 'CSCode']);
    };
    TBProperties.BuildMappingRuleProperties = function (mappingRuleArray) {
        // Rule part
        mappingRuleArray.ruleData.push(['_meta.ID', 'Name', 'ContextName']);
        // Condition part
        mappingRuleArray.conditionsData.push(['ParentContext', '_meta.ID', 'Name', 'Scope.Name', 'ContextName']);
        // Action part
        mappingRuleArray.actionsData.push(['ParentContext', '_meta.ID', 'Name', 'ContextName']);
    };
    TBProperties.BuildExistDataProperties = function (data, isExits) {
        if (isExits === void 0) { isExits = true; }
        data.text.push(["ParentContext", "_meta.ID ", "Match_Any", "Scope.Name", "ContextName"]);
        data.Entities.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Entity", "ContextName"]);
        if (isExits) {
            data.Values.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Element.ElementPath ", "ContextName"]);
        }
        else {
            data.Values.push(["ParentContext", "_meta.ID ", "Any_Empty", "Order_Action.Name", "Element.ElementPath ", "ContextName"]);
        }
    };
    TBProperties.BuildEntToStaticCountProperties = function (container) {
        container.data.push(["ParentContext", "_meta.ID ", "Match_Any", "Value", "Comparer.Code", "FurtherScope", "Scope.Name", "ContextName"]);
        container.Entities.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Entity", "ContextName"]);
    };
    TBProperties.BuildEntToEntCountProperties = function (container) {
        container.data.push(["ParentContext", "_meta.ID ", "Match_Any", "Comparer.Code", "FurtherScope", "Scope.Name", "ContextName"]);
        container.Entities1.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Entity", "ContextName"]);
        container.Entities2.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Entity", "ContextName"]);
    };
    TBProperties.BuildEntToUDCCountProperties = function (container) {
        container.data.push(["ParentContext", "_meta.ID ", "Match_Any", "Element.ElementPath", "Comparer.Code", "FurtherScope", "Scope.Name", "ContextName"]);
        container.Entities.push(["ParentContext", "_meta.ID ", "Order_Action.Name", "Entity", "ContextName"]);
    };
    TBProperties.BuildProductToProductProperties = function (array) {
        array.push(['ParentContext',
            'Product.Element_Guid',
            'Min_Occurs',
            'Max_Occurs',
            'Product.Available_Start_Date',
            'Product.Available_End_Date',
            'Product.Effective_Start_Date',
            'Product.Effective_End_Date',
            'Association_Start_Date',
            'Association_End_Date',
            'ContextName',
            'Selector']);
    };
    TBProperties.BuildProductToChargeProperties = function (array) {
        array.push(['ParentContext',
            'Charge.Element_Guid',
            'Min_Occurs',
            'Max_Occurs',
            'ContextName',
            'Selector']);
    };
    TBProperties.BuildProductToCostProperties = function (array) {
        array.push(['ParentContext',
            'Cost.Element_Guid',
            'Min_Occurs',
            'Max_Occurs',
            'ContextName',
            'Selector']);
    };
    TBProperties.BuildCBDiscounts = function (array) {
        array.push(['ParentContext',
            'Discount.Element_Guid',
            'Min_Occurs',
            'Max_Occurs',
            'ContextName',
            'Selector']);
    };
    TBProperties.BuildCBPricing = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Path_To_Adjusted_Entity',
            'ExcludeTargetDiscount',
            'ContextName']);
    };
    TBProperties.BuildDiscountRate = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'OrdOfExec',
            'IsExclusive',
            'ContextName']);
    };
    TBProperties.BuildChgAdjst = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Amount',
            'TgtChg',
            'ContextName']);
    };
    TBProperties.BuildAdjType = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Name']);
    };
    TBProperties.BuildCBCalculations = function (array) {
        array.push(['ParentContextName',
            'MarkupType',
            'MarkupAmount',
            'Aggregate',
            'AggregateMarkupValue',
            'ContextName']);
    };
    TBProperties.BuildCBMarkup = function (array) {
        array.push(['ParentContextName',
            'CostLinkID',
            'CostPortfolioItemID',
            'CostValue',
            'MarkupValue',
            'ResultValue']);
    };
    TBProperties.BuildThresholdValues = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'UnitsGreaterOrEqualTo',
            'UnitRate']);
    };
    TBProperties.BuildTieredValues = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'UnitsLessOrEqualTo',
            'UnitRate']);
    };
    TBProperties.BuildUnitBasedRateValues = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'ContextName']);
    };
    TBProperties.BuildRateProperties = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Rate',
            'ContextName']);
    };
    TBProperties.BuildCUDC = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Min_Occurs',
            'Max_Occurs',
            'Name',
            'Display_Description',
            'AvStart',
            'AvEnd',
            'ContextName']);
    };
    TBProperties.BuildCharacteristic = function (array) {
        array.push(['ParentContext',
            '_meta.ID',
            'Name']);
    };
    TBProperties.BuildProductProperties = function (array, entity) {
        array.push(['Property', 'Value']);
        array.push(['Available_Start_Date', entity.Available_Start_Date]);
        array.push(['Effective_Start_Date', entity.Effective_Start_Date]);
        array.push(['Available_End_Date', entity.Available_End_Date]);
        array.push(['Effective_End_Date', entity.Effective_End_Date]);
    };
    TBProperties.BuildChargeGroupValues = function (group, relation) {
        group.push(['ParentContext', 'Charge_Group.Element_Guid', 'ContextName', 'Selector']);
        relation.push(['ParentContext', 'Charge.Element_Guid', 'Min_Occurs', 'Max_Occurs', 'ContextName', 'Selector']);
    };
    TBProperties.BuildDiscountGroupValues = function (group, relation) {
        group.push(['ParentContext', 'Discount_Group.Element_Guid', 'ContextName', 'Selector']);
        relation.push(['ParentContext', 'Discount.Element_Guid', 'Min_Occurs', 'Max_Occurs', 'ContextName', 'Selector']);
    };
    TBProperties.BuildComponentGroupValues = function (group, relation) {
        group.push(['ParentContext', 'Component_Group.Element_Guid', 'ContextName', 'Selector']);
        relation.push(['ParentContext', 'Component.Element_Guid', 'Min_Occurs', 'Max_Occurs', 'ContextName', 'Selector']);
    };
    TBProperties.BuildProductToDiscountProperties = function (array) {
        array.push(['ParentContext', 'Discount.Element_Guid', 'Min_Occurs', 'Max_Occurs', 'ContextName', 'Selector']);
    };
    return TBProperties;
}());
module.exports = TBProperties;

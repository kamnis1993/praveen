"use strict";
/// <reference types="lodash" />
var ConditionCodeContainer = /** @class */ (function () {
    function ConditionCodeContainer() {
        this.Values = [];
        this.CommPhaseValues = [];
        this.TechPhaseValues = [];
        this.ExistsData = new ExistsContainer();
        this.NotExistsData = new ExistsContainer();
        this.EntToEntCount = new EntToEntContainer();
        this.EntToStaticCount = new EntToStaticContainer();
        this.EntToUDCCount = new EntToUDCContainer();
    }
    return ConditionCodeContainer;
}());
var ExistsContainer = /** @class */ (function () {
    function ExistsContainer() {
        this.text = [];
        this.Values = [];
        this.Entities = [];
    }
    return ExistsContainer;
}());
var EntToStaticContainer = /** @class */ (function () {
    function EntToStaticContainer() {
        this.data = [];
        this.Entities = [];
    }
    return EntToStaticContainer;
}());
var EntToEntContainer = /** @class */ (function () {
    function EntToEntContainer() {
        this.data = [];
        this.Entities1 = [];
        this.Entities2 = [];
    }
    return EntToEntContainer;
}());
var EntToUDCContainer = /** @class */ (function () {
    function EntToUDCContainer() {
        this.data = [];
        this.Entities = [];
    }
    return EntToUDCContainer;
}());
module.exports = ConditionCodeContainer;

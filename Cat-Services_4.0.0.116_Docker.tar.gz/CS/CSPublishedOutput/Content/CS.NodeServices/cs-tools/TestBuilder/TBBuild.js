"use strict";
///<reference types="node" />
var TBDataAccess = require("./TBDataAccess");
var TBContainer = require("./TBContainer");
var TBProperties = require("./TBProperties");
var TBRequest = require("./TBRequest");
var TBResponse = require("./TBResponse");
var TBUtils = require("./TBUtils");
var async = require('async');
var fs = require('fs');
var TBBuild = /** @class */ (function () {
    function TBBuild() {
    }
    /**
    * Check if an alias file already exists
    * @param {any} aliasFile - file containing aliases
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBBuild.CheckForExistingAliasFile = function (aliasFile, aliases) {
        console.log('Checking for Alias File');
        // Check if file exists
        if (fs.existsSync(aliasFile)) {
            // Check if its empty
            // Prevents "Unexpected End of JSON input" error
            var checkForContent = fs.readFileSync(aliasFile).toString();
            if (checkForContent !== "") {
                var existingAliases = JSON.parse(fs.readFileSync(aliasFile));
                Object.keys(existingAliases).forEach(function (key) {
                    var value = existingAliases[key];
                    aliases.push([key, value]);
                });
            }
        }
    };
    /**
    * Generate Alias file
    * @param {any} rootEntity - root item in specification
    * @param {any} aliasFile - file containing aliases
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBBuild.BuildAliasFile = function (rootEntity, aliasFile, aliases) {
        console.log('Building Alias File');
        var aliasStream = fs.createWriteStream(aliasFile);
        aliasStream.once("open", function (fd) {
            aliasStream.write('{\r\n');
            var firstTime = true;
            for (var i = 0; i < aliases.length; i++) {
                if (!firstTime) {
                    aliasStream.write(',');
                    aliasStream.write('\r\n');
                }
                firstTime = false;
                aliasStream.write('  "' + aliases[i][0] + '": "' + aliases[i][1] + '"');
            }
            aliasStream.write('\r\n');
            aliasStream.write('}');
            aliasStream.end();
        });
    };
    /**
    * Main function to Generate .feature file
    * @param {any} rootEntity - root item in specification
    * @param {any} featureFile - variables defined in TestBuilder.ts to defined paths/values for test
    * @param {string} story
    * @param {string} storyName
    * @param {string} feature
    * @param {string} featureDescription
    * @param {string} scenarioComments
    * @param {string} scenarioDescription
    * @param {string} requestFileName
    * @param {string} activationDate
    * @param {any} rootEntityGuid
    * @param {any} businessIDToEntityLookup
    * @param {string} requestPath
    * @param {string} requestUrl - end of TestBuilder.ts variables
    * @param {any} stream - file containing aliases
    * @param {any[]} aliases - list of all aliases
    * @returns {void}
    */
    TBBuild.BuildFeatureFile = function (rootEntity, featureFile, story, storyName, feature, featureDescription, scenarioComments, scenarioDescription, requestFileName, activationDate, rootEntityGuid, businessIDToEntityLookup, requestPaths, requestUrl, dataset, stream, aliases, callback) {
        // Create the feature file
        console.log('Building Feature File');
        stream = fs.createWriteStream(featureFile);
        stream.once("open", function (fd) {
            TBBuild.BuildFeatureHeader(story, storyName, featureDescription, stream);
            TBBuild.BuildApplicationRunner(story, feature, dataset, stream);
            TBBuild.BuildSpecificationAssertion(rootEntity, rootEntityGuid, aliases, stream, businessIDToEntityLookup);
            var actions = [];
            var _loop_1 = function (i) {
                actions.push(async.ensureAsync(function (callback) {
                    TBBuild.BuildScenarioHeader(scenarioComments, scenarioDescription, stream);
                    var file = fs.readFileSync(requestPaths[i], 'utf-8');
                    var request = JSON.parse(file.toString('utf8').replace(/^\uFEFF/, ''));
                    TBRequest.BuildRequestAssertions(request, feature, story, requestFileName[i], activationDate, stream, aliases);
                    TBResponse.BuildApiCall(stream, requestUrl);
                    TBDataAccess.GetResponse(request, requestUrl, function (statusCode, response) {
                        TBResponse.BuildResponseAssertions(statusCode, response, stream, aliases);
                        return callback(null, null);
                    });
                }));
            };
            for (var i = 0; i < requestPaths.length; i++) {
                _loop_1(i);
            }
            async.series(actions, function (error, results) {
                stream.end();
                return callback(null);
            });
        });
    };
    /**
    * Build background and headers for feature file
    * @param {string} story - 'S12345'
    * @param {string} storyName - Name of test
    * @param {string} featureDescription
    * @param {any} stream - file being output to
    * @returns {void}
    */
    TBBuild.BuildFeatureHeader = function (story, storyName, featureDescription, stream) {
        TBUtils.WriteLine('# ' + story + ' : ' + storyName, stream, 0);
        TBUtils.WriteLine('Feature: ' + featureDescription, stream, 0);
        TBUtils.WriteNewLine(stream);
        TBUtils.WriteLine('Background:', stream, 1);
    };
    /**
    * Build scenario header
    * @param {string} scenarioComments
    * @param {string} scenarioDescription
    * @param {any} stream - file being output to
    * @returns {void}
    */
    TBBuild.BuildScenarioHeader = function (scenarioComments, scenarioDescription, stream) {
        TBUtils.WriteLine('Scenario: ' + scenarioDescription, stream, 1);
        TBUtils.WriteLine('# ' + scenarioComments + '', stream);
        TBUtils.WriteNewLine(stream);
    };
    /**
    * Generate assertions relating to server, data set and alias locations
    * @param {string} story 'S12345'
    * @param {string} feature 'Pricing'/'Mapping' etc
    * @param {any} stream - file being output to
    * @returns {void}
    */
    TBBuild.BuildApplicationRunner = function (story, feature, dataset, stream) {
        // TODO change given running server line to point at nqx folder
        TBUtils.WriteLine('Given a running server populated from "../../data_sets/' + dataset + '"', stream);
        TBUtils.WriteLine('And the aliases for Feature "' + story + '" loaded from "../../Features/' + feature + '/aliases"' + '', stream);
        TBUtils.WriteNewLine(stream);
    };
    /**
    * Generate assertions relating to server, data set and alias locations
    * @param {any} rootEntity root item in specification
    * @param {any} rootEntityGuid guid of root item
    * @param {any[]} alliases list of all aliases
    * @param {any} stream file being output to
    * @param {any[]} businessIDToEntityLookup array storing entitys and their BIDs
    * @returns {void}
    */
    TBBuild.BuildSpecificationAssertion = function (rootEntity, rootEntityGuid, aliases, stream, businessIDToEntityLookup) {
        TBUtils.WriteLine('# Specification', stream);
        var rootAlias = TBUtils.AddAlias("root", rootEntityGuid, aliases);
        TBUtils.WriteLine('And the datastore contains a product spec with ID "' + rootAlias + '"', stream);
        TBProperties.BuildProperties('ProductSpec', rootEntity, stream);
        TBBuild.BuildProductToProduct('ProductSpec', rootEntity, aliases, stream, businessIDToEntityLookup);
    };
    /**
    * Check root item for any rules, cost, charges and products
    * @param {any} parentContext name of parent
    * @param {any} entity root item in specification
    * @param {any[]} alliases list of all aliases
    * @param {any} stream file being output to
    * @param {any[]} businessIDToEntityLookup array storing entitys and their BIDs
    * @returns {void}
    */
    TBBuild.BuildProductToProduct = function (parentContext, entity, aliases, stream, businessIDToEntityLookup) {
        var Container = {};
        TBContainer.CreateContainer(Container);
        var alias = TBUtils.AddAlias(entity.Name, entity.Element_Guid, aliases);
        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, entity, alias);
        // Build rules
        if (entity.MappingRules) {
            TBBuild.BuildMappingRules(entity, parentContext, Container.mappingRuleValues, aliases);
        }
        if (entity.ChildCompatibilityRules) {
            TBBuild.BuildCompatibilityRules(parentContext, entity.ChildCompatibilityRules, Container.childCompatibilityRules, aliases, Container.childCompatibilityRulesText);
        }
        if (entity.PortfolioCompRule) {
            TBBuild.BuildCompatibilityRules(parentContext, entity.PortfolioCompRule, Container.portfolioCompatibilityRules, aliases, Container.portfolioCompatibilityRulesText);
        }
        if (entity.PC_CompRules) {
            TBBuild.BuildCompatibilityRules(parentContext, entity.PC_CompRules, Container.productCandidateCompatibilityRules, aliases, Container.productCandidateCompatibilityRulesText);
        }
        if (entity.TChild_Group_Cardinality_Rule) {
            TBBuild.BuildGroupCardinalityRules(parentContext, entity.TChild_Group_Cardinality_Rule, Container, aliases);
        }
        Container = TBBuild.BuildConfigurableFacts(entity, parentContext, Container, aliases);
        if (entity.SigmaEntLinks) {
            TBBuild.BuildEntityLinks(parentContext, entity.SigmaEntLinks, Container, aliases);
        }
        // Build entity relations
        if (entity.Product_To_Cost || entity.Product_To_Charge || entity.Product_To_Product || entity.CBDiscounts) {
            TBBuild.BuildProducts(parentContext, entity, aliases, businessIDToEntityLookup, Container);
        }
        TBContainer.WriteContainer(Container, stream, businessIDToEntityLookup);
    };
    /**
    * Iterate over the spec and pick out information of every entity
    * @param {any} parentContext name of parent
    * @param {any} entity root item in specification
    * @param {any[]} alliases list of all aliases
    * @param {any[]} businessIDToEntityLookup array storing entitys and their BIDs
    * @param {any} container contains multiple arrays to store all values
    * @returns {void}
    */
    TBBuild.BuildProducts = function (parentContext, entity, aliases, businessIDToEntityLookup, container) {
        if (entity.Product_To_Cost) {
            var context_1;
            TBUtils.AsArray(entity.Product_To_Cost).forEach(function (productToCost) {
                if (productToCost.Cost) {
                    TBUtils.AsArray(productToCost.Cost).forEach(function (cost) {
                        var alias = TBUtils.AddAlias(cost.Name, cost.Element_Guid, aliases);
                        context_1 = cost.Name + '_' + container.costCounter;
                        TBUtils.AddContext(context_1);
                        container.costValues.push([parentContext, alias, productToCost.Min_Occurs, productToCost.Max_Occurs, context_1, 'Cost']);
                        container.costCounter++;
                        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, cost, alias);
                        TBBuild.BuildRate(cost, context_1, container, aliases, businessIDToEntityLookup);
                    });
                }
                if (productToCost.CommPhases || productToCost.TechPhases) {
                    TBBuild.BuildPhaseCodes(productToCost, context_1 + ' Relation', container.relationCardinalityRules.CommPhaseValues, container.relationCardinalityRules.TechPhaseValues, aliases);
                }
            });
        }
        if (entity.Product_To_Charge) {
            var context_2;
            TBUtils.AsArray(entity.Product_To_Charge).forEach(function (productToCharge) {
                if (productToCharge.Charge) {
                    TBUtils.AsArray(productToCharge.Charge).forEach(function (charge) {
                        var alias = TBUtils.AddAlias(charge.Name, charge.Element_Guid, aliases);
                        context_2 = charge.Name + '_' + container.chargeCounter;
                        TBUtils.AddContext(context_2);
                        container.chargeValues.push([parentContext, alias, productToCharge.Min_Occurs, productToCharge.Max_Occurs, context_2, 'Charge']);
                        container.chargeCounter++;
                        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, charge, alias);
                        TBBuild.BuildRate(charge, context_2, container, aliases, businessIDToEntityLookup);
                    });
                }
                if (productToCharge.CommPhases || productToCharge.TechPhases) {
                    TBBuild.BuildPhaseCodes(productToCharge, context_2 + ' Relation', container.relationCardinalityRules.CommPhaseValues, container.relationCardinalityRules.TechPhaseValues, aliases);
                }
            });
        }
        if (entity.CBDiscounts) {
            var rateCounter = 0;
            var context_3;
            TBUtils.AsArray(entity.CBDiscounts).forEach(function (cbdiscount) {
                if (cbdiscount.Discount) {
                    TBUtils.AsArray(cbdiscount.Discount).forEach(function (discount) {
                        var alias = TBUtils.AddAlias(discount.Name, discount.Element_Guid, aliases);
                        context_3 = discount.Name + '_' + container.discountCounter;
                        TBUtils.AddContext(context_3);
                        container.discountValues.push([parentContext,
                            alias,
                            cbdiscount.Min_Occurs,
                            cbdiscount.Max_Occurs,
                            context_3,
                            'Discount']);
                        container.discountCounter++;
                        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, discount, alias);
                        if (discount.Rates) {
                            TBUtils.AsArray(discount.Rates).forEach(function (rate) {
                                TBBuild.BuildDiscountRate(rate, rateCounter, context_3, container, businessIDToEntityLookup, aliases);
                                rateCounter++;
                            });
                        }
                    });
                }
                if (cbdiscount.CommPhases || cbdiscount.TechPhases) {
                    TBBuild.BuildPhaseCodes(cbdiscount, context_3 + ' Relation', container.relationCardinalityRules.CommPhaseValues, container.relationCardinalityRules.TechPhaseValues, aliases);
                }
            });
        }
        if (entity.Product_To_Discount) {
            TBUtils.AsArray(entity.Product_To_Discount).forEach(function (productToDiscount) {
                if (productToDiscount.Discount) {
                    TBUtils.AsArray(productToDiscount.Discount).forEach(function (discount) {
                        var alias = TBUtils.AddAlias(discount.Name, discount.Element_Guid, aliases);
                        var context = TBUtils.AddContext(discount.Name + "_" + container.discountCounter);
                        container.productToDiscountValues.push([parentContext, alias, productToDiscount.Min_Occurs, productToDiscount.Max_Occurs, context, 'Discount']);
                        container.discountCounter++;
                    });
                }
            });
        }
        if (entity.Product_To_Charge_Group) {
            TBUtils.AsArray(entity.Product_To_Charge_Group).forEach(function (productToChargeGroup) {
                if (productToChargeGroup.Charge_Group) {
                    TBUtils.AsArray(productToChargeGroup.Charge_Group).forEach(function (group) {
                        var alias = TBUtils.AddAlias("Charge_Group_" + container.ChargeGroupCounter, group.Element_Guid, aliases);
                        var contextName = TBUtils.AddContext("Charge_Group_" + container.ChargeGroupCounter);
                        container.ChargeGroup.push([parentContext, alias, contextName, 'Charge_Group']);
                        if (group.Charge_Relation) {
                            TBUtils.AsArray(group.Charge_Relation).forEach(function (relation) {
                                TBUtils.AsArray(relation.Charge).forEach(function (charge) {
                                    var relationAlias = TBUtils.AddAlias("Charge_" + container.chargeCounter, charge.Element_Guid, aliases);
                                    var relationContextName = TBUtils.AddContext("Charge_" + container.chargeCounter);
                                    container.ChargeRelation.push([contextName, relationAlias, relation.Min_Occurs, relation.Max_Occurs, relationContextName, 'Charge']);
                                    container.chargeCounter++;
                                });
                            });
                        }
                        container.ChargeGroupCounter++;
                    });
                }
            });
        }
        if (entity.Product_To_Discount_Group) {
            TBUtils.AsArray(entity.Product_To_Discount_Group).forEach(function (productToDiscountGroup) {
                if (productToDiscountGroup.Discount_Group) {
                    TBUtils.AsArray(productToDiscountGroup.Discount_Group).forEach(function (group) {
                        var alias = TBUtils.AddAlias("Discount_Group_" + container.DiscountGroupCounter, group.Element_Guid, aliases);
                        var contextName = TBUtils.AddContext("Discount_Group_" + container.DiscountGroupCounter);
                        container.DiscountGroup.push([parentContext, alias, contextName, 'Discount_Group']);
                        if (group.Discount_Relation) {
                            TBUtils.AsArray(group.Discount_Relation).forEach(function (relation) {
                                TBUtils.AsArray(relation.Discount).forEach(function (discount) {
                                    var relationAlias = TBUtils.AddAlias("Discount_" + container.discountCounter, discount.Element_Guid, aliases);
                                    var relationContextName = TBUtils.AddContext("Discount_" + container.discountCounter);
                                    container.DiscountRelation.push([contextName, relationAlias, relation.Min_Occurs, relation.Max_Occurs, relationContextName, 'Discount']);
                                    container.discountCounter++;
                                });
                            });
                        }
                        container.DiscountGroupCounter++;
                    });
                }
            });
        }
        // Product to Product has to come last as it contains recursive function call
        if (entity.Product_To_Product) {
            var productContext_1;
            TBUtils.AsArray(entity.Product_To_Product).forEach(function (productToProduct) {
                if (productToProduct.Product) {
                    TBUtils.AsArray(productToProduct.Product).forEach(function (product) {
                        var alias = TBUtils.AddAlias(product.Name, product.Element_Guid, aliases);
                        productContext_1 = TBUtils.AddContext(product.Name);
                        container.productValues.push([parentContext,
                            alias,
                            productToProduct.Min_Occurs,
                            productToProduct.Max_Occurs,
                            product.Available_Start_Date,
                            product.Available_End_Date,
                            product.Effective_Start_Date,
                            product.Effective_End_Date,
                            productToProduct.Association_Start_Date,
                            productToProduct.Association_End_Date,
                            productContext_1,
                            'Product']);
                        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, product, alias);
                        if (product.MappingRules) {
                            TBBuild.BuildMappingRules(product, productContext_1, container.mappingRuleValues, aliases);
                        }
                        if (product.ChildCompatibilityRules) {
                            TBBuild.BuildCompatibilityRules(productContext_1, product.ChildCompatibilityRules, container.childCompatibilityRules, aliases, container.childCompatibilityRulesText);
                        }
                        if (product.PortfolioCompRule) {
                            TBBuild.BuildCompatibilityRules(productContext_1, product.PortfolioCompRule, container.portfolioCompatibilityRules, aliases, container.portfolioCompatibilityRulesText);
                        }
                        if (product.PC_CompRules) {
                            TBBuild.BuildCompatibilityRules(productContext_1, product.PC_CompRules, container.productCandidateCompatibilityRules, aliases, container.productCandidateCompatibilityRulesText);
                        }
                        if (product.Commercial_SpecCharUse) {
                            TBBuild.BuildCommercialSpecCharUse(productContext_1, product, container.charContextNames, container.commercialSpecChars.Values, container.commercialSpecChars.CommPhaseValues, container.commercialSpecChars.TechPhaseValues, container.characteristic_CharValueValues, container.characteristic_Values, aliases);
                        }
                        if (product.Commercial_UserDefinedChar) {
                            TBBuild.BuildUserDefinedChar(productContext_1, product, container.commercial_UserDefinedChar, container.characteristic, aliases);
                        }
                        if (product.TChild_Group_Cardinality_Rule) {
                            TBBuild.BuildGroupCardinalityRules(productContext_1, product.TChild_Group_Cardinality_Rule, container, aliases);
                        }
                        if (product.EntityLinkValues) {
                            TBBuild.BuildEntityLinks(productContext_1, product.EntityLinks.Values, container, aliases);
                        }
                        container = TBBuild.BuildConfigurableFacts(product, productContext_1, container, aliases);
                        // Recursive call with child products
                        TBBuild.BuildProducts(productContext_1, product, aliases, businessIDToEntityLookup, container);
                    });
                    if (productToProduct.CommPhases || productToProduct.TechPhases) {
                        TBBuild.BuildPhaseCodes(productToProduct, productContext_1 + ' Relation', container.relationCardinalityRules.CommPhaseValues, container.relationCardinalityRules.TechPhaseValues, aliases);
                    }
                }
            });
        }
    };
    TBBuild.BuildUserDefinedChar = function (parentContext, product, userDefinedCharValues, characteristicValues, aliases) {
        var count = 1;
        TBUtils.AsArray(product.Commercial_UserDefinedChar).forEach(function (userDefinedChar) {
            //Context name is the first value from the description + a number
            //while statement to check value isnt already present, increments the count if so and reassigns
            //R1 becomes R2 etc
            var contextName;
            if (userDefinedChar.Display_Description) {
                contextName = userDefinedChar.Display_Description.charAt(1) + count;
            }
            else {
                contextName = "CN_UDC_" + count;
            }
            //Create alias linking the Characteristic name and metaID
            var alias = TBUtils.AddAlias(userDefinedChar.Display_Description, userDefinedChar._meta.ID, aliases);
            userDefinedCharValues.push([parentContext, alias, userDefinedChar.Min_Occurs, userDefinedChar.Max_Occurs, userDefinedChar.Name, userDefinedChar.Display_Description, userDefinedChar.AvStart, userDefinedChar.AvEnd, contextName]);
            //Can now repeat a similar process for Characteristic.Characteristic_CharValue
            if (userDefinedChar.Characteristic) {
                TBUtils.AsArray(userDefinedChar.Characteristic).forEach(function (Characteristic) {
                    var alias = TBUtils.AddAlias(Characteristic.Name, Characteristic._meta.ID, aliases);
                    characteristicValues.push([contextName, alias, Characteristic.Name]);
                });
            }
            count++;
        });
    };
    /**
    * Build recurring and non_recurring rates
    * @param {any} item entity from spec that contains a rate
    * @param {string} parentContext name of parent
    * @param {any} container contains multiple arrays to store all values of entities
    * @param {any[]} alliases list of all aliases
    * @param {any} businessIDToEntityLookup array storing entitys aliases and their BIDs
    * @returns {void}
    */
    TBBuild.BuildRate = function (item, parentContext, container, aliases, businessIDToEntityLookup) {
        if (item.Rate_Non_Recurring) {
            // Create unique contextNames when a single entity has multiple rates attached
            var rateCounter_1 = 1;
            TBUtils.AsArray(item.Rate_Non_Recurring).forEach(function (Rate_Non_Recurring) {
                // Attach rate counter if its > 0
                // Rate_0 is unnecessary
                var contextName;
                var rateAliasNR;
                if (rateCounter_1 > 0) {
                    contextName = TBUtils.AddContext(parentContext + '_Rate_' + rateCounter_1);
                    rateAliasNR = TBUtils.AddAlias((parentContext + '_Rate_' + rateCounter_1), Rate_Non_Recurring._meta.ID, aliases);
                }
                else {
                    contextName = TBUtils.AddContext(parentContext + '_Rate');
                    rateAliasNR = TBUtils.AddAlias((parentContext + '_Rate'), Rate_Non_Recurring._meta.ID, aliases);
                }
                TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, Rate_Non_Recurring, rateAliasNR);
                if (typeof (Rate_Non_Recurring.Rate) === "object") {
                    // Handle Thres and Tier
                    container.unitBasedRates.nonRecurringValues.push([parentContext, rateAliasNR, contextName]);
                    TBBuild.BuildUnitBasedRates(contextName, Rate_Non_Recurring.Rate, container, rateCounter_1, aliases);
                }
                else {
                    container.nonRecurringRateValues.push([parentContext, rateAliasNR, Rate_Non_Recurring.Rate, contextName]);
                }
                // Cost Based Charges will contain a costratetype
                if (Rate_Non_Recurring.CostRateType) {
                    TBBuild.BuildCBCAssertions(contextName, Rate_Non_Recurring, container.nonRecurringStrings, "Non_Recurring");
                }
                rateCounter_1++;
            });
        }
        if (item.Rate_Recurring) {
            // Create unique contextNames when a single entity has multiple rates attached
            var rateCounter_2 = 0;
            TBUtils.AsArray(item.Rate_Recurring).forEach(function (Rate_Recurring) {
                // Attach rate counter if its > 0
                // Rate_0 is unnecessary
                var contextName;
                var rateAliasR;
                if (rateCounter_2 > 0) {
                    contextName = TBUtils.AddContext(parentContext + '_Rate_' + rateCounter_2);
                    rateAliasR = TBUtils.AddAlias((parentContext + '_Rate_' + rateCounter_2), Rate_Recurring._meta.ID, aliases);
                }
                else {
                    contextName = TBUtils.AddContext(parentContext + '_Rate');
                    rateAliasR = TBUtils.AddAlias((parentContext + '_Rate'), Rate_Recurring._meta.ID, aliases);
                }
                TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, Rate_Recurring, rateAliasR);
                if (typeof (Rate_Recurring.Rate) === "object") {
                    // Handle Thres and Tier
                    container.unitBasedRates.recurringValues.push([parentContext, rateAliasR, contextName]);
                    TBBuild.BuildUnitBasedRates(contextName, Rate_Recurring.Rate, container, rateCounter_2, aliases);
                }
                else {
                    container.recurringRateValues.push([parentContext, rateAliasR, Rate_Recurring.Rate, contextName]);
                }
                // Cost Based Charges will contain a costratetype
                if (Rate_Recurring.CostRateType) {
                    TBBuild.BuildCBCAssertions(contextName, Rate_Recurring, container.recurringStrings, "Recurring");
                }
                rateCounter_2++;
            });
        }
    };
    /**
    * Build the rates contained with a discount object
    * @param {string} parentContext name of parent
    * @param {any} rate rate contained within a discount
    * @param {any} container contains multiple arrays to store all values of entities
    * @param {any[]} alliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildUnitBasedRates = function (parentContext, rate, container, counter, aliases) {
        var unitBasedRateCounter = 1;
        TBUtils.AsArray(rate).forEach(function (rate) {
            // Check if Tiered or Threshold
            // Threshold has to have a GreaterOrEqual to, Tiered can be missing LessOrEqualTo
            if (rate.UnitsGreaterOrEqualTo) {
                var alias = void 0;
                if (counter > 0) {
                    alias = TBUtils.AddAlias(("Rate_" + counter + "_ThresholdBand_" + unitBasedRateCounter), rate._meta.ID, aliases);
                }
                else {
                    alias = TBUtils.AddAlias(("Rate_ThresholdBand_" + unitBasedRateCounter), rate._meta.ID, aliases);
                }
                container.unitBasedRates.thresholdRateValues.push([parentContext, alias, rate.UnitsGreaterOrEqualTo, rate.UnitRate]);
            }
            else {
                var alias = void 0;
                if (counter > 0) {
                    alias = TBUtils.AddAlias(("Rate_" + counter + "_TieredBand_" + unitBasedRateCounter), rate._meta.ID, aliases);
                }
                else {
                    alias = TBUtils.AddAlias(("Rate_TieredBand_" + unitBasedRateCounter), rate._meta.ID, aliases);
                }
                container.unitBasedRates.tieredRateValues.push([parentContext, alias, rate.UnitsLessOrEqualTo, rate.UnitRate]);
            }
            unitBasedRateCounter++;
        });
    };
    /**
    * Build the rates contained with a discount object
    * @param {any} rate rate contained within a discount
    * @param {number} counter entity from spec that contains a rate
    * @param {string} parentContext name of parent
    * @param {any} container contains multiple arrays to store all values of entities
    * @param {any} businessIDToEntityLookup array storing entitys aliases and their BIDs
    * @param {any[]} alliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildDiscountRate = function (rate, counter, parentContext, container, businessIDToEntityLookup, aliases) {
        var discountRateAlias;
        var contextName;
        if (counter > 0) {
            contextName = parentContext + '_Rate_' + counter;
            discountRateAlias = TBUtils.AddAlias(('Discount_Rate_' + counter), rate._meta.ID, aliases);
        }
        else {
            contextName = parentContext + '_Rate';
            discountRateAlias = TBUtils.AddAlias('Discount_Rate', rate._meta.ID, aliases);
        }
        container.discountRateValues.push([parentContext, discountRateAlias, rate.OrdOfExec, rate.IsExclusive, contextName]);
        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, rate, discountRateAlias);
        if (rate.ChgAdjst) {
            var adjstCounter = 1;
            TBUtils.AsArray(rate.ChgAdjst).forEach(function (chgadjst) {
                var name = "Rate_" + counter + "_ChgAdjst_" + adjstCounter;
                TBBuild.BuildChgAdjst(chgadjst, container, contextName, name, aliases, businessIDToEntityLookup);
                adjstCounter++;
            });
            counter++;
        }
    };
    /**
    * build assertion strings relating to costratetypes and their associated costs
    * @param {any} parentContext name of parent
    * @param {any} rate entity from spec that contains the costratetype
    * @param {any} array a member of Container object that the values can be stored into
    * @param {any} type either "recurring" or "non_recurring"
    * @returns {void}
    */
    TBBuild.BuildCBCAssertions = function (parentContext, rate, array, type) {
        // Should always be equal number of CostRateTypes and costs
        TBUtils.AsArray(rate.CostRateType).forEach(function (type) {
            TBUtils.AsArray(rate.Cost).forEach(function (cost) {
                array.push('And that "' + parentContext + '" has a "CostRateType.Name" of "' + type.Name + '"');
                array.push('And that "' + parentContext + '" contains a "Cost"');
                array.push('And that "Cost" has a "CostEntity" with a business ID Path of "' + cost.CostEntity + '"');
            });
        });
    };
    /**
    * gather data on charge adjustments and adjustment types
    * @param {any} chgAdjst chargeAdjustment object
    * @param {any} container object that holds arrays that product data will be stored in
    * @param {any} parentContext name of parent
    * @param {any} context name to be used for self
    * @param {any} type either "recurring" or "non_recurring"
    * @param {any[]} aliases list of all aliases
    * @param {any} businessIDToEntityLookup list of entities and their BIDs
    * @returns {void}
    */
    TBBuild.BuildChgAdjst = function (chgAdjst, container, parentContext, context, aliases, businessIDToEntityLookup) {
        var chgAdjstAlias = TBUtils.AddAlias(context, chgAdjst._meta.ID, aliases);
        TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, chgAdjst, chgAdjstAlias);
        context = TBUtils.AddContext(context);
        container.chgAdjstValues.push([parentContext, chgAdjstAlias, chgAdjst.Amount, chgAdjst.TgtChg, context]);
        if (chgAdjst.AdjType) {
            TBUtils.AsArray(chgAdjst.AdjType).forEach(function (type) {
                var name = type.Name + "_AdjType";
                var adjTypeAlias = TBUtils.AddAlias(name, type._meta.ID, aliases);
                TBBuild.UpdateBusinessIDToEntityLookUp(businessIDToEntityLookup, type, adjTypeAlias);
                container.adjTypeValues.push([context, adjTypeAlias, type.Name]);
            });
        }
    };
    /**
    * updates the businessIDToEntityLookup array
    * @param {any[]} businessIDToEntityLookup list of entities and their BIDs
    * @param {any} entity entity being added to lookup
    * @param {any} alias alias of entity
    * @returns {void}
    */
    TBBuild.UpdateBusinessIDToEntityLookUp = function (businessIDToEntityLookup, entity, alias) {
        // Business ID duplications are not checked
        businessIDToEntityLookup.push({ businessId: entity._meta.BusinessID, entityDetails: { entityId: entity._meta.ID, entityName: entity.Name, entityAlias: alias } });
    };
    /**
    * search businessIDToEntityLookup array for an entity with a given BID
    * @param {any[]} businessIDToEntityLookup list of entities and their BIDs
    * @param {any} businessId BID being used to search
    * @returns {void}
    */
    TBBuild.FindEntityForBusinessID = function (businessIDToEntityLookup, businessId) {
        var length = businessIDToEntityLookup.length;
        var index = 0;
        while (length--) {
            if (businessIDToEntityLookup[index].businessId === businessId) {
                return businessIDToEntityLookup[index].entityDetails;
            }
            index++;
        }
    };
    /**
    * Build specChar data, is called as a part of BuildProducts recursive call
    * @param {any} product product to check for chars
    * @param {any} charContextNames array of existing context names for chars
    * @param {any[]} commercialSpecCharValues array to store specChar usage
    * @param {any} characteristic_CharValueValues array to store characteristic_CharValues
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildCommercialSpecCharUse = function (productContext, product, charContextNames, commercialSpecCharValues, commPhaseValues, techPhaseValues, characteristic_CharValueValues, characteristicValues, aliases) {
        TBUtils.AsArray(product.Commercial_SpecCharUse).forEach(function (Commercial_SpecCharUse) {
            var count = 1;
            //Context name is the first value from the description + a number
            //while statement to check value isnt already present, increments the count if so and reassigns
            //R1 becomes R2 etc
            var contextName = Commercial_SpecCharUse.Description.charAt(1) + count;
            while (charContextNames.includes(contextName)) {
                count++;
                contextName = Commercial_SpecCharUse.Description.charAt(1) + count;
            }
            //if value isnt a duplicate push it to the array
            charContextNames.push(contextName);
            //Create alias linking the Characteristic name and metaID
            var alias = TBUtils.AddAlias(Commercial_SpecCharUse.Description, Commercial_SpecCharUse._meta.ID, aliases);
            commercialSpecCharValues.push([productContext, alias, Commercial_SpecCharUse.Min_Occurs, Commercial_SpecCharUse.Max_Occurs, Commercial_SpecCharUse.AvStart, Commercial_SpecCharUse.AvEnd, contextName]);
            TBBuild.BuildPhaseCodes(Commercial_SpecCharUse, contextName, commPhaseValues, techPhaseValues, aliases);
            //Can now repeat a similar process for Characteristic and Characteristic.Characteristic_CharValue
            if (Commercial_SpecCharUse.Characteristic) {
                TBUtils.AsArray(Commercial_SpecCharUse.Characteristic).forEach(function (Characteristic) {
                    var charUniqueName = contextName + "_" + Characteristic.Name;
                    var alias = TBUtils.AddAlias(charUniqueName, Characteristic._meta.ID, aliases);
                    var charContextName = TBUtils.AddContext(charUniqueName);
                    characteristicValues.push([contextName, alias, Characteristic.Name, charContextName]);
                    if (Characteristic.Characteristic_CharValue) {
                        TBUtils.AsArray(Characteristic.Characteristic_CharValue).forEach(function (Characteristic_CharValue) {
                            //Don't use this alias here, is used in portfolio response but is needed here regardless
                            var valueAlias = TBUtils.AddAlias(Characteristic_CharValue.Value, Characteristic_CharValue._meta.ID, aliases);
                            characteristic_CharValueValues.push([charContextName, valueAlias, Characteristic_CharValue.Value, Characteristic_CharValue._meta.AvStart, Characteristic_CharValue._meta.AvEnd]);
                        });
                    }
                });
            }
        });
    };
    /**
    * Build data for compatibilityRules
    * @param {any} productContext name of product with rules attached to it
    * @param {any} compatibilityRules rules associated with the product
    * @param {any} compatibilityRuleConatiner array to store values
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildCompatibilityRules = function (productContext, compatibilityRules, compatibilityRuleConatiner, aliases, textValues) {
        TBUtils.AsArray(compatibilityRules).forEach(function (compatibilityRule) {
            var uniqueName = compatibilityRule.Name + "_" + TBBuild.ruleCount++;
            var CompatibilityRulesAlias = TBUtils.AddAlias(uniqueName, compatibilityRule._meta.ID, aliases);
            var CompatibilityRulesContextName = TBUtils.AddContext(uniqueName);
            compatibilityRuleConatiner.Values.push([productContext, CompatibilityRulesAlias, compatibilityRule.Name, compatibilityRule.ErrorMessage, CompatibilityRulesContextName]);
            TBBuild.BuildPhaseCodes(compatibilityRule, productContext, compatibilityRuleConatiner.CommPhaseValues, compatibilityRuleConatiner.TechPhaseValues, aliases);
            TBBuild.BuildExistOrderPaths(compatibilityRule, textValues, null, CompatibilityRulesContextName, aliases);
            TBBuild.BuildPathsForExistsData(TBUtils.AsArray(compatibilityRule.Exists_Data), compatibilityRuleConatiner.ExistsData, CompatibilityRulesContextName, aliases);
            TBBuild.BuildPathsForExistsData(TBUtils.AsArray(compatibilityRule.Not_Exists_Data), compatibilityRuleConatiner.NotExistsData, CompatibilityRulesContextName, aliases, false);
            TBBuild.BuildPathsForEntToStaticCount(TBUtils.AsArray(compatibilityRule.EntToStaticCount), compatibilityRuleConatiner.EntToStaticCount, CompatibilityRulesContextName, aliases);
            TBBuild.BuildPathsForEntToUDCCount(TBUtils.AsArray(compatibilityRule.EntToUDCCount), compatibilityRuleConatiner.EntToUDCCount, CompatibilityRulesContextName, aliases);
            TBBuild.BuildPathsForEntToEntCount(TBUtils.AsArray(compatibilityRule.EntToEntCount), compatibilityRuleConatiner.EntToEntCount, CompatibilityRulesContextName, aliases);
        });
    };
    /**
    * Build data for GroupCardinalityRules
    * @param {any} productContext name of product with rules attached to it
    * @param {any} groupCardinalityRules rules associated with the product
    * @param {any} container array to store values
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildGroupCardinalityRules = function (productContext, groupCardinalityRules, container, aliases) {
        TBUtils.AsArray(groupCardinalityRules).forEach(function (rule) {
            var ruleAlias = TBUtils.AddAlias(rule.Rule_Description, rule._meta.ID, aliases);
            var ruleContextName = TBUtils.AddContext(rule.Rule_Description);
            container.groupCardinalityRules.Values.push([productContext, ruleAlias,
                rule.Rule_Description, rule.Minimum_Child_Elements, rule.Maximum_Child_Elements, ruleContextName]);
            TBBuild.BuildPhaseCodes(rule, ruleContextName, container.groupCardinalityRules.CommPhaseValues, container.groupCardinalityRules.TechPhaseValues, aliases);
        });
    };
    /**
    * Build data for Entity links
    * @param {any} productContext name of product with rules attached to it
    * @param {any} entityLinks associated with the product
    * @param {any} container array to store values
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildEntityLinks = function (productContext, entityLinks, container, aliases) {
        TBUtils.AsArray(entityLinks).forEach(function (entityLink) {
            var alias = TBUtils.AddAlias(entityLink.Name, entityLink._meta.ID, aliases);
            var contextName = TBUtils.AddContext(entityLink.Name);
            container.EntityLinks.Values.push([productContext, alias, entityLink.Name, contextName]);
            TBBuild.BuildPhaseCodes(entityLink, contextName, container.EntityLinkCommPhaseValues, container.EntityLinkTechPhaseValues, aliases);
        });
    };
    /**
    * Build Data for phase codes
    * @param {any} entity the object that contains CommPhases and TechPhases elements
    * @param {any} contextName the current object context name
    * @param {any} commPhaseValues array to store Commercial Phase values
    * @param {any} techPhaseValues array to store Technical Phase values
    * @param {any[]} aliases list of all aliases
    */
    TBBuild.BuildPhaseCodes = function (entity, contextName, commPhaseValues, techPhaseValues, aliases) {
        if (entity.CommPhases) {
            TBUtils.AsArray(entity.CommPhases).forEach(function (commPhase) {
                var commPhaseAlias = TBUtils.AddAlias("CommPhase_" + commPhase.CSCode, commPhase._meta.ID, aliases);
                commPhaseValues.push([contextName, commPhaseAlias, commPhase.Name, commPhase.CSCode]);
            });
        }
        if (entity.TechPhases) {
            TBUtils.AsArray(entity.TechPhases).forEach(function (techPhase) {
                var techPhaseAlias = TBUtils.AddAlias("TechPhase_" + techPhase.CSCode, techPhase._meta.ID, aliases);
                techPhaseValues.push([contextName, techPhaseAlias, techPhase.Name, techPhase.CSCode]);
            });
        }
    };
    /**
    * Get all the Configurable facts belonging to an entity
    * Looking for Pattern of "TConfigurable_Fact"
    * @param {any} entity to search
    */
    TBBuild.GetConfigurableFacts = function (entity, container) {
        var result = [];
        var CheckIsConfigurableFact = function (key, entityToCheck) {
            if (entityToCheck._meta && entityToCheck._meta.Pattern === "TConfigurable_Fact") {
                result[key] = entityToCheck; // Story the entity against the key to be used later
            }
        };
        for (var key in entity) {
            if (Array.isArray(entity[key])) {
                for (var arrayKey in entity[key]) {
                    CheckIsConfigurableFact(key, entity[key][arrayKey]);
                }
            }
            else {
                CheckIsConfigurableFact(key, entity[key]);
            }
        }
        return result;
    };
    /**
     *Build data for Configurable facts
    * @param {any} entity the object to search for facts
    * @param {any} parentContext reference name of object containing the facts
    * @param {any} container array to store values
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildConfigurableFacts = function (entity, parentContext, container, aliases) {
        var configurableFactsOnEntity = TBBuild.GetConfigurableFacts(entity, container);
        for (var key in configurableFactsOnEntity) {
            if (!container.ConfigurableFacts[key]) {
                container.ConfigurableFacts[key] = {};
                TBBuild.CreateConfigurableFactsContainer(container.ConfigurableFacts[key]);
            }
            var fact = configurableFactsOnEntity[key];
            var uniqueFactName = entity.Name + "_Fact_" + key;
            var factContextName = TBUtils.AddContext(uniqueFactName);
            var factAlias = TBUtils.AddAlias(uniqueFactName, fact._meta.ID, aliases);
            container.ConfigurableFacts[key].Facts.push([parentContext, factAlias, fact.Min_Occurs, fact.Max_Occurs, fact.AvStart, fact.AvEnd, factContextName]);
            TBBuild.BuildPhaseCodes(fact, factContextName, container.ConfigurableFacts[key].FactCommPhaseValues, container.ConfigurableFacts[key].FactTechPhaseValues, aliases);
            if (fact.Values) {
                TBUtils.AsArray(fact.Values).forEach(function (value) {
                    var valueAlias = TBUtils.AddAlias(value.Name, value._meta.ID, aliases);
                    container.ConfigurableFacts[key].FactValues.push([factContextName, valueAlias, value.Name, value._meta.AvStart, value._meta.AvEnd]);
                });
            }
        }
        return container;
    };
    /**
    * Build data for compatibilityRules
    * @param {any} entity name of product with rules attached to it
    * @param {string} parentContextName Parent context name
    * @param {any} mappingRuleValues array to store values
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildMappingRules = function (entity, parentContextName, mappingRuleValues, aliases) {
        // The object which holds all the required data and will be written to mappingRuleValues(passed parameter)
        var mappingRuleTable = {
            parentContext: parentContextName,
            data: {
                ruleData: [],
                conditionsData: [],
                actionsData: []
            },
            IsExistOrderItems: false,
            existOrderItems: {
                conditionContextName: null,
                name: null,
                alias: null,
                sourceEntity: null,
                itemAction: null
            },
            IsExistData: false,
            ExistsData: {
                text: [],
                Values: [],
                Entities: []
            },
            IsNotExistData: false,
            NotExistsData: {
                text: [],
                Values: [],
                Entities: []
            },
            actionDetails: {
                mappingRuleAlias: null,
                targetEntity: ""
            },
            IsEntToStaticCount: false,
            EntToStaticCount: {
                data: [],
                Entities: []
            },
            IsEntToEntCount: false,
            EntToEntCount: {
                data: [],
                Entities1: [],
                Entities2: []
            },
            IsEntToUDCCount: false,
            EntToUDCCount: {
                data: [],
                Entities: []
            },
            paths: []
        };
        TBProperties.BuildMappingRuleProperties(mappingRuleTable.data);
        TBProperties.BuildExistDataProperties(mappingRuleTable.ExistsData);
        TBProperties.BuildExistDataProperties(mappingRuleTable.NotExistsData, false);
        TBProperties.BuildEntToStaticCountProperties(mappingRuleTable.EntToStaticCount);
        TBProperties.BuildEntToEntCountProperties(mappingRuleTable.EntToEntCount);
        TBProperties.BuildEntToUDCCountProperties(mappingRuleTable.EntToUDCCount);
        var NameCounter = 0;
        TBUtils.AsArray(entity.MappingRules).forEach(function (mappingRule, index) {
            // Data part
            var uniqueMappingRuleName = "mappingRule" + ++NameCounter;
            var mappingRuleAlias = TBUtils.AddAlias(uniqueMappingRuleName, mappingRule._meta.ID, aliases);
            var mappingRuleContextName = TBUtils.AddContext(uniqueMappingRuleName);
            mappingRuleTable.data.ruleData.push([mappingRuleAlias, mappingRule.Name, mappingRuleContextName]);
            // Condition part
            if (mappingRule.Conditions) {
                TBUtils.AsArray(mappingRule.Conditions).forEach(function (condition) {
                    var conditionAlias = TBUtils.AddAlias(condition.Name, condition._meta.ID, aliases);
                    var conditionsContextName = TBUtils.AddContext(condition.Name);
                    TBUtils.AsArray(condition.Scope).forEach(function (scope) {
                        mappingRuleTable.data.conditionsData.push([mappingRuleContextName, conditionAlias, condition.Name, scope.Name, conditionsContextName]);
                    });
                    TBBuild.BuildMappingRulesConditions(mappingRuleTable, condition, conditionsContextName, aliases);
                    TBBuild.BuildExistOrderPaths(condition, mappingRuleTable.paths, condition.Name, conditionsContextName, aliases);
                    if (condition.Exists_Data) {
                        mappingRuleTable.IsExistData = true;
                        TBBuild.BuildPathsForExistsData(condition.Exists_Data, mappingRuleTable.ExistsData, conditionsContextName, aliases);
                    }
                    if (condition.Not_Exists_Data) {
                        mappingRuleTable.IsNotExistData = true;
                        TBBuild.BuildPathsForExistsData(condition.Not_Exists_Data, mappingRuleTable.NotExistsData, conditionsContextName, aliases, false);
                    }
                    if (condition.EntToStaticCount) {
                        mappingRuleTable.IsEntToStaticCount = true;
                        TBBuild.BuildPathsForEntToStaticCount(condition.EntToStaticCount, mappingRuleTable.EntToStaticCount, conditionsContextName, aliases);
                    }
                    if (condition.EntToEntCount) {
                        mappingRuleTable.IsEntToEntCount = true;
                        TBBuild.BuildPathsForEntToEntCount(condition.EntToEntCount, mappingRuleTable.EntToEntCount, conditionsContextName, aliases);
                    }
                    if (condition.EntToUDCCount) {
                        mappingRuleTable.IsEntToUDCCount = true;
                        TBBuild.BuildPathsForEntToUDCCount(condition.EntToUDCCount, mappingRuleTable.EntToUDCCount, conditionsContextName, aliases);
                    }
                });
            }
            // Action part
            if (mappingRule.Actions) {
                TBUtils.AsArray(mappingRule.Actions).forEach(function (action) {
                    var alias = TBUtils.AddAlias(action.Name, action._meta.ID, aliases);
                    var actionContextName = TBUtils.AddContext(action.Name);
                    mappingRuleTable.data.actionsData.push([mappingRuleContextName, alias, action.Name, actionContextName]);
                    mappingRuleTable.actionDetails.targetEntity = action.Target;
                    mappingRuleTable.actionDetails.mappingRuleAlias = mappingRuleAlias;
                });
            }
        });
        mappingRuleValues.push(mappingRuleTable);
    };
    TBBuild.BuildExistOrderPaths = function (condition, paths, conditionName, conditionContextName, aliases) {
        if (condition.ExistsOrderValueAction) {
            TBBuild.BuildPathsForAction(condition.ExistsOrderValueAction, paths, conditionName || "ExistsOrderValueAction", conditionContextName, aliases);
        }
        if (condition.NotExistsOrderValueAction) {
            TBBuild.BuildPathsForAction(condition.NotExistsOrderValueAction, paths, conditionName || "NotExistsOrderValueAction", conditionContextName, aliases);
        }
        if (condition.NoValueExistsOrderAction) {
            TBBuild.BuildPathsForAction(condition.NoValueExistsOrderAction, paths, conditionName || "NoValueExistsOrderAction", conditionContextName, aliases);
        }
    };
    TBBuild.BuildPathsForAction = function (conditions, paths, conditionName, conditionContextName, aliases) {
        TBUtils.AsArray(conditions).forEach(function (condition) {
            var text = [];
            text.push('And that "' + conditionContextName + '" contains a "' + conditionName + '"');
            text.push('And that "' + conditionName + '" contains an "EntityValue"');
            text.push('And that "EntityValue" has a path to an entity of "' + TBUtils.TranslateValuesToAliases(condition.EntityValue.EntityPath, aliases) + '"');
            text.push('And that "EntityValue" references a value located at "' + TBUtils.TranslateValuesToAliases(condition.EntityValue.ElementPath, aliases) + '"');
            text.push('And that "' + conditionName + '" contains an "ItemAction"');
            text.push('And that "ItemAction" has a "Name" of "' + condition.ItemAction.Name + '"');
            paths.push([conditionContextName, text]);
        });
    };
    TBBuild.BuildPathsForExistsData = function (conditions, existDataContainer, conditionContextName, aliases, isExits) {
        if (isExits === void 0) { isExits = true; }
        TBUtils.AsArray(conditions).forEach(function (condition, index) {
            var text = [];
            var conditionName = conditionContextName + "_ED_" + index;
            var condAlias = TBUtils.AddAlias(conditionName + "_Value_" + index, condition._meta.ID, aliases);
            var CondContextName = TBUtils.AddContext(conditionName + index);
            var scopeName = undefined;
            if (condition.Scope !== undefined) {
                scopeName = condition.Scope.Name;
            }
            existDataContainer.text.push([conditionContextName, condAlias, condition.Match_Any, scopeName, CondContextName]);
            TBUtils.AsArray(condition.Values).forEach(function (value, index) {
                var ValueContextName = TBUtils.AddContext(conditionName + "_Value_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Value_" + index, value._meta.ID, aliases);
                var orderaction = undefined;
                if (value.Order_Action !== undefined) {
                    orderaction = value.Order_Action.Name;
                }
                if (isExits) {
                    existDataContainer.Values.push([CondContextName, elementalias, orderaction, TBUtils.TranslateValuesToAliases(value.Element.ElementPath, aliases, "/"), ValueContextName]);
                }
                else {
                    existDataContainer.Values.push([CondContextName, elementalias, value.Any_Empty, orderaction, TBUtils.TranslateValuesToAliases(value.Element.ElementPath, aliases, "/"), ValueContextName]);
                }
            });
            TBUtils.AsArray(condition.Entities).forEach(function (entity, index) {
                var EntityContextName = TBUtils.AddContext(conditionName + "_Entity_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Entity_" + index, entity._meta.ID, aliases);
                var orderaction = undefined;
                if (entity.Order_Action !== undefined) {
                    orderaction = entity.Order_Action.Name;
                }
                existDataContainer.Entities.push([CondContextName, elementalias, orderaction, entity.Entity, EntityContextName]);
            });
        });
    };
    TBBuild.BuildPathsForEntToEntCount = function (conditions, EntToEntContainer, conditionContextName, aliases) {
        TBUtils.AsArray(conditions).forEach(function (condition, index) {
            var text = [];
            var conditionName = conditionContextName + "_EToE_" + index;
            var condAlias = TBUtils.AddAlias(conditionName + "_Value_" + index, condition._meta.ID, aliases);
            var CondContextName = TBUtils.AddContext(conditionName + index);
            var scopeName = undefined;
            if (condition.Scope !== undefined) {
                scopeName = condition.Scope.Name;
            }
            EntToEntContainer.data.push([conditionContextName, condAlias, condition.Match_Any, condition.Comparer.Code, condition.FurtherScope, scopeName, CondContextName]);
            TBUtils.AsArray(condition.Entities_1).forEach(function (entity, index) {
                var EntityContextName = TBUtils.AddContext(conditionName + "_Entity1_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Entity1_" + index, entity._meta.ID, aliases);
                var orderaction = undefined;
                if (entity.Order_Action !== undefined) {
                    orderaction = entity.Order_Action.Name;
                }
                EntToEntContainer.Entities1.push([CondContextName, elementalias, orderaction, entity.Entity, EntityContextName]);
            });
            TBUtils.AsArray(condition.Entities_2).forEach(function (entity, index) {
                var EntityContextName = TBUtils.AddContext(conditionName + "_Entity2_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Entity2_" + index, entity._meta.ID, aliases);
                var orderaction = undefined;
                if (entity.Order_Action !== undefined) {
                    orderaction = entity.Order_Action.Name;
                }
                EntToEntContainer.Entities2.push([CondContextName, elementalias, orderaction, entity.Entity, EntityContextName]);
            });
        });
    };
    TBBuild.BuildPathsForEntToStaticCount = function (conditions, EntToStaticCountContainer, conditionContextName, aliases) {
        TBUtils.AsArray(conditions).forEach(function (condition, index) {
            var text = [];
            var conditionName = conditionContextName + "_EToStatic_" + index;
            var condAlias = TBUtils.AddAlias(conditionName + "_Value_" + index, condition._meta.ID, aliases);
            var CondContextName = TBUtils.AddContext(conditionName + index);
            var scopeName = undefined;
            if (condition.Scope !== undefined) {
                scopeName = condition.Scope.Name;
            }
            EntToStaticCountContainer.data.push([conditionContextName, condAlias, condition.Match_Any, condition.Value, condition.Comparer.Code, condition.FurtherScope, scopeName, CondContextName]);
            TBUtils.AsArray(condition.Entities).forEach(function (entity, index) {
                var EntityContextName = TBUtils.AddContext(conditionName + "_Entity_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Entity_" + index, entity._meta.ID, aliases);
                var orderaction = undefined;
                if (entity.Order_Action !== undefined) {
                    orderaction = entity.Order_Action.Name;
                }
                EntToStaticCountContainer.Entities.push([CondContextName, elementalias, orderaction, entity.Entity, EntityContextName]);
            });
        });
    };
    TBBuild.BuildPathsForEntToUDCCount = function (conditions, EntToUDCCountContainer, conditionContextName, aliases) {
        console.log(JSON.stringify(conditions));
        TBUtils.AsArray(conditions).forEach(function (condition, index) {
            var text = [];
            var conditionName = conditionContextName + "_EToUDC_" + index;
            var condAlias = TBUtils.AddAlias(conditionName + "_Value_" + index, condition._meta.ID, aliases);
            var CondContextName = TBUtils.AddContext(conditionName + index);
            var scopeName = undefined;
            if (condition.Scope !== undefined) {
                scopeName = condition.Scope.Name;
            }
            TBUtils.AsArray(condition.Element).forEach(function (element) {
                var elementpath = TBUtils.TranslateValuesToAliases(element.ElementPath, aliases, "/");
                EntToUDCCountContainer.data.push([conditionContextName, condAlias, condition.Match_Any, elementpath, condition.Comparer.Code, condition.FurtherScope, scopeName, CondContextName]);
            });
            TBUtils.AsArray(condition.Entities).forEach(function (entity, index) {
                var EntityContextName = TBUtils.AddContext(conditionName + "_Entity_" + index);
                var elementalias = TBUtils.AddAlias(conditionName + "_Entity_" + index, entity._meta.ID, aliases);
                var orderaction = undefined;
                if (entity.Order_Action !== undefined) {
                    orderaction = entity.Order_Action.Name;
                }
                EntToUDCCountContainer.Entities.push([CondContextName, elementalias, orderaction, entity.Entity, EntityContextName]);
            });
        });
    };
    /**
    * Gather data for mapping rule conditions
    * @param {any} mappingRuleTable array to store values
    * @param {any} condition json data for the individual condition
    * @param {any} conditionContextName name of the currently processed condition
    * @param {any[]} aliases list of all aliases
    * @returns {void}
    */
    TBBuild.BuildMappingRulesConditions = function (mappingRuleTable, condition, conditionsContextName, aliases) {
        // TODO This code could be extended in the future to build all condition types
        if (condition.ExistsOrdActItem) {
            mappingRuleTable.IsExistOrderItems = true;
            TBUtils.AsArray(condition.ExistsOrdActItem).forEach(function (existOrderActionItem) {
                var existOrderActionItemName = condition.Name + "_ExistsOrdActItem";
                var existOrderActItemAlias = TBUtils.AddAlias(existOrderActionItemName, existOrderActionItem._meta.ID, aliases);
                mappingRuleTable.existOrderItems.conditionContextName = conditionsContextName;
                mappingRuleTable.existOrderItems.name = existOrderActionItemName;
                mappingRuleTable.existOrderItems.alias = existOrderActItemAlias;
                // Add BusinessId as it is . As look up table construction is not complete
                mappingRuleTable.existOrderItems.sourceEntity = existOrderActionItem.Entity;
                // Since ItemAction is an array, it is indexed to 0. Ideally there shouldn't be more than one entry in array
                mappingRuleTable.existOrderItems.itemAction = existOrderActionItem.ItemAction[0].Name;
            });
        }
    };
    /**
    * Build container item for configurable facts
    * There are potentially multiple container.configurableFacts arrays to populate
    * @param {any} configurableFact the empty object
    * @returns {void}
    */
    TBBuild.CreateConfigurableFactsContainer = function (configurableFact) {
        configurableFact.Facts = [];
        configurableFact.FactValues = [];
        configurableFact.FactCommPhaseValues = [];
        configurableFact.FactTechPhaseValues = [];
        TBProperties.BuildConfigurableFactProperties(configurableFact.Facts, configurableFact.FactCommPhaseValues, configurableFact.FactTechPhaseValues, configurableFact.FactValues);
        return configurableFact;
    };
    // Helps to generate unique context name for rules in case of multicardinality
    TBBuild.ruleCount = 0;
    return TBBuild;
}());
module.exports = TBBuild;

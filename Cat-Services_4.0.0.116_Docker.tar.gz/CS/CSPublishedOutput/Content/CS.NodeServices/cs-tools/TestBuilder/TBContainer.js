"use strict";
var PhaseCodeContainer = require("./PhaseCodeContainer");
var TBBuild = require("./TBBuild");
var TBProperties = require("./TBProperties");
var TBUtils = require("./TBUtils");
var ConditionCodeContainer = require("./ConditionCodeContainer");
var TBContainer = /** @class */ (function () {
    function TBContainer() {
    }
    /**
    * Build container item, adding all members and arrays and then calling properties functions for each
    * @param {any} Container the empty object
    * @returns {void}
    */
    TBContainer.CreateContainer = function (Container) {
        Container.productValues = [];
        TBProperties.BuildProductToProductProperties(Container.productValues);
        // Mapping rules
        Container.mappingRuleValues = [];
        // Compatibility rules
        Container.childCompatibilityRules = new ConditionCodeContainer();
        TBProperties.BuildCompatibilityRulesProperties(Container.childCompatibilityRules);
        Container.portfolioCompatibilityRules = new ConditionCodeContainer();
        TBProperties.BuildCompatibilityRulesProperties(Container.portfolioCompatibilityRules);
        Container.productCandidateCompatibilityRules = new ConditionCodeContainer();
        TBProperties.BuildCompatibilityRulesProperties(Container.productCandidateCompatibilityRules);
        Container.productCandidateCompatibilityRulesText = [];
        Container.childCompatibilityRulesText = [];
        Container.portfolioCompatibilityRulesText = [];
        // Group Cardinality Rules
        Container.groupCardinalityRules = new PhaseCodeContainer();
        TBProperties.BuildCardinalityRulesProperties(Container.groupCardinalityRules);
        // Relation Cardinality Rules
        Container.relationCardinalityRules = new PhaseCodeContainer();
        TBProperties.BuildRelationshipPhaseProperties(Container.relationCardinalityRules);
        // char use
        Container.charContextNames = [];
        Container.characteristic_Values = [];
        Container.characteristic_CharValueValues = [];
        Container.commercialSpecChars = new PhaseCodeContainer();
        TBProperties.BuildCharUseProperties(Container.commercialSpecChars, Container.characteristic_Values, Container.characteristic_CharValueValues);
        Container.ConfigurableFacts = {};
        Container.EntityLinks = new PhaseCodeContainer();
        TBProperties.BuildEntityLinkValuesProperties(Container.EntityLinks);
        // Pricing - Costs
        Container.costValues = [];
        Container.costCounter = 1;
        TBProperties.BuildProductToCostProperties(Container.costValues);
        // Pricing - Charges
        Container.chargeValues = [];
        Container.chargeCounter = 1;
        TBProperties.BuildProductToChargeProperties(Container.chargeValues);
        // Pricing - non recurring
        Container.nonRecurringRateValues = [];
        Container.nonRecurringStrings = [];
        TBProperties.BuildRateProperties(Container.nonRecurringRateValues);
        // Pricing - recurring
        Container.recurringRateValues = [];
        Container.recurringStrings = [];
        TBProperties.BuildRateProperties(Container.recurringRateValues);
        // Pricing - discounts
        Container.discountValues = [];
        Container.discountCounter = 1;
        TBProperties.BuildCBDiscounts(Container.discountValues);
        Container.discountRateValues = [];
        TBProperties.BuildDiscountRate(Container.discountRateValues);
        Container.cbPricingValues = [];
        TBProperties.BuildCBPricing(Container.cbPricingValues);
        Container.chgAdjstValues = [];
        TBProperties.BuildChgAdjst(Container.chgAdjstValues);
        Container.adjTypeValues = [];
        TBProperties.BuildAdjType(Container.adjTypeValues);
        Container.costBasedCalculationValues = [];
        TBProperties.BuildCBCalculations(Container.costBasedCalculationValues);
        Container.costBasedMarkupValues = [];
        TBProperties.BuildCBMarkup(Container.costBasedMarkupValues);
        // Tiered and threshold pricing
        Container.unitBasedRates = {};
        Container.unitBasedRates.nonRecurringValues = [];
        Container.unitBasedRates.recurringValues = [];
        Container.unitBasedRates.thresholdRateValues = [];
        Container.unitBasedRates.tieredRateValues = [];
        TBProperties.BuildUnitBasedRateValues(Container.unitBasedRates.nonRecurringValues);
        TBProperties.BuildUnitBasedRateValues(Container.unitBasedRates.recurringValues);
        TBProperties.BuildThresholdValues(Container.unitBasedRates.thresholdRateValues);
        TBProperties.BuildTieredValues(Container.unitBasedRates.tieredRateValues);
        Container.commercial_UserDefinedChar = [];
        Container.characteristic = [];
        TBProperties.BuildCUDC(Container.commercial_UserDefinedChar);
        TBProperties.BuildCharacteristic(Container.characteristic);
        // GroupCardinalityRules
        // Charge Groups
        Container.ChargeGroup = [];
        Container.ChargeRelation = [];
        Container.ChargeGroupCounter = 1;
        TBProperties.BuildChargeGroupValues(Container.ChargeGroup, Container.ChargeRelation);
        // Discount Groups
        Container.DiscountGroup = [];
        Container.DiscountRelation = [];
        Container.DiscountGroupCounter = 1;
        TBProperties.BuildDiscountGroupValues(Container.DiscountGroup, Container.DiscountRelation);
        // Component Groups
        Container.ComponentGroup = [];
        Container.ComponentRelation = [];
        Container.ComponentGroupCounter = 1;
        TBProperties.BuildComponentGroupValues(Container.ComponentGroup, Container.ComponentRelation);
        Container.productToDiscountValues = [];
        TBProperties.BuildProductToDiscountProperties(Container.productToDiscountValues);
    };
    /**
    * Check every array within Container object and write out those that have picked up values throughout processing
    * @param {any} Container object that holds the arrays
    * @param {any} stream file being output to
    * @param {any} businessIDToEntityLookup array of entitys and their BIDs
    * @returns {void}
    */
    TBContainer.WriteContainer = function (Container, stream, businessIDToEntityLookup) {
        if (Container.productValues.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Product" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.productValues, stream);
        }
        if (Container.costValues.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Cost" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.costValues, stream);
        }
        if (Container.chargeValues.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Charge" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.chargeValues, stream);
        }
        if (Container.productToDiscountValues.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Discount" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.productToDiscountValues, stream);
        }
        if (Container.nonRecurringRateValues.length > 1) {
            TBUtils.WriteLine('And the "Rate_Non_Recurring" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.nonRecurringRateValues, stream);
            TBUtils.WriteNewLine(stream);
            // String array has no headers so > 0 check is ok
            if (Container.nonRecurringStrings.length > 0) {
                for (var i = 0; i < Container.nonRecurringStrings.length; i++) {
                    TBUtils.WriteLine(Container.nonRecurringStrings[i], stream);
                }
                TBUtils.WriteNewLine(stream);
            }
        }
        if (Container.recurringRateValues.length > 1) {
            TBUtils.WriteLine('And the "Rate_Recurring" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.recurringRateValues, stream);
            TBUtils.WriteNewLine(stream);
            if (Container.recurringStrings.length > 0) {
                for (var i = 0; i < Container.recurringStrings.length; i++) {
                    TBUtils.WriteLine(Container.recurringStrings[i], stream);
                }
                TBUtils.WriteNewLine(stream);
            }
        }
        if (Container.unitBasedRates.recurringValues.length > 1) {
            TBUtils.WriteLine('And the "Rate_Recurring" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.unitBasedRates.recurringValues, stream);
        }
        if (Container.unitBasedRates.nonRecurringValues.length > 1) {
            TBUtils.WriteLine('And the "Rate_Non_Recurring" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.unitBasedRates.nonRecurringValues, stream);
        }
        if (Container.unitBasedRates.tieredRateValues.length > 1) {
            TBUtils.WriteLine('And the "Rate" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.unitBasedRates.tieredRateValues, stream);
        }
        if (Container.unitBasedRates.thresholdRateValues.length > 1) {
            TBUtils.WriteLine('And the "Rate" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.unitBasedRates.thresholdRateValues, stream);
        }
        if (Container.ChargeGroup.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Charge_Group" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.ChargeGroup, stream);
        }
        if (Container.ChargeRelation.length > 1) {
            TBUtils.WriteLine('And the "Charge_Relation" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.ChargeRelation, stream);
        }
        if (Container.DiscountGroup.length > 1) {
            TBUtils.WriteLine('And the "Product_To_Discount_Group" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.DiscountGroup, stream);
        }
        if (Container.DiscountRelation.length > 1) {
            TBUtils.WriteLine('And the "Discount_Relation" contains the following instances:', stream);
            TBUtils.WriteArrayTable(Container.DiscountRelation, stream);
        }
        if (Container.childCompatibilityRules.Values.length > 1) {
            TBUtils.WriteLine('And the "ChildCompatibilityRules" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.childCompatibilityRules.Values, stream);
            TBContainer.WritePhaseCodes(Container.childCompatibilityRules.CommPhaseValues, Container.childCompatibilityRules.TechPhaseValues, stream);
            TBContainer.WriteCompatibilityRulesConditionText(Container.childCompatibilityRulesText, stream);
            TBContainer.WriteConditionExistsData(Container.childCompatibilityRules.ExistsData, stream);
            TBContainer.WriteConditionExistsData(Container.childCompatibilityRules.NotExistsData, stream, false);
            TBContainer.WriteConditionEntToStaticCount(Container.childCompatibilityRules.EntToStaticCount, stream);
            TBContainer.WriteConditionEntToUDCCount(Container.childCompatibilityRules.EntToUDCCount, stream);
            TBContainer.WriteConditionEntToEntCount(Container.childCompatibilityRules.EntToEntCount, stream);
        }
        if (Container.portfolioCompatibilityRules.Values.length > 1) {
            TBUtils.WriteLine('And the "PortfolioCompRule" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.portfolioCompatibilityRules.Values, stream);
            TBContainer.WritePhaseCodes(Container.portfolioCompatibilityRules.CommPhaseValues, Container.portfolioCompatibilityRules.TechPhaseValues, stream);
            TBContainer.WriteCompatibilityRulesConditionText(Container.portfolioCompatibilityRulesText, stream);
            TBContainer.WriteConditionExistsData(Container.portfolioCompatibilityRules.ExistsData, stream);
            TBContainer.WriteConditionExistsData(Container.portfolioCompatibilityRules.NotExistsData, stream, false);
            TBContainer.WriteConditionEntToStaticCount(Container.portfolioCompatibilityRules.EntToStaticCount, stream);
            TBContainer.WriteConditionEntToUDCCount(Container.portfolioCompatibilityRules.EntToUDCCount, stream);
            TBContainer.WriteConditionEntToEntCount(Container.portfolioCompatibilityRules.EntToEntCount, stream);
        }
        if (Container.productCandidateCompatibilityRules.Values.length > 1) {
            TBUtils.WriteLine('And the "PC_CompRules" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.productCandidateCompatibilityRules.Values, stream);
            TBContainer.WritePhaseCodes(Container.productCandidateCompatibilityRules.CommPhaseValues, Container.productCandidateCompatibilityRules.TechPhaseValues, stream);
            TBContainer.WriteCompatibilityRulesConditionText(Container.productCandidateCompatibilityRulesText, stream);
            TBContainer.WriteConditionExistsData(Container.productCandidateCompatibilityRules.ExistsData, stream);
            TBContainer.WriteConditionExistsData(Container.productCandidateCompatibilityRules.NotExistsData, stream, false);
            TBContainer.WriteConditionEntToStaticCount(Container.productCandidateCompatibilityRules.EntToStaticCount, stream);
            TBContainer.WriteConditionEntToUDCCount(Container.productCandidateCompatibilityRules.EntToUDCCount, stream);
            TBContainer.WriteConditionEntToEntCount(Container.productCandidateCompatibilityRules.EntToEntCount, stream);
        }
        if (Container.groupCardinalityRules.Values.length > 1) {
            TBUtils.WriteLine('And the "TChild_Group_Cardinality_Rule" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.groupCardinalityRules.Values, stream);
            TBContainer.WritePhaseCodes(Container.groupCardinalityRules.CommPhaseValues, Container.groupCardinalityRules.TechPhaseValues, stream);
        }
        if ((Container.productValues.length > 1) && ((Container.relationCardinalityRules.CommPhaseValues.length > 1) || (Container.relationCardinalityRules.TechPhaseValues.length > 1))) {
            TBContainer.CopyProductValuesToPhaseCodeObject(Container.productValues, Container.relationCardinalityRules);
            TBUtils.WriteLine('And the "Product_To_Product" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.relationCardinalityRules.Values, stream);
            TBContainer.WritePhaseCodes(Container.relationCardinalityRules.CommPhaseValues, Container.relationCardinalityRules.TechPhaseValues, stream);
        }
        if (Container.commercialSpecChars.Values.length > 1) {
            TBUtils.WriteLine('And the "Commercial_SpecCharUse" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.commercialSpecChars.Values, stream);
            TBContainer.WritePhaseCodes(Container.commercialSpecChars.CommPhaseValues, Container.commercialSpecChars.TechPhaseValues, stream);
        }
        if (Container.characteristic_Values.length > 1) {
            TBUtils.WriteLine('And the "Characteristic" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.characteristic_Values, stream);
        }
        if (Container.characteristic_CharValueValues.length > 1) {
            TBUtils.WriteLine('And the "Characteristic_CharValue" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.characteristic_CharValueValues, stream);
        }
        if ((Container.mappingRuleValues[0]) && (Container.mappingRuleValues[0].data.ruleData.length > 1)) {
            TBContainer.WriteMappingRules(businessIDToEntityLookup, Container.mappingRuleValues, stream);
        }
        TBContainer.WriteConfigurableFacts(Container.ConfigurableFacts, stream);
        if (Container.EntityLinks.Values.length > 1) {
            TBUtils.WriteLine('And the "SigmaEntLinks" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.EntityLinks.Values, stream);
            TBContainer.WritePhaseCodes(Container.EntityLinks.CommPhaseValues, Container.EntityLinks.TechPhaseValues, stream);
        }
        if (Container.discountValues.length > 1) {
            TBUtils.WriteLine('And the "CBDiscounts" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.discountValues, stream);
        }
        if (Container.cbPricingValues.length > 1) {
            TBUtils.WriteLine('And the "CBPricing" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.cbPricingValues, stream);
        }
        if (Container.discountRateValues.length > 1) {
            TBUtils.WriteLine('And the "Rates" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.discountRateValues, stream);
        }
        if (Container.chgAdjstValues.length > 1) {
            TBUtils.WriteLine('And the "ChgAdjst" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.chgAdjstValues, stream);
        }
        if (Container.adjTypeValues.length > 1) {
            TBUtils.WriteLine('And the "AdjType" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.adjTypeValues, stream);
        }
        if (Container.commercial_UserDefinedChar.length > 1) {
            TBUtils.WriteLine('And the "Commercial_UserDefinedChar" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.commercial_UserDefinedChar, stream);
        }
        if (Container.characteristic.length > 1) {
            TBUtils.WriteLine('And the "Characteristic" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(Container.characteristic, stream);
        }
    };
    TBContainer.WriteConditionExistsData = function (existsData, stream, isExists) {
        if (isExists === void 0) { isExists = true; }
        if (existsData.text.length === 1) {
            return;
        }
        if (existsData.Values.length === 1) {
            existsData.Values.pop();
        }
        if (existsData.Entities.length === 1) {
            existsData.Entities.pop();
        }
        if (isExists) {
            TBUtils.WriteLine('And the "Exists_Data" contains the following instances:', stream);
        }
        else {
            TBUtils.WriteLine('And the "Not_Exists_Data" contains the following instances:', stream);
        }
        TBUtils.WriteArrayTable(existsData.text, stream);
        if (existsData.Values.length > 0) {
            TBUtils.WriteLine('And the "Values" contains the following instances:', stream);
            TBUtils.WriteArrayTable(existsData.Values, stream);
        }
        if (existsData.Entities.length > 0) {
            TBUtils.WriteLine('And the "Entities" contains the following instances:', stream);
            TBUtils.WriteArrayTable(existsData.Entities, stream);
        }
    };
    TBContainer.WriteConditionEntToStaticCount = function (entToEntData, stream) {
        if (entToEntData.data.length === 1 || entToEntData.Entities.length === 1) {
            return;
        }
        TBUtils.WriteLine('And the "EntToStaticCount" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToEntData.data, stream);
        TBUtils.WriteLine('And the "Entities" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToEntData.Entities, stream);
    };
    TBContainer.WriteConditionEntToUDCCount = function (entToUDCData, stream) {
        if (entToUDCData.data.length === 1 || entToUDCData.Entities.length === 1) {
            return;
        }
        TBUtils.WriteLine('And the "EntToUDCCount" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToUDCData.data, stream);
        TBUtils.WriteLine('And the "Entities" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToUDCData.Entities, stream);
    };
    TBContainer.WriteConditionEntToEntCount = function (entToEntData, stream) {
        if (entToEntData.data.length === 1 || entToEntData.Entities1.length === 1 || entToEntData.Entities2.length === 1) {
            return;
        }
        TBUtils.WriteLine('And the "EntToEntCount" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToEntData.data, stream);
        TBUtils.WriteLine('And the "Entities_1" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToEntData.Entities1, stream);
        TBUtils.WriteLine('And the "Entities_2" contains the following instances:', stream);
        TBUtils.WriteArrayTable(entToEntData.Entities2, stream);
    };
    TBContainer.WriteCompatibilityRulesConditionText = function (textValues, stream) {
        if (textValues.length > 0) {
            textValues.forEach(function (pathGroup) {
                var text = pathGroup[1];
                text.forEach(function (line) {
                    TBUtils.WriteLine(line, stream);
                });
            });
            TBUtils.WriteNewLine(stream);
        }
    };
    /**
    * Write out mapping rules, due to data+conditions+actions a seperate function is needed for this
    * @param {any} businessIDToEntityLookup list of entities and their BIDs
    * @param {any} mappingRuleValues array to store values
    * @param {any} stream file to output to
    * @returns {void}
    */
    TBContainer.WriteMappingRules = function (businessIDToEntityLookup, mappingRuleValues, stream) {
        if (mappingRuleValues.length < 1) {
            return;
        }
        mappingRuleValues.forEach(function (values) {
            TBUtils.WriteLine('And the "MappingRules" on that "' + values.parentContext + '" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(values.data.ruleData, stream);
            if (values.data.conditionsData.length > 1) {
                TBUtils.WriteLine('And the "Conditions" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(values.data.conditionsData, stream);
            }
            if (values.data.actionsData.length > 1) {
                TBUtils.WriteLine('And the "Actions" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(values.data.actionsData, stream);
            }
            if (values.paths.length > 0) {
                values.paths.forEach(function (pathGroup) {
                    var text = pathGroup[1];
                    text.forEach(function (line) {
                        TBUtils.WriteLine(line, stream);
                    });
                });
                TBUtils.WriteNewLine(stream);
            }
            // TODO: Extend this for other conditions
            if (values.IsExistOrderItems) {
                TBUtils.WriteLine('And the "ExistsOrdActItem" on that "' + values.existOrderItems.conditionContextName + '" contains a "' + values.existOrderItems.name + '" with a "_meta.ID" of "' + values.existOrderItems.alias + '"', stream);
                // Resolve Source and Target Business ID
                var entityDetails = TBBuild.FindEntityForBusinessID(businessIDToEntityLookup, values.existOrderItems.sourceEntity);
                TBUtils.WriteLine('And that "' + values.existOrderItems.name + '" has a "Entity" path to an entity of "' + entityDetails.entityName + '"', stream);
                TBUtils.WriteLine('And that "' + values.existOrderItems.name + '" has a "ItemAction" of "' + values.existOrderItems.itemAction + '"\n', stream);
                var targetEntities = values.actionDetails.targetEntity.split(',');
                var resolvedEntities = "";
                targetEntities.forEach(function (businessId) {
                    var entityDetails = TBBuild.FindEntityForBusinessID(businessIDToEntityLookup, businessId);
                    resolvedEntities += (entityDetails.entityName + ",");
                });
                TBUtils.WriteLine('And that "' + values.actionDetails.mappingRuleAlias + '" has a "Target" path to an entity of "' + resolvedEntities + '"\n', stream);
            }
            if (values.IsExistData) {
                TBContainer.WriteConditionExistsData(values.ExistsData, stream);
            }
            if (values.IsNotExistData) {
                TBContainer.WriteConditionExistsData(values.NotExistsData, stream, false);
            }
            if (values.IsEntToStaticCount) {
                TBContainer.WriteConditionEntToStaticCount(values.EntToStaticCount, stream);
            }
            if (values.IsEntToUDCCount) {
                TBContainer.WriteConditionEntToUDCCount(values.EntToUDCCount, stream);
            }
            if (values.IsEntToEntCount) {
                TBContainer.WriteConditionEntToEntCount(values.EntToEntCount, stream);
            }
        });
    };
    /**
    * Write out table arrays for Commercial and Technical phase code values
    * @param {any} commercialPhaseCodeValues
    * @param {any} technicalPhaseCodeValues
    * @param {any} stream file to output to
    */
    TBContainer.WritePhaseCodes = function (commercialPhaseCodeValues, technicalPhaseCodeValues, stream) {
        if (commercialPhaseCodeValues.length > 1) {
            TBUtils.WriteLine('And the "CommPhases" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(commercialPhaseCodeValues, stream);
        }
        if (technicalPhaseCodeValues.length > 1) {
            TBUtils.WriteLine('And the "TechPhases" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(technicalPhaseCodeValues, stream);
        }
    };
    /**
    * Write out table arrays for Configurable Facts
    * @param {any} configurableFacts
    * @param {any} stream file to output to
    */
    TBContainer.WriteConfigurableFacts = function (configurableFacts, stream) {
        Object.keys(configurableFacts).forEach(function (key) {
            var fact = configurableFacts[key];
            TBUtils.WriteLine('And the "' + key + '" contains only the following instances:', stream);
            TBUtils.WriteArrayTable(fact.Facts, stream);
            if (fact.FactValues.length > 1) {
                TBUtils.WriteLine('And the "Values" contains only the following instances:', stream);
                TBUtils.WriteArrayTable(fact.FactValues, stream);
            }
            TBContainer.WritePhaseCodes(fact.FactCommPhaseValues, fact.FactTechPhaseValues, stream);
        });
    };
    /**
    * Copy the Product_To_Product values to the relationCardinality object
    * @param {any} productValues
    * @param {any} relationCardinality
    */
    TBContainer.CopyProductValuesToPhaseCodeObject = function (productValues, relationCardinality) {
        var tempArray = productValues;
        for (var x = 1; x < tempArray.length; x++) {
            var newContextName = tempArray[x][10] + " Relation";
            relationCardinality.Values.push([tempArray[x][0], tempArray[x][1], tempArray[x][2], tempArray[x][3], newContextName]);
        }
    };
    return TBContainer;
}());
module.exports = TBContainer;

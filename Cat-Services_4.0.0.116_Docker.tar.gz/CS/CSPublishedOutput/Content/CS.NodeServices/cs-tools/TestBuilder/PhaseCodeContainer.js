"use strict";
/**
 * The interface for phase code values
 */
var PhaseCodeContainer = /** @class */ (function () {
    function PhaseCodeContainer() {
        this.Values = [];
        this.CommPhaseValues = [];
        this.TechPhaseValues = [];
    }
    return PhaseCodeContainer;
}());
module.exports = PhaseCodeContainer;

"use strict";
///<reference types="node" />
Object.defineProperty(exports, "__esModule", { value: true });
var TBDataAccess = require("./TBDataAccess");
var TBBuild = require("./TBBuild");
var fs = require('fs');
var querystring = require("querystring");
var http = require("http");
// Configuration
var rootPath = process.argv[2]; // Author added these to add variables from command line
var feature = process.argv[3];
var dataset = process.argv[4]; // Added in 3.x
var story = process.argv[5];
var storyName = process.argv[6];
var rootEntityGuid = process.argv[7];
var requestFileName = process.argv[8];
var requestUrl = process.argv[9];
var activationDate = process.argv[10];
console.log(JSON.stringify(process.argv, null, 2));
// var rootPath = 'w:/Work/CatalogServices3'; // Your work path
// var feature         = 'RuleConditions/Test';               // The feature this test belongs to e.g. 'Mapping/portfolio_features'
// var dataset         = 'TestFest_DevOnly';                       // The Dataset being used for this test e.g. 1.X_QA_RegressionPack
// var story           = 'S13697';                                  // Story ID, usually the versionOne number, used for the request and alias paths
// var storyName       = '1.1Test';                       // Name used for the feature file
// var rootEntityGuid  = '3bd7d5d7-1c7d-4629-a081-dbea8a71fc5f';    // The root entity in the specification
// var requestFileName = 'tbc.json';  // The request used for this scenario
// var requestUrl      = '/api/ordercandidate/decompose';          // The url of the api endpoint to call
// var activationDate  = TBUtils.TodaysDate();                     // The specific activation date of the request, use null to omit or TodaysDate() as the default
// End of Configuration
// ===========================
// Optional configuration
// (Please leave this section as you found it before committing any updates to TB.js to help guide other devs)
var featureDescription = 'TODO: Describe the feature here';
var scenarioDescription = 'TODO: Describe the scenario here';
var scenarioComments = 'TODO: Write something here about the specifics of this test, what is the expectation of the result and why?';
// End of Optional Configuration
// ============================
// Seperating the requests
var commaSeperatedRequests = requestFileName.split(",");
// Some of these may need to be altered on a per test basis
var featurePath = rootPath + '/Tests/CS.AcceptanceTests/Features/' + feature;
var featureFile = featurePath + '/' + storyName + '.feature';
var aliasFile = featurePath + '/aliases/Aliases_' + story + '.json';
var datastorePath = rootPath + '/Tests/CS.AcceptanceTests/Data_sets/' + dataset;
var requestPath = []; //= rootPath + '/Tests/CS.AcceptanceTests/features/' + feature + '/requests/' + story + '/' + requestFileName;
for (var i = 0; i < commaSeperatedRequests.length; i++) {
    requestPath.push(rootPath + '/Tests/CS.AcceptanceTests/features/' + feature + '/requests/' + story + '/' + commaSeperatedRequests[i]);
}
var aliases = [];
var stream = null;
// Array of {businessId:null, entityDetails:{entityId: null, entityName: null, entityAlias: null}} objects
var businessIDToEntityLookup = [];
/** NOTE:
* TB is built on the assumption that the rules are named as below in Product specification.
*   |Rules                                      | Tag name in Specification  |
    | Mapping rules                             | MappingRules               |
    | Child compatibility rules                 | ChildCompatibilityRules    |
    | Portfolio rules                           | PortfolioCompRule          |
    | ProductCandidate compatibility rules      | PC_CompRules               |
* If you are expecting Rules to be read by test builder and you dont see in feature file, it is probably because the rules are
* named differently in the product specification. As a workaround, change the rules name in test builder as defined in product specification.
* TODO: Update to test builder to recognize the rules from its base schema element rather than reading the tag name. Become immune to rules name change.
*/
console.log('Starting TestBuilder');
TBDataAccess.RefreshData(datastorePath, function () {
    TBDataAccess.GetSpecification(rootEntityGuid, function (specification) {
        var rootItem = null;
        if (specification.Bundle) {
            rootItem = specification.Bundle;
        }
        else if (specification.Package) {
            rootItem = specification.Package;
        }
        else if (specification.Component) {
            rootItem = specification.Component;
        }
        TBBuild.CheckForExistingAliasFile(aliasFile, aliases);
        TBBuild.BuildFeatureFile(rootItem, featureFile, story, storyName, feature, featureDescription, scenarioComments, scenarioDescription, commaSeperatedRequests, activationDate, rootEntityGuid, businessIDToEntityLookup, requestPath, requestUrl, dataset, stream, aliases, function (err) {
            TBBuild.BuildAliasFile(rootItem, aliasFile, aliases);
            console.log('TestBuilder Complete');
        });
    });
});

"use strict";
/// <reference types="node" />
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderCandidateRequestGenerator = require("../cs-lib-composition/OrderCandidateRequestGenerator");
var OrderCandidateResponseBuilder = require("../cs-lib-composition/OrderCandidateResponseBuilder");
var OrderGenerationRequest = require("../cs-lib-types/BusinessEntities/OrderGenerationRequest");
var Utilities = require("../cs-lib-utilities/Utilities");
var Interpret = /** @class */ (function () {
    function Interpret() {
    }
    Interpret.prototype.DeriveOrderCandidate = function (request, callback) {
        var errorContext = new CsErrorContext({});
        var orderGenerationRequest = new OrderGenerationRequest(request);
        if (!orderGenerationRequest.OldCandidate || !orderGenerationRequest.NewCandidate) {
            return callback(ErrorCode.Validation.InvalidOrderGenerationRequest.Code, null, null); //400
        }
        var orderGenerator = new OrderCandidateRequestGenerator(orderGenerationRequest, errorContext);
        var orderCandidateRequest = orderGenerator.GenerateOrder();
        if (errorContext.HasProcessError) {
            return callback(errorContext.ProcessError, null, null);
        }
        if (errorContext.HasBadDataError) {
            return callback(errorContext.GetBadDataErrorsResponse(), null, null);
        }
        // HACK: need to pass back activation date as a string, but our OrderCandidateRequest won't let us do this
        // DON'T use this for other properties, if this needs further extending we need to reconsider how we return a generated order request
        var activationDate = Utilities.DateString(orderCandidateRequest.ActivationDate);
        var orderCandidateResponse = JSON.parse(JSON.stringify(orderCandidateRequest));
        orderCandidateResponse.ActivationDate = activationDate;
        // End HACK
        var statusCode = orderGenerator.CandidatesAreIdentical ? 202 : 200;
        return callback(null, ConverterUtils.OrderSingularize(orderCandidateResponse), statusCode); // 'OrderCandidateRequest'
    };
    Interpret.prototype.InterpretOrder = function (request, compiledSpecs, callback) {
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder('technical', errorContext);
        decomposeContextBuilder.BuildFromOrderCandidate(request, compiledSpecs, function (decomposeContextCollection) {
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            var builder = new OrderCandidateResponseBuilder(errorContext);
            var response = builder.Build(decomposeContextCollection);
            response.ValidationErrors = errorContext.GetValidationErrorsForResponse();
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            else if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            else {
                return callback(null, ConverterUtils.OrderSingularize(response)); //, 'OrderCandidateResponse');
            }
        });
    };
    return Interpret;
}());
module.exports = Interpret;

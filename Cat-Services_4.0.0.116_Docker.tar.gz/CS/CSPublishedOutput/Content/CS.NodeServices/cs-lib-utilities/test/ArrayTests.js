"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe('GetValueByKey', function () {
    var array = { CaseInsensitiveTest: "result1", CaseSensitiveTest1: "result2", CaseSensitiveTest2: "result3" };
    it('should return value where key matches a case insensitive search', function (done) {
        chai.expect(Utilities.GetValueByKey(array, "CASEinsensitiveTeSt")).to.equal("result1");
        done();
    });
    it('should return value where key matches a case sensitive search', function (done) {
        chai.expect(Utilities.GetValueByKey(array, "CaseSensitiveTest1", true)).to.equal("result2");
        done();
    });
    it('should return undefined where key does not match a case sensitive search', function (done) {
        chai.expect(Utilities.GetValueByKey(array, "CASESensiTIVeTest2", true)).to.be.undefined;
        done();
    });
    it('should return undefined where no match is found', function (done) {
        chai.expect(Utilities.GetValueByKey(array, "Test4", true)).to.be.undefined;
        done();
    });
    it('should return undefined where array is undefined', function (done) {
        chai.expect(Utilities.GetValueByKey(undefined, "")).to.be.undefined;
        done();
    });
});
describe("asArray", function () {
    it('Should convert a single item into an array just containing the single item', function (done) {
        var singleNumber = 10;
        var singleNumberArray = Utilities.asArray(singleNumber);
        chai.expect(Array.isArray(singleNumberArray)).is.true;
        chai.expect(singleNumberArray.length).to.equal(1);
        chai.expect(singleNumberArray[0]).to.equal(10);
        var singleItem = { 1: 11, 2: 22 };
        var singleItemArray = Utilities.asArray(singleItem);
        chai.expect(Array.isArray(singleItemArray)).is.true;
        chai.expect(singleItemArray.length).to.equal(1);
        chai.expect(singleItemArray[0]).to.equal(singleItem);
        done();
    });
    it('Should return the same array without clonning it', function (done) {
        var multipleItem = [11, 22, 33, 44];
        var multipleItemArray = Utilities.asArray(multipleItem);
        chai.expect(multipleItemArray.length).to.equal(4);
        // Compares the contents of the object
        chai.expect(JSON.stringify(multipleItemArray)).equal(JSON.stringify(multipleItem));
        // Check if the same object is returned and no clone is created
        chai.expect(multipleItemArray).equal(multipleItem);
        var arrayOfObjects = [{ 0: 11, 1: 22, 2: 33, 3: 44 }, { 4: 55, 5: 66, 6: 77, 7: 88 }, { 8: 99, 9: 109, 10: 119, 11: 129 }];
        var new_arrayOfObjects = Utilities.asArray(arrayOfObjects);
        chai.expect(new_arrayOfObjects.length).to.equal(3);
        // Compares the contents of the object
        chai.expect(JSON.stringify(new_arrayOfObjects)).equal(JSON.stringify(arrayOfObjects));
        // Check if the same object is returned and no clone is created
        chai.expect(arrayOfObjects).equal(new_arrayOfObjects);
        var arrayOfArray = [['h', 'e', 'l', 'l', 'o'], ['w', 'o', 'r', 'l', 'd']];
        var new_arrayOfArray = Utilities.asArray(arrayOfArray);
        chai.expect(new_arrayOfArray.length).to.equal(2);
        // Check if the same object is returned and no clone is created
        chai.expect(new_arrayOfArray).equal(arrayOfArray);
        chai.expect(new_arrayOfArray[0]).equal(arrayOfArray[0]);
        done();
    });
});

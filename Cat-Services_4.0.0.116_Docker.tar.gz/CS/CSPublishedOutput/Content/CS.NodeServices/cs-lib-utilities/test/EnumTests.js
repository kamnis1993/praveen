"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
var TestEnum;
(function (TestEnum) {
    TestEnum[TestEnum["FirstTestValue"] = 0] = "FirstTestValue";
    TestEnum[TestEnum["SecondTestValue"] = 1] = "SecondTestValue";
    TestEnum[TestEnum["ThirdTestValue"] = 2] = "ThirdTestValue";
})(TestEnum || (TestEnum = {}));
var TestConstantType = {
    FirstTestValue: "0",
    SecondTestValue: "1",
    ThirdTestValue: "2",
};
describe('Enum & Constants Tests', function () {
    describe("GetEnumString", function () {
        it("should return the correct string key representing the enum value", function () {
            chai.expect(Utilities.GetEnumString(TestEnum, 0)).to.be.equal("FirstTestValue");
            chai.expect(Utilities.GetEnumString(TestEnum, 2)).to.be.equal("ThirdTestValue");
        });
        it("should return the correct string value representing the enum key", function () {
            chai.expect(Utilities.GetEnumString(TestEnum, "FirstTestValue")).to.be.equal(0);
            chai.expect(Utilities.GetEnumString(TestEnum, "ThirdTestValue")).to.be.equal(2);
        });
        it("should return null if the value does not exist in the enum", function () {
            chai.expect(Utilities.GetEnumString(TestEnum, 4)).to.be.null;
        });
        it("should return null if the enum is null", function () {
            chai.expect(Utilities.GetEnumString(null, 0)).to.be.null;
        });
        it("should return null if the value is null", function () {
            chai.expect(Utilities.GetEnumString(TestEnum, null)).to.be.null;
        });
    });
    describe("GetConstantsKeyByValue", function () {
        it("should return the correct string representing the contants key", function () {
            chai.expect(Utilities.GetConstantsKeyByValue(TestEnum, "0")).to.be.equal("FirstTestValue");
            chai.expect(Utilities.GetConstantsKeyByValue(TestEnum, "2")).to.be.equal("ThirdTestValue");
        });
        it("should return null if the value does not exist in the enum", function () {
            chai.expect(Utilities.GetConstantsKeyByValue(TestEnum, "4")).to.be.null;
        });
        it("should return null if the enum is null", function () {
            chai.expect(Utilities.GetConstantsKeyByValue(null, "0")).to.be.null;
        });
        it("should return null if the value is null", function () {
            chai.expect(Utilities.GetConstantsKeyByValue(TestEnum, null)).to.be.null;
        });
    });
});

"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe('JSON Tests', function () {
    var testSource = {
        "ID": "123456789",
        "Parent": {
            "ID": "234567891",
            "Child": {
                "ID": "345678912"
            }
        }
    };
    describe("GetFirstProperty: When getting the first property", function () {
        it("should return the first property of a JSON object", function () {
            var result = Utilities.GetFirstProperty(testSource);
            chai.expect(result).to.be.equal("123456789");
        });
        it("should return the first property of a JSON string", function () {
            var result = Utilities.GetFirstProperty(JSON.stringify(testSource));
            chai.expect(result).to.be.equal("123456789");
        });
        it("should handle undefined", function () {
            var result = Utilities.GetFirstProperty(undefined);
            chai.expect(result).to.be.undefined;
        });
        it("should handle null", function () {
            var result = Utilities.GetFirstProperty(null);
            chai.expect(result).to.be.null;
        });
        it("should return the first property of an array", function () {
            // This test is asserting that if an object is passed inside and array,
            // no outer property can be found so it returns the first object of the array
            var arraySource = [];
            arraySource.push(testSource);
            arraySource.push({});
            var result = Utilities.GetFirstProperty(arraySource);
            chai.expect(result).to.deep.equal(testSource);
        });
    });
});

"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var LodashUtilities = require("../LodashUtilities");
var Utilities = require("../Utilities");
describe("DeleteDeepValue: Deleting a deep value using a path", function () {
    var target = {
        appVersion: '0.0.1',
        dbConnection: {
            host: 'localhost',
            port: 27107,
            serverOptions: {
                name: "server",
                auto_reconnect: true,
                poolSize: 2,
                socketOptions: {
                    keepAlive: 1
                }
            },
            dbCreateOptions: {
                fsync: true,
                native_parser: true
            }
        }
    };
    describe("When deleting a property path with an invalid object literal or path", function () {
        it("should return undefined when given a string as a target", function () {
            var stringValue = "Not an object literal";
            var result = Utilities.DeleteDeepProperty(stringValue, "dbConnection.dbCreateOptions");
            chai.expect(result).to.be.undefined;
        });
        it("should return undefined when given an array as a target", function () {
            var arrayValue = [];
            var result = Utilities.DeleteDeepProperty(arrayValue, "dbConnection.dbCreateOptions");
            chai.expect(result).to.be.undefined;
        });
        it("should return undefined when given a number as a target", function () {
            var numberValue = 123;
            var result = Utilities.DeleteDeepProperty(numberValue, "dbConnection.dbCreateOptions");
            chai.expect(result).to.be.undefined;
        });
        it("should not mutate the target and return undefined if the first object in the path to the property is undefined", function () {
            var damagedClonedTarget = LodashUtilities.CloneDeep(target);
            damagedClonedTarget.dbConnection = undefined;
            var damagedClonedTargetCopy = LodashUtilities.CloneDeep(damagedClonedTarget);
            var result = Utilities.DeleteDeepProperty(damagedClonedTarget, "dbConnection.serverOptions.socketOptions");
            chai.expect(result).to.be.undefined;
            chai.expect(damagedClonedTarget).to.deep.equal(damagedClonedTargetCopy);
        });
        it("should not mutate the target and return undefined if the second object in the path to the property is undefined", function () {
            var damagedClonedTarget = LodashUtilities.CloneDeep(target);
            damagedClonedTarget.dbConnection.serverOptions = undefined;
            var damagedClonedTargetCopy = LodashUtilities.CloneDeep(damagedClonedTarget);
            var result = Utilities.DeleteDeepProperty(damagedClonedTarget, "dbConnection.serverOptions.socketOptions");
            chai.expect(result).to.be.undefined;
            chai.expect(damagedClonedTarget).to.deep.equal(damagedClonedTargetCopy);
        });
    });
    describe("When deleting a property path with a valid object literal", function () {
        it("should delete the property at the given path (root of the target)", function () {
            var clonedTarget = LodashUtilities.CloneDeep(target);
            chai.expect(clonedTarget.dbConnection).to.not.be.undefined;
            Utilities.DeleteDeepProperty(clonedTarget, "dbConnection");
            chai.expect(clonedTarget.dbConnection).to.be.undefined;
        });
        it("should delete the property at the given path (2 deep)", function () {
            var clonedTarget = LodashUtilities.CloneDeep(target);
            chai.expect(clonedTarget.dbConnection.serverOptions.name).to.not.be.undefined;
            Utilities.DeleteDeepProperty(clonedTarget, "dbConnection.serverOptions");
            chai.expect(clonedTarget.dbConnection.serverOptions).to.be.undefined;
        });
        it("should delete the property at the given path (3 deep)", function () {
            var clonedTarget = LodashUtilities.CloneDeep(target);
            chai.expect(clonedTarget.dbConnection.serverOptions.socketOptions).to.not.be.undefined;
            Utilities.DeleteDeepProperty(clonedTarget, "dbConnection.serverOptions.socketOptions");
            chai.expect(clonedTarget.dbConnection.serverOptions.socketOptions).to.be.undefined;
        });
        it("should return the key and the value of the deleted property", function () {
            var clonedTarget = LodashUtilities.CloneDeep(target);
            var result = Utilities.DeleteDeepProperty(clonedTarget, "dbConnection.dbCreateOptions.fsync");
            chai.expect(result.key).to.equal('fsync');
            chai.expect(result.value).to.equal(target.dbConnection.dbCreateOptions.fsync);
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe("Utilities ParseAsType methods should always return the expected type or undefined", function () {
    it("Utilities.ParseAsNumber should return a valid string and return a number", function (done) {
        var value = Utilities.ParseAsNumber("312", 1);
        chai.expect(typeof value).to.equal("number");
        chai.expect(value).to.equal(312);
        done();
    });
    it("Utilities.ParseAsNumber should return the default number from an invalid string", function (done) {
        var value = Utilities.ParseAsNumber("Not a number", 1);
        chai.expect(typeof value).to.equal("number");
        chai.expect(value).to.equal(1);
        done();
    });
    it("Utilities.ParseAsNumber should return a number passed to it without changing its value or type", function (done) {
        var value = Utilities.ParseAsNumber(123, 1);
        chai.expect(typeof value).to.equal("number");
        chai.expect(value).to.equal(123);
        done();
    });
});

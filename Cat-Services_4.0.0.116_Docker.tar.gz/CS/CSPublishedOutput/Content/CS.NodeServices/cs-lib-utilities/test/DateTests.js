"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe('IsValidDate', function () {
    it('should return true for a valid date object', function (done) {
        var valueToCheck = new Date("2016-08-04");
        chai.expect(Utilities.IsValidDate(valueToCheck)).to.be.true;
        done();
    });
    it('should return false for an invalid date object', function (done) {
        var valueToCheck = new Date("2016-13-04");
        chai.expect(Utilities.IsValidDate(valueToCheck)).to.be.false;
        done();
    });
    it('should return true for a valid ISO date string', function (done) {
        var valueToCheck = "2015-06-22T00:00:00.000Z";
        chai.expect(Utilities.IsValidDate(valueToCheck)).to.be.true;
        done();
    });
    it('should return false for an invalid ISO date string', function (done) {
        var valueToCheck = "2015-22-06T00:00:00.000Z";
        chai.expect(Utilities.IsValidDate(valueToCheck)).to.be.false;
        done();
    });
    it('should return false for a null value', function (done) {
        var valueToCheck = null;
        chai.expect(Utilities.IsValidDate(valueToCheck)).to.be.false;
        done();
    });
});
describe('FormatDate', function () {
    it('should return a date formatted to dd-MM-yyyy where day and month numbers are less than 10', function (done) {
        var formattedDate = Utilities.FormatDate(new Date("2016-03-09T12:00:00"));
        chai.expect(formattedDate).to.equal("09-03-2016");
        done();
    });
    it('should return a date formatted to dd-MM-yyyy where day and month numbers are greater than or equal to 10', function (done) {
        var formattedDate = Utilities.FormatDate(new Date("2016-11-25T12:00:00"));
        chai.expect(formattedDate).to.equal("25-11-2016");
        done();
    });
    it('should handle null dates', function (done) {
        var formattedDate = Utilities.FormatDate(null);
        chai.expect(formattedDate).to.be.null;
        done();
    });
});
describe('FormatDateAsJSON', function () {
    it('should return a date formatted to yyyy-MM-ddTmm:hh:ss:msZ where month, day, hour, minute, second and millisecond numbers are less than 10', function (done) {
        // Months start at 0 for some reason so 2 is March
        var testDate = new Date("2016-03-03T04:01:09.004");
        var formattedDate = Utilities.FormatDateAsJSON(testDate);
        chai.expect(formattedDate).to.equal("2016-03-03T04:01:09.004Z");
        done();
    });
    it('should return a date formatted to yyyy-MM-ddTmm:hh:ss:msZ where month, day, hour, minute, second and millisecond numbers are greater than or equal to 10', function (done) {
        // Months start at 0 for some reason so 11 is December
        var testDate = new Date("2016-12-13T23:11:29.034");
        var formattedDate = Utilities.FormatDateAsJSON(testDate);
        chai.expect(formattedDate).to.equal("2016-12-13T23:11:29.034Z");
        done();
    });
    it('should return a date formatted to yyyy-MM-ddTmm:hh:ss:msZ where millisecond numbers are greater than or equal to 100', function (done) {
        // Months start at 0 for some reason so 0 is January
        var testDate = new Date("2016-01-31T23:59:59.999");
        var formattedDate = Utilities.FormatDateAsJSON(testDate);
        chai.expect(formattedDate).to.equal("2016-01-31T23:59:59.999Z");
        done();
    });
    it('should return a date formatted to yyyy-MM-ddTmm:hh:ss:msZ including adjustment for Daylight Saving', function (done) {
        // Expecting hour to be reduced by 1
        var testDate = new Date("2016-05-03T03:01:09.004Z");
        var formattedDate = Utilities.FormatDateAsJSON(testDate);
        chai.expect(formattedDate).to.equal("2016-05-03T03:01:09.004Z");
        done();
    });
    it('should handle null dates', function (done) {
        var formattedDate = Utilities.FormatDateAsJSON(null);
        chai.expect(formattedDate).to.be.null;
        done();
    });
});
describe('ParseDateFromString', function () {
    it('should return 11pm during a DST period', function (done) {
        var formattedDate = Utilities.ParseDateFromString("2016-06-12T23:00:00.000Z").toUTCString();
        chai.expect(formattedDate.toString()).to.equal("Sun, 12 Jun 2016 23:00:00 GMT");
        done();
    });
    it('should return 12am during a DST period', function (done) {
        var formattedDate = Utilities.ParseDateFromString("2016-06-13T00:00:00.000Z").toUTCString();
        chai.expect(formattedDate.toString()).to.equal("Mon, 13 Jun 2016 00:00:00 GMT");
        done();
    });
    it('should return 1am during a DST period', function (done) {
        var formattedDate = Utilities.ParseDateFromString("2016-06-13T01:00:00.000Z").toUTCString();
        chai.expect(formattedDate.toString()).to.equal("Mon, 13 Jun 2016 01:00:00 GMT");
        done();
    });
    it('should return 12am outside of a DST period', function (done) {
        var formattedDate = Utilities.ParseDateFromString("2016-12-13T00:00:00.000Z").toUTCString();
        chai.expect(formattedDate.toString()).to.equal("Tue, 13 Dec 2016 00:00:00 GMT");
        done();
    });
    it('should return a set time outside of a DST period', function (done) {
        var formattedDate = Utilities.ParseDateFromString("2016-12-13T23:11:29.034Z").toUTCString();
        chai.expect(formattedDate.toString()).to.equal("Tue, 13 Dec 2016 23:11:29 GMT");
        done();
    });
    it('should handle null dates', function (done) {
        var formattedDate = Utilities.ParseDateFromString(null);
        chai.expect(formattedDate).to.be.undefined;
        done();
    });
});

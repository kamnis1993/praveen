"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
var TestClass = /** @class */ (function () {
    function TestClass(spec) {
        this.Name = spec.Name;
        this.Description = spec.Description;
    }
    return TestClass;
}());
var convertor = function (item) {
    if (item.Name === 'NotKnown') {
        return undefined;
    }
    return new TestClass(item);
};
var singleValue = {
    Name: 'First',
    Description: 'First Description'
};
var multiValue = [
    {
        Name: 'First',
        Description: 'First Description'
    },
    {
        Name: 'Second',
        Description: 'Second Description'
    },
    {
        Name: 'Third',
        Description: 'Third Description'
    }
];
describe('Argument Helper Tests', function () {
    describe('ConvertToArrayOf: Creating an array from a literal object', function () {
        it('should return an empty array if the literal is undefined or null', function (done) {
            var arrayResult = Utilities.ConvertToArrayOf(undefined, convertor);
            chai.expect(arrayResult instanceof Array).to.be.true;
            chai.expect(arrayResult.length).to.be.equal(0);
            done();
        });
        it('should return an array with one item of the specified type if the literal is not an array', function (done) {
            var singleValue = {
                Name: 'First',
                Description: 'First Description'
            };
            var arrayResult = Utilities.ConvertToArrayOf(singleValue, convertor);
            chai.expect(arrayResult instanceof Array).to.be.true;
            chai.expect(arrayResult.length).to.be.equal(1);
            chai.expect(arrayResult[0] instanceof TestClass).to.be.true;
            done();
        });
        it('should return an array of the specified type if the literal is an array', function (done) {
            var arrayResult = Utilities.ConvertToArrayOf(multiValue, convertor);
            chai.expect(arrayResult instanceof Array).to.be.true;
            chai.expect(arrayResult.length).to.be.equal(3);
            for (var i = 0; i < 3; i++) {
                chai.expect(arrayResult[i] instanceof TestClass).to.be.true;
            }
            done();
        });
        it('the returned array should not contain an item if the convertor returns undefined', function (done) {
            var testValue = [];
            multiValue.forEach(function (item) { testValue.push(item); });
            testValue.push({
                Name: 'NotKnown',
                Description: 'NotKnown Description'
            });
            var arrayResult = Utilities.ConvertToArrayOf(testValue, convertor);
            chai.expect(arrayResult instanceof Array).to.be.true;
            chai.expect(arrayResult.length).to.be.equal(3);
            for (var i = 0; i < 3; i++) {
                chai.expect(arrayResult[i] instanceof TestClass).to.be.true;
            }
            done();
        });
    });
});

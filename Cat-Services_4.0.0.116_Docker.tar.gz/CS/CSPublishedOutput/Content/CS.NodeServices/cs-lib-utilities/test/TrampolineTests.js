"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
/// <reference types="node" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe("StartQueueWorker tests", function () {
    var incomingWork = function () { return [1, 2, 3]; };
    var multiplyBy2Worker = function (w, r) { r(null, w * 2); };
    var failingWorker = function (w, r) { r(new Error("Fail"), 1); };
    describe("When running a simple worker against a static array", function () {
        it("should output a transformed array", function (done) {
            Utilities.StartQueueWorker(incomingWork(), function (err, result) {
                chai.expect(JSON.stringify(result)).to.equal(JSON.stringify([2, 4, 6])); // chai doesn't compare value in arrays!
                done();
            }, multiplyBy2Worker);
        });
        it("should have no error in result", function (done) {
            Utilities.StartQueueWorker(incomingWork(), function (err, result) {
                chai.expect(err).to.be.undefined;
                done();
            }, multiplyBy2Worker);
        });
    });
    describe("When running with a worker that adds new work", function () {
        it("should complete all work, included that added by worker", function (done) {
            var initialWork = [1, 2, 3];
            var generativeWorker = function (w, r) {
                if (w < 5) {
                    initialWork.push(w + 3);
                    r(null, w);
                }
                else {
                    r(null, w);
                }
            };
            Utilities.StartQueueWorker(initialWork, function (err, result) {
                chai.expect(JSON.stringify(result)).to.equal(JSON.stringify([1, 2, 3, 4, 5, 6, 7])); // chai doesn't compare value in arrays!
                done();
            }, generativeWorker);
        });
    });
    describe("When running a failing worker against a static array", function () {
        it("should return the error", function (done) {
            Utilities.StartQueueWorker(incomingWork(), function (err, result) {
                chai.expect(err.toString()).to.equal("Error: Fail");
                done();
            }, failingWorker);
        });
        it("should give an undefined result", function (done) {
            Utilities.StartQueueWorker(incomingWork(), function (err, result) {
                chai.expect(result).to.be.undefined;
                done();
            }, failingWorker);
        });
    });
});

"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe('ValueIsATypeOf: Checking if the path contains a type', function () {
    it('should find the type within the path for a single given type', function (done) {
        var isATypeOf = Utilities.PathContains("a/b/c/d/e", ['a']);
        chai.expect(isATypeOf).to.be.true;
        done();
    });
    it("should find the type within the path if both types match", function (done) {
        var isATypeOf = Utilities.PathContains("a/b/c/d/e", ['c', 'e']);
        chai.expect(isATypeOf).to.be.true;
        done();
    });
    it("should find the type within the path if only one of two types match", function (done) {
        var isATypeOf = Utilities.PathContains("a/b/c/d/e", ['z', 'e']);
        chai.expect(isATypeOf).to.be.true;
        done();
    });
    it("should not find the type within the path if it doesn't match exactly", function (done) {
        var isATypeOf = Utilities.PathContains("Generic_NRC_Template/Non_Recurring_Charge/Charge/Launch_Entity", ['Recurring_Charge']);
        chai.expect(isATypeOf).to.be.false;
        done();
    });
});

"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var LodashUtilities = require("../LodashUtilities");
var Utilities = require("../Utilities");
describe("DeepValue Tests", function () {
    var target = {
        appVersion: '0.0.1',
        dbConnection: {
            host: 'localhost',
            port: 27107,
            serverOptions: {
                name: "server",
                auto_reconnect: true,
                poolSize: 2,
                socketOptions: {
                    keepAlive: 1
                }
            },
            dbCreateOptions: {
                fsync: true,
                native_parser: true
            }
        }
    };
    var defaultProperty = {
        first: {
            second: "notFirst"
        }
    };
    describe("DeepValueExists: When testing if a property path exists in an object literal", function () {
        it("should return false if the target is undefined or null", function () {
            var result = Utilities.DeepValueExists(undefined, "a.b.c");
            chai.expect(result).to.be.false;
        });
        it("should return false if the target is not an object", function () {
            var result = Utilities.DeepValueExists([], "a.b.c");
            chai.expect(result).to.be.false;
        });
        it("should return true if the path is not specified or empty", function () {
            var result = Utilities.DeepValueExists(target, null);
            chai.expect(result).to.be.true;
        });
        it("should return false if the path doesn't exist", function () {
            var result = Utilities.DeepValueExists(target, "dbConnection.socketOptions");
            chai.expect(result).to.be.false;
        });
        it("should return true if the path exists", function () {
            var result = Utilities.DeepValueExists(target, "dbConnection.serverOptions.poolSize");
            chai.expect(result).to.be.true;
        });
    });
    describe("GetDeepValue: When looking for a property in an object literal", function () {
        it("should return undefined if the target is undefined or null and no defaultProperty is specified", function () {
            var result = Utilities.GetDeepValue(undefined, "a.b.c");
            chai.expect(result).to.be.undefined;
        });
        it("should return the defaultProperty if the target is undefined", function () {
            var result = Utilities.GetDeepValue(undefined, "a.b.c", defaultProperty);
            chai.expect(result.first.second).to.equal("notFirst");
        });
        it("should return the defaultProperty if the target is not an object", function () {
            var result = Utilities.GetDeepValue([], "a.b.c", defaultProperty);
            chai.expect(result.first.second).to.equal("notFirst");
        });
        it("should return the target object if the path is not specified or empty", function () {
            var result = Utilities.GetDeepValue(target, null);
            chai.expect(result.dbConnection.host).to.equal("localhost");
        });
        it("should return undefined if the path doesn't exist and no defaultProperty is specified", function () {
            var result = Utilities.GetDeepValue(target, "dbConnection.socketOptions");
            chai.expect(result).to.be.undefined;
        });
        it("should return the defaultProperty if the path doesn't exist", function () {
            var result = Utilities.GetDeepValue(target, "dbConnection.socketOptions", defaultProperty);
            chai.expect(result.first.second).to.equal("notFirst");
        });
        it("should return the property as an object if the path exists", function () {
            var result = Utilities.GetDeepValue(target, "dbConnection.serverOptions");
            chai.expect(result.socketOptions.keepAlive).to.equal(1);
        });
        it("should return the property as an object if the path exists and a defaultValue is specified", function () {
            var result = Utilities.GetDeepValue(target, "dbConnection.serverOptions", defaultProperty);
            chai.expect(result.socketOptions.keepAlive).to.equal(1);
            chai.expect(result.first).to.be.undefined;
        });
        it("should return the property merged with the defaultValue if requested", function () {
            var result = Utilities.GetDeepValue(target, "dbConnection.serverOptions", defaultProperty, true);
            chai.expect(result.socketOptions.keepAlive).to.equal(1);
            chai.expect(result.first.second).to.equal("notFirst");
        });
    });
    describe("SetDeepValue: When setting a value in an object literal", function () {
        it("should set the property if the path exists", function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetDeepValue(newTarget, "dbConnection.serverOptions.name", "banana");
            chai.expect(newTarget.dbConnection.serverOptions.name).to.equal("banana");
        });
        it("should create the property if property does not exist without destroying current data", function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetDeepValue(newTarget, "dbConnection.serverOptions.description", "yellow thing");
            chai.expect(newTarget.dbConnection.serverOptions.description).to.equal("yellow thing");
            chai.expect(newTarget.dbConnection.serverOptions.name).to.equal("server");
        });
        it("should create the path and the property if neither exist", function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetDeepValue(newTarget, "what.is.the.colour", "yellow");
            chai.expect(newTarget.what.is.the.colour).to.equal("yellow");
        });
        it("should make no modifications if the path is not specified", function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetDeepValue(newTarget, "", "bendy-bendy");
            chai.expect(LodashUtilities.IsEqual(newTarget, target)).to.be.true;
        });
        it("should remove a property if the value is not specified (null or undefined", function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetDeepValue(newTarget, "dbConnection.serverOptions.name", null);
            chai.expect(Utilities.DeepValueExists(newTarget, "dbConnection.serverOptions.name")).to.be.false;
        });
        it("should return a new object if the target is undefined or null", function () {
            var result = Utilities.SetDeepValue(undefined, "a.b.c", "wally");
            chai.expect(result).to.not.be.undefined;
            chai.expect(result.a.b.c).to.equal("wally");
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
/// <reference types="node" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
describe("StartQueueWorker tests", function () {
    describe("When finding a value by path", function () {
        it("should match existent paths", function () {
            var target = { a: { b: { 'c': 'x' } } };
            var result = Utilities.FindPath(target, "a.b.c");
            chai.expect(result[0]).to.equal('x');
        });
        it("should return undefined for non-existent paths", function () {
            var target = { a: { b: { 'c': 'x' } } };
            var result = Utilities.FindPath(target, "w.x.y");
            chai.expect(result).to.be.undefined;
        });
        it("should find values inside arrays", function () {
            var target = { a: { b: [{ 'c': 'x' }] } };
            var result = Utilities.FindPath(target, "a.b.c");
            chai.expect(result[0]).to.equal('x');
        });
    });
    describe("When looking for elements where top level object is an array", function () {
        it("should match existent paths", function () {
            var target = [{ 'c': 'x' }];
            var result = Utilities.FindPath(target, "c");
            chai.expect(result).to.not.be.undefined;
            chai.expect(result[0]).to.equal('x');
        });
    });
});
describe("ConvertBusinessIdPathToGuidPath", function () {
    var bIdToGuidLookups = {};
    bIdToGuidLookups["abc"] = "1";
    bIdToGuidLookups["def"] = "2";
    bIdToGuidLookups["ghi"] = "3";
    bIdToGuidLookups["jkl"] = "4";
    it("should return the original path if BIdToGuidLookups is undefined", function () {
        var testPath = "ghi,def,abc,jkl";
        var expectedResult = testPath;
        var result = Utilities.ConvertBusinessIdPathToGuidPath(undefined, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should return the original path if BIdToGuidLookups is empty", function () {
        var testPath = "ghi,def,abc,jkl";
        var expectedResult = testPath;
        var result = Utilities.ConvertBusinessIdPathToGuidPath([], testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should return an empty string if the original path is undefined", function () {
        var testPath = undefined;
        var expectedResult = "";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should return an empty string if the original path is empty", function () {
        var testPath = "";
        var expectedResult = "";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should convert all BIds in a path to Guids", function () {
        var testPath = "ghi,def,abc,jkl";
        var expectedResult = "3,2,1,4";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should convert a single BId path to a Guid", function () {
        var testPath = "def";
        var expectedResult = "2";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should convert an uppercase BId path to the correct Guids", function () {
        var testPath = "def,JKL";
        var expectedResult = "2,4";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
    it("should not convert a missing BId in a path to the correct Guids", function () {
        var testPath = "def,UNKNOWN,jkl";
        var expectedResult = "2,UNKNOWN,4";
        var result = Utilities.ConvertBusinessIdPathToGuidPath(bIdToGuidLookups, testPath);
        chai.expect(result).to.equal(expectedResult);
    });
});

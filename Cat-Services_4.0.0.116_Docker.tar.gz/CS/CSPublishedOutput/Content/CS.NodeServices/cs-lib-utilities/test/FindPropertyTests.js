"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var LodashUtilities = require("../LodashUtilities");
var Utilities = require("../Utilities");
describe('FindProperty Tests', function () {
    var target = {
        "ID": "22223387",
        "OrderCandidate": {
            "OrderID": "456321456",
            "Customer": {
                "ID": "987744jer",
                "Action": "delete"
            },
            "OrderContext": [],
            "OrderItems": []
        },
        "CustomerPortfolio": {
            "PortfolioItems": [
                {
                    "ID": "44444444",
                    "EntityID": "777777888999",
                    "ChildEntities": [
                        {
                            "ID": "9999999999",
                            "EntityID": "54658566",
                            "Action": "add",
                            "ChildEntities": []
                        }
                    ]
                },
                {
                    "ID": "11111111",
                    "EntityID": "222233332",
                    "ChildEntities": [
                        {
                            "ID": "7888899888",
                            "EntityID": "12121212",
                            "ItemAction": "Something",
                            "ChildEntities": []
                        }
                    ]
                }
            ]
        },
        "ActiviationDate": "2014-12-12"
    };
    describe('PropertyExists: When testing if a property path exists anywhere in an object literal', function () {
        it('should return false if the target is undefined or null', function () {
            var result = Utilities.PropertyExists(undefined, 'Whatever');
            chai.expect(result).to.be.false;
        });
        it('should return false if the property is not specified or empty', function () {
            var result = Utilities.PropertyExists(target, null);
            chai.expect(result).to.be.false;
        });
        it('should return false if the property does not exist', function () {
            var result = Utilities.PropertyExists(target, 'SomethingThatsNotThere');
            chai.expect(result).to.be.false;
        });
        it('should return true if the property exists', function () {
            var result = Utilities.PropertyExists(target, 'Action');
            chai.expect(result).to.be.true;
        });
    });
    describe('FindObjectsContainingProperty: When setting a property where ever it appears in the object', function () {
        it('should return an empty array if the target is undefined or null', function () {
            var result = Utilities.FindObjectsContainingProperty(undefined, 'Whatever');
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(0);
        });
        it('should return an empty array if the property is not specified or empty', function () {
            var result = Utilities.FindObjectsContainingProperty(target, null);
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(0);
        });
        it('should return an empty array if the target is not an object', function () {
            var result = Utilities.FindObjectsContainingProperty('AString', 'Whatever');
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(0);
        });
        it('should return an empty array if the property does not exist in the target', function () {
            var result = Utilities.FindObjectsContainingProperty(target, 'SomethingThatsNotThere');
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(0);
        });
        it('should return each item the property is found in in an array', function () {
            var result = Utilities.FindObjectsContainingProperty(target, 'Action');
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(2);
            chai.expect(['9999999999', '987744jer']).to.contain(result[0].ID);
            chai.expect(['9999999999', '987744jer']).to.contain(result[1].ID);
        });
    });
    describe('SetPropertyEverywhere: Set a property whereever it occurs', function () {
        it('should set the property everywhere it exists', function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetPropertyEverywhere(newTarget, 'Action', 'banana');
            var result = Utilities.FindObjectsContainingProperty(newTarget, 'Action');
            chai.expect(result instanceof Array).to.be.true;
            chai.expect(result.length).to.be.equal(2);
            chai.expect(['9999999999', '987744jer']).to.contain(result[0].ID);
            chai.expect(['9999999999', '987744jer']).to.contain(result[1].ID);
            chai.expect(result[0].Action).to.equal('banana');
            chai.expect(result[1].Action).to.equal('banana');
        });
        it('should make no modifications if the property does not exist', function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetPropertyEverywhere(newTarget, 'SomethingThatsNotThere', 'banana');
            chai.expect(LodashUtilities.IsEqual(newTarget, target)).to.be.true;
        });
        it('should make no modifications if the property is not specified or empty', function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetPropertyEverywhere(newTarget, undefined, 'banana');
            chai.expect(LodashUtilities.IsEqual(newTarget, target)).to.be.true;
        });
        it('should remove a property if the value is undefined', function () {
            var newTarget = LodashUtilities.CloneDeep(target);
            Utilities.SetPropertyEverywhere(newTarget, 'Action', undefined);
            chai.expect(Utilities.PropertyExists(newTarget, 'Action')).to.be.false;
        });
    });
});

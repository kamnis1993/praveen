"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var Utilities = require("../Utilities");
var ProductSpecIdType = require("../../cs-lib-types/Enums/ProductSpecIdType");
describe('Is Validator Tests', function () {
    describe('IsDateValidForDateRange: When testing if a date falls within a specified range', function () {
        it('should return true if the tested date is null or undefined irrespective of the date range', function () {
            var result = Utilities.IsDateValidForDateRange(undefined, null, null);
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange(null, '2015-01-14', '2015-04-04');
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange(undefined, new Date('2015-01-01'), new Date('2016-01-01'));
            chai.expect(result).to.be.true;
        });
        it('should return true if no date range is specified', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), null, null);
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange('2015-04-04', null, null);
            chai.expect(result).to.be.true;
        });
        it('should return true if after the start date and before the end date', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), '2015-01-01', '2016-01-01');
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange('2015-04-04', new Date('2015-01-01'), new Date('2016-01-01'));
            chai.expect(result).to.be.true;
        });
        it('should return true if before the end date and the start date is not specified', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), null, '2016-01-01');
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange('2015-04-04', null, new Date('2016-01-01'));
            chai.expect(result).to.be.true;
        });
        it('should return true if after start date and end date is not specified', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), '2015-01-01', null);
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange('2015-04-04', new Date('2015-01-01'), null);
            chai.expect(result).to.be.true;
        });
        it('should return false if before the start date', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2014-04-04'), '2015-01-01', '2016-01-01');
            chai.expect(result).to.be.false;
            result = Utilities.IsDateValidForDateRange('2014-04-04', new Date('2015-01-01'), new Date('2016-01-01'));
            chai.expect(result).to.be.false;
        });
        it('should return false if after the end date', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2016-04-04'), '2015-01-01', '2016-01-01');
            chai.expect(result).to.be.false;
            result = Utilities.IsDateValidForDateRange('2016-04-04', new Date('2015-01-01'), new Date('2016-01-01'));
            chai.expect(result).to.be.false;
        });
        it('should use appropriate effective date if no standard date is not specified', function () {
            var result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), null, null, '2015-01-01', '2016-01-01');
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange('2015-04-04', null, null, new Date('2015-01-01'), new Date('2016-01-01'));
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange(new Date('2015-04-04'), '2015-01-01', '2016-01-01', '2015-05-01', '2015-07-01');
            chai.expect(result).to.be.true;
            result = Utilities.IsDateValidForDateRange(new Date('2014-04-04'), '2015-01-01', null, null, '2016-01-01');
            chai.expect(result).to.be.false;
            result = Utilities.IsDateValidForDateRange(new Date('2014-04-04'), null, '2016-01-01', '2015-01-01', null);
            chai.expect(result).to.be.false;
            result = Utilities.IsDateValidForDateRange(new Date('2016-04-04'), '2015-01-01', null, null, '2016-01-01');
            chai.expect(result).to.be.false;
            result = Utilities.IsDateValidForDateRange(new Date('2016-04-04'), null, '2016-01-01', '2015-01-01', null);
            chai.expect(result).to.be.false;
        });
    });
    describe('IsValidId: When testing if a product id is valid', function () {
        it('should correctly test if an id matches the expected format of an entity Guid', function () {
            var result = Utilities.IsValidId("", ProductSpecIdType.Guid);
            chai.expect(result).to.be.false;
            result = Utilities.IsValidId("12345", ProductSpecIdType.Guid);
            chai.expect(result).to.be.false;
            result = Utilities.IsValidId("b3c99630-b5fc-4af3-b645-64ca939df1f6", ProductSpecIdType.Guid);
            chai.expect(result).to.be.true;
        });
        it('should correctly test if an id matches the expected format of a business Id', function () {
            var result = Utilities.IsValidId("", ProductSpecIdType.BusinessId);
            chai.expect(result).to.be.false;
            result = Utilities.IsValidId("b3c99630-b5fc-4af3-b645-64ca939df1f6", ProductSpecIdType.BusinessId);
            chai.expect(result).to.be.false;
            result = Utilities.IsValidId("ABC_123", ProductSpecIdType.BusinessId);
            chai.expect(result).to.be.false;
            result = Utilities.IsValidId("ABC123", ProductSpecIdType.BusinessId);
            chai.expect(result).to.be.true;
            result = Utilities.IsValidId("12345678912345757346373", ProductSpecIdType.BusinessId);
            chai.expect(result).to.be.true;
        });
    });
});

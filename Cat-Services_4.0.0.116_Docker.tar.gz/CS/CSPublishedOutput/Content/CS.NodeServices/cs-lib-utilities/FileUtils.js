"use strict";
/// <reference types="node" />
var fs = require("fs");
var path = require("path");
/**
 * A set of file system helpers
 */
var FileUtils = /** @class */ (function () {
    function FileUtils() {
    }
    /**
     * Read a file on a specified path and parse as JSON synchronously.
     * The path is resolved to the current directory
     * @param {string} fileName path to the file
     * @param {string} [workingDir] Optional. the current working directory if path is relative. Default: __dirname
     * @returns {any} if valid json, an object literal, otherwise undefined
     */
    FileUtils.ReadJsonFileSync = function (fileName, workingDir) {
        var fileAsJson = undefined;
        workingDir = workingDir || __dirname;
        var absFileName = path.resolve(workingDir, fileName);
        if (fs.existsSync(absFileName)) {
            try {
                fileAsJson = JSON.parse(fs.readFileSync(fileName, { encoding: 'utf8' }));
            }
            catch (e) {
                // Ignore, and undefined is returned
            }
        }
        return fileAsJson;
    };
    /**
     * Read a file on a specified path and parse as JSON.
     * The path is resolved to the current directory
     * @param {string} fileName path to the file
     * @param {string} workingDir the current working directory if path is relative. Default: __dirname
     * @param {function(err: Error, data: any)} callback if successful 'data' is the parsed object, otherwise undefined
     */
    FileUtils.ReadJsonFile = function (fileName, workingDir, callback) {
        workingDir = workingDir || __dirname;
        var absFileName = path.resolve(workingDir, fileName);
        fs.exists(absFileName, function (exists) {
            if (!exists) {
                return callback(null, undefined);
            }
            fs.readFile(fileName, { encoding: 'utf8' }, function (err, data) {
                if (err || !data) {
                    return callback(err, undefined);
                }
                try {
                    var fileAsJson = JSON.parse(data);
                    return callback(null, fileAsJson);
                }
                catch (e) {
                    // Ignore, undefined is returned
                    return callback(null, undefined);
                }
            });
        });
    };
    /**
    * Writes a string array to file.
    * This is a highly performant way of writing a lot of data or data in a specific sequence.
    * @param {string} outputPath - The full path of the file to write to.
    * @param {string[]} data - The data to write to file
    * @param {boolean} append (optional) - Specify whether to append to the file. Defaults to false.
    */
    FileUtils.WriteArrayToFile = function (outputPath, data, append) {
        append = append || false;
        var file = fs.createWriteStream(outputPath, append ? { 'flags': 'a' } : { 'flags': 'w' });
        file.on('error', function (err) {
            /* log and continue on error */
            console.log(err.toString());
        });
        // Write each log item to file
        Object.keys(data).forEach(function (index) {
            file.write(data[index] + "\n");
        });
        file.end();
    };
    return FileUtils;
}());
module.exports = FileUtils;

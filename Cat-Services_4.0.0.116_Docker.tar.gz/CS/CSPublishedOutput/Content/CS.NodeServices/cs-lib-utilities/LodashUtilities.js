"use strict";
/// <reference types="lodash" />
var _ = require("lodash");
/**
* This class provides a wrapper around the common lodash utilities.
* It is intended to prevent the need for lodash to be included in every module
* and allows lodash to be phased out over time without impacting many modules.
*/
var LodashUtilities = /** @class */ (function () {
    function LodashUtilities() {
    }
    LodashUtilities.Clone = function (hasValue, isDeep) {
        if (isDeep) {
            return _.cloneDeep(hasValue);
        }
        return _.clone(hasValue);
    };
    LodashUtilities.CloneDeep = function (value) {
        return _.cloneDeep(value);
    };
    LodashUtilities.CloneTargetOnly = function (hasValue) {
        return _.clone(hasValue);
    };
    LodashUtilities.Contains = function (collection, target) {
        return _.includes(collection, target);
    };
    LodashUtilities.CountBy = function (collection) {
        return _.countBy(collection);
    };
    LodashUtilities.Difference = function (hasArray, Values) {
        return _.difference(hasArray, Values);
    };
    LodashUtilities.EndsWith = function (strings, target) {
        return _.endsWith(strings, target);
    };
    LodashUtilities.Every = function (collection, prediciate) {
        return _.every(collection, prediciate);
    };
    LodashUtilities.EveryWithCallback = function (hasArray, callback) {
        return _.every(hasArray, callback);
    };
    LodashUtilities.Find = function (collection, callback) {
        return _.find(collection, callback);
    };
    LodashUtilities.FindIndex = function (hasArray, callback) {
        _.findIndex(hasArray, callback);
    };
    LodashUtilities.FindKey = function (hasObject, callback) {
        return _.findKey(hasObject, callback);
    };
    LodashUtilities.FindWithObject = function (hasArray, hasObject) {
        return _.find(hasArray, hasObject);
    };
    LodashUtilities.First = function (collection) {
        return _.first(collection);
    };
    LodashUtilities.Flatten = function (hasArray) {
        return _.flatten(hasArray);
    };
    LodashUtilities.ForOwn = function (hasObject, callback) {
        _.forOwn(hasObject, callback);
    };
    LodashUtilities.GroupByCallback = function (collection, callback) {
        return _.groupBy(collection, callback);
    };
    LodashUtilities.GroupByString = function (collection, Strings) {
        return _.groupBy(collection, Strings);
    };
    LodashUtilities.Has = function (hasObject, path) {
        return _.has(hasObject, path);
    };
    LodashUtilities.Intersection = function (hasArray, anotherArray) {
        return _.intersection(hasArray, anotherArray);
    };
    LodashUtilities.IntersectionString = function (hasAny, hasArray) {
        return _.intersection(hasAny, hasArray);
    };
    LodashUtilities.IsArray = function (value) {
        return _.isArray(value);
    };
    LodashUtilities.IsEmpty = function (value) {
        return _.isEmpty(value);
    };
    LodashUtilities.IsEqual = function (value, other) {
        return _.isEqual(value, other);
    };
    LodashUtilities.IsFunction = function (value) {
        return _.isFunction(value);
    };
    LodashUtilities.IsObject = function (value) {
        return _.isObject(value);
    };
    LodashUtilities.IsString = function (value) {
        return _.isString(value);
    };
    LodashUtilities.IsPlainObject = function (value) {
        return _.isPlainObject(value);
    };
    LodashUtilities.Keys = function (hasObject) {
        return _.keys(hasObject);
    };
    LodashUtilities.Map = function (collection, callback) {
        return _.map(collection, callback);
    };
    LodashUtilities.Merge = function (hasObject, source, value) {
        if (value === void 0) { value = undefined; }
        return _.merge(hasObject, source, value);
    };
    LodashUtilities.ParseInt = function (hasString) {
        return _.parseInt(hasString);
    };
    LodashUtilities.Pick = function (hasObject, predicate) {
        return _.pick(hasObject, predicate);
    };
    LodashUtilities.Pluck = function (collection, path) {
        return _.map(collection, path);
    };
    LodashUtilities.Remove = function (hasArray, callback) {
        return _.remove(hasArray, callback);
    };
    LodashUtilities.SortBy = function (collection, callback) {
        return _.sortBy(collection, callback);
    };
    LodashUtilities.Some = function (collection, hasAny) {
        return _.some(collection, hasAny);
    };
    LodashUtilities.StartsWith = function (strings, target) {
        return _.startsWith(strings, target);
    };
    LodashUtilities.Uniq = function (hasArray, pluckValue) {
        if (pluckValue === void 0) { pluckValue = undefined; }
        return _.uniqBy(hasArray, pluckValue);
    };
    LodashUtilities.UniqWithCallback = function (hasArray, callback) {
        return _.uniqBy(hasArray, callback);
    };
    LodashUtilities.Values = function (hasObject) {
        return _.values(hasObject);
    };
    LodashUtilities.Where = function (collection, source) {
        return _.filter(collection, source);
    };
    return LodashUtilities;
}());
module.exports = LodashUtilities;

"use strict";
/// <reference types="node-uuid" />
/// <reference types="validator" />
var uuid = require("node-uuid");
var stream = require("stream");
var validator = require("validator");
var LodashUtilities = require("./LodashUtilities");
var ProductSpecIdType = require("../cs-lib-types/Enums/ProductSpecIdType");
var Utilities = /** @class */ (function () {
    function Utilities() {
    }
    /**
     * Find a value (or undefined) in a target object given a path string
     * @param target -- the object to inspect (i.e. {a:{b:{c:'x'}}})
     * @param pathString -- a path through the object (i.e. "a.b.c")
     * @returns -- the value found or undefined if no such path (i.e. 'x')
     */
    Utilities.FindPath = function (target, pathString) {
        var _this = this;
        if (Array.isArray(target)) {
            return target.reduce(function (a, i) { return a.concat(_this.FindPathInternal(i, pathString)); }, []);
        }
        else {
            return this.FindPathInternal(target, pathString);
        }
    };
    Utilities.FindPathInternal = function (target, pathString) {
        var arr = pathString.split(".");
        while (arr.length && (target = target[arr.shift()])) {
            if (arr.length && target.length && target.forEach) { // handle arrays
                var remainder = arr.join('.');
                var results = [];
                for (var i = 0; i < target.length; i++) {
                    var x = Utilities.FindPath(target[i], remainder);
                    if (x) {
                        results = results.concat(x);
                    }
                }
                return results;
            }
        }
        return (target) ? [target] : undefined; //single result, wrap in array for consistency
    };
    /**
    * Convert a path consisting of BusinessIds to it's equivalent Guid path
    * @param {any} bIdToGuidLookups
    * @param {string} pathToConvert
    * @returns {string}
    */
    Utilities.ConvertBusinessIdPathToGuidPath = function (bIdToGuidLookups, pathToConvert) {
        if (Utilities.IsNotDefined(pathToConvert, true)) {
            return "";
        }
        if (Utilities.IsNotDefined(bIdToGuidLookups) || bIdToGuidLookups.length === 0) {
            return pathToConvert;
        }
        var pathArray = pathToConvert.split(",");
        var result = [];
        pathArray.forEach(function (businessId) {
            var guid = bIdToGuidLookups[businessId.trim().toLowerCase()];
            result.push(guid || businessId); // Maintain bid if matching guid is not found, this is very unlikely but will help debugging.
        });
        return result.join(",");
    };
    /** Change scalar values into arrays. Array returned unaltered */
    // ReSharper disable once InconsistentNaming
    Utilities.asArray = function (x) {
        if (!this.IsDefined(x)) {
            return [];
        }
        if (Array.isArray(x)) {
            return x;
        }
        return [].concat.apply([], [x]);
    };
    /**
     * Convert an object literal to an array of type T using the specified convertor.
     * If the source is undefined or null, then an empty array is returned.
     * The convertor is called for each item in source, which is always treated as an array even if it is a single object
     * If the itemConvertor returns undefined, then the item is not in the final array
     * @param {any} source the literal object to convert
     * @param {(item: any) => T} itemConvertor a function which will take an object literal and return an object of type T
     * @returns {Array<T>} the resulting array
     */
    Utilities.ConvertToArrayOf = function (source, itemConvertor) {
        var newArray = [];
        if (source === undefined || source === null) {
            return newArray;
        }
        var sourceArray = Utilities.asArray(source);
        sourceArray.forEach(function (sourceItem) {
            var newItem = itemConvertor(sourceItem);
            if (newItem !== undefined) {
                newArray.push(newItem);
            }
        });
        return newArray;
    };
    /**
     * Iterate over an array applying the iterator to each item.
     * If a single item is passed it is treated as an array of one item
     * @param {any} items the object to iterate over
     * @param {(item: any) => void} iterator the iterator to apply to each
     */
    Utilities.IterateAsArray = function (items, iterator) {
        if (items !== undefined && items !== null) {
            var itemsArray = this.asArray(items);
            itemsArray.forEach(iterator);
        }
    };
    /**
     * Return a new array of all the duplicates in the source array of string
     * Note: Uses lodash functionality
     * @param {Array<string>} srcArray the source array containing the duplicates
     * @returns {Array<string>}
     */
    Utilities.DuplicatesInStringArray = function (srcArray) {
        return LodashUtilities.Keys(LodashUtilities.Pick(LodashUtilities.CountBy(srcArray), function (count) { return count > 1; }));
    };
    /**
     * Joins two values together
     * @param {any} old The first object to join
     * @param {any} additional The second object to join
     * @returns {any}
     */
    Utilities.JoinValues = function (old, additional) {
        if (additional === undefined) {
            return old;
        }
        if (old) {
            if (Array.isArray(old)) {
                if (Array.isArray(additional)) {
                    return old.concat(additional);
                }
                else {
                    return old.concat([additional]);
                }
            }
            else {
                return [old, additional];
            }
        }
        else {
            return additional;
        }
    };
    /**
     * Test if a property is Not defined with an optional addition of testing for a non-zero length
     * @param {any} item the property to test
     * @param {boolean = false} checkLength whether or not to test for zero length as not defined
     * @returns {boolean} true if considered not defined, otherwise false
     */
    Utilities.IsNotDefined = function (item, checkLength) {
        if (checkLength === void 0) { checkLength = false; }
        return (item === undefined || item === null || (checkLength && item.length === 0));
    };
    /**
     * Test is something is defined - the reverse of "IsNotDefined"
     * @param {any} item the property to test
     * @param {boolean = false} checkLength whether or not to test for zero length as not defined
     * @returns {boolean} true if considered defined, otherwise false
     */
    Utilities.IsDefined = function (item, checkLength) {
        if (checkLength === void 0) { checkLength = false; }
        return !Utilities.IsNotDefined(item, checkLength);
    };
    /**
     * Returns true if a string contains only zeros and dashes
     */
    Utilities.IsEmptyGuid = function (guid) {
        return (guid.replace(/[0\-]/g, '').length === 0); // eslint-disable-line no-useless-escape
    };
    /**
     * Checks if a date is within the date range specified. An undefined end is considered open range
     * If normal dates are not specified then effective ones are used if specified.
     * Accepts anything that can be parsed as a date (ie. Date or string)
     * @param {any} dateToCheck the date to check
     * @param {any} startDate start of date range
     * @param {any} endDate end of date range
     * @param {any} [effectiveStart] Optional: effective start of the date range (see components)
     * @param {any} [effectiveEnd] Optional: effective end of the date range
     * @returns {boolean} true if considered in range, otherwise false
     */
    Utilities.IsDateValidForDateRange = function (dateToCheck, startDate, endDate, effectiveStart, effectiveEnd) {
        var targetDate = this.GetDateValue(dateToCheck);
        if (this.IsNotDefined(targetDate)) {
            return true;
        }
        var start = this.GetDateValue(startDate);
        if (this.IsNotDefined(start)) {
            start = this.GetDateValue(effectiveStart);
        }
        var end = this.GetDateValue(endDate);
        if (this.IsNotDefined(end)) {
            end = this.GetDateValue(effectiveEnd);
        }
        return (this.IsNotDefined(start) || targetDate >= start) && (this.IsNotDefined(end) || targetDate <= end);
    };
    /**
     * Checks if a value exists (not undefiend or null) and returns a default if so.
     * @param {any} value The value to check exists
     * @param {any} defaultValue default to return if the value does not exist. This can be function
     * @param {boolean) toLowerCase (Default: false) if true and value is a string, convert to lowercase
     * @returns {any} The value if it exists otherwise the defaultValue. If defaultValue is a function then its output
     */
    Utilities.ValueOrDefault = function (value, defaultValue, toLowerCase) {
        if (toLowerCase === void 0) { toLowerCase = false; }
        if (value !== undefined && value !== null) {
            return LodashUtilities.IsString(value) && toLowerCase ? value.toLowerCase() : value;
        }
        return LodashUtilities.IsFunction(defaultValue) ? defaultValue() : defaultValue;
    };
    /** takes a date or a string and returns a date */
    Utilities.EnsureDate = function (maybeDate) {
        // this is only here to get around problems with the TypeScript type checking
        if (Utilities.IsNotDefined(maybeDate)) {
            return null;
        }
        if (maybeDate.length === 19) {
            maybeDate = maybeDate + ".000Z";
        }
        else if (maybeDate.length === 23) {
            maybeDate = maybeDate + "Z";
        }
        return new Date(maybeDate);
    };
    /**
    * Validates that a date or a string is a valid date
    * @param {string} maybeDate the value to test
    * @returns {boolean} [true] is the value is a valid date
    */
    Utilities.IsValidDate = function (maybeDate) {
        maybeDate = Utilities.EnsureDate(maybeDate);
        if (Object.prototype.toString.call(maybeDate) !== "[object Date]") {
            return false;
        }
        if (isNaN(maybeDate.getTime())) {
            return false;
        }
        return true;
    };
    /** takes a date or a string and returns a number equivalent to the valueOf() the Date */
    Utilities.GetDateValue = function (maybeDate) {
        if (this.IsNotDefined(maybeDate)) {
            return undefined;
        }
        if (maybeDate.length === 19) {
            maybeDate = maybeDate + ".000Z";
        }
        else if (maybeDate.length === 23) {
            maybeDate = maybeDate + "Z";
        }
        return (new Date(maybeDate)).valueOf();
    };
    /** takes a Date object or a date string and returns an ISO 8601 date string with no time (like "2015-01-05") */
    Utilities.DateString = function (maybeDateTime) {
        var d = Utilities.GetDateValue(maybeDateTime);
        if (!d) {
            return undefined;
        }
        return new Date(d).toISOString().slice(0, 10);
    };
    /**
     * Parse a date from a string. Return undefined if not valid.
     * @param {string} strDate the string to parse as a date
     * @param {boolean} forceUTC (default: false) whether the date should always be considered UTC
     * @returns {Date} the parsed Date or undefined
     */
    Utilities.ParseDateFromString = function (strDate, forceUTC) {
        if (forceUTC === void 0) { forceUTC = false; }
        if (strDate === undefined || strDate === null || isNaN(Date.parse(strDate))) {
            return undefined;
        }
        if (forceUTC) {
            var utcString = strDate.slice(-1) === 'Z' ? strDate : strDate + 'Z';
            return new Date(utcString);
        }
        else {
            return new Date(strDate);
        }
    };
    /**
     * Returns the date as an iso string
     * @param {Date} d The date to format
     * @returns {string}
     */
    Utilities.IsoDateString = function (d) {
        var pad = function (numToPad) {
            if (numToPad < 10) {
                return '0' + numToPad;
            }
            return '' + numToPad;
        };
        return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate());
    };
    /**
     * Parse a spec value and ensure a boolean is returned
     * @param {any} value the value to parse
     * @param {boolean} defaultValue a default if parsing fails
     * @returns {boolean} the parsed boolean or defaultValue
     */
    Utilities.ParseAsBoolean = function (value, defaultValue) {
        if (value === undefined || value === null) {
            return defaultValue;
        }
        if (typeof (value) === 'boolean') {
            return value;
        }
        if (typeof (value) !== 'string') {
            return defaultValue;
        }
        return value.toLowerCase() === 'true';
    };
    /**
     * Parse a given value and ensure a number is returned
     * @param {any} value - the value to request to set it to
     * @param {number} defaultValue - the value to return if the value fails to
     * @returns {number}
     */
    Utilities.ParseAsNumber = function (value, defaultValue) {
        if (value === undefined || value === null) {
            return defaultValue;
        }
        if (typeof (value) === 'number') {
            return value;
        }
        if (typeof (value) === 'string' && !(isNaN(parseInt(value)))) {
            return parseInt(value);
        }
        return defaultValue;
    };
    /**
     * Check if a given value is a number
     * @param {any} value - the value to check
     * @returns {boolean}
     */
    Utilities.IsNumeric = function (value) {
        if (value === undefined || value === null) {
            return false;
        }
        if (typeof (value) === 'number') {
            return true;
        }
        if (typeof (value) === 'string' && !(isNaN(parseInt(value)))) {
            return true;
        }
        return false;
    };
    /**
     * Determine if an object contains a property. Does a deep search
     * @param {any} target the object to check
     * @param {string} property the name of the property to search for
     * @returns {boolean} true if the property is found
     */
    Utilities.PropertyExists = function (target, property) {
        if (target === undefined || target === null) {
            return false;
        }
        if (property === undefined || property === null || property.length === 0) {
            return false;
        }
        var found = false;
        var checkArray = function (array) {
            array.some(function (obj) { return checkObject(obj); });
        };
        var checkObject = function (obj) {
            if (obj === undefined || obj === null || obj !== Object(obj)) {
                return found;
            }
            found = found || (obj[property] !== undefined);
            if (!found) {
                // ReSharper disable once MissingHasOwnPropertyInForeach
                for (var p in obj) {
                    var child = obj[p];
                    if (Array.isArray(child)) {
                        checkArray(child);
                    }
                    else if (child === Object(child)) {
                        checkObject(child);
                    }
                }
            }
            return found;
        };
        if (Array.isArray(target)) {
            checkArray(target);
        }
        else if (target === Object(target)) {
            checkObject(target);
        }
        // ReSharper disable once ExpressionIsAlwaysConst - set inside the inline functions
        return found;
    };
    /**
     * Search deep in an object and return an array of all objects which contain the specified property
     * @param {any} target the object to search
     * @param {string} property the name of the property to look for
     * @returns {Array<any>} an array of all objects which have the specified property
     */
    Utilities.FindObjectsContainingProperty = function (target, property) {
        var found = [];
        if (target === undefined || target === null) {
            return [];
        }
        if (property === undefined || property === null || property.length === 0) {
            return [];
        }
        var findInArray = function (array) {
            array.forEach(function (obj) { findInObject(obj); });
        };
        var findInObject = function (obj) {
            if (obj === undefined || obj === null || obj !== Object(obj)) {
                return;
            }
            if (obj[property] !== undefined) {
                found.push(obj);
            }
            // ReSharper disable once MissingHasOwnPropertyInForeach
            for (var p in obj) {
                var child = obj[p];
                if (Array.isArray(child)) {
                    findInArray(child);
                }
                else if (child === Object(child)) {
                    findInObject(child);
                }
            }
        };
        if (Array.isArray(target)) {
            findInArray(target);
        }
        else if (target === Object(target)) {
            findInObject(target);
        }
        return found;
    };
    /**
     * Set a property everywhere it appears in an object to s specific value.
     * Searches deep and across arrays. Defining a value of "undefined" will remove the
     * property from the object.
     * @param {any} target the object of the search/replace
     * @param {string} property the name of the property
     * @param {any} value the value to set each instance of the property to.
     */
    Utilities.SetPropertyEverywhere = function (target, property, value) {
        var foundItems = this.FindObjectsContainingProperty(target, property);
        if (foundItems.length > 0) {
            foundItems.forEach(function (item) { item[property] = value; });
        }
    };
    /**
     * Determine if a deep path exists to a property in a target literal
     * @param {any} target the object to search for the property(e.g. {a:{b:{c:{d:'x'}}}}
     * @param {string} onPath the period separated path through the object
     * @returns {boolean} true is path exists
     */
    Utilities.DeepValueExists = function (target, onPath) {
        return Utilities.GetDeepValue(target, onPath) !== undefined;
    };
    /**
     * Get a property on a deep path within a target object literal.
     * If any part of the path doesn't exist, return undefined or the defaultValue if specified
     * @param {any} target the object to search for the property(e.g. {a:{b:{c:{d:'x'}}}}
     * @param {string} path the period separated path through the object (e.g. a.b.c)
     * @param {any} [defaultValue] Optional. Object to return if path does not exist in target
     * @param {boolean} [mergeDefault] optional. Merge the defaultValue with any value found
     * @returns {any} the value requested or the defaultValue if not found
     */
    Utilities.GetDeepValue = function (target, path, defaultValue, mergeDefault) {
        if (Array.isArray(target) && target.length === 1) {
            target = target[0]; // unpack single values wrapped in an array
        }
        mergeDefault = (mergeDefault || false) && defaultValue !== undefined && defaultValue !== null;
        if (!target) {
            return defaultValue;
        }
        if (!(target instanceof Object)) {
            return defaultValue;
        }
        if (!path || path.length === 0) {
            return target;
        }
        var tmp = target;
        var pathAttrs = path.split(".");
        for (var i = 0; i < pathAttrs.length; i++) {
            if (Array.isArray(tmp) && tmp.length === 1) {
                tmp = tmp[0]; // unpack single values wrapped in an array
            }
            if (this.IsNotDefined(tmp[pathAttrs[i]])) {
                return defaultValue;
            }
            tmp = tmp[pathAttrs[i]];
        }
        return mergeDefault ? LodashUtilities.Merge({}, defaultValue, tmp) : tmp;
    };
    /**
     * Set a deep value within an object given the path to the object in a period separated string.
     * If any part of the path doesn't exist it will be created.
     * @param {any} target the object to search for the property(e.g. {a:{b:{c:{d:'x'}}}}
     * @param {string} path the period separated path to the key (e.g. a.b.c)
     * @param {any} value to set the key to
     * @return {any} the updated object
     */
    Utilities.SetDeepValue = function (target, path, value) {
        if (!target) {
            target = {};
        }
        if (!path || path.length === 0) {
            return target;
        }
        var bits = path.split(".");
        var lastKey = bits.pop();
        var tmp = target;
        for (var i = 0; i < bits.length; i++) {
            var p = bits[i];
            if (tmp[p] === null || typeof (tmp[p]) !== 'object') {
                tmp[p] = {};
            }
            tmp = tmp[p];
        }
        tmp[lastKey] = value;
        return target;
    };
    /**
     * DeleteDeepProperty - Mutates the given object by deleting the property deep inside it using a given a path string
     * @param target -- the object to inspect (i.e. {a:{b:{c:'x'}}})
     * @param pathString -- a path through the object (i.e. "a.b.c")
     * @returns -- an object with the key & value that was deleted (useful for checking whether a deletion was carried out)
     */
    Utilities.DeleteDeepProperty = function (target, objectPath) {
        if (Utilities.IsNotDefined(target, true) || Object.prototype.toString.call(target) !== '[object Object]') {
            return undefined;
        }
        var tmp = target;
        var subObjects = objectPath.split(".");
        var lastKey = subObjects.pop();
        for (var subObjectIdx = 0; subObjectIdx < subObjects.length; subObjectIdx++) {
            var subObjectKey = subObjects[subObjectIdx];
            tmp = tmp[subObjectKey];
            if (Utilities.IsNotDefined(tmp) || typeof (tmp) !== 'object') {
                return undefined;
            }
        }
        if (Utilities.IsNotDefined(tmp[lastKey])) {
            return undefined;
        }
        var value = { key: lastKey, value: tmp[lastKey] };
        delete tmp[lastKey];
        return value;
    };
    /**
     * Create a random ID to be used in OrderItems and PortfolioItems
     * @param {string} [prefix] Optional. A prefix to prepend to the random ID, defaults to ID
     * @returns {string} A randomly generated ID
     * @static
     */
    Utilities.CreateID = function (prefix) {
        prefix = prefix || 'CS';
        return prefix + '_' + this.GenerateGuid();
    };
    /**
     * Process a queue of work using a `doWork` function, calling `done` when finished.
     *
     * StandardCallback pattern `function(err, result) {...}` used.
     * @param queue -- work items. Can be added to by the `doWork` function
     * @param doWork -- process a work item, should call `workDone` with any results produced
     * @param done -- called when queue is empty or when errors occur, with the error or an array of results from `doWork`
     */
    Utilities.StartQueueWorker = function (queue, done, doWork) {
        var output = [];
        var trampoline = function (err, result) {
            if (err) { // failed a step. All results considered unreliable.
                return done(err, undefined);
            }
            if (result) { // got something from the worker function
                output.push(result);
            }
            if (queue.length < 1) { // job done
                return done(undefined, output);
            }
            // do next work item
            var work = queue.shift();
            return doWork(work, trampoline);
        };
        trampoline(null, null);
    };
    /**
     * Process a queue of work using a `doWork` function, calling `done` when finished. This passes the entire queue in for each iteration.
     * The `doWork` function should provide the next batch of work to process each time, or empty to stop processing.
     *
     * @param firstBatch -- first set of work items.
     * @param doWork -- process a work item, should call `workDone` with any results produced, and the next batch to process.
     * @param done -- called when queue is empty or when errors occur, with the error or an array of results from `doWork`
     */
    Utilities.StartBatchWorker = function (firstBatch, done, doWork) {
        var output = [];
        var trampoline = function (err, result, nextBatch) {
            if (err) { // failed a step. All results considered unreliable.
                return done(err, undefined);
            }
            if (result) { // got something from the worker function
                output.push(result);
            }
            if ((!nextBatch) || nextBatch.length < 1) { // job done
                return done(undefined, output);
            }
            // do next work item
            return doWork(nextBatch, trampoline);
        };
        trampoline(null, null, firstBatch);
    };
    /**
     * Check if a target string ends with the specified search string.
     * Note: this uses substring as it is faster than indexOf on long strings
     * @param {string} target the string to search
     * @param {string} searchString the string to look for
     * @param {boolean} caseInsensitive (Default: false) whether the search should be case insensitive
     * @returns {boolean}
     */
    Utilities.StringEndsWith = function (target, searchString, caseInsensitive) {
        if (caseInsensitive === void 0) { caseInsensitive = false; }
        if (searchString === undefined || searchString === null || searchString.length === 0) {
            return false;
        }
        if (target === undefined || target === null || target.length === 0) {
            return false;
        }
        if (caseInsensitive) {
            target = target.toLowerCase();
            searchString = searchString.toLowerCase();
        }
        return target.substring(target.length - searchString.length, target.length) === searchString;
    };
    /**
     * Generates a random guid - note, this is purely for providing a value, and no guarantees are made that the guid will be unique
     */
    Utilities.GenerateGuid = function () {
        return uuid.v4();
    };
    /**
     * Remove any null properties from obj and return it. Should keep falsey values.
      * @param obj
     */
    Utilities.FilterNulls = function (obj) {
        for (var i in obj) {
            if (obj[i] === null) {
                delete obj[i];
            }
        }
        return obj;
    };
    /**
    * Checks if the supplied value is in the given path
    * @param {string} path the value to check the type of
    * @param {Array<string>} elementTypes the types to match against
    * @param {boolean} compareBaseType? indicates if the base type of the value should be compared against the list of types
    * @returns {boolean} a boolean indicating if the supplied list of types contains the type of the supplied element value
    */
    Utilities.PathContains = function (path, elementTypes, compareBaseType) {
        if (Utilities.IsDefined(path, true)) {
            var splitPath = path.split('/');
            if (compareBaseType) {
                return elementTypes.indexOf(splitPath.pop()) >= 0;
            }
            else {
                return elementTypes.some(function (type) {
                    return splitPath.indexOf(type) >= 0;
                });
            }
        }
        return false;
    };
    /**
    * Creates a readable stream from a string or object.
    * @param {any} input - The object to convert to a stream
    * @returns {stream.Readable}
    */
    Utilities.ConvertToStream = function (input) {
        if (input === undefined || input === null) {
            return undefined;
        }
        var s = new stream.Readable();
        if (typeof (input) === 'string') {
            s.push(input);
        }
        else {
            s.push(JSON.stringify(input));
        }
        s.push(null); // This is necessary to indicate end-of-file
        return s;
    };
    /**
    * Gets a value from array by matching on a specific key.
    * Allows for case insensitive searches.
    * @param {any[]} array - The array to search
    * @param {string} key - The key to search for
    * @returns {any}
    */
    Utilities.GetValueByKey = function (array, key, caseSensitive) {
        caseSensitive = caseSensitive || false;
        if (Utilities.IsNotDefined(array)) {
            return undefined;
        }
        var k, keys = Object.keys(array);
        var n = keys.length;
        while (n--) {
            k = keys[n];
            if (!caseSensitive && k.toLowerCase() === key.toLowerCase()) {
                return array[k];
            }
            if (caseSensitive && k === key) {
                return array[k];
            }
        }
        return undefined;
    };
    /**
    * Gets the first property from a json object.
    * @param {any} jsonObject The full JSON object
    * @returns {any}
    */
    Utilities.GetFirstProperty = function (source) {
        var result = source;
        // Convert JSON string to object if necessary
        if (typeof result === "string") {
            result = JSON.parse(result);
        }
        for (var propName in result) {
            if (result.hasOwnProperty(propName)) {
                result = result[propName];
                break;
            }
        }
        return result;
    };
    /**
    Validates the ID based on the ProductSpecIdType
    @param {string} id The ID to validate
    @param {ProductSpecIdType} idType The ProductSpecIdType of the ID
    @returns {boolean}
    */
    Utilities.IsValidId = function (id, idType) {
        if (idType === ProductSpecIdType.Guid) {
            return validator.default.isUUID(id);
        }
        else if (idType === ProductSpecIdType.BusinessId) {
            return validator.default.isAlphanumeric(id) && !validator.default.isUUID(id);
        }
        else {
            return false;
        }
    };
    /**
    * Gets the string representation of an enum key by it's value
    * @param {any} enumeration - The enumeration
    * @param {any} value: The value to convert
    * @returns {string}
    */
    Utilities.GetEnumString = function (enumeration, value) {
        if (Utilities.IsDefined(value)) {
            for (var k in enumeration) {
                if (k === value.toString()) {
                    return enumeration[k];
                }
            }
        }
        return null;
    };
    /**
    * Gets the key for a constants list by it's value
    * @param {any} constantsType - The constants type
    * @param {string} value: The value to convert
    * @returns {string}
    */
    Utilities.GetConstantsKeyByValue = function (constantsType, value) {
        if (Utilities.IsDefined(value)) {
            for (var k in constantsType) {
                if (constantsType[k].toString() === value.toString()) {
                    return k;
                }
            }
        }
        return null;
    };
    /**
    * Gets the currentDate in dd-MM-yyyy format
    * @returns {string}
    */
    Utilities.TodaysDate = function () {
        return Utilities.FormatDate(new Date());
    };
    /**
    * Formats a date in dd-MM-yyyy format
    * @returns {string}
    */
    Utilities.FormatDate = function (date) {
        date = Utilities.EnsureDate(date);
        if (Utilities.IsNotDefined(date)) {
            return null;
        }
        var dd = date.getDate();
        var day = dd < 10 ? "0" + dd.toString() : dd.toString();
        var mm = date.getMonth() + 1;
        var month = mm < 10 ? "0" + mm.toString() : mm.toString();
        var year = date.getFullYear();
        return day + '-' + month + '-' + year;
    };
    /**
    * Formats a date in yyyy-MM-ddTmm:hh:ss:msZ format
    * @returns {string}
    */
    Utilities.FormatDateAsJSON = function (date) {
        date = Utilities.EnsureDate(date);
        if (Utilities.IsNotDefined(date)) {
            return null;
        }
        // Note. this should include Daylight Saving
        return date.toISOString();
    };
    return Utilities;
}());
module.exports = Utilities;

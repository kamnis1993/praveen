"use strict";
/// <reference types="node" />
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class which encapsulates portfolio wide cardinality validation of entities
 */
var PortfolioCardinalityValidator = /** @class */ (function () {
    function PortfolioCardinalityValidator() {
    }
    /**
     * Perform portfolio wide cardinality Validation on the supplied DecomposeContexts
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContexts to validate
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    PortfolioCardinalityValidator.Validate = function (decomposeContexts, errorContext) {
        if (errorContext.HasBreakingErrors) {
            return;
        }
        if (decomposeContexts.length === 0) {
            return;
        }
        PortfolioCardinalityValidator.ValidateDecomposeContexts(decomposeContexts, errorContext);
    };
    /**
     * Perform portfolio Cardinality Validation on a set of DecomposeContexts
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContexts to validate
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    PortfolioCardinalityValidator.ValidateDecomposeContexts = function (decomposeContexts, errorContext) {
        Logger.debug(0, "Validation", "Validating portfolio cardinality");
        decomposeContexts.forEach(function (decomposeContextItem) {
            var portfolioCardinalityLookup = decomposeContextItem.CompiledSpec.CardinalityLookups.EntityIdToPortfolio;
            // Loop through the portfolio cardinality dictionary
            Object.keys(portfolioCardinalityLookup).forEach(function (entityId) {
                var cardinalityData = portfolioCardinalityLookup[entityId];
                var matchingOrderfolioItems = [];
                for (var c = 0; c < decomposeContexts.length; c++) {
                    var decomposeContext = decomposeContexts[c];
                    matchingOrderfolioItems = matchingOrderfolioItems.concat(PortfolioCardinalityValidator.GetMatchingOrderfolioItems(entityId, decomposeContext));
                }
                var totalNumberOfInstances = matchingOrderfolioItems.length;
                if (totalNumberOfInstances < cardinalityData.Min || totalNumberOfInstances > cardinalityData.Max) {
                    // PortfolioCardinalityErrors should be unique per entity
                    var matchingErrors = errorContext.GetValidationErrorsForResponse().filter(function (validationError) {
                        return validationError.EntityID === entityId && validationError.ErrorCode === ErrorCode.Validation.PortfolioCardinalityError.Code;
                    });
                    if (!matchingErrors || matchingErrors.length < 1) {
                        var entityUniqueCode = PortfolioCardinalityValidator.BuildEntityUniqueCode(matchingOrderfolioItems);
                        Logger.debug(1, "Validation", "Portfolio cardinality violation", {
                            EntityId: entityId,
                            EntityUniqueCode: entityUniqueCode,
                            Min: cardinalityData.Min,
                            Max: cardinalityData.Max,
                            ActualNumber: totalNumberOfInstances
                        });
                        errorContext.RaiseValidationError(ErrorCode.Validation.PortfolioCardinalityError, entityUniqueCode, entityId, { Min: cardinalityData.Min, Max: cardinalityData.Max, ActualNumber: totalNumberOfInstances });
                    }
                }
            });
        });
    };
    /**
     * Builds an entity unique code for an array of orderfolio items
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems The array of orderfolio items
     * @returns {string}
     */
    PortfolioCardinalityValidator.BuildEntityUniqueCode = function (orderfolioItems) {
        return LodashUtilities.Pluck(orderfolioItems, "EntityUniqueCode").join();
    };
    /**
     * Gets the number of times the supplied entityId is used in the supplied decomposecontext->Orderfolio
     * @param {string} entityId the entityId to find the number of instances of
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context to search through
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    PortfolioCardinalityValidator.GetMatchingOrderfolioItems = function (entityId, decomposeContext) {
        var matchingOrderfolioItems = [];
        Object.keys(decomposeContext.Orderfolio).forEach(function (orderfolioKey) {
            var orderfolioItems = decomposeContext.Orderfolio[orderfolioKey];
            if (!Utilities.IsDefined(orderfolioItems) || orderfolioItems.length === 0) {
                return;
            }
            if (orderfolioItems[0].EntityId === entityId) {
                for (var c = 0; c < orderfolioItems.length; c++) {
                    var orderfolioItem = orderfolioItems[c];
                    if (orderfolioItem.Action === OrderActions.Delete || orderfolioItem.IsInvalid) {
                        continue;
                    }
                    matchingOrderfolioItems.push(orderfolioItem);
                }
            }
        });
        return matchingOrderfolioItems;
    };
    return PortfolioCardinalityValidator;
}());
module.exports = PortfolioCardinalityValidator;

"use strict";
/// <reference types="node" />
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class which encapsulates validation of IDs within an order request
 */
var OrderIdValidator = /** @class */ (function () {
    function OrderIdValidator() {
    }
    /**
     * Perform Limit Validation on the DecomposeContext set of an order
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    OrderIdValidator.Validate = function (request, errorContext) {
        if (errorContext.HasBreakingErrors) {
            return;
        }
        var idBucket = [];
        // Get the OrderRequestId. Raise an error if it's missing
        if (Utilities.IsNotDefined(request.ID)) {
            errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: 'ID', Item: 'OrderCandidateRequest' });
            return;
        }
        else {
            idBucket.push(request.ID);
        }
        // Get Id's from the Customer Portfolio
        if (Utilities.IsDefined(request.CustomerPortfolio)) {
            this.HarvestPortfolioIds(request.CustomerPortfolio, idBucket);
        }
        // Get Id's from OrderCandidate, OrderItems
        if (Utilities.IsDefined(request.OrderCandidate)) {
            this.HarvestOrderIds(request.OrderCandidate, idBucket, errorContext);
        }
        // Complain about any duplicate Id's
        this.RaiseErrorsForDuplicateIds(idBucket, errorContext, ErrorCode.Validation.DuplicateID);
    };
    /**
     * Gather all the IDs from the portfolio items in a CustomerPortfolio
     * @param {CustomerPortfolio} portfolio the source Customer Portfolio
     * @param {Array<string>} idBucket the bucket into which all harvested IDs should be placed
     */
    OrderIdValidator.HarvestPortfolioIds = function (portfolio, idBucket) {
        var getIds = function (portfolioItems) {
            Utilities.asArray(portfolioItems).forEach(function (portfolioItem) {
                idBucket.push(portfolioItem.ID);
                if (Utilities.IsDefined(portfolioItem.ChildEntities, true)) {
                    getIds(portfolioItem.ChildEntities);
                }
            });
        };
        if (Utilities.IsDefined(portfolio.PortfolioItems, true)) {
            getIds(portfolio.PortfolioItems);
        }
    };
    /**
     * Gather all IDs from the order items in an OrderCandidate
     * Gather the OrderCandidate ID, raise an error if it is missing
     * Gather all referenced portfolio item IDs actioned by the order items and raise errors if any appear more than once
     * @param {OrderCandidate} order the source OrderCandidate
     * @param {Array<string>} idBucket the bucket into which all harvested IDs should be placed
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    OrderIdValidator.HarvestOrderIds = function (order, idBucket, errorContext) {
        if (Utilities.IsNotDefined(order.OrderID)) {
            errorContext.RaiseCsError(400, ErrorCode.Validation.OrderRequestInvalid.MissingProperty, { Property: 'OrderID', Item: 'OrderCandidate' });
            return;
        }
        else {
            idBucket.push(order.OrderID);
        }
        // Used to hold all portfolioId references. Each should only be actioned once
        var portfolioIdRefs = [];
        var getIds = function (orderItems) {
            Utilities.asArray(orderItems).forEach(function (orderItem) {
                idBucket.push(orderItem.ID);
                // Portfolio item ID on an order is optional, because if the order is an add, you don't have to provide one
                // We will generate one later
                // Note. We do not validate duplicate ids for reassign items, See S-10467
                if (Utilities.IsDefined(orderItem.PortfolioItemID, true)) {
                    if (orderItem.ItemAction !== OrderActions.Reassign
                        && orderItem.ItemAction !== OrderActions.Reassigned
                        && orderItem.ItemAction !== OrderActions.ReassignedUpdate) {
                        portfolioIdRefs.push(orderItem.PortfolioItemID);
                    }
                }
                else {
                    if (orderItem.ItemAction === OrderActions.Reassign ||
                        orderItem.ItemAction === OrderActions.Reassigned ||
                        orderItem.ItemAction === OrderActions.ReassignedUpdate) {
                        // If there are any reassign, reassigned or reassignedUpdate without a portfolioItemID then raise severe validation error
                        var message = { Name: "ItemAction", Type: orderItem.ItemAction, Description: "This item is missing PortfolioItemID" };
                        errorContext.RaiseSevereValidationError(ErrorCode.Validation.ReassignItemMissingPortfolioItemId, orderItem.ID, orderItem.EntityID, message);
                    }
                }
                if (Utilities.IsDefined(orderItem.ChildOrderItems, true)) {
                    getIds(orderItem.ChildOrderItems);
                }
            });
        };
        if (Utilities.IsDefined(order.OrderItems, true)) {
            getIds(order.OrderItems);
        }
        // Raise errors for portfolio item IDs which are referenced by more than one Order Item
        if (Utilities.IsDefined(portfolioIdRefs, true)) {
            // Raise duplicate PortfolioItemId error between non-reassign and reassigned items
            this.RaiseErrorsForDuplicateIds(portfolioIdRefs, errorContext, ErrorCode.Validation.DuplicatePortfolioItemID);
        }
    };
    /**
     * Check a bucket load of ID's, and raise a validation error for any that appear more than once.
     * The Validation error code defaults to DuplicateID
     * @param {Array<string>} idBucket the bucket of ID's to check for uniqueness
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     * @param {string} [errorCode] Default: DuplicateID, the errorCode to set on the validation error
     */
    OrderIdValidator.RaiseErrorsForDuplicateIds = function (idBucket, errorContext, errorDescriptor) {
        var duplicates = Utilities.DuplicatesInStringArray(idBucket);
        if (Utilities.IsNotDefined(duplicates, true)) {
            return;
        }
        duplicates.forEach(function (duplicateId) {
            Logger.debug(0, "Validation", "Duplicate IDs", { duplicateId: duplicateId });
            errorContext.RaiseValidationError(errorDescriptor, duplicateId, null);
        });
    };
    return OrderIdValidator;
}());
module.exports = OrderIdValidator;

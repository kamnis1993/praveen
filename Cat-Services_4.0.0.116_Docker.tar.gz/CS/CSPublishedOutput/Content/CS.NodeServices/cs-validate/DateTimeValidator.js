"use strict";
/**
 * Contains methods for validating dates and times
 */
var DateTimeValidator = /** @class */ (function () {
    function DateTimeValidator() {
    }
    /**
    * Validates that a value matches the date format defined as "YYYY-MM-DD" or "YYYYMMDD"
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DateTimeValidator.IsValidUdcDate = function (value) {
        // Check that the value is in the format 1111-11-11 or 11111111
        // Also checking here that the month is between 01 and 12 and the day is between 01 and 31
        var regEx = new RegExp("^\\d{4}(-?)((0[1-9])|(1[0-2]))((-?)((0[1-9])|([1-2]\\d)|(3[0-1])))$", "g");
        var isValidFormat = regEx.test(value);
        if (!isValidFormat) {
            return false;
        }
        // Split the value into date parts
        value = value.split("-").join("");
        var year = Number(value.substring(0, 4));
        var month = Number(value.substring(4, 6));
        var day = Number(value.substring(6, 8));
        // 30 days have September, etc.
        if (DateTimeValidator.Is30DayMonth(month) && (day > 30)) {
            return false;
        }
        // Oh February!
        if (month === 2) {
            if (day >= 30) {
                return false;
            }
            if (day === 29 && !DateTimeValidator.IsLeapYear(year)) {
                return false;
            }
        }
        return true;
    };
    /**
    * Validates that a value matches the time format defined as "hh:mm:ss", "hh:mm", "hhmmss" or "hhmm"
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DateTimeValidator.IsValidUdcTime = function (value) {
        // Check that the value is in the format 11:11:11, 11:11, 111111 or 1111
        // Also checking here that the hour is between 00 and 23 and the minutes and seconds is between 00 and 59
        var regEx = new RegExp("^(([0-1][0-9])|(2[0-3]))(:?)([0-5][0-9])(:?)(([0-5][0-9])?)$", "g");
        var isValidFormat = regEx.test(value);
        return isValidFormat;
    };
    /**
    * Validates that a value matches the datetime format defined as <date>T<time> and is a valid date and time
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DateTimeValidator.IsValidUdcDateTime = function (value) {
        // Check that the value is in the basic datetime format e.g. 9999-99-99T99:99:99
        var regEx = new RegExp("^((\\d{8})|(\\d|[-]){10})([T])((\\d{4})|(\\d{6})|((\\d|[:]){5})|((\\d|[:]){8}))$", "g");
        var isValidFormat = regEx.test(value);
        if (!isValidFormat) {
            return false;
        }
        // Check the individual date and time formats
        var date = value.split("T")[0];
        var time = value.split("T")[1];
        return DateTimeValidator.IsValidUdcDate(date)
            && DateTimeValidator.IsValidUdcTime(time);
    };
    /**
    * Determines if an integer represents a month that has 30 days.
    * @param {number} month
    * @return {boolean}
    */
    DateTimeValidator.Is30DayMonth = function (month) {
        return [4, 6, 9, 11].indexOf(month) > -1;
    };
    /**
    * Determines if an integer represents a leap year.
    * Based on the leap year algorithm.
    * @param {number} year
    * @return {boolean}
    */
    DateTimeValidator.IsLeapYear = function (year) {
        return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
    };
    return DateTimeValidator;
}());
module.exports = DateTimeValidator;

"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var DateTimeValidator = require("../DateTimeValidator");
describe('DateTimeValidator', function () {
    describe('IsValidUdcDate()', function () {
        it('should return true for dates in the following formats YYYY-MM-DD and YYYYMMDD', function (done) {
            var validDates = [
                "1900-08-04",
                "19700804",
                "2016-01-01",
                "20160101",
                "2016-02-28",
                "20160228",
                "2017-04-30",
                "20170430",
                "2025-12-31",
                "20251231"
            ];
            validDates.forEach(function (date) {
                chai.expect(DateTimeValidator.IsValidUdcDate(date), "Failed to validate: " + date).to.be.true;
            });
            done();
        });
        it('should return false for invalid dates', function (done) {
            var inValidDates = [
                "AAAA",
                "1900",
                "1900-05",
                "190005",
                "1900-AA-AA",
                "1900-01-AA",
                "AAAA-01-01",
                "2016:08:08",
                "2016/08/08",
                "1900-05-001"
            ];
            inValidDates.forEach(function (date) {
                chai.expect(DateTimeValidator.IsValidUdcDate(date), "Failed to validate: " + date).to.be.false;
            });
            done();
        });
        it('should return false for invalid specific dates', function (done) {
            var inValidDates = [
                "19000001",
                "19001301",
                "1900-00-01",
                "1900-01-00",
                "1900-13-12",
                "1900-01-32",
                "1900-12-32",
                "1900-02-30",
                "1900-04-31",
                "1900-06-31",
                "1900-09-31",
                "1900-11-31"
            ];
            inValidDates.forEach(function (date) {
                chai.expect(DateTimeValidator.IsValidUdcDate(date), "Failed to validate: " + date).to.be.false;
            });
            done();
        });
        it('should correctly handle leap years', function (done) {
            var validLeapYearDates = [
                "1904-02-29",
                "1980-02-29",
                "20200229",
                "20280229",
                "21040229"
            ];
            validLeapYearDates.forEach(function (date) {
                chai.expect(DateTimeValidator.IsValidUdcDate(date), "Failed to validate: " + date).to.be.true;
            });
            // Note that 1900 and 2100 are not leap years!
            var inValidLeapYearDates = [
                "1900-02-29",
                "1901-02-29",
                "1983-02-29",
                "20250229",
                "21000229"
            ];
            inValidLeapYearDates.forEach(function (date) {
                chai.expect(DateTimeValidator.IsValidUdcDate(date), "Failed to validate: " + date).to.be.false;
            });
            done();
        });
    });
    describe('IsValidUdcTime()', function () {
        it('should return true for times in the following formats hh:mm:ss, hh:mm, hhmmss and hhmm', function (done) {
            var validTimes = [
                "00:00:00",
                "00:00",
                "000000",
                "0000",
                "09:09:09",
                "09:09",
                "090909",
                "0909",
                "12:34:56",
                "12:34",
                "123456",
                "1234",
                "23:59:59",
                "23:59",
                "235959",
                "2359"
            ];
            validTimes.forEach(function (time) {
                chai.expect(DateTimeValidator.IsValidUdcTime(time), "Failed to validate: " + time).to.be.true;
            });
            done();
        });
        it('should return false for invalid times', function (done) {
            var invalidTimes = [
                "AAAAAA",
                "11:AA:AA",
                "11AA",
                "11:11:AA",
                "111",
                "11111",
                "1111111",
                "11:1",
                "11:11:1",
                "11:111",
                "11:11:111",
                "10:60",
                "10:61:00",
                "10:59:60",
                "1099",
                "105999",
                "24:00",
                "2459",
                "245901",
                "23:59:99"
            ];
            invalidTimes.forEach(function (time) {
                chai.expect(DateTimeValidator.IsValidUdcTime(time), "Failed to validate: " + time).to.be.false;
            });
            done();
        });
    });
    describe('IsValidUdcDateTime()', function () {
        it('should return true for datetimes in the format <date>T<Time>', function (done) {
            var validDateTimes = [
                "1111-11-11T00:00:00",
                "2016-02-29T23:59:59",
                "20201130T2359",
                "19701231T000059"
            ];
            validDateTimes.forEach(function (datetime) {
                chai.expect(DateTimeValidator.IsValidUdcDateTime(datetime), "Failed to validate: " + datetime).to.be.true;
            });
            done();
        });
        it('should return false for invalid datetimes', function (done) {
            var validDateTimes = [
                "1111-11-11 00:00:00",
                "2016-02-31T23:59:59",
                "20201130T2362",
                "19701231000059"
            ];
            validDateTimes.forEach(function (datetime) {
                chai.expect(DateTimeValidator.IsValidUdcDateTime(datetime), "Failed to validate: " + datetime).to.be.false;
            });
            done();
        });
    });
});

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var OrderIdValidator = require("../OrderIdValidator");
var Fakei18n = /** @class */ (function () {
    function Fakei18n() {
    }
    Fakei18n.prototype.translate = function (messageCode) {
        return 'Translated: ' + messageCode;
    };
    return Fakei18n;
}());
describe("OrderId Validator", function () {
    it("Should not raise a validation error if there are no duplicate order or portfolio IDs", function (done) {
        var errorContext = new CsErrorContext({});
        var request = GetOrderRequest("OrderIDValidatorNoDuplicates.json");
        OrderIdValidator.Validate(request, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0);
        done();
    });
    it("Should not raise a validation error if a reassign item and a reassigned item share the same portfolio ID", function (done) {
        var errorContext = new CsErrorContext({});
        var request = GetOrderRequest("OrderIDValidatorNoDuplicates.json");
        OrderIdValidator.Validate(request, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0);
        done();
    });
    it("Should raise a validation error if a reassign item, a reassigned item  or reassignedUpdate item doesn't have portfolioItem ID", function (done) {
        var errorContext = new CsErrorContext({});
        var request = GetOrderRequest("ReassignMissingPortfolioItemIDs.json");
        OrderIdValidator.Validate(request, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(3);
        chai.expect(validationErrors[0].ErrorCode).to.equal("ReassignItemMissingPortfolioItemId");
        chai.expect(validationErrors[0].EntityID).to.equal("e");
        MatchContextParameterValue(validationErrors[0], "Type", "reassigned");
        chai.expect(validationErrors[1].ErrorCode).to.equal("ReassignItemMissingPortfolioItemId");
        chai.expect(validationErrors[1].EntityID).to.equal("f");
        MatchContextParameterValue(validationErrors[1], "Type", "reassign");
        chai.expect(validationErrors[2].ErrorCode).to.equal("ReassignItemMissingPortfolioItemId");
        chai.expect(validationErrors[2].EntityID).to.equal("g");
        MatchContextParameterValue(validationErrors[2], "Type", "reassignedupdate");
        done();
    });
    it("Should raise a MissingProperty Process Error when a OrderCandidateRequest exists without a request ID", function (done) {
        var errorContext = new CsErrorContext({});
        var request = GetOrderRequest("OrderIDValidatorMissingRequestID.json");
        OrderIdValidator.Validate(request, errorContext);
        var processError = errorContext.ProcessError;
        chai.expect(processError.message).to.equal('The property must be specified: { Property: ID, Item: OrderCandidateRequest}');
        chai.expect(processError.substitutions.Property).to.equal('ID');
        chai.expect(processError.substitutions.Item).to.equal('OrderCandidateRequest');
        done();
    });
    it("Should raise a MissingProperty Process Error when a OrderCandidate exists without an order ID", function (done) {
        var errorContext = new CsErrorContext({});
        var request = GetOrderRequest("OrderIDValidatorMissingOrderID.json");
        OrderIdValidator.Validate(request, errorContext);
        var processError = errorContext.ProcessError;
        chai.expect(processError.message).to.equal('The property must be specified: { Property: OrderID, Item: OrderCandidate}');
        chai.expect(processError.substitutions.Property).to.equal('OrderID');
        chai.expect(processError.substitutions.Item).to.equal('OrderCandidate');
        done();
    });
    /**
    it("Should raise a DuplicateID error if a request contains duplicate order IDs", function (done: any): void
    {
        let errorContext: CsErrorContext = new CsErrorContext({});
        let request = GetOrderRequest("OrderIDValidatorDuplicateOrderIDs.json");
        OrderIdValidator.Validate(request, errorContext);

        let validationErrors = errorContext.GetValidationErrorsForResponse();

        chai.expect(validationErrors.length).to.equal(4);

        // OrderCandidateRequest and OrderCandidate has same ID
        chai.expect(validationErrors[0].ErrorCode).to.equal('DuplicateID');
        chai.expect(validationErrors[0].EntityUniqueCode).to.equal('ID_1');

        // Portfolioitems b and child_b has same ID
        chai.expect(validationErrors[1].ErrorCode).to.equal('DuplicateID');
        chai.expect(validationErrors[1].EntityUniqueCode).to.equal('pi_b');

        chai.expect(validationErrors[2].ErrorCode).to.equal('DuplicateID');
        chai.expect(validationErrors[2].EntityUniqueCode).to.equal('B');

        // Even though Reassign and Reassigned share same PortfolioItemID but should have Unique ID
        chai.expect(validationErrors[3].ErrorCode).to.equal('DuplicateID');
        chai.expect(validationErrors[3].EntityUniqueCode).to.equal('C');

        done();
    });

    it("Should raise a DuplicatePortfolioItemID error if a request contains duplicate portfolio IDs", function (done: any): void
    {
        let errorContext: CsErrorContext = new CsErrorContext({});
        let request = GetOrderRequest("OrderIDValidatorDuplicatePortfolioItemIDs.json");
        OrderIdValidator.Validate(request, errorContext);

        let validationErrors = errorContext.GetValidationErrorsForResponse();

        chai.expect(validationErrors.length).to.equal(1);

        // NOTE. This test also asserts that no duplicatedPortfolioItems for reassigned Items are raised.
        // This validation is handled by ReassignCandidateHydrator and ItemPairBuilder

        // DuplicatePortfolioItemID error for reassign and update/add items
        chai.expect(validationErrors[0].ErrorCode).to.equal('DuplicatePortfolioItemID');
        chai.expect(validationErrors[0].EntityUniqueCode).to.equal('pi_a');

        done();
    }); */
});
function GetOrderRequest(fileName) {
    var readInFile = fs.readFileSync('cs-validate/test/data/' + fileName, { encoding: 'utf8' });
    return JSON.parse(readInFile.toString());
}
function MatchContextParameterValue(validationError, name, value) {
    validationError.ContextParameters.forEach(function (parameter) {
        if (parameter.Name === name) {
            chai.expect(parameter.Value === value).to.be.true;
            return;
        }
    });
}

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var ReassignValidator = require("../ReassignValidator");
var Utilities = require("../../cs-lib-utilities/Utilities");
var Fakei18n = /** @class */ (function () {
    function Fakei18n() {
    }
    Fakei18n.prototype.translate = function (messageCode) {
        return 'Translated: ' + messageCode;
    };
    return Fakei18n;
}());
describe("Reassign Validator", function () {
    it("should not raise a validation errors when reassigned pairs match", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMatchingReassigned.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'reassign errors found');
        done();
    });
    it("should not raise a validation errors when reassignedUpdate pairs match", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMatchingReassignedUpdate.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'reassign errors found');
        done();
    });
    it("should not raise a validation errors when all pairs match", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMultipleMatching.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'reassign errors found');
        done();
    });
    it("should not raise a validation errors when reassign/delete pairs match", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMatchingReassignDelete.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'reassign errors found');
        done();
    });
    it("should not raise a validation errors when missing/delete pairs are found", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMatchingMissingDelete.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'reassign errors found');
        done();
    });
    it("should raise a validation error for a missing reassign item", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMissingReassign.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(1, 'no reassign errors found');
        chai.expect(validationErrors[0].ErrorCode).to.equal("MissingReassignItem");
        chai.expect(validationErrors[0].EntityID).to.equal("c");
        done();
    });
    it("should raise a validation error for a missing reassigned item", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMissingReassigned.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(1, 'no reassign errors found');
        chai.expect(validationErrors[0].ErrorCode).to.equal("MissingReassignedItem");
        chai.expect(validationErrors[0].EntityID).to.equal("c");
        done();
    });
    it("should raise a validation error for multiple mismatched, even when there are multiple matches with the same entityId", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMultipleMissingItems.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(2, 'no reassign errors found');
        chai.expect(validationErrors[0].ErrorCode).to.equal("MissingReassignItem");
        chai.expect(validationErrors[0].EntityID).to.equal("c");
        chai.expect(validationErrors[1].ErrorCode).to.equal("MissingReassignItem");
        chai.expect(validationErrors[1].EntityID).to.equal("e");
        done();
    });
    it("should raise a validation error for mismatched pairs across multiple decompose contexts", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContexts = GetDecomposeContextFromFile("ReassignValidatorMultipleDecomposeContexts.json");
        ReassignValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(2, 'no reassign errors found');
        chai.expect(validationErrors[0].ErrorCode).to.equal("MissingReassignItem");
        chai.expect(validationErrors[0].EntityID).to.equal("r");
        chai.expect(validationErrors[1].ErrorCode).to.equal("MissingReassignItem");
        chai.expect(validationErrors[1].EntityID).to.equal("y");
        done();
    });
});
function GetDecomposeContextFromFile(fileName) {
    var decomposeContextsFileContents = fs.readFileSync('cs-validate/test/data/' + fileName, { encoding: 'utf8' });
    return Utilities.asArray(JSON.parse(decomposeContextsFileContents.toString()));
}

"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
var EntityCardinalityValidator = require("../EntityCardinalityValidator");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../../cs-lib-utilities/LodashUtilities");
var Utilities = require("../../cs-lib-utilities/Utilities");
var Fakei18n = /** @class */ (function () {
    function Fakei18n() {
    }
    Fakei18n.prototype.translate = function (messageCode) {
        return 'Translated: ' + messageCode;
    };
    return Fakei18n;
}());
describe("When checking the entity cardinality and the cardinalities are within limits", function () {
    it("There should be no validation errors in in the error context", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContextsFileContents = fs.readFileSync('cs-validate/test/data/EntityCardinalityValidatorAllCorrect.json', { encoding: 'utf8' });
        var decomposeContexts = Utilities.asArray(JSON.parse(decomposeContextsFileContents.toString()));
        EntityCardinalityValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        chai.expect(validationErrors.length).to.equal(0, 'cardinality errors found');
        done();
    });
});
describe("When checking the entity cardinality and the minimum is not met ", function () {
    it("Should output a 'RelationCardinalityNotSatisfied' validation error in the error context", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContextsFileContents = fs.readFileSync('cs-validate/test/data/EntityCardinalityValidatorMinimum.json', { encoding: 'utf8' });
        var decomposeContexts = Utilities.asArray(JSON.parse(decomposeContextsFileContents.toString()));
        EntityCardinalityValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        var matchError = {};
        matchError.ErrorCode = ErrorCode.Validation.RelationCardinalityNotSatisfied.Code.split(".")[1];
        chai.expect(ErrorExistsMatching(validationErrors, matchError)).to.be.equal(true, 'minimum number of child entities not met');
        done();
    });
});
describe("When checking the entity cardinality and the maximum is exceeded", function () {
    it("Should output a 'RelationCardinalityNotSatisfied' validation error in the error context", function (done) {
        var errorContext = new CsErrorContext({});
        var decomposeContextsFileContents = fs.readFileSync('cs-validate/test/data/EntityCardinalityValidatorMaximum.json', { encoding: 'utf8' });
        var decomposeContexts = Utilities.asArray(JSON.parse(decomposeContextsFileContents.toString()));
        EntityCardinalityValidator.Validate(decomposeContexts, errorContext);
        var validationErrors = errorContext.GetValidationErrorsForResponse();
        var matchError = {};
        matchError.ErrorCode = ErrorCode.Validation.RelationCardinalityNotSatisfied.Code.split(".")[1];
        chai.expect(ErrorExistsMatching(validationErrors, matchError)).to.be.equal(true, 'maximum number of child entities not met');
        done();
    });
});
/**
 * Check if a ValidationErrors array an error which matches the properties specified in matchError
 * @param {any} matchError a literal object containing the properties to match
 * @returns {boolean} True if a match is found
 */
function ErrorExistsMatching(validationErrors, matchError) {
    return LodashUtilities.Some(validationErrors, matchError);
}

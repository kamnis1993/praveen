"use strict";
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var CharValueValidator = require("../CharValueValidator");
var fs = require("fs");
var chai = require("chai");
var ErrorCode = require("../../cs-lib-constants/ErrorCodes/ErrorCodes");
var MockErrorContext = /** @class */ (function () {
    function MockErrorContext() {
        this.ValidationErrors = [];
    }
    MockErrorContext.prototype.RaiseValidationErrorWithChildInfo = function (translationKey, entityUniqueCode, entityId, childUniqueCode, childId, messageParameters, extraInfo, xsiType, isSevere, phaseCodes) {
        this.ValidationErrors.push({ ErrorCode: translationKey, EntityUniqueCode: entityUniqueCode, EntityId: entityId, PhaseCodes: phaseCodes });
    };
    return MockErrorContext;
}());
describe("when asking the Value Cardinality Validator to validate a decompose context with all cardinalities satisfied", function () {
    it("should not push any errors into the error context", function (done) {
        fs.readFile('cs-validate/test/data/ValueCardinalitySatisfied.json', { encoding: 'utf8' }, function (error, fileContents) {
            var decomposeContext = JSON.parse(fileContents);
            var errorContext = new MockErrorContext();
            CharValueValidator.ValidateCardinality("0", decomposeContext, errorContext);
            CharValueValidator.ValidateCardinality("1", decomposeContext, errorContext);
            chai.expect(errorContext.ValidationErrors.length).to.equal(0);
            done();
        });
    });
});
describe("when asking the Value Cardinality Validator to validate a decompose context where all value cardinalities are not satisfied", function () {
    it("should push validation errors into the error context", function (done) {
        fs.readFile('cs-validate/test/data/ValueCardinalityNotSatisfied.json', { encoding: 'utf8' }, function (error, fileContents) {
            var decomposeContext = JSON.parse(fileContents);
            var errorContext = new MockErrorContext();
            errorContext.ValidationErrors = [];
            CharValueValidator.ValidateCardinality("0", decomposeContext, errorContext);
            CharValueValidator.ValidateCardinality("1", decomposeContext, errorContext);
            chai.expect(errorContext.ValidationErrors.length).to.equal(2);
            chai.expect(errorContext.ValidationErrors[0].EntityId).to.equal('x');
            chai.expect(errorContext.ValidationErrors[0].EntityUniqueCode).to.equal('oi_x');
            chai.expect(errorContext.ValidationErrors[0].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].EntityId).to.equal('y');
            chai.expect(errorContext.ValidationErrors[1].EntityUniqueCode).to.equal('pi_y');
            chai.expect(errorContext.ValidationErrors[1].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            done();
        });
    });
});
describe("when asking the Value Cardinality Validator to validate a decompose context with commericial boundary where all value cardinalities are not satisfied with Phase codes", function () {
    it("should push validation errors into the error context with commercial phase codes only", function (done) {
        fs.readFile('cs-validate/test/data/CommericialBoundary_ValueCardinalityNotSatisfiedWithPhaseCodes.json', { encoding: 'utf8' }, function (error, fileContents) {
            var decomposeContext = JSON.parse(fileContents);
            var errorContext = new MockErrorContext();
            errorContext.ValidationErrors = [];
            CharValueValidator.ValidateCardinality("0", decomposeContext, errorContext);
            CharValueValidator.ValidateCardinality("1", decomposeContext, errorContext);
            chai.expect(errorContext.ValidationErrors.length).to.equal(2);
            chai.expect(errorContext.ValidationErrors[0].EntityId).to.equal('x');
            chai.expect(errorContext.ValidationErrors[0].EntityUniqueCode).to.equal('oi_x');
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes.Commercial[0]).to.equal('QuoteCode');
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes.Technical).is.undefined;
            chai.expect(errorContext.ValidationErrors[0].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].EntityId).to.equal('y');
            chai.expect(errorContext.ValidationErrors[1].EntityUniqueCode).to.equal('pi_y');
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes.Commercial[0]).to.equal('QuoteCode');
            chai.expect(errorContext.ValidationErrors[1].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes.Technical).is.undefined;
            done();
        });
    });
});
describe("when asking the Value Cardinality Validator to validate a decompose context with Technical boundary where all value cardinalities are not satisfied with Phase codes", function () {
    it("should push validation errors into the error context with commercial and technical phase codes", function (done) {
        fs.readFile('cs-validate/test/data/TechnicalBoundary_ValueCardinalityNotSatisfiedWithPhaseCodes.json', { encoding: 'utf8' }, function (error, fileContents) {
            var decomposeContext = JSON.parse(fileContents);
            var errorContext = new MockErrorContext();
            errorContext.ValidationErrors = [];
            CharValueValidator.ValidateCardinality("0", decomposeContext, errorContext);
            CharValueValidator.ValidateCardinality("1", decomposeContext, errorContext);
            chai.expect(errorContext.ValidationErrors.length).to.equal(2);
            chai.expect(errorContext.ValidationErrors[0].EntityId).to.equal('x');
            chai.expect(errorContext.ValidationErrors[0].EntityUniqueCode).to.equal('oi_x');
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes.Commercial[0]).to.equal('QuoteCode');
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes.Technical[0]).to.equal('AcceptanceCode');
            chai.expect(errorContext.ValidationErrors[0].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].EntityId).to.equal('y');
            chai.expect(errorContext.ValidationErrors[1].EntityUniqueCode).to.equal('pi_y');
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes.Commercial[0]).to.equal('QuoteCode');
            chai.expect(errorContext.ValidationErrors[1].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes.Technical[0]).to.equal('AcceptanceCode');
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes.Technical[1]).to.equal('CompletionCode');
            done();
        });
    });
});
describe("when asking the Value Cardinality Validator to validate a decompose context where Max value cardinalities are not satisfied with Phase codes", function () {
    it("should push validation errors into the error context with no phase codes", function (done) {
        fs.readFile('cs-validate/test/data/MaxValueCardinalityNotSatisfiedWithPhaseCodes.json', { encoding: 'utf8' }, function (error, fileContents) {
            var decomposeContext = JSON.parse(fileContents);
            var errorContext = new MockErrorContext();
            //Boundary conditions doesnt matter.When maximum cardinality is not satisfied, phase codes are not included in Validation error
            errorContext.ValidationErrors = [];
            CharValueValidator.ValidateCardinality("0", decomposeContext, errorContext);
            CharValueValidator.ValidateCardinality("1", decomposeContext, errorContext);
            chai.expect(errorContext.ValidationErrors.length).to.equal(2);
            chai.expect(errorContext.ValidationErrors[0].EntityId).to.equal('x');
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes).is.undefined;
            chai.expect(errorContext.ValidationErrors[0].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[0].PhaseCodes).is.undefined;
            chai.expect(errorContext.ValidationErrors[1].EntityId).to.equal('y');
            chai.expect(errorContext.ValidationErrors[1].ErrorCode).to.equal(ErrorCode.Validation.CharacteristicOutOfRange);
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes).is.undefined;
            chai.expect(errorContext.ValidationErrors[1].PhaseCodes).is.undefined;
            done();
        });
    });
});

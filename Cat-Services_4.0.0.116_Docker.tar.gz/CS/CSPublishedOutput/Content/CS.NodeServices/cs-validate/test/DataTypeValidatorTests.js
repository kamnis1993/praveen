"use strict";
/// <reference types="node" />
/// <reference types="mocha" />
/// <reference types="chai" />
Object.defineProperty(exports, "__esModule", { value: true });
var chai = require("chai");
var DataTypeValidator = require("../DataTypeValidator");
describe('DataTypeValidator', function () {
    describe('IsValidString()', function () {
        it('should return true for valid string values', function (done) {
            var validValues = [
                "",
                "AAAA",
                "Aaaa",
                "20",
                "20.1",
                0,
                99.34,
                false
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidString(testValue), "Failed to validate: " + testValue).to.be.true;
            });
            done();
        });
        it('should return true for valid string values', function (done) {
            var validValues = [
                undefined,
                null
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidString(testValue), "Failed to validate: " + testValue).to.be.false;
            });
            done();
        });
    });
    describe('IsValidBoolean()', function () {
        it('should return true for valid boolean values', function (done) {
            var validValues = [
                true,
                "TRUE",
                "True",
                "true",
                false,
                "FALSE",
                "False",
                "false"
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidBoolean(testValue), "Failed to validate: " + testValue).to.be.true;
            });
            done();
        });
        it('should return false for invalid boolean values', function (done) {
            var invalidValues = [
                "Hello",
                5,
                10.34,
                undefined,
                null,
                1,
                -1,
                0,
                "1",
                "-1",
                "0",
                "yes",
                "no"
            ];
            invalidValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidBoolean(testValue), "Failed to validate: " + testValue).to.be.false;
            });
            done();
        });
    });
    describe('IsValidInteger()', function () {
        it('should return true for valid integer values', function (done) {
            var validValues = [
                -55,
                0,
                1,
                32567,
                "1",
                "0",
                "32567",
                1.0,
                "-1.0"
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidInteger(testValue), "Failed to validate: " + testValue).to.be.true;
            });
            done();
        });
        it('should return false for invalid integer values', function (done) {
            var invalidValues = [
                undefined,
                null,
                "Hello",
                true,
                10.34,
                "10.34",
                "-1.00002",
                -1.2345
            ];
            invalidValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidInteger(testValue), "Failed to validate: " + testValue).to.be.false;
            });
            done();
        });
    });
    describe('IsValidDecimal()', function () {
        it('should return true for valid decimal values', function (done) {
            var validValues = [
                55.01,
                0.2,
                -1.9,
                32567.2345,
                "1.3",
                "0.2",
                "32567.9876",
                "-1.0",
                10,
                1.0
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidDecimal(testValue), "Failed to validate: " + testValue).to.be.true;
            });
            done();
        });
        it('should return false for invalid decimal values', function (done) {
            var invalidValues = [
                undefined,
                null,
                "Hello",
                true
            ];
            invalidValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidDecimal(testValue), "Failed to validate: " + testValue).to.be.false;
            });
            done();
        });
    });
    describe('IsValidUri()', function () {
        it('should return true for valid URI values', function (done) {
            var validValues = [
                "http://localhost/",
                "http://example.w3.org/path%20with%20spaces.html",
                "http://example.w3.org/%20",
                "ftp://ftp.is.co.za/rfc/rfc1808.txt",
                "ftp://ftp.is.co.za/../../../rfc/rfc1808.txt",
                "http://www.ietf.org/rfc/rfc2396.txt",
                "ldap://[2001:db8::7]/c=GB?objectClass?one",
                "mailto:John.Doe@example.com",
                "news:comp.infosystems.www.servers.unix",
                "tel:+1-816-555-1212",
                "telnet://192.0.2.16:80/",
                "urn:oasis:names:specification:docbook:dtd:xml:4.1.2"
            ];
            validValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidUri(testValue), "Failed to validate: " + testValue).to.be.true;
            });
            done();
        });
        it('should return false for invalid URI values', function (done) {
            var invalidValues = [
                "",
                "foo",
                "foo@bar",
                "http://<foo>",
                "://bob/",
                "1http://bob",
                "1http:////foo.html",
                "http://example.w3.org/%illegal.html",
                "http://example.w3.org/%a",
                "http://example.w3.org/%a/foo",
                "http://example.w3.org/%at",
                1,
                10.34,
                undefined,
                null,
                true
            ];
            invalidValues.forEach(function (testValue) {
                chai.expect(DataTypeValidator.IsValidUri(testValue), "Failed to validate: " + testValue).to.be.false;
            });
            done();
        });
    });
});

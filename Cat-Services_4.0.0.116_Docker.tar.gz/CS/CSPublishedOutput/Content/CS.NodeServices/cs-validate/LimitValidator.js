"use strict";
/// <reference types="node" />
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * A class which encapsulates validation of entity and relation limits for an order
 */
var LimitValidator = /** @class */ (function () {
    function LimitValidator() {
    }
    /**
     * Perform Limit Validation on the DecomposeContext set of an order
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    LimitValidator.Validate = function (decomposeContexts, errorContext) {
        var _this = this;
        if (errorContext.HasBreakingErrors) {
            return;
        }
        Logger.debug(0, "Validation", "Validating Limits");
        var limits = [];
        if (LimitValidator.HasLimits(decomposeContexts)) {
            limits = decomposeContexts[0].ContextData.Limits;
        }
        var uniqueEntities = this.ExtractUniqueEntityLimitItems(decomposeContexts);
        if (Utilities.IsNotDefined(uniqueEntities, true)) {
            return;
        }
        uniqueEntities.forEach(function (entityLimitItem) {
            if (entityLimitItem.IsInvalid) {
                Logger.debug(1, "Validation", "Skipping as limit item is marked as invalid", {
                    EntityLimitItem: entityLimitItem.EntityId
                });
                return;
            }
            _this.ValidateEntityLimitsForEntity(entityLimitItem, limits, errorContext);
            _this.ValidateRelationLimitsForEntity(entityLimitItem, limits, uniqueEntities, errorContext);
        });
    };
    /**
     * Validate entity limits against the contextual parameters in the Customer Portfolio
     * @param {ILimitItem} entity the LimitItem to perform Relation limit checks against
     * @param {Array<string>} contextualParams the Contextual Parameters from the Customer Portfolio
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    LimitValidator.ValidateEntityLimitsForEntity = function (entity, limits, errorContext) {
        // If no limits defined, then nothing to do
        if (Utilities.IsNotDefined(entity.EntityLimits, true)) {
            return;
        }
        var entityLimitGroups = LodashUtilities.GroupByCallback(entity.EntityLimits, function (entityLimit) {
            return entityLimit.LimitName;
        });
        Object.keys(entityLimitGroups).forEach(function (groupKey) {
            var entityLimits = entityLimitGroups[groupKey];
            var found = limits.some(function (limit) {
                return entityLimits.some(function (entityLimit) { return entityLimit.LimitID === limit.toLowerCase(); });
            });
            if (!found) {
                var limitName = entityLimits[0].LimitName;
                var limitType = entityLimits[0].LimitType;
                var extraInfo = 'Entity "' + entity.EntityId + '" is not valid for limit ' + limitName;
                errorContext.RaiseValidationError(ErrorCode.Validation.LimitNotSatisfied, entity.OrderfolioID, entity.EntityId, null, extraInfo, limitType);
                Logger.debug(1, "Validation", "Entity Limit Error", { info: extraInfo });
            }
            Logger.debug(1, "Validation", "Entity valid for limit", {
                EntityId: entity.EntityId,
                LimitName: limitName,
                LimitType: limitType
            });
        });
    };
    /**
     * Validate relation limits against the contextual parameters in the Customer Portfolio
     * @param {ILimitItem} entity the LimitItem to perform Relation limit checks against
     * @param {Array<string>} limits the Contextual Parameters from the Customer Portfolio
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    LimitValidator.ValidateRelationLimitsForEntity = function (entity, limits, candidateEntities, errorContext) {
        // If no limits defined, then nothing to do
        if (Utilities.IsNotDefined(entity.RelationLimits, true)) {
            return;
        }
        entity.RelationLimits.forEach(function (relationLimit) {
            // If no limits defined, then nothing to do
            if (Utilities.IsNotDefined(relationLimit.Limits)) {
                return;
            }
            // Child should exist in OrderCandidate unique items and be date valid
            var childExistsInCandidate = candidateEntities.some(function (limitItem) {
                var isMatch = relationLimit.ChildEntityId === limitItem.EntityId;
                return isMatch && !limitItem.IsInvalid;
            });
            if (!childExistsInCandidate) {
                return;
            }
            var relationLimitGroups = LodashUtilities.GroupByCallback(relationLimit.Limits, function (relationLimit) {
                return relationLimit.LimitName;
            });
            Object.keys(relationLimitGroups).forEach(function (groupKey) {
                var relationLimits = relationLimitGroups[groupKey];
                var found = limits.some(function (limit) {
                    return relationLimit.Limits.some(function (relationEntityLimit) { return relationEntityLimit.LimitID === limit.toLowerCase(); });
                });
                if (!found) {
                    var limitName = relationLimits[0].LimitName;
                    var limitType = relationLimits[0].LimitType;
                    var extraInfo = 'Entity "' + entity.EntityId + '" is not valid for limit ' + limitName + " on Relation for Parent" + entity.EntityId + " to child " + relationLimit.ChildEntityId;
                    errorContext.RaiseValidationError(ErrorCode.Validation.LimitNotSatisfied, entity.OrderfolioID, entity.EntityId, null, extraInfo, limitType);
                    Logger.debug(1, "Validation", "Relation Limit Error", { Info: extraInfo });
                }
                Logger.debug(1, "Validation", "Relation valid for limits", {
                    ParentId: entity.EntityId,
                    ChildId: relationLimit.ChildEntityId,
                    LimitName: relationLimits[0].LimitName,
                    LimitType: relationLimits[0].LimitType
                });
            });
        });
    };
    /**
     * Get a list of the unique EntityId's and their limits from the whole DecomposeContext set of an order
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
     * @returns {Array<string>} An array of unique entityId's within an order
     */
    LimitValidator.ExtractUniqueEntityLimitItems = function (decomposeContexts) {
        var foundEntityIds = [];
        decomposeContexts.forEach(function (decomposeContext) {
            Object.keys(decomposeContext.Orderfolio).forEach(function (key) {
                var orderfolioItemSet = decomposeContext.Orderfolio[key];
                var selectedOrderfolioItems = orderfolioItemSet.filter(function (item) {
                    return item.Action !== OrderActions.Delete;
                });
                var orderfolioRelationMappings = selectedOrderfolioItems.map(function (orderfolioItem) {
                    return {
                        OrderfolioID: orderfolioItem.EntityUniqueCode,
                        EntityId: orderfolioItem.EntityId,
                        IsInvalid: orderfolioItem.IsInvalid,
                        EntityLimits: decomposeContext.CompiledSpec.EntityLimits[orderfolioItem.EntityId],
                        RelationLimits: decomposeContext.CompiledSpec.RelationLimits[orderfolioItem.EntityId]
                    };
                });
                foundEntityIds = foundEntityIds.concat(orderfolioRelationMappings);
            });
        });
        return LodashUtilities.UniqWithCallback(foundEntityIds, function (item) { return item.EntityId; });
    };
    /**
     * Method to check if the decompose contexts have contextual parameters
     * @param {Array<CsTypes.DecomposeContext} decomposeContexts The decompose contexts
     * @returns {boolean}
     */
    LimitValidator.HasLimits = function (decomposeContexts) {
        return decomposeContexts.length > 0
            && Utilities.IsDefined(decomposeContexts[0].ContextData)
            && Utilities.IsDefined(decomposeContexts[0].ContextData.Limits)
            && decomposeContexts[0].ContextData.Limits.length > 0;
    };
    return LimitValidator;
}());
module.exports = LimitValidator;

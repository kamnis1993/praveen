"use strict";
///<reference types = "node" />
///<reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var CompiledSpecificationQueries = require("../cs-lib-composition/CompiledSpecificationQueries");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var RuleConditionAuditor = require("../cs-mapping/RuleConditionAuditor");
var RuleScope = require("../cs-lib-constants/RuleScope");
var Utilities = require("../cs-lib-utilities/Utilities");
var PhaseCodeAccessor = require("../cs-lib-composition/compiler/PhaseCodeAccessor");
var RuleConditionType = require("../cs-lib-constants/RuleConditionType");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
/**
 * A class that contains methods for validating compatibility rules and raising validation errors if necessary
 */
var CompatibilityRuleExecutor = /** @class */ (function () {
    function CompatibilityRuleExecutor(decomposeContexts, errorContext) {
        this._decomposeContexts = decomposeContexts;
        this._ruleConditionAuditor = new RuleConditionAuditor(decomposeContexts, errorContext);
    }
    /**
    * Executes all the compatibility rules in the supplied decompose contexts
    * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts that contain the compatibility rules to validate
    * @param {CsErrorContext} errorContext the error context in which to raise any errors
    */
    CompatibilityRuleExecutor.prototype.ExecuteRules = function (errorContext) {
        var _this = this;
        this._decomposeContexts.forEach(function (decomposeContext, decomposeIndex) {
            // Don't execute rules for root entities that have not been affected or have been deleted
            var rootAction = OrderfolioQueries.GetRootOrderfolioAction(decomposeContext.Orderfolio);
            if (Utilities.IsNotDefined(rootAction) || rootAction === OrderActions.Delete) {
                Logger.debug(0, "CompatibilityRule", "Compatibility Rule on Root not applied", { SubType: "CompatibilityRuleAction", Action: rootAction });
                return;
            }
            decomposeContext.CompiledSpec.CompatibilityRules.forEach(function (compatibilityRule) {
                Logger.debug(0, "CompatibilityRule", "Started Processing Compatibility Rule - " + compatibilityRule.Name, { compatibilityRule: compatibilityRule });
                if (compatibilityRule.RuleScope === RuleScope.Portfolio && decomposeContext.IgnorePortfolioWideRules) {
                    Logger.debug(1, "CompatibilityRule", "Rule ignored as Portfolio rules are set to be ignored ", { Name: compatibilityRule.Name, ID: compatibilityRule.ID });
                    return;
                }
                if (rootAction === OrderActions.NoChange && compatibilityRule.RuleScope !== RuleScope.Portfolio) {
                    Logger.debug(1, "CompatibilityRule", "Rule ignored based on action and scope", { ID: compatibilityRule.ID, Action: rootAction, Scope: compatibilityRule.RuleScope });
                    return;
                }
                // Do not apply the rule if the order date falls outside the rule's applicable date range
                if (!OrderfolioQueries.RuleDateCriteriaIsMet(compatibilityRule.StartDate, compatibilityRule.EndDate, decomposeContext.ActivationDate)) {
                    Logger.debug(1, "CompatibilityRule", "Rule ignored as its date is out of range", { ID: compatibilityRule.ID, RuleStartDate: compatibilityRule.StartDate, RuleEndDate: compatibilityRule.EndDate, ActivationDate: decomposeContext.ActivationDate });
                    return;
                }
                // Fire for each instance of the container entity
                var containerEntities = decomposeContext.Orderfolio[compatibilityRule.EntityUuid];
                if (!containerEntities || containerEntities.length < 1) {
                    Logger.debug(1, "CompatibilityRule", "Rule ignored as it could not find Entity UUID in the orderfolio", { Name: compatibilityRule.Name, ID: compatibilityRule.ID, EntityUuid: compatibilityRule.EntityUuid });
                    return;
                }
                for (var containerIdx = 0; containerIdx < containerEntities.length; containerIdx++) {
                    var containerEntity = containerEntities[containerIdx];
                    Logger.debug(1, "CompatibilityRule", "Processing Orderfolio with ID: " + containerEntity.PortfolioItemId, containerEntity);
                    if (containerEntity.IsInvalid) {
                        Logger.debug(2, "CompatibilityRule", "Orderfolio with ID: " + containerEntity.PortfolioItemId + " is invalid", containerEntity);
                        continue;
                    }
                    var entitiesToCheck;
                    // If the action for the container entity is delete then we do not fire the rule
                    // If the action is undefined (nochange) then we will fire the rule, as we know our parent is in the affected portfolio
                    // The check for that is above with IsRootOrderfolioItemInAffectedPortfolio
                    if (Utilities.IsDefined(containerEntity.Action) && containerEntity.Action === OrderActions.Delete) {
                        Logger.debug(2, "CompatibilityRule", "Compatibility rules not fired for " + containerEntity.PortfolioItemId +
                            " as it has a Delete action", containerEntity);
                        continue;
                    }
                    // If we have further scope defined (only child rules) then the scope at which the rule is checked changes
                    if (Utilities.IsDefined(compatibilityRule.FurtherScope)) {
                        Logger.debug(2, "CompatibilityRule", "Further scope of value " + compatibilityRule.FurtherScope + " is defined on compatibility rule");
                        entitiesToCheck = CompatibilityRuleExecutor.GetFurtherScopeOrderfolioItems(containerEntity, compatibilityRule, decomposeContext);
                    }
                    else {
                        entitiesToCheck = [containerEntity];
                    }
                    entitiesToCheck.forEach(function (scopedEntity) {
                        Logger.debug(2, "CompatibilityRule", "Starting to validate rule against: " + scopedEntity.PortfolioItemId);
                        if (_this.ValidateRuleConditions(compatibilityRule, _this._decomposeContexts, decomposeIndex, scopedEntity, containerEntity)) {
                            var phaseCodesDictionary = PhaseCodeAccessor.GetCompatibilityRulePhaseCodes(_this._decomposeContexts[decomposeIndex].CompiledSpec, scopedEntity, _this._decomposeContexts[decomposeIndex].BoundaryCondition);
                            var parentLookup = _this._decomposeContexts[decomposeIndex].CompiledSpec.CardinalityLookups.EntityCardinalitiesByChildId[scopedEntity.CompoundKey.Key];
                            var parentKey = undefined;
                            var parentInfo = undefined;
                            // parentLookup will be undefined if the scopedEntity is a root entity.
                            if (Utilities.IsDefined(parentLookup)) {
                                parentKey = parentLookup.ParentKey;
                                // if there were multiple parents then choosing the very first one.
                                parentInfo = _this._decomposeContexts[decomposeIndex].Orderfolio[parentKey][0];
                            }
                            Logger.debug(3, "CompatibilityRule", "Rule Satisfied: Validation error raised", {
                                Name: compatibilityRule.Name,
                                ID: compatibilityRule.ID,
                                ErrorCode: ErrorCode.Validation.InvalidCustomerPortfolio.Code,
                                ErrorMessage: compatibilityRule.ErrorMessage,
                                Phasecodes: phaseCodesDictionary[compatibilityRule.ID]
                            });
                            errorContext.RaiseCompatibilityError(compatibilityRule, ErrorCode.Validation.InvalidCustomerPortfolio, scopedEntity, decomposeContext, phaseCodesDictionary[compatibilityRule.ID], Utilities.IsDefined(parentInfo) ? parentInfo.EntityId : undefined, Utilities.IsDefined(parentInfo) ? parentInfo.EntityUniqueCode : undefined);
                        }
                        else {
                            Logger.debug(3, "CompatibilityRule", "Rule Not Satisfied", {
                                Name: compatibilityRule.Name,
                                ID: compatibilityRule.ID
                            });
                        }
                    });
                }
            });
        });
    };
    /**
     * Gets the orderfolio items using the further scope
     * @param {CsTypes.OrderfolioItem} containerEntity The container entity
     * @param {CsTypes.CompatibilityRule} compatibilityRule The compatibility rule
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @returns {Array<CsTypes.OrderfolioItem>}
     */
    CompatibilityRuleExecutor.GetFurtherScopeOrderfolioItems = function (containerEntity, compatibilityRule, decomposeContext) {
        var furtherScopeOrderfolioItems = [];
        // Get all orderfolio items for further scope uuid.
        var orderfolioItems = decomposeContext.Orderfolio[compatibilityRule.FurtherScope];
        Logger.debug(3, "CompatibilityRule", "Attempted to find Orderfolio items with a value of  " + compatibilityRule.FurtherScope + " from the decompose context", orderfolioItems);
        if (Utilities.IsNotDefined(orderfolioItems)) {
            Logger.debug(4, "CompatibilityRule", "No Orderfolio items found with the further scope ID of " + compatibilityRule.FurtherScope);
            return furtherScopeOrderfolioItems;
        }
        // Filter items to only the container entity and not deleted entities
        furtherScopeOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(containerEntity.CompoundKey, orderfolioItems, decomposeContext, true);
        Logger.debug(3, "CompatibilityRule", furtherScopeOrderfolioItems.length + " child orderfolio items filtered from parent " + containerEntity.PortfolioItemId, furtherScopeOrderfolioItems);
        return furtherScopeOrderfolioItems;
    };
    /**
     * Validate the conditions in the supplied RuleConditionCollection
     * All conditions must evaluate to true in order for the message to be displayed, the reverse of Mapping Rule conditions
     * @param {CsTypes.CompatibilityRule} conditions the The compatibility rule that contains the rule collection to evaluate
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts to use to when validating the conditions
     * @param {CsTypes.OrderfolioItem} scopedEntity The entity from where the rule scope starts
     * @param {CsTypes.OrderfolioItem} containerEntity The entity that contains the rule
     * @return True if all conditions are true, otherwise false
     */
    CompatibilityRuleExecutor.prototype.ValidateRuleConditions = function (compatibilityRule, decomposeContexts, currentDecomposeIndex, scopedEntity, containerEntity) {
        var _this = this;
        var conditions = compatibilityRule.Conditions;
        // All paths can be treated the same here, so concatenate the conditions and process
        var conditionPaths = CompiledSpecificationQueries.AllRuleConditions(conditions);
        if (conditionPaths.length === 0) {
            Logger.debug(0, "CompatibilityRule", "No condition paths found", { SubType: "ConditionsPaths", conditionPath: conditionPaths, ruleID: compatibilityRule.ID });
            return false;
        }
        Logger.debug(3, "CompatibilityRule", "Found " + conditionPaths.length + " conditions", compatibilityRule.Conditions);
        return conditionPaths.every(function (condition) {
            Logger.debug(4, "CompatibilityRule", "Evaluating condition - " + condition.Name, condition);
            var ruleMatched;
            if (condition.ConditionType === RuleConditionType.EntToEnt || condition.ConditionType === RuleConditionType.EntToStatic
                || condition.ConditionType === RuleConditionType.EntToUDC) {
                ruleMatched = _this._ruleConditionAuditor.CheckCountCondition(condition, decomposeContexts[currentDecomposeIndex], containerEntity, false);
            }
            else if (condition.ConditionType === RuleConditionType.ExistsData || condition.ConditionType === RuleConditionType.NotExistsData) {
                ruleMatched = _this._ruleConditionAuditor.MultipleValueConditionsMetForCompatibilityRule(condition, currentDecomposeIndex, scopedEntity, containerEntity);
            }
            else {
                ruleMatched = _this.AtLeastOneTargetExists(condition, decomposeContexts, currentDecomposeIndex, scopedEntity, containerEntity);
            }
            CompatibilityRuleExecutor.LogRuleApplicableStatus(condition, compatibilityRule, ruleMatched);
            return condition.ExistsCondition ? ruleMatched : !ruleMatched;
        });
    };
    /**
     * Method searches the supplied decompose contexts to check if at least 1 of the supplied conditions->targets exist
     * @param {CsTypes.Condition} condition the condition that contains the target info
     * @param {CsTypes.DecomposeContextCollection} decomposeContexts the decompose contexts to search
     * @returns {boolean} a value indicating if at least 1 of the targets exists in the orderfolio
     */
    CompatibilityRuleExecutor.prototype.AtLeastOneTargetExists = function (condition, decomposeContexts, currentDecomposeIndex, scopedEntity, containerEntity) {
        var _this = this;
        for (var targetPath = 0; targetPath < condition.TargetPaths.length; targetPath++) {
            var targetPathItem = condition.TargetPaths[targetPath];
            for (var j = 0; j < targetPathItem.Targets.length; j++) {
                var target = targetPathItem.Targets[j];
                Logger.debug(5, "CompatibilityRule", "Evaluating condition's target set with key of " + target.Key, target);
                var targetDecomposeContext = Utilities.IsNotDefined(target.DecomposeContextIndex, true) ? decomposeContexts[currentDecomposeIndex] : decomposeContexts[target.DecomposeContextIndex];
                var targetOrderfolioItems = targetDecomposeContext.Orderfolio[target.Key];
                if (!targetOrderfolioItems || targetOrderfolioItems.length < 1) {
                    Logger.debug(6, "CompatibilityRule", "No Orderfolio items found with target key of " + target.Key, target);
                    continue;
                }
                if (condition.Scope === RuleScope.Child) {
                    var scopedKey = (target.UseFurtherScope) ? (scopedEntity.CompoundKey) : (containerEntity.CompoundKey);
                    Logger.debug(6, "CompatibilityRule", "Attaining child orderfolio items that contain key " + target.Key, target);
                    // If we have a scope of child ensure that we only look at children underneath the instance of the container entity
                    targetOrderfolioItems = OrderfolioQueries.FilterChildrenToParent(scopedKey, targetOrderfolioItems, targetDecomposeContext);
                    if (targetOrderfolioItems.length < 1) {
                        Logger.debug(6, "CompatibilityRule", "No child orderfolio items found with target key of " + target.Key, target);
                        continue;
                    }
                }
                if (this._ruleConditionAuditor.TargetExists(targetDecomposeContext, targetOrderfolioItems, condition)) {
                    Logger.debug(6, "CompatibilityRule", "TargetExists", function () { return (_this.LogMappedContext(condition, targetPathItem, targetOrderfolioItems)); });
                    return true;
                }
            }
        }
        Logger.debug(6, "CompatibilityRule", "NoTargetExists", { "Condition": condition });
        return false;
    };
    /**
    * Apply logging for mapped context
    * @param {CsTypes.Condition} targetOrderfolioItems The condition that contains the target info
    * @param {CsTypes.OrderfolioItem[]} targetOrderfolioItems The targetOrderfolioItems to be evaluated against
    */
    CompatibilityRuleExecutor.prototype.LogMappedContext = function (condition, targetPath, targetOrderfolioItems) {
        var unsquashedTargets = targetPath.Targets;
        return {
            Condition: {
                ConditionType: condition.ConditionType,
                Scope: condition.Scope,
                RegExpression: targetPath.RegExp,
                MatchAll: targetPath.MatchAll,
                UseId: targetPath.UseId,
                ValueID: targetPath.ValueId,
                Action: targetPath.Action,
                Targets: unsquashedTargets,
                LinkTypeID: targetPath.LinkTypeID
            },
            TargetOrderfolioItem: {
                Keys: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.CompoundKey.Key; }),
                Entities: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return { "EntityId": targetOrderfolioItem.EntityId, "PortfolioItemId": targetOrderfolioItem.PortfolioItemId }; }),
                CharacteristicUses: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.CharacteristicUses; }),
                UserDefinedCharacteristics: LodashUtilities.Map(targetOrderfolioItems, function (targetOrderfolioItem) { return targetOrderfolioItem.UserDefinedCharacteristics; })
            }
        };
    };
    /**
    * Apply logging message
    * @param {CsTypes.Condition} condition The condition that contains the target info
    * @param {CsTypes.CompatibilityRule} compatibilityRule The compatibility rule that contains the rule collection to evaluate
    * @param {boolean} oneTargetExists A value indicating if at least 1 of the targets exists in the orderfolio
    */
    CompatibilityRuleExecutor.LogRuleApplicableStatus = function (condition, compatibilityRule, oneTargetExists) {
        var logMessage = "";
        if (condition.ExistsCondition) {
            if (oneTargetExists) {
                logMessage = "Condition satisfied as target should and does exist";
            }
            else {
                logMessage = "Condition not satisfied as target should exist";
            }
        }
        else {
            if (oneTargetExists) {
                logMessage = "Condition not satisfied as target should not exist";
            }
            else {
                logMessage = "Condition satisfied as target shouldn't and doesn't exist";
            }
        }
        Logger.debug(4, "CompatibilityRule", logMessage, {
            Type: "condition",
            SubType: "TargetExist",
            TargetExistsPaths: condition.TargetPaths,
            TargetConditionType: condition.ConditionType,
            TargetExists: condition.ExistsCondition,
            ruleID: compatibilityRule.ID
        });
    };
    return CompatibilityRuleExecutor;
}());
module.exports = CompatibilityRuleExecutor;

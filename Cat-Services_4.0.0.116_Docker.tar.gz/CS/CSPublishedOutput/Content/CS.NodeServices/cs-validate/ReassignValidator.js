"use strict";
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Logger = require("../cs-logging/Logger");
/**
 * Contains methods for validating reassigned items in the decompose contexts
 */
var ReassignValidator = /** @class */ (function () {
    function ReassignValidator() {
    }
    /**
     * Validates the reassign items for the decompose contexts
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts The array of decompose contexts
     * @param {CsErrorContext} errorContext The error context
     */
    ReassignValidator.Validate = function (decomposeContexts, errorContext) {
        if (errorContext.HasBreakingErrors) {
            return;
        }
        var reassignItems = [];
        var reassignedItems = [];
        // Build 2 lists containing reassign items and reassigned items
        // We need to do this across all decompose contexts
        decomposeContexts.forEach(function (decomposeContext) {
            Logger.debug(0, "Validation", "Validating reassign items");
            var orderfolio = decomposeContext.Orderfolio;
            Object.keys(orderfolio).forEach(function (orderfolioKey) {
                orderfolio[orderfolioKey].forEach(function (orderfolioItem) {
                    // find reassign items
                    switch (orderfolioItem.Action) {
                        case OrderActions.Reassign:
                            Logger.debug(1, "Validation", "Reassigning item", {
                                EntityId: orderfolioItem.EntityId,
                                PortfolioId: orderfolioItem.PortfolioItemId,
                                Action: orderfolioItem.Action
                            });
                            reassignItems.push({ EntityId: orderfolioItem.EntityId, PortfolioId: orderfolioItem.PortfolioItemId, Action: orderfolioItem.Action });
                            break;
                        case OrderActions.Reassigned:
                        case OrderActions.ReassignedUpdate:
                        case OrderActions.Delete:
                            Logger.debug(1, "Validation", "Reassigning item", {
                                EntityId: orderfolioItem.EntityId,
                                PortfolioId: orderfolioItem.PortfolioItemId,
                                Action: orderfolioItem.Action
                            });
                            // Note that we also need to include Delete actions in the pair checking on the reassigned side, as reassign/delete is a valid match
                            reassignedItems.push({ EntityId: orderfolioItem.EntityId, PortfolioId: orderfolioItem.PortfolioItemId, Action: orderfolioItem.Action });
                            break;
                    }
                });
            });
        });
        ReassignValidator.ValidateAllReassignPairsMatch(reassignItems, reassignedItems, errorContext);
    };
    /**
    * Validates an orderfolio to ensure that every reassign item has a matching reassigned or reassignedupdate item
    * @param {any[]} reassignItems The reassign Items
    * @param {any[]} reassignedItems The reassigned Items
    * @param {CsErrorContext} errorContext The error context
    */
    ReassignValidator.ValidateAllReassignPairsMatch = function (reassignItems, reassignedItems, errorContext) {
        // Check the 2 lists contain matching pairs
        // remove all matching pairs and raise an error for each remaining EntityID
        var matches = [];
        for (var i = reassignItems.length - 1; i >= 0; i--) {
            var match = ReassignValidator.GetFirstReassignedItemMatch(reassignedItems, reassignItems[i]);
            if (match > -1) {
                reassignItems.splice(i, 1);
                reassignedItems.splice(match, 1);
            }
        }
        // We must remove unmatched items with action "Delete" from the reassignedItems
        // because missing/delete is a valid state (unrelated to reassign).
        reassignedItems = ReassignValidator.RemoveDeletesFromReassignedItems(reassignedItems);
        var unmatchedItems = reassignItems.concat(reassignedItems);
        unmatchedItems.forEach(function (item) {
            if (item.Action === OrderActions.Reassign) {
                Logger.debug(2, "Validation", "Missing reassigned item", {
                    EntityId: item.EntityID,
                    PortfolioId: item.PortfolioId,
                    ItemAction: item.Action,
                    ItemInfo: item
                });
                errorContext.RaiseValidationError(ErrorCode.Validation.MissingReassignedItem, item.PortfolioId, item.EntityId);
            }
            else {
                Logger.debug(2, "Validation", "Missing reassign item", {
                    EntityId: item.EntityID,
                    PortfolioId: item.PortfolioId,
                    ItemAction: item.Action,
                    ItemInfo: item
                });
                errorContext.RaiseValidationError(ErrorCode.Validation.MissingReassignItem, item.PortfolioId, item.EntityId);
            }
        });
    };
    /**
    * Return the index of the first ReassignedItem matching a reassign item
    * @param {any[]} reassignedItems The array of reassigned items
    * @param {any} reassignItem The reassign item to match
    * @returns {number}
    */
    ReassignValidator.GetFirstReassignedItemMatch = function (reassignedItems, reassignItem) {
        for (var i = 0; i < reassignedItems.length; i += 1) {
            if (reassignedItems[i].EntityId === reassignItem.EntityId
                && reassignedItems[i].PortfolioId === reassignItem.PortfolioId) {
                return i;
            }
        }
        return -1;
    };
    /**
    * Returns the ReassignedItems array with all deleted items removed
    * @param {any[]} reassignedItems The array of reassigned items
    * @returns {any[]}
    */
    ReassignValidator.RemoveDeletesFromReassignedItems = function (reassignedItems) {
        return reassignedItems.filter(function (item) { return item.Action.toLowerCase() !== "delete"; });
    };
    return ReassignValidator;
}());
module.exports = ReassignValidator;

"use strict";
/// <reference types="node" />
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var Logger = require("../cs-logging/Logger");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioLinkedEntityQueries = require("../cs-lib-types/QueryableEntities/OrderfolioLinkedEntityQueries");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
var PhaseCodeAccessor = require("../cs-lib-composition/compiler/PhaseCodeAccessor");
/**
 * Class that validates entity links for the decompose contexts
 */
var EntityLinkValidator = /** @class */ (function () {
    function EntityLinkValidator() {
    }
    /**
     * Validates the entity links for the decompose contexts
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts The array of decompose contexts
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.Validate = function (decomposeContexts, errorContext) {
        if (errorContext.HasBreakingErrors) {
            return;
        }
        Logger.debug(0, "Validation", "Validating Entity Links");
        decomposeContexts.forEach(function (decomposeContext) {
            var orderfolio = decomposeContext.Orderfolio;
            Object.keys(decomposeContext.Orderfolio).forEach(function (orderfolioKey) {
                var orderfolioItems = orderfolio[orderfolioKey];
                orderfolioItems.forEach(function (orderfolioItem) {
                    EntityLinkValidator.ValidateOrderfolioItem(orderfolioItem, decomposeContext, errorContext);
                });
            });
        });
    };
    /**
     * Validates an orderfolio item
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item to validate
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.ValidateOrderfolioItem = function (orderfolioItem, decomposeContext, errorContext) {
        var orderfolio = decomposeContext.Orderfolio;
        var specLinkedEntitiesBySource = decomposeContext.CompiledSpec.EntityLinksBySourceLookup;
        if (Utilities.IsDefined(orderfolioItem.Action) && orderfolioItem.Action === OrderActions.Delete) {
            Logger.debug(1, "Validation", "Order item action is delete. Ignoring.", {
                EntityId: orderfolioItem.EntityId
            });
            return;
        }
        var orderfolioItemSpecLinks = specLinkedEntitiesBySource[orderfolioItem.CompoundKey.Key];
        if (!orderfolioItemSpecLinks) {
            return;
        }
        // Ensure orderfolio has a linked entity entry for this orderfolio item
        EntityLinkValidator.ValidateRequiredEntityLinks(orderfolioItem, orderfolioItemSpecLinks, decomposeContext.LinkedEntities, errorContext, decomposeContext);
        var entityLinksOnItem = OrderfolioLinkedEntityQueries.GetBySource(decomposeContext.LinkedEntities, orderfolioItem.CompoundKey);
        // If there are no entity links specified, then we do not need to do anymore validation for this orderfolio item
        if (entityLinksOnItem.length < 1) {
            return;
        }
        // Validate unique links
        EntityLinkValidator.ValidateUniqueEntityLinks(orderfolioItem, orderfolio, decomposeContext.LinkedEntities, errorContext);
        // Ensure orderfolio obeys IsMulti indicator
        EntityLinkValidator.ValidateMultiEntityLinks(orderfolioItem, decomposeContext.LinkedEntities, errorContext);
        // Ensure the links specified are valid
        EntityLinkValidator.ValidateEntityLinkTargets(orderfolio, orderfolioItem, decomposeContext.LinkedEntities, errorContext);
    };
    /**
     * Validates that all required entity links for an orderfolio item have been provided
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item to check
     * @param {CsTypes.EntityLink[]} specEntityLinks The entity links in the specification
     * @param {Array<CsTypes.SourceToTargetEntityLink>} linkedEntities The entity links in the orderfolio
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.ValidateRequiredEntityLinks = function (orderfolioItem, specEntityLinks, linkedEntities, errorContext, decomposeContext) {
        var matchingLinks = specEntityLinks.filter(function (specLinkedEntity) { return specLinkedEntity.IsRequired; });
        if (!matchingLinks) {
            return;
        }
        // Ensure orderfolio has a linked entity entry for this orderfolio item
        matchingLinks.forEach(function (currentLink) {
            var contextLinkedEntitiesForOrderfolioItem = OrderfolioLinkedEntityQueries.GetBySourceAndLinkType(linkedEntities, orderfolioItem.CompoundKey, currentLink.Id, true);
            if (Utilities.IsNotDefined(contextLinkedEntitiesForOrderfolioItem, true)) {
                var uniqueKey = orderfolioItem.EntityUniqueCode;
                var extraInfo = 'An EntityLink with an ID ' + currentLink.Id + ' is required for this entity';
                // Phase error tagging is applicable only for the required type entity links.
                var phasecode = PhaseCodeAccessor.GetEntityLinkPhaseCodes(decomposeContext.CompiledSpec, currentLink.Container, decomposeContext.BoundaryCondition);
                Logger.debug(2, "Validation", "InvalidEntityLink", { Info: extraInfo });
                errorContext.RaiseValidationError(ErrorCode.Validation.MissingEntityLink, uniqueKey, orderfolioItem.EntityId, { LinkTypeID: currentLink.Id }, extraInfo, null, phasecode[currentLink.Id]);
            }
        });
    };
    /**
     * Validates the IsMulti indicator on an entity link
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @param {Array<CsTypes.SourceToTargetEntityLink>} linkedEntities The entity links in the orderfolio
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.ValidateMultiEntityLinks = function (orderfolioItem, linkedEntities, errorContext) {
        var invalidEntityLinks = OrderfolioLinkedEntityQueries.GetInvalidMultiLinks(linkedEntities, orderfolioItem.CompoundKey);
        if (!invalidEntityLinks || invalidEntityLinks.length < 1) {
            return;
        }
        for (var linkIdx = 0; linkIdx < invalidEntityLinks.length; linkIdx++) {
            var entityLink = invalidEntityLinks[linkIdx];
            var uniqueKey = orderfolioItem.EntityUniqueCode;
            var extraInfo = 'An EntityLink with an ID ' + entityLink.LinkTypeID + ' cannot have multiple links for this entity';
            var messageParameters = { RelationID: entityLink.LinkTypeID, EntityUniqueCode: uniqueKey };
            Logger.debug(2, "Validation", "Invalid IsMulti indicator", { Info: extraInfo });
            errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.IsMultiViolated, uniqueKey, orderfolioItem.EntityId, messageParameters, null, extraInfo);
        }
    };
    /**
     * Validates the unique entity links on an orderfolio item
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} orderfolio The orderfolio
     * @param {Array<CsTypes.SourceToTargetEntityLink>} linkedEntities The entity links in the orderfolio
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.ValidateUniqueEntityLinks = function (orderfolioItem, orderfolio, linkedEntities, errorContext) {
        var uniqueLinks = OrderfolioLinkedEntityQueries.GetUniqueLinks(linkedEntities, orderfolioItem.CompoundKey);
        if (uniqueLinks.length < 1) {
            Logger.debug(2, "Validation", "Skipping as no unique entity links identified", {
                EntityId: Utilities.IsDefined(orderfolioItem.EntityId) ? orderfolioItem.EntityId : "undefined"
            });
            return;
        }
        for (var linkIdx = 0; linkIdx < uniqueLinks.length; linkIdx++) {
            var entityLink = uniqueLinks[linkIdx];
            var matchingTargets = OrderfolioLinkedEntityQueries.GetByTargetAndLinkType(linkedEntities, entityLink.Target, entityLink.LinkTypeID, true);
            if (matchingTargets.length === 1) {
                continue;
            }
            for (var targetIdx = 0; targetIdx < matchingTargets.length; targetIdx++) {
                var currentSource = matchingTargets[targetIdx];
                // If the first instance of the target is our orderfolio item then it is valid
                if (OrderfolioQueries.CompareOrderfolioItemLookup(entityLink.Source, currentSource.Source)) {
                    break;
                }
                var existingSourceOrderfolioItem = orderfolio[currentSource.Source.Key][currentSource.Source.Index];
                // Has the same target, but is deleted, so we don't count it
                if (Utilities.IsDefined(existingSourceOrderfolioItem.Action) && existingSourceOrderfolioItem.Action === OrderActions.Delete) {
                    continue;
                }
                EntityLinkValidator.RaiseUniqueValidationError(orderfolio, orderfolioItem, currentSource, errorContext);
            }
        }
    };
    /**
     * Validates that all the the relationships have targets that are valid against the spec
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} orderfolio The orderfolio
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item to check
     * @param {Array<CsTypes.SourceToTargetEntityLink>} linkedEntities The entity links in the orderfolio
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.ValidateEntityLinkTargets = function (orderfolio, orderfolioItem, linkedEntities, errorContext) {
        var invalidTargets = OrderfolioLinkedEntityQueries.GetInvalidTargetLinks(linkedEntities, orderfolioItem.CompoundKey);
        if (!invalidTargets || invalidTargets.length < 1) {
            return;
        }
        var uniqueKey = orderfolioItem.EntityUniqueCode;
        for (var errIndex = 0; errIndex < invalidTargets.length; errIndex++) {
            var invalidTarget = invalidTargets[errIndex];
            var targetOrderfolioItem = orderfolio[invalidTarget.Target.Key][invalidTarget.Target.Index];
            var messageParameters = { PortfolioItemID: targetOrderfolioItem.PortfolioItemId, EntityLinkID: invalidTarget.LinkTypeID };
            errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.InvalidTarget, uniqueKey, null, messageParameters);
            Logger.debug(2, "Validation", "Invalid relationship target", { info: messageParameters });
        }
    };
    /**
     * Raises a validation error for an orderfolio item that has violated the IsUnique rule
     * @param {CsTypes.Dictionary<CsTypes.OrderfolioItem[]>} orderfolio The orderfolio
     * @param {CsTypes.OrderfolioItem} sourceOrderfolioItem The orderfolio item
     * @param {CsTypes.SourceToTargetEntityLink} existingSource The details of the first instance of the target that has been seen
     * @param {CsErrorContext} errorContext The error context
     */
    EntityLinkValidator.RaiseUniqueValidationError = function (orderfolio, sourceOrderfolioItem, existingSource, errorContext) {
        var targetOrderfolioItem = orderfolio[existingSource.Target.Key][existingSource.Target.Index];
        var existingSourceOrderfolioItem = orderfolio[existingSource.Source.Key][existingSource.Source.Index];
        var uniqueSourceKey = sourceOrderfolioItem.EntityUniqueCode;
        var uniqueTargetKey = targetOrderfolioItem.EntityUniqueCode;
        var uniqueExistingSourceKey = existingSourceOrderfolioItem.EntityUniqueCode;
        var extraInfo = 'An EntityLink with an ID \'' + existingSource.LinkTypeID + '\' must have unique targets';
        var messageParameters = { TargetID: uniqueTargetKey, RelationID: existingSource.LinkTypeID, ExistingSourceID: uniqueExistingSourceKey };
        errorContext.RaiseValidationError(ErrorCode.Validation.InvalidEntityLink.IsUniqueViolated, uniqueSourceKey, sourceOrderfolioItem.EntityId, messageParameters, extraInfo, null);
        Logger.debug(3, "Validation", "Invalid IsUnique indicator", { Info: extraInfo });
    };
    return EntityLinkValidator;
}());
module.exports = EntityLinkValidator;

"use strict";
var DateTimeValidator = require("../cs-validate/DateTimeValidator");
var DataTypeValidator = require("../cs-validate/DataTypeValidator");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var UDCTypeConstants = require("../cs-lib-constants/UDCTypeConstants");
var Utilities = require("../cs-lib-utilities/Utilities");
var PhaseCodeAccessor = require("../cs-lib-composition/compiler/PhaseCodeAccessor");
/**
 * Contains methods for validating the cardinality of characteristic values
 */
var CharValueValidator = /** @class */ (function () {
    function CharValueValidator() {
    }
    /**
     * Validates that the values on the supplied characteristic use are valid for the specification
     * @param {CsTypes.CharacteristicUse} charUse the char use that contains the values
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item that contains the charuse->values
     * @param {CsTypes.DecomposeContext} decomposeContext the decompose context to use in the validation
     * @param {CsErrorContext} errorContext the error context in which any errors would be pushed if they are encountered
     */
    CharValueValidator.ValidateValues = function (charUse, orderfolioItem, decomposeContext, errorContext) {
        var charValues = charUse.Values;
        var uuid = orderfolioItem.CompoundKey.Key.toString();
        var validValuesForCharUse = decomposeContext.CompiledSpec.CharacteristicUseLookups.UuidAndUseIdToValidValues[uuid + "|" + charUse.UseId];
        if (Utilities.IsNotDefined(validValuesForCharUse)) {
            validValuesForCharUse = [];
        }
        for (var c = 0; c < charValues.length; c++) {
            var charValue = charValues[c];
            if (charValue.Action === MergedActions.DeleteExisting || charValue.Action === MergedActions.DeleteMissing) {
                continue;
            }
            var valueIsValid = validValuesForCharUse.some(function (validValue) {
                return validValue === charValue.Value;
            });
            // if the value is valid then we can validate it against the dates (if they are configured)
            if (valueIsValid) {
                // if dates aren't valid the function will raise the correct validation error and we can continue
                // if dates are valid or don't exist we will carry on and raise the validation error at the bottom of the function
                CharValueValidator.ValidateValueDates(decomposeContext, uuid, charUse, charValue, orderfolioItem, errorContext);
                continue;
            }
            Logger.debug(2, "Validation", "Invalid char value: " + charValue.Value + " - not in specification", {
                EntityUniqueCode: orderfolioItem.EntityUniqueCode,
                EntityId: orderfolioItem.EntityId,
                CharValue: charValue.Value,
                CharUse: charUse.UseId
            });
            errorContext.RaiseValidationErrorWithChildInfo(ErrorCode.Validation.InvalidCharacteristicValue, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, charValue.Value, charUse.UseId);
        }
    };
    CharValueValidator.ValidateValueDates = function (decomposeContext, uuid, charUse, charValue, orderfolioItem, errorContext) {
        var charUseDictionary = decomposeContext.CompiledSpec.CharacteristicUseLookups.ConfigurableDataDates[uuid];
        if (Utilities.IsNotDefined(charUseDictionary)) {
            return;
        }
        var charUseDates;
        // The value in the dictionary is a list so we need to iterate over it to find the correct Characteristic
        for (var index in charUseDictionary) {
            var current = charUseDictionary[index];
            if (Utilities.IsDefined(current[charUse.UseId])) {
                charUseDates = current[charUse.UseId];
                break;
            }
        }
        // If no charuse dates were found thats fine just return true;
        if (Utilities.IsNotDefined(charUseDates)) {
            return;
        }
        // We need to find the specifc value dates from the .Values of the char use
        // It's ok to return true if none are found
        var charValueDates;
        if (Utilities.IsDefined(charUseDates.Values)) {
            charValueDates = charUseDates.Values[charValue.Value];
        }
        // Send the values to be compared to the activation date
        if (Utilities.IsDefined(charValueDates)) {
            if (!Utilities.IsDateValidForDateRange(decomposeContext.ActivationDate, Utilities.IsDefined(charValueDates.StartDate) ? charValueDates.StartDate : null, Utilities.IsDefined(charValueDates.EndDate) ? charValueDates.EndDate : null)) {
                Logger.debug(2, "Validation", "Char value: " + charValue.Value + " - is out of date", {
                    EntityUniqueCode: orderfolioItem.EntityUniqueCode,
                    EntityId: orderfolioItem.EntityId,
                    CharValue: charValue.Value,
                    CharUse: charUse.UseId,
                    ValueStartDate: charValueDates.StartDate,
                    ValueEndDate: charValueDates.EndDate,
                    ActivationDate: decomposeContext.ActivationDate
                });
                errorContext.RaiseValidationErrorWithChildInfo(ErrorCode.Validation.OutOfDateCharacteristicValue, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, charValue.Value, charUse.UseId);
            }
        }
    };
    /**
     * Validate the values on the supplied orderfolioItem -> charUse using the regular expression supplied on the char use
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item that contains the char use
     * @param {CsTypes.CharacteristicUse} charUse the char use that contains the values that we want to validate
     * @param {CsTypes.RegexInfo} regexInfo the regular expression info as defined on the char use in the spec
     * @param {CsErrorContext} errorContext the error context to raise any errors with
     * @param {CsTypes.CompiledSpecification} compiledSpecification The compiled specification
     */
    CharValueValidator.ValidateValuesUsingRegularExpression = function (orderfolioItem, charUse, regexInfo, errorContext, compiledSpecification) {
        for (var c = 0; c < charUse.Values.length; c++) {
            var regEx = new RegExp(regexInfo.RegularExpression, "g");
            var charValue = charUse.Values[c];
            var result = regEx.exec(charValue.Value);
            if (result && result.length > 0) {
                continue;
            }
            var charUseInfo = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseId];
            errorContext.RaiseValidationErrorWithChildInfo(ErrorCode.Validation.InvalidConfiguredValue, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, charUseInfo.CharacteristicId, charUseInfo.CharacteristicId, { RequestMessage: charValue.Value,
                ErrorMessage: regexInfo.RegexMessage,
                CharacteristicName: compiledSpecification.CharacteristicUseLookups.IdToName[charUse.CharacteristicId],
                RegularExpression: regexInfo.RegularExpression
            }, null, null);
            Logger.debug(2, "Validation", "Invalid regex for values", {
                Info: charUseInfo
            });
        }
    };
    /**
     * Validate the values on the supplied orderfolioItem match an expected type.
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item that contains the char use
     * @param {CsTypes.CharacteristicUse} charUse the char use that contains the values that we want to validate
     * @param {string} expectedTypeGuid The data type guid as defined on the char use in the spec
     * @param {CsErrorContext} errorContext the error context to raise any errors with
     * @param {CsTypes.CompiledSpecification} The compiled specification
     */
    CharValueValidator.ValidateValueType = function (orderfolioItem, charUse, expectedTypeGuid, errorContext, compiledSpecification) {
        if (Utilities.IsNotDefined(expectedTypeGuid)) {
            return; // If the expected Type is unknown, we cannot validate, so continue
        }
        for (var c = 0; c < charUse.Values.length; c++) {
            var charValue = charUse.Values[c].Value;
            if (Utilities.IsNotDefined(charValue)) {
                continue; // If the value is undefined, we cannot validate, so continue
            }
            // Test the data type
            if (CharValueValidator.ValueMatchesDataType(charValue, expectedTypeGuid)) {
                continue;
            }
            var charUseInfo = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseId];
            errorContext.RaiseValidationErrorWithChildInfo(CharValueValidator.BuildErrorCode(expectedTypeGuid), orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, charUseInfo.CharacteristicId, charUseInfo.CharacteristicId, { ErrorMessage: CharValueValidator.BuildErrorMessage(expectedTypeGuid, charValue) }, null, null);
            Logger.debug(2, "Validation", "Invalid value type", {
                Info: charUseInfo
            });
        }
    };
    /**
    * Checks if a value matches an expected data type.
    * @param {any} charValue The characteristic use value
    * @param {string} expectedTypeGuid The data type guid as defined on the char use in the spec
    * @returns {boolean}
    */
    CharValueValidator.ValueMatchesDataType = function (charValue, expectedTypeGuid) {
        switch (expectedTypeGuid) {
            case UDCTypeConstants.String:
                return DataTypeValidator.IsValidString(charValue);
            case UDCTypeConstants.Boolean:
                return DataTypeValidator.IsValidBoolean(charValue);
            case UDCTypeConstants.Integer:
                return DataTypeValidator.IsValidInteger(charValue);
            case UDCTypeConstants.Decimal:
                return DataTypeValidator.IsValidDecimal(charValue);
            case UDCTypeConstants.URI:
                return DataTypeValidator.IsValidUri(charValue);
            case UDCTypeConstants.Date:
                return DateTimeValidator.IsValidUdcDate(charValue);
            case UDCTypeConstants.Time:
                return DateTimeValidator.IsValidUdcTime(charValue);
            case UDCTypeConstants.DateTime:
                return DateTimeValidator.IsValidUdcDateTime(charValue);
            default:
                return DataTypeValidator.IsValidString(charValue);
        }
    };
    /**
    * Creates the correct Error Code for a specified data type guid.
    * @param {string} expectedTypeGuid The data type guid as defined on the char use in the spec
    * @returns {CsTypes.ErrorDescriptor}
    */
    CharValueValidator.BuildErrorCode = function (expectedTypeGuid) {
        var errorCode = ErrorCode.Validation.InvalidUserDefinedCharacteristicType;
        if (CharValueValidator.IsDateOrTimeType(expectedTypeGuid)) {
            errorCode = ErrorCode.Validation.InvalidUserDefinedCharacteristicDateType;
        }
        return errorCode;
    };
    /**
    * Creates the correct Error Message for a specified data type guid.
    * @param {string} expectedTypeGuid The data type guid as defined on the char use in the spec
    * @param {any} charValue The characteristic use value
    * @returns {CsTypes.ErrorDescriptor}
    */
    CharValueValidator.BuildErrorMessage = function (expectedTypeGuid, charValue) {
        var errorMessage = "Expected value: " + charValue.toString() + " to be of type: " + Utilities.GetConstantsKeyByValue(UDCTypeConstants, expectedTypeGuid);
        if (CharValueValidator.IsDateOrTimeType(expectedTypeGuid)) {
            if (expectedTypeGuid === UDCTypeConstants.Date) {
                errorMessage += " and format of YYYY-MM-DD or YYYYMMDD";
            }
            else if (expectedTypeGuid === UDCTypeConstants.Time) {
                errorMessage += " and format of hh:mm:ss, hh:mm, hhmmss or hhmm";
            }
            else if (expectedTypeGuid === UDCTypeConstants.DateTime) {
                errorMessage += " and be a valid date time in the format of <date>T<time>";
            }
        }
        return errorMessage;
    };
    /**
    * Determines if a data type guid is a Date, Time or DateTime type.
    * @param {string} typeGuid the data type guid as defined on the char use in the spec
    * @returns {boolean}
    */
    CharValueValidator.IsDateOrTimeType = function (typeGuid) {
        return (typeGuid === UDCTypeConstants.Date || typeGuid === UDCTypeConstants.Time || typeGuid === UDCTypeConstants.DateTime);
    };
    /**
     * validates that the all the items in the orderfolio, contained in the supplied decompose context, satisfy the value cardinality rules
     * @param {CsTypes.DecomposeContext} decomposeContext the context that contains the orderfolio to validate
     * @param {CsErrorContext} errorContext the context in which to push any errors should they occur
     */
    CharValueValidator.ValidateCardinality = function (orderfolioKey, decomposeContext, errorContext) {
        var charUseValueCardinalities = decomposeContext.CompiledSpec.CardinalityLookups.UuidToValue[orderfolioKey];
        if (Utilities.IsNotDefined(charUseValueCardinalities, true)) {
            return;
        }
        var orderfolioItemSet = decomposeContext.Orderfolio[orderfolioKey];
        if (Utilities.IsDefined(orderfolioItemSet, true)) {
            CharValueValidator.ValidateValueCardinalitiesForOrderfolioItems(charUseValueCardinalities, orderfolioItemSet, errorContext, decomposeContext.CompiledSpec, decomposeContext.BoundaryCondition);
        }
    };
    /**
     * Validates that each value cardinality is met on each item in a supplied list of orderfolio items
     * @param {Array<CsTypes.ValueCardinality>} valueCardinalityData the value cardinality data to be satisfied by each of the supplied orderfolio items
     * @param {Array<CsTypes.OrderfolioItem>} orderfolioItems the orderfolio items to validate against
     * @param {CsErrorContext} errorContext the context in which to push any errors should they occur
     * @param {CsTypes.CompiledSpecification} Compiled specification
     * @param {string} Boundary condition set on decompose context
     */
    CharValueValidator.ValidateValueCardinalitiesForOrderfolioItems = function (valueCardinalityData, orderfolioItems, errorContext, compiledSpecification, boundary) {
        valueCardinalityData.forEach(function (valueCardinality) {
            orderfolioItems.forEach(function (orderfolioItem) {
                if (orderfolioItem.Action === OrderActions.Delete) {
                    return;
                }
                if (orderfolioItem.IsInvalid) {
                    return;
                }
                // Find any matching characteristic Use
                var list = orderfolioItem.CharacteristicUses.concat(orderfolioItem.UserDefinedCharacteristics);
                var charUse = LodashUtilities.Find(list, function (charUse) {
                    return charUse.UseId === valueCardinality.UseId;
                });
                // Get the number of values that will exist on a portfolio item for the matching Char use
                var numberOfCharValues = 0;
                if (Utilities.IsDefined(charUse)) {
                    numberOfCharValues = (charUse.Values.reduce(function (count, charValue) {
                        if (charValue.Action === MergedActions.AddExisting
                            || charValue.Action === MergedActions.AddMissing
                            || charValue.Action === MergedActions.SkipExisting) {
                            count++;
                        }
                        return count;
                    }, 0));
                }
                // Check the cardinality
                var minCardinalityNotMet = (numberOfCharValues < valueCardinality.Min);
                var maxCardinalityExceeded = (numberOfCharValues > valueCardinality.Max);
                if (minCardinalityNotMet || maxCardinalityExceeded) {
                    var charUseInfo = compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[valueCardinality.UseId];
                    var extraInfo = "Expected " + valueCardinality.Min + ":" + valueCardinality.Max + ", but got " + numberOfCharValues + " in " + charUseInfo.UseArea + " (" + charUseInfo.CharacteristicId + ")";
                    var phaseCodesDictionary = {};
                    if (minCardinalityNotMet) {
                        // Only return PhaseCodes where the minimum Cardinality is not met
                        phaseCodesDictionary = PhaseCodeAccessor.GetCharacteristicUsePhaseCodes(compiledSpecification, orderfolioItem.CompoundKey.Key, boundary);
                    }
                    errorContext.RaiseValidationErrorWithChildInfo(ErrorCode.Validation.CharacteristicOutOfRange, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId, charUseInfo.CharacteristicId, charUseInfo.CharacteristicId, null, extraInfo, null, null, phaseCodesDictionary[valueCardinality.UseId]);
                    Logger.debug(1, "Validation", "Maximum cardinality for values exceeded", {
                        OrderfolioItem: orderfolioItem.EntityId,
                        ExtraInfo: extraInfo
                    });
                }
            });
        });
    };
    return CharValueValidator;
}());
module.exports = CharValueValidator;

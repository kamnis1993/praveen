"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var CompatibilityRuleExecutor = require("./CompatibilityRuleExecutor");
var ConverterUtils = require("../cs-lib-composition/ConverterUtils");
var CsErrorContext = require("../cs-lib-types/CsErrorContext");
var Decompose = require("../cs-decompose/Decompose");
var DecomposeContextBuilder = require("../cs-lib-composition/DecomposeContextBuilder");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderIdValidator = require("./OrderIdValidator");
var CandidateType = require("../cs-lib-constants/CandidateType");
var Utilities = require("../cs-lib-utilities/Utilities");
var ValidateDecomposeContexts = require("./ValidateDecomposeContexts");
var Validate = /** @class */ (function () {
    function Validate() {
    }
    /**
     * @summary Performs the Order candidate validation (WITHOUT INFERRENCE)
     * @param {express.Request} httpRequest containing the incoming http Request
     * @param {express.Response} httpResponse containing the http Response
     * @param {BoundaryCondition} boundaryCondition indicating how the validation should be performed
     */
    Validate.prototype.ValidateOrderCandidateLocked = function (requestBody, compiledSpecs, boundaryCondition, callback) {
        // Get the response's error context
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromOrderCandidateRequest(requestBody, compiledSpecs, function (decomposeContexts) {
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            ValidateDecomposeContexts.ValidateDecomposeContexts(decomposeContexts, errorContext);
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            else if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            else {
                return callback(null, errorContext.GetValidationErrorsForResponse()); //, 'ValidateResponse', 'ValidationError');
            }
        });
    };
    /**
 * @summary Performs the Product candidate validation (WITHOUT INFERRENCE)
 * @param {express.Request} httpRequest containing the incoming http Request
 * @param {express.Response} httpResponse containing the http Response
 * @param {BoundaryCondition} boundaryCondition indicating how the validation should be performed
 */
    Validate.prototype.ValidateProductCandidateLocked = function (requestBody, compiledSpecs, boundaryCondition, callback) {
        // Get the response's error context
        var errorContext = new CsErrorContext({});
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromProductCandidate(requestBody, compiledSpecs, function (decomposeContexts) {
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            ValidateDecomposeContexts.ValidateDecomposeContexts(decomposeContexts, errorContext);
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            else if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            else {
                return callback(null, errorContext.GetValidationErrorsForResponse()); //, 'ValidateResponse', 'ValidationError');
            }
        });
    };
    /**
* @summary Performs the Order candidate validation (WITH INFERRENCE)
* @param {express.Request} httpRequest containing the incoming http Request
* @param {express.Response} httpResponse containing the http Response
* @param {BoundaryCondition} boundaryCondition indicating how the validation should be performed
*/
    Validate.prototype.ValidateOrderCandidate = function (requestBody, compiledSpecs, boundaryCondition, callback) {
        var errorContext = new CsErrorContext({});
        this.ConfirmValidRequestBody(requestBody, CandidateType.Order, errorContext);
        if (errorContext.HasProcessError) {
            return callback(errorContext.ProcessError, null);
        }
        if (errorContext.HasBadDataError) {
            return callback(errorContext.GetBadDataErrorsResponse(), null);
        }
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromOrderCandidateRequest(requestBody, compiledSpecs, function (decomposeContexts) {
            // TODO: Shared Method
            if (errorContext.HasProcessError) {
                return callback(errorContext.ProcessError, null);
            }
            if (errorContext.HasBadDataError) {
                return callback(errorContext.GetBadDataErrorsResponse(), null);
            }
            if (errorContext.HasSevereValidationError) {
                return callback(ConverterUtils.OrderSingularize(errorContext.GetValidationErrorsForResponse()), null);
            }
            new Decompose().PerformDecomposeProcess("OrderCandidate", decomposeContexts, errorContext, function (error, result) {
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                else if (errorContext.HasBadDataError) {
                    return callback(errorContext.GetBadDataErrorsResponse(), null);
                }
                else {
                    return callback(error, ConverterUtils.OrderSingularize(errorContext.GetValidationErrorsForResponse())); //, 'ValidateResponse', 'ValidationError');
                }
            });
        });
    };
    /**
     * @summary Performs the product candidate validation (WITH INFERRENCE)
     * @param {express.Request} httpRequest containing the incoming http Request
     * @param {express.Response} httpResponse containing the http Response
     * @param {BoundaryCondition} boundaryCondition indicating how the validation should be performed
     */
    Validate.prototype.ValidateProductCandidate = function (requestBody, compiledSpecs, boundaryCondition, callback) {
        var _this = this;
        var errorContext = new CsErrorContext({});
        this.ConfirmValidRequestBody(requestBody, CandidateType.Order, errorContext);
        if (errorContext.HasProcessError) {
            return callback(errorContext.ProcessError, null);
        }
        if (errorContext.HasBadDataError) {
            return callback(errorContext.GetBadDataErrorsResponse(), null);
        }
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromProductCandidate(requestBody, compiledSpecs, function (decomposeContexts) {
            _this.ValidatedErrorContent(errorContext, function (err, result) {
                return callback(err, result);
            });
            new Decompose().PerformDecomposeProcess("ProductCandidate", decomposeContexts, errorContext, function (error, result) {
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                else if (errorContext.HasBadDataError) {
                    return callback(errorContext.GetBadDataErrorsResponse(), null);
                }
                else {
                    return callback(error, ConverterUtils.OrderSingularize(errorContext.GetValidationErrorsForResponse())); //, 'ValidateResponse', 'ValidationError');
                }
            });
        });
    };
    /**
* @summary Performs the portfolio candidate validation (WITH INFERRENCE)
* @param {express.Request} httpRequest containing the incoming http Request
* @param {express.Response} httpResponse containing the http Response
* @param {BoundaryCondition} boundaryCondition indicating how the validation should be performed
*/
    Validate.prototype.ValidatePortfolio = function (requestBody, compiledSpecs, boundaryCondition, callback) {
        var _this = this;
        var errorContext = new CsErrorContext({});
        this.ConfirmValidRequestBody(requestBody, CandidateType.Portfolio, errorContext);
        if (errorContext.HasProcessError) {
            return callback(errorContext.ProcessError, null);
        }
        if (errorContext.HasBadDataError) {
            return callback(errorContext.GetBadDataErrorsResponse(), null);
        }
        var decomposeContextBuilder = new DecomposeContextBuilder(boundaryCondition, errorContext);
        decomposeContextBuilder.BuildFromPortfolioCandidate(requestBody, compiledSpecs, function (decomposeContexts) {
            _this.ValidatedErrorContent(errorContext, function (err, result) {
                return callback(err, result);
            });
            // TODO: Replace OrderCandidate with designated Portfolio builder
            new Decompose().PerformDecomposeProcess("OrderCandidate", decomposeContexts, errorContext, function (error, result) {
                if (errorContext.HasProcessError) {
                    return callback(errorContext.ProcessError, null);
                }
                else if (errorContext.HasBadDataError) {
                    return callback(errorContext.GetBadDataErrorsResponse(), null);
                }
                else {
                    return callback(error, ConverterUtils.OrderSingularize(errorContext.GetValidationErrorsForResponse())); //, 'ValidateResponse', 'ValidationError');
                }
            });
        });
    };
    Validate.prototype.ValidatedErrorContent = function (errorContext, callback) {
        if (errorContext.HasProcessError) {
            return callback(errorContext.ProcessError, null);
        }
        if (errorContext.HasBadDataError) {
            return callback(errorContext.GetBadDataErrorsResponse(), null);
        }
        if (errorContext.HasSevereValidationError) {
            return callback(ConverterUtils.OrderSingularize(errorContext.GetValidationErrorsForResponse()), null);
        }
    };
    /**
     * Confirms that the body of the request is valid.
     * - Checks it is not empty
     * @param {express.Request} requestBody The request body from the http request
     * @param {string} candidateType the type of CandidateType which is being decomposed
     * @param {CsErrorContext} errorContext The error context
     */
    Validate.prototype.ConfirmValidRequestBody = function (requestBody, candidateType, errorContext) {
        if (Utilities.IsNotDefined(requestBody, true)) {
            var errorDescriptor;
            switch (candidateType) {
                case CandidateType.Product:
                    errorDescriptor = ErrorCode.Decompose.InvalidProductCandidate;
                    break;
                case CandidateType.Order:
                    errorDescriptor = ErrorCode.Decompose.InvalidOrderCandidate;
                    break;
                case CandidateType.Portfolio:
                    errorDescriptor = ErrorCode.Decompose.InvalidPortfolioCandidate;
                    break;
                default:
                    // This would never be reached and is here for the benefit of the developer
                    errorDescriptor = ErrorCode.Decompose.InvalidCandidate;
            }
            errorContext.RaiseCsError(400, errorDescriptor, null);
            return;
        }
        return;
    };
    /**
     * Validate all the ID's within an order for uniqueness
     * @param {OrderCandidateRequest} orderRequest the OrderCandidateRequest to validate the ID's of
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    Validate.prototype.ValidateOrderIds = function (orderRequest, errorContext) {
        OrderIdValidator.Validate(orderRequest, errorContext);
    };
    /*
    * Apply compatibility rules and record any digressions
    * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
    * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
    */
    Validate.prototype.ApplyCompatibilityRules = function (decomposeContexts, errorContext) {
        new CompatibilityRuleExecutor(decomposeContexts, errorContext).ExecuteRules(errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
    };
    /**
     * Validates the root items are of the correct technicality for the validation request type i.e. cannot validate a technical root item if performing commercial validation)
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the decompose contexts that contain the root item
     * @param {CsErrorContext} errorContext DescriptionOfParam
     */
    Validate.prototype.ValidateTechnicalityOfRootItems = function (decomposeContexts, errorContext) {
        for (var c = 0; c < decomposeContexts.length; c++) {
            var decomposeContext = decomposeContexts[c];
            var validationType = decomposeContext.BoundaryCondition;
            if (validationType !== BoundaryConditionConstants.Commercial) {
                return;
            }
            var rootItemKey = decomposeContext.CompiledSpec.CompositionTree.Key;
            var rootOrderfolioItemIsTechnical = decomposeContext.CompiledSpec.TechnicalItems.indexOf(rootItemKey) !== -1;
            if (rootOrderfolioItemIsTechnical) {
                errorContext.RaiseCsError(400, ErrorCode.Validation.UnableToCommerciallyValidateCandidateWithTechnicalRoot);
                return;
            }
        }
    };
    return Validate;
}());
module.exports = Validate;

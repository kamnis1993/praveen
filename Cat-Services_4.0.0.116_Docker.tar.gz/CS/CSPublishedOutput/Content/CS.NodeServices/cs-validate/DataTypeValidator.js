"use strict";
/// <reference types="valid-url"/>
var ValidUrl = require("valid-url");
var Utilities = require("../cs-lib-utilities/Utilities");
/**
 * Contains methods for validating data types.
 */
var DataTypeValidator = /** @class */ (function () {
    function DataTypeValidator() {
    }
    /**
    * Validates that a value parses as a string data type.
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DataTypeValidator.IsValidString = function (value) {
        if (Utilities.IsNotDefined(value)) {
            return false;
        }
        // Anything can be parsed as a string, so it is valid
        return true;
    };
    /**
    * Validates that a value parses as a boolean data type.
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DataTypeValidator.IsValidBoolean = function (value) {
        if (Utilities.IsNotDefined(value)) {
            return false;
        }
        var stringValue = value.toString().toLowerCase().trim();
        var validBooleanStrings = ["true", "false"];
        if (validBooleanStrings.indexOf(stringValue) > -1) {
            return true;
        }
        return typeof value === "boolean" || value instanceof Boolean;
    };
    /**
    * Validates that a value parses as an integer data type.
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DataTypeValidator.IsValidInteger = function (value) {
        if (Utilities.IsNotDefined(value)) {
            return false;
        }
        // Integer validation should allow any integer number or any decimal number that equates to an integer, e.g 1.00, but not 1.01
        return Utilities.IsNumeric(value)
            && (value % 1) === 0; // Check there is no remainder after deviding by 1
    };
    /**
    * Validates that a value parses as a decimal data type.
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DataTypeValidator.IsValidDecimal = function (value) {
        if (Utilities.IsNotDefined(value)) {
            return false;
        }
        // Decimal validation should allow any numbers including integers
        return Utilities.IsNumeric(value);
    };
    /**
    * Validates that a value parses as a Uri data type.
    * @param {string} value the value to test
    * @returns {boolean} [true] if the value matches the date format
    */
    DataTypeValidator.IsValidUri = function (value) {
        if (Utilities.IsNotDefined(value)) {
            return false;
        }
        // Need to convert non-string values to string to compare using valid-uri
        value = value.toString();
        // The valid-url library returns the validated output on success or undefined on failure.
        return ValidUrl.isUri(value) === value;
    };
    return DataTypeValidator;
}());
module.exports = DataTypeValidator;

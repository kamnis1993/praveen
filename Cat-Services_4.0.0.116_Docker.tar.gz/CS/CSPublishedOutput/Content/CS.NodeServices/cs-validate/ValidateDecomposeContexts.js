"use strict";
var BoundaryConditionConstants = require("../cs-lib-constants/BoundaryConditionConstants");
var CharUseValidator = require("./CharUseValidator");
var CompatibilityRuleExecutor = require("./CompatibilityRuleExecutor");
var EntityCardinalityValidator = require("./EntityCardinalityValidator");
var EntityLinkValidator = require("./EntityLinkValidator");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var LimitValidator = require("./LimitValidator");
var OrderActions = require("../cs-lib-constants/OrderActions");
var PortfolioCardinalityValidator = require("./PortfolioCardinalityValidator");
var ReassignValidator = require("./ReassignValidator");
var Logger = require("../cs-logging/Logger");
var ValidateDecomposeContexts = /** @class */ (function () {
    function ValidateDecomposeContexts() {
    }
    /**
     * Validate a DecomposeContext set, specifically for cardinalities
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    ValidateDecomposeContexts.ValidateDecomposeContexts = function (decomposeContexts, errorContext) {
        // Only validate decompose contexts that have a root item that has been affected or is not deleted
        var toBeValidated = decomposeContexts.filter(function (context) {
            return context.Orderfolio[1][0].Action !== OrderActions.Delete;
        });
        ValidateDecomposeContexts.ValidateTechnicalityOfRootItems(toBeValidated, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        EntityCardinalityValidator.Validate(toBeValidated, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        CharUseValidator.Validate(toBeValidated, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        LimitValidator.Validate(toBeValidated, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        EntityLinkValidator.Validate(toBeValidated, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        ReassignValidator.Validate(decomposeContexts, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        // Portfolio wide validation needs to be done on all portfolio items even if they haven't been affected
        PortfolioCardinalityValidator.Validate(decomposeContexts, errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
        ValidateDecomposeContexts.ApplyCompatibilityRules(decomposeContexts, errorContext);
    };
    /**
 * Validates the root items are of the correct technicality for the validation request type i.e. cannot validate a technical root item if performing commercial validation)
 * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the decompose contexts that contain the root item
 * @param {CsErrorContext} errorContext DescriptionOfParam
 */
    ValidateDecomposeContexts.ValidateTechnicalityOfRootItems = function (decomposeContexts, errorContext) {
        Logger.debug(0, "Validation", "Validating technicality of root items");
        for (var c = 0; c < decomposeContexts.length; c++) {
            var decomposeContext = decomposeContexts[c];
            var validationType = decomposeContext.BoundaryCondition;
            if (validationType !== BoundaryConditionConstants.Commercial) {
                Logger.debug(1, "Validation", "Boundary condition is technical.");
                return;
            }
            var rootItemKey = decomposeContext.CompiledSpec.CompositionTree.Key;
            var rootOrderfolioItemIsTechnical = decomposeContext.CompiledSpec.TechnicalItems.indexOf(rootItemKey) !== -1;
            if (rootOrderfolioItemIsTechnical) {
                Logger.debug(1, "Validation", "Root orderfolio item is technical error.");
                errorContext.RaiseCsError(400, ErrorCode.Validation.UnableToCommerciallyValidateCandidateWithTechnicalRoot);
                return;
            }
        }
    };
    /*
* Apply compatibility rules and record any digressions
* @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
* @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
*/
    ValidateDecomposeContexts.ApplyCompatibilityRules = function (decomposeContexts, errorContext) {
        new CompatibilityRuleExecutor(decomposeContexts, errorContext).ExecuteRules(errorContext);
        if (errorContext.HasBreakingErrors) {
            return;
        }
    };
    return ValidateDecomposeContexts;
}());
module.exports = ValidateDecomposeContexts;

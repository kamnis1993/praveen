"use strict";
/// <reference types="node" />
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BoundaryCondition = require("../cs-lib-constants/BoundaryConditionConstants");
var DateStatus = require("../cs-lib-constants/DateStatus");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
var PhaseCodeAccessor = require("../cs-lib-composition/compiler/PhaseCodeAccessor");
var Logger = require("../cs-logging/Logger");
/**
 * A class which encapsulates validation of Entity Cardinalities for an order
 */
var EntityCardinalityValidator = /** @class */ (function () {
    function EntityCardinalityValidator() {
    }
    /**
     * Perform Entity Cardinality Validation on the DecomposeContext set of an order
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the DecomposeContext set of the order
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    EntityCardinalityValidator.Validate = function (decomposeContexts, errorContext) {
        var _this = this;
        if (errorContext.HasBreakingErrors) {
            return;
        }
        Logger.debug(0, "Validation", "Validating Entity Cardinalities");
        // Validate every DecomposeContext, stopping if a Process Error is raised (i.e. return false to every)
        decomposeContexts.every(function (decomposeContext) {
            _this.ValidateDecomposeContext(decomposeContext, errorContext);
            return !errorContext.HasBreakingErrors;
        });
    };
    /**
     * Perform Entity Cardinality Validation on a single DecomposeContext
     * @param {CsTypes.DecomposeContext} decomposeContext the DecomposeContext to validate
     * @param {CsErrorContext} errorContext the CsErrorContext into which validation and process errors should be recorded
     */
    EntityCardinalityValidator.ValidateDecomposeContext = function (decomposeContext, errorContext) {
        // Loop through the EntityCardinality table
        decomposeContext.CompiledSpec.CardinalityLookups.EntityCardinalities.forEach(function (entityRelation) {
            if (decomposeContext.CompiledSpec.EntityDates[entityRelation.ChildKey].DateStatus !== DateStatus.Available) {
                return;
            }
            var parentKey = entityRelation.ParentKey.toString();
            var parentOrderfolioItemSet = decomposeContext.Orderfolio[parentKey];
            if (Utilities.IsNotDefined(parentOrderfolioItemSet, true)) {
                return;
            }
            // Find some child information
            var templates = Utilities.GetDeepValue(decomposeContext, 'CompiledSpec.EntityTemplateLookup', {});
            var childTemplate = templates[entityRelation.ChildKey.toString()];
            var childInfo = {
                ChildId: (Utilities.IsDefined(childTemplate) ? childTemplate.EntityId : 'Not Found'),
                ExtraInfo: undefined
            };
            parentOrderfolioItemSet.forEach(function (parentOrderfolioItem) {
                if (parentOrderfolioItem.Action === OrderActions.Delete
                    || parentOrderfolioItem.Action === OrderActions.Reassign
                    || parentOrderfolioItem.IsInvalid) {
                    return;
                }
                var parentItemKey = parentOrderfolioItem.CompoundKey.Key.toString() + '-' + parentOrderfolioItem.CompoundKey.Index.toString();
                var numberOfChildren = 0;
                // Get the children for the parent, and then count the children specific to the relationship if parent key exists
                var parentsChildren = Utilities.asArray(decomposeContext.ParentToChildTable[parentItemKey]);
                if (parentsChildren.length > 0) {
                    parentsChildren.forEach(function (childLookup) {
                        if (childLookup.Key === entityRelation.ChildKey) {
                            var childOrderfolioItem = decomposeContext.Orderfolio[childLookup.Key][childLookup.Index];
                            if (childOrderfolioItem.IsInvalid) {
                                return;
                            }
                            if (!childOrderfolioItem.Action
                                || (childOrderfolioItem.Action !== OrderActions.Delete
                                    && childOrderfolioItem.Action !== OrderActions.Reassign)) {
                                numberOfChildren++;
                            }
                        }
                    });
                }
                // If this relation is technical and we are doing a commercial decompose and they have not supplied any children, ignore the relation?
                //still perform the validation if they have supplied technical children
                if (decomposeContext.BoundaryCondition === BoundaryCondition.Commercial) {
                    if (numberOfChildren === 0 && decomposeContext.CompiledSpec.TechnicalItems.indexOf(entityRelation.ChildKey) >= 0) {
                        return; // continue to next cardinality pair
                    }
                    if (decomposeContext.CompiledSpec.TechnicalItems.indexOf(entityRelation.ParentKey) >= 0) {
                        return; // continue to next cardinality pair
                    }
                }
                // Compare against Min and Max
                if (numberOfChildren < entityRelation.Min) {
                    var phaseCodes = PhaseCodeAccessor.GetRelationCardinalityPhaseCodes(decomposeContext.CompiledSpec, entityRelation.ChildKey, decomposeContext.BoundaryCondition);
                    var errMinId = errorContext.RaiseValidationError(ErrorCode.Validation.RelationCardinalityNotSatisfied, parentOrderfolioItem.EntityUniqueCode, parentOrderfolioItem.EntityId, null, null, null, phaseCodes);
                    childInfo.ExtraInfo = 'Less than minimum required, found ' + numberOfChildren + ' expected >= ' + entityRelation.Min;
                    errorContext.UpdateValidationError(errMinId, childInfo);
                    Logger.debug(1, "Validation", "Entity min Cardinality not met for parent " + parentOrderfolioItem.EntityId + ".", {
                        Min: entityRelation.Min,
                        Max: entityRelation.Max,
                        Actual: numberOfChildren,
                        Id: (Utilities.IsDefined(childTemplate) ? childTemplate.EntityId : "not found"),
                        ErrorInfo: "The minimum children required on "
                            + parentOrderfolioItem.EntityId +
                            " has not been met (required: "
                            + entityRelation.Min + ". actual: " +
                            numberOfChildren + ")."
                    });
                }
                if (entityRelation.Max !== 2147483647 && numberOfChildren > entityRelation.Max) { //number.MAX_VALUE
                    var errMaxId = errorContext.RaiseValidationError(ErrorCode.Validation.RelationCardinalityNotSatisfied, parentOrderfolioItem.EntityUniqueCode, parentOrderfolioItem.EntityId);
                    childInfo.ExtraInfo = 'Greater than maximum allowed, found ' + numberOfChildren + ' expected <= ' + entityRelation.Max;
                    errorContext.UpdateValidationError(errMaxId, childInfo);
                    Logger.debug(1, "Validation", "Entity Max Cardinality exceeded for parent " + parentOrderfolioItem.EntityId + ".", {
                        Min: entityRelation.Min,
                        Max: entityRelation.Max,
                        Actual: numberOfChildren,
                        ChildId: (Utilities.IsDefined(childTemplate) ? childTemplate.EntityId : "not found"),
                        ErrorInfo: "The number of children allowed on "
                            + parentOrderfolioItem.EntityId +
                            " has been exceeded (allowed: "
                            + entityRelation.Max + ". actual: " +
                            numberOfChildren + ")."
                    });
                }
            });
        });
    };
    return EntityCardinalityValidator;
}());
module.exports = EntityCardinalityValidator;

"use strict";
var CharValueValidator = require("./CharValueValidator");
var ErrorCode = require("../cs-lib-constants/ErrorCodes/ErrorCodes");
var OrderActions = require("../cs-lib-constants/OrderActions");
var Utilities = require("../cs-lib-utilities/Utilities");
var Logger = require("../cs-logging/Logger");
/**
 * Contains methods for validating the char uses on an orderfolio
 */
var CharUseValidator = /** @class */ (function () {
    function CharUseValidator() {
    }
    /**
     * Validates all the characteristic uses in the supplied decompose context to ensure that they exist in the specification and have the correct values / number of values
     * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the decompose contexts to validate
     * @param {CsErrorContext} errorContext the context in which any validation error should be raised if they are encountered
     */
    CharUseValidator.Validate = function (decomposeContexts, errorContext) {
        Logger.debug(0, "Validation", "Validating char uses");
        for (var c = 0; c < decomposeContexts.length; c++) {
            var decomposeContext = decomposeContexts[c];
            var orderfolio = decomposeContext.Orderfolio;
            var compiledSpecification = decomposeContext.CompiledSpec;
            for (var orderfolioKey in orderfolio) {
                var orderfolioItemSet = orderfolio[orderfolioKey];
                CharValueValidator.ValidateCardinality(orderfolioKey, decomposeContext, errorContext);
                for (var j = 0; j < orderfolioItemSet.length; j++) {
                    var orderfolioItem = orderfolioItemSet[j];
                    if (orderfolioItem.Action === OrderActions.Delete) {
                        Logger.debug(1, "Validation", "Skipping orderfolio item as the item action is 'delete'", {
                            OrderfolioItem: orderfolioItem
                        });
                        continue;
                    }
                    if (orderfolioItem.IsInvalid) {
                        Logger.debug(1, "Validation", "Skipping orderfolio item as the item is marked as invalid", {
                            OrderfolioItem: orderfolioItem
                        });
                        continue;
                    }
                    var characteristicUses = orderfolioItem.CharacteristicUses;
                    var userDefinedCharacteristicUses = orderfolioItem.UserDefinedCharacteristics;
                    for (var k = 0; k < characteristicUses.length; k++) {
                        var characteristicUse = characteristicUses[k];
                        if (!CharUseValidator.IsInDate(orderfolioKey, compiledSpecification, characteristicUse, orderfolioItem, decomposeContext.ActivationDate)) {
                            errorContext.RaiseValidationError(ErrorCode.Validation.OutOfDateCharacteristicUse, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId);
                            continue;
                        }
                        if (CharUseValidator.IsValidCharacteristicUse(orderfolioKey, compiledSpecification, characteristicUse, decomposeContext.ActivationDate)) {
                            CharValueValidator.ValidateValues(characteristicUse, orderfolioItem, decomposeContext, errorContext);
                            continue;
                        }
                        Logger.debug(2, "ValidateDecomposeContexts", "Invalid char use: " + characteristicUse.UseId + " - not in specification", {
                            CharUseId: characteristicUse.UseId,
                            Characteristic: characteristicUse.CharacteristicId,
                            OrderfolioItemUniqueCode: orderfolioItem.EntityUniqueCode,
                            EntityId: orderfolioItem.EntityId
                        });
                        errorContext.RaiseValidationError(ErrorCode.Validation.InvalidCharacteristicUse, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId);
                    }
                    for (var i = 0; i < userDefinedCharacteristicUses.length; i++) {
                        var udc = userDefinedCharacteristicUses[i];
                        if (CharUseValidator.IsValidCharacteristicUse(orderfolioKey, compiledSpecification, udc, decomposeContext.ActivationDate)) {
                            if (!CharUseValidator.IsInDate(orderfolioKey, compiledSpecification, udc, orderfolioItem, decomposeContext.ActivationDate)) {
                                errorContext.RaiseValidationError(ErrorCode.Validation.OutOfDateCharacteristicUse, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId);
                                continue;
                            }
                            // User defined characteristic uses also require regular expression validation of their values
                            var regExInfo = compiledSpecification.CharacteristicUseLookups.UseIdToRegexInfo[udc.UseId];
                            if (Utilities.IsDefined(regExInfo) && Utilities.IsDefined(regExInfo.RegularExpression)) {
                                CharValueValidator.ValidateValuesUsingRegularExpression(orderfolioItem, udc, regExInfo, errorContext, compiledSpecification);
                            }
                            var valueDataTypeGuid = compiledSpecification.CharacteristicUseLookups.UseIdToDataTypeGuid[udc.UseId];
                            CharValueValidator.ValidateValueType(orderfolioItem, udc, valueDataTypeGuid, errorContext, compiledSpecification);
                            continue;
                        }
                        errorContext.RaiseValidationError(ErrorCode.Validation.InvalidCharacteristicUse, orderfolioItem.EntityUniqueCode, orderfolioItem.EntityId);
                    }
                }
            }
        }
    };
    CharUseValidator.IsInDate = function (key, compiledSpecification, charUse, orderfolioItem, activationDate) {
        var charUseDictionary = compiledSpecification.CharacteristicUseLookups.ConfigurableDataDates[key];
        if (Utilities.IsNotDefined(charUseDictionary)) {
            return true;
        }
        var charUseDates;
        // The value in the dictionary is a list so we need to iterate over it to find the correct Characteristic
        for (var index in charUseDictionary) {
            var current = charUseDictionary[index];
            if (Utilities.IsDefined(current[charUse.UseId])) {
                charUseDates = current[charUse.UseId];
                break;
            }
        }
        // If no value dates were found thats fine just return true;
        if (Utilities.IsNotDefined(charUseDates)) {
            return true;
        }
        if (!Utilities.IsDateValidForDateRange(activationDate, Utilities.IsDefined(charUseDates.StartDate) ? charUseDates.StartDate : null, Utilities.IsDefined(charUseDates.EndDate) ? charUseDates.EndDate : null)) {
            Logger.debug(2, "Validation", "Char use: " + charUse.UseId + " - is out of date", {
                EntityUniqueCode: orderfolioItem.EntityUniqueCode,
                EntityId: orderfolioItem.EntityId,
                CharUse: charUse.UseId,
                UseStartDate: charUseDates.StartDate,
                UseEndDate: charUseDates.EndDate,
                ActivationDate: activationDate
            });
            return false;
        }
        return true;
    };
    /**
     * Determines if the supplied characteristic use is valid for a specification
     * @param {string} key the key of the entity that this char use resides in
     * @param {CsTypes.CompiledSpecification} compiledSpecification the compiled Specification that contains the list of valid char uses for entities
     * @param {CsTypes.CharacteristicUse} charUse the char use to check the validity of
     * @returns {boolean} true or false indicating if the char use is valid or not
     */
    CharUseValidator.IsValidCharacteristicUse = function (key, compiledSpecification, charUse, activationDate) {
        var validCharuses = compiledSpecification.CharacteristicUseLookups.UuidToSpecItem[key];
        if (!validCharuses) {
            Logger.debug(2, "ValidateDecomposeContexts", "Invalid char uses", {
                Message: "Could not find a spec item for the specified orderfolio key",
                OrderFolioKey: key,
                UuidToSpecItem: compiledSpecification.CharacteristicUseLookups.UuidToSpecItem
            });
            return false;
        }
        return validCharuses.some(function (validCharUseInfo) {
            return Utilities.IsDefined(charUse.UseId) &&
                Utilities.IsDefined(compiledSpecification.CharacteristicUseLookups.UseIdToCharacteristic[charUse.UseId]) &&
                (charUse.UseId.toLowerCase() === validCharUseInfo.CharacteristicUseId.toLowerCase());
        });
    };
    return CharUseValidator;
}());
module.exports = CharUseValidator;

"use strict";
/// <reference path="../cs-lib-types/CompiledTypes/CsTypes.d.ts" />
var BoundaryCondition = require("../cs-lib-constants/BoundaryConditionConstants");
var DateStatus = require("../cs-lib-constants/DateStatus");
var DecomposeGeneratedTypes = require("../cs-lib-constants/DecomposeGeneratedTypes");
var DecomposeActivities = require("../cs-lib-constants/DecomposeActivities");
var LodashUtilities = require("../cs-lib-utilities/LodashUtilities");
var Logger = require("../cs-logging/Logger");
var MergedActions = require("../cs-lib-constants/MergedActions");
var OrderActions = require("../cs-lib-constants/OrderActions");
var OrderfolioQueries = require("../cs-lib-composition/OrderfolioQueries");
var Utilities = require("../cs-lib-utilities/Utilities");
/*
 * Class contains properties and methods for inferring orderfolio items
 */
var Inferrer = /** @class */ (function () {
    function Inferrer() {
    }
    /**
    * Infers orderfolio items for orderfolio's in each of the supplied decompose contexts
    * @param {Array<CsTypes.DecomposeContext>} decomposeContexts the decompose contexts that contains the orderfolios to perform the inference on
    */
    Inferrer.InferOrderfolioItems = function (decomposeContexts, errorContext) {
        for (var decomposeContextIdx = 0; decomposeContextIdx < decomposeContexts.length; decomposeContextIdx++) {
            var decomposeContext = decomposeContexts[decomposeContextIdx];
            Inferrer.InferOrderfolioItemsForSingleContext(decomposeContext);
        }
    };
    /**
    * Infers orderfolio items for orderfolio's in the supplied decompose context
    * @param {CsTypes.DecomposeContext} decomposeContext -- the decompose context that contains the orderfolio to perform inference on
    */
    Inferrer.InferOrderfolioItemsForSingleContext = function (decomposeContext) {
        if (!OrderfolioQueries.IsRootOrderfolioItemInAffectedPortfolio(decomposeContext.Orderfolio)) {
            return;
        }
        Inferrer.InferEntities(decomposeContext);
        Inferrer.InferCharacteristics(decomposeContext);
    };
    /**
     * Infers the entities for orderfolio items on a decompose context
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    Inferrer.InferEntities = function (decomposeContext) {
        var relationCardinalities = decomposeContext.CompiledSpec.CardinalityLookups.EntityCardinalities;
        for (var relationIdx = 0; relationIdx < relationCardinalities.length; relationIdx++) {
            var cardinalityInfo = relationCardinalities[relationIdx];
            // If this relation is technical and we are doing a commercial decompose, ignore the relation
            if (decomposeContext.BoundaryCondition === BoundaryCondition.Commercial) {
                if (decomposeContext.CompiledSpec.TechnicalItems.indexOf(cardinalityInfo.ChildKey) >= 0) {
                    continue;
                } // continue to next cardinality pair
                if (decomposeContext.CompiledSpec.TechnicalItems.indexOf(cardinalityInfo.ParentKey) >= 0) {
                    continue;
                } // continue to next cardinality pair
            }
            var parentKey = cardinalityInfo.ParentKey;
            if (!OrderfolioQueries.IsActivityValidForOrderfolioItem(decomposeContext.CompiledSpec, parentKey, DecomposeActivities.Inference)) {
                continue;
            }
            var orderfolioItemSet = decomposeContext.Orderfolio[parentKey];
            if (!orderfolioItemSet) {
                continue;
            }
            for (var positionIdx = 0; positionIdx < orderfolioItemSet.length; positionIdx++) {
                var ofi = orderfolioItemSet[positionIdx];
                if (ofi.IsInvalid) {
                    continue;
                }
                Inferrer.InferChildEntities(ofi, decomposeContext, cardinalityInfo);
            }
        }
    };
    /**
     * Infers the characteristic uses for the orderfolio items on a decompose context
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     */
    Inferrer.InferCharacteristics = function (decomposeContext) {
        var keys = Object.keys(decomposeContext.Orderfolio);
        for (var keyIdx = 0; keyIdx < keys.length; keyIdx++) {
            var selectedKey = keys[keyIdx];
            if (!OrderfolioQueries.IsActivityValidForOrderfolioItem(decomposeContext.CompiledSpec, selectedKey, DecomposeActivities.Inference)) {
                continue;
            }
            // If this relation is technical and we are doing a commercial decompose, do no inference
            if (decomposeContext.BoundaryCondition === BoundaryCondition.Commercial) {
                if (decomposeContext.CompiledSpec.TechnicalItems.indexOf(selectedKey) >= 0) {
                    continue;
                }
            }
            var valueCardinalities = decomposeContext.CompiledSpec.CardinalityLookups.UuidToValue[selectedKey];
            if (!valueCardinalities) {
                continue;
            }
            var orderfolioItemSet = decomposeContext.Orderfolio[selectedKey];
            for (var postionIdx = 0; postionIdx < orderfolioItemSet.length; postionIdx++) {
                var orderfolioItem = orderfolioItemSet[postionIdx];
                if (orderfolioItem.IsInvalid) {
                    continue;
                }
                Inferrer.InferCharacteristicValues(orderfolioItemSet[postionIdx], decomposeContext, valueCardinalities);
            }
        }
    };
    /**
     * Infers the characteristic values for an orderfolio item
     * @param {CsTypes.OrderfolioItem} orderfolioItem The orderfolio item that contains the char uses to infer the values for
     * @param {CsTypes.DecomposeContext} decomposeContext The decompose context
     * @param {Array<CsTypes.ValueCardinality>} valueCardinalities The list of value cardinality for the orderfolio item
     */
    Inferrer.InferCharacteristicValues = function (orderfolioItem, decomposeContext, valueCardinalities) {
        if (orderfolioItem.Action === OrderActions.Delete || valueCardinalities.length < 1) {
            return;
        }
        var haveValuesBeenAdded = false;
        for (var c = 0; c < valueCardinalities.length; c++) {
            var valueCardinality = valueCardinalities[c];
            var charUseOnOrderfolioItem = Inferrer.GetCharacteristicUseFromOrderfolioItem(valueCardinality.UseId, orderfolioItem);
            if (!valueCardinality.InferableSetOfValues) {
                continue;
            }
            // If this is populated then replace all values with the values in the set
            // See ValueCardinality.InferableSetOfValues for more details
            var valuesToAdd = Inferrer.GetCharValuesToAdd(valueCardinality, charUseOnOrderfolioItem, decomposeContext);
            if (valuesToAdd.length < 1) {
                continue;
            }
            haveValuesBeenAdded = true;
            if (charUseOnOrderfolioItem) {
                charUseOnOrderfolioItem.Values = charUseOnOrderfolioItem.Values.concat(valuesToAdd);
                charUseOnOrderfolioItem.OrderItemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
            }
            else {
                // If a reassigned item has inferred characteristics, its action must be changed to reassignedupdate
                if (orderfolioItem.Action === OrderActions.Reassigned) {
                    orderfolioItem.Action = OrderActions.ReassignedUpdate;
                }
                orderfolioItem.CharacteristicUses.push({
                    Action: OrderActions.Modify,
                    UseId: valueCardinality.UseId,
                    Values: valuesToAdd,
                    OrderItemSource: OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId),
                    PortfolioItemSource: OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId)
                });
                Logger.debug(0, "Inferrer", "CharacteristicUse added to OrderfolioItem", {
                    EntityId: orderfolioItem.EntityId,
                    EntityUniqueCode: orderfolioItem.EntityUniqueCode,
                    CharacteristicUse: valuesToAdd
                });
            }
        }
        // Update the action hierarchy
        if (haveValuesBeenAdded) {
            OrderfolioQueries.EnsureActionHierarchy(decomposeContext, orderfolioItem);
        }
    };
    /**
     * Gets the values to add to the characteristic use
     * @param {CsTypes.ValueCardinality} valueCardinality The value cardinality
     * @param {CsTypes.CharacteristicUse} charUseOnOrderfolioItem The characteristic if it already exists
     * @param {CsTypes.DecomposeContext] decomposeContext The decompose context
     * @returns {}
     */
    Inferrer.GetCharValuesToAdd = function (valueCardinality, charUseOnOrderfolioItem, decomposeContext) {
        // If this is populated then replace all values with the values in the set
        // See ValueCardinality.InferableSetOfValues for more details
        var valuesToAdd = [];
        var existingValues = [];
        if (Utilities.IsDefined(charUseOnOrderfolioItem)) {
            existingValues = charUseOnOrderfolioItem.Values;
        }
        for (var charValueIdx = 0; charValueIdx < valueCardinality.InferableSetOfValues.length; charValueIdx++) {
            var valueToInfer = valueCardinality.InferableSetOfValues[charValueIdx];
            var existingValue = LodashUtilities.Find(existingValues, function (v) { return v.Value === valueToInfer; });
            if (Utilities.IsDefined(existingValue) && !OrderfolioQueries.IsDeleted(existingValue)) {
                continue;
            }
            valuesToAdd.push({
                Action: MergedActions.AddMissing,
                Value: valueCardinality.InferableSetOfValues[charValueIdx],
                ItemSource: OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId)
            });
        }
        return valuesToAdd;
    };
    /**
     * Gets the characteristic use from an orderfolio item that has a given use area and characteristic id
     * @param {string} useArea the use area to match against
     * @param {string} characteristicId the char id to match against
     * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item that contains the char uses to look through
     * @returns {CsTypes.CharacteristicUse} the char use with the matching use area and char id
     */
    Inferrer.GetCharacteristicUseFromOrderfolioItem = function (charUseId, orderfolioItem) {
        if (!orderfolioItem.CharacteristicUses) {
            return null;
        }
        for (var c = 0; c < orderfolioItem.CharacteristicUses.length; c++) // TODO: I don't like this scanning. We should fix the data so we can do a lookup.
         {
            var charUseOnOrderfolioItem = orderfolioItem.CharacteristicUses[c];
            if (charUseOnOrderfolioItem.UseId === charUseId) {
                return charUseOnOrderfolioItem;
            }
        }
        return null;
    };
    /**
    * Ensures that the orderfolio item passed in has the minimum number of children as specified in the supplied cardinality info
    * @param {CsTypes.OrderfolioItem} parentOrderfolioItem the parent orderfolio item to check the children of
    * @param {CsTypes.DecomposeContext} decomposeContext the decompose context that contains the orderfolio from which the number of children per orderfolio item can be determined
    * @param {CsTypes.EntityCardinality} cardinalityInfo cardinality information that must be satisfied by each of the supplied parent orderfolio items
    */
    Inferrer.InferChildEntities = function (parentOrderfolioItem, decomposeContext, cardinalityInfo) {
        if (parentOrderfolioItem.Action === OrderActions.Delete || parentOrderfolioItem.Action === OrderActions.Reassign) {
            return;
        }
        if (decomposeContext.CompiledSpec.EntityDates[cardinalityInfo.ChildKey].DateStatus !== DateStatus.Available) {
            return;
        }
        var parentToChildDictionaryKey = parentOrderfolioItem.CompoundKey.Key + '-' + parentOrderfolioItem.CompoundKey.Index;
        var childRelations = decomposeContext.ParentToChildTable[parentToChildDictionaryKey];
        var numberOfMissingChildren = 0;
        var actualNumberOfChildren = 0;
        if (childRelations) {
            actualNumberOfChildren = childRelations.filter(function (orderfolioItemLookup) {
                return (orderfolioItemLookup.Key === cardinalityInfo.ChildKey
                    && decomposeContext.Orderfolio[orderfolioItemLookup.Key.toString()][0].Action !== OrderActions.Reassign);
            }).length;
        }
        if (actualNumberOfChildren < cardinalityInfo.Min) {
            numberOfMissingChildren = cardinalityInfo.Min - actualNumberOfChildren;
        }
        if (numberOfMissingChildren <= 0) {
            return;
        }
        var template = decomposeContext.CompiledSpec.EntityTemplateLookup[cardinalityInfo.ChildKey.toString()];
        Inferrer.AddOrderfolioItemsToItemSet(numberOfMissingChildren, template, parentOrderfolioItem, decomposeContext, parentToChildDictionaryKey);
    };
    /**
    * Adds a number of the supplied orderfolio item to the orderfolio
    * @param {number} numberOfItemsToAdd the number of times to add this orderfolio item
    * @param {CsTypes.OrderfolioItem} orderfolioItem the orderfolio item to add
    * @param {CsTypes.OrderfolioItem} parentOrderfolioItem The parent of the item we are going to add
    * @param {CsTypes.DecomposeContext} decomposeContext the decompose context that contains the parent to child dictionary that should be updated when the new item is inserted
    * @param {string} parentToChildDictionaryKey the key to use when updating the parent to child dictionary
    */
    Inferrer.AddOrderfolioItemsToItemSet = function (numberOfItemsToAdd, orderfolioItem, parentOrderfolioItem, decomposeContext, parentToChildDictionaryKey) {
        if (numberOfItemsToAdd < 1) {
            return;
        }
        if (Utilities.IsNotDefined(parentOrderfolioItem.OrderItemId, true)) {
            // Need parent ID for DecomposeGenID so if we don't have one then generate one
            // This happens if the parent we are inferring on exists in the portfolio and not in the order
            parentOrderfolioItem.OrderItemId = Utilities.CreateID();
        }
        // Mark Reassigned entities that have inferred children as ReassignedUpdate
        if (parentOrderfolioItem.Action === OrderActions.Reassigned) {
            parentOrderfolioItem.Action = OrderActions.ReassignedUpdate;
        }
        for (var itemIdx = 0; itemIdx < numberOfItemsToAdd; itemIdx++) {
            var newOrderfolioItem = JSON.parse(JSON.stringify(orderfolioItem));
            newOrderfolioItem.OrderItemId = Utilities.CreateID();
            newOrderfolioItem.PortfolioItemId = Utilities.CreateID();
            newOrderfolioItem.EntityUniqueCode = newOrderfolioItem.OrderItemId;
            newOrderfolioItem.OrderItemSource = OrderfolioQueries.GetGeneratedItemSource(decomposeContext.OrderRequestId);
            newOrderfolioItem.PortfolioItemSource = newOrderfolioItem.OrderItemSource;
            newOrderfolioItem.ItemAdded = true;
            var existingOrderfolioItems = decomposeContext.Orderfolio[orderfolioItem.CompoundKey.Key];
            if (existingOrderfolioItems && existingOrderfolioItems.length > 0) {
                newOrderfolioItem.CompoundKey.Index = existingOrderfolioItems.length;
                existingOrderfolioItems.push(newOrderfolioItem);
            }
            else {
                newOrderfolioItem.CompoundKey.Index = 0;
                decomposeContext.Orderfolio[orderfolioItem.CompoundKey.Key] = [newOrderfolioItem];
            }
            var decomposeGenIndex = 0;
            if (newOrderfolioItem.CompoundKey.Index > 0) {
                decomposeGenIndex = OrderfolioQueries.FilterChildrenToParent(parentOrderfolioItem.CompoundKey, existingOrderfolioItems, decomposeContext, true).length;
            }
            newOrderfolioItem.DecomposeGenID = OrderfolioQueries.GetDecomposeGenID(DecomposeGeneratedTypes.Inference, [parentOrderfolioItem.OrderItemId, newOrderfolioItem.EntityId, decomposeGenIndex.toString()]);
            Logger.debug(0, "Inferrer", "Item Added to Order", {
                CompoundKey: newOrderfolioItem.CompoundKey,
                EntityId: newOrderfolioItem.EntityId,
                ParentEntityId: parentOrderfolioItem.EntityId
            });
            Inferrer.UpdateRelationshipDictionaries(decomposeContext.ParentToChildTable, decomposeContext.ChildToParentTable, parentToChildDictionaryKey, newOrderfolioItem);
        }
        // Now that we have added an item, make sure that our parents have the correct item action
        OrderfolioQueries.EnsureActionHierarchy(decomposeContext, parentOrderfolioItem);
    };
    /**
     * Updates the relationship dictionaries to include the relationship between the parentDictionaryKey and the childOrderfolioItem
     * @param {CsTypes.Dictionary<Array<CsTypes.OrderItemLookup>>} parentToChildDictionary the dictionary that holds the relationship between parent and child orderfolio items
     * @param {CsTypes.Dictionary<CsTypes.OrderItemLookup>} childToParentDictionary holds the relationship between a child orderfolio item and its parent
     * @param {string} parentToChildDictionaryKey the dictionary key for the parent entity
     * @param {CsTypes.OrderfolioItem} childOrderfolioItem the new orderfolio item that has been added to the orderfolio that caused the need for relationship tables to be updated
     */
    Inferrer.UpdateRelationshipDictionaries = function (parentToChildDictionary, childToParentDictionary, parentToChildDictionaryKey, childOrderfolioItem) {
        var childToParentDictionaryKey = childOrderfolioItem.CompoundKey.Key + '-' + childOrderfolioItem.CompoundKey.Index;
        var parentKeyParts = parentToChildDictionaryKey.split('-');
        if (!parentToChildDictionary[parentToChildDictionaryKey]) {
            parentToChildDictionary[parentToChildDictionaryKey] = [];
        }
        parentToChildDictionary[parentToChildDictionaryKey].push({ Key: childOrderfolioItem.CompoundKey.Key, Index: childOrderfolioItem.CompoundKey.Index });
        childToParentDictionary[childToParentDictionaryKey] = { Key: parentKeyParts[0], Index: parseInt(parentKeyParts[1]) };
    };
    return Inferrer;
}());
module.exports = Inferrer;

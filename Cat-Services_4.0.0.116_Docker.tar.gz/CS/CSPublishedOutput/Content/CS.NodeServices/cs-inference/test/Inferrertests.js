"use strict";
/// <reference types="mocha"/>
/// <reference types="chai"/>
/// <reference types="node"/>
Object.defineProperty(exports, "__esModule", { value: true });
var Inferrer = require("../Inferrer");
var chai = require("chai");
var fs = require("fs");
var CsErrorContext = require("../../cs-lib-types/CsErrorContext");
describe("when asking the inferrer to infer multiple decompose contexts", function () {
    var decomposeContexts;
    it("should ensure that any inferable char values get inferred and added to the orderfolio in the correct decompose context", function (done) {
        fs.readFile('cs-inference/test/data/DecomposeContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var errorContext = new CsErrorContext({});
            Inferrer.InferOrderfolioItems(decomposeContexts, errorContext);
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].EntityId).to.equal('x');
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].CharacteristicUses.length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].CharacteristicUses[0].UseId).to.equal('AAAA');
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].CharacteristicUses[0].Values.length).to.equal(2);
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].CharacteristicUses[0].Values[0].Value).to.equal('Red');
            chai.expect(decomposeContexts[0].Orderfolio['1'][0].CharacteristicUses[0].Values[1].Value).to.equal('Green');
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].EntityId).to.equal('y');
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].CharacteristicUses.length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].CharacteristicUses[0].UseId).to.equal('BBBB');
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].CharacteristicUses[0].Values.length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].CharacteristicUses[0].Values[0].Value).to.equal('Micro');
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].EntityId).to.equal('z');
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].CharacteristicUses.length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].CharacteristicUses[0].UseId).to.equal('CCCC');
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].CharacteristicUses[0].Values.length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].CharacteristicUses[0].Values[0].Value).to.equal('Copper');
            done();
        });
    });
    it("should ensure that any inferable entities get inferred and added to the orderfolio in the correct decompose context and the parent to child tables get updated", function (done) {
        fs.readFile('cs-inference/test/data/DecomposeContexts.json', { encoding: 'utf8' }, function (error, decomposeContextsFileContents) {
            decomposeContexts = JSON.parse(decomposeContextsFileContents);
            var errorContext = new CsErrorContext({});
            Inferrer.InferOrderfolioItems(decomposeContexts, errorContext);
            //assert first decompose context
            chai.expect(decomposeContexts[0].Orderfolio['2'].length).to.equal(3);
            chai.expect(decomposeContexts[0].Orderfolio['2'][0].EntityId).to.equal('y');
            chai.expect(decomposeContexts[0].ParentToChildTable['1-0'].length).to.equal(3);
            chai.expect(decomposeContexts[0].ChildToParentTable['2-0'].Key).to.equal('1');
            chai.expect(decomposeContexts[0].ChildToParentTable['2-1'].Key).to.equal('1');
            chai.expect(decomposeContexts[0].ChildToParentTable['2-2'].Key).to.equal('1');
            chai.expect(decomposeContexts[0].ParentToChildTable['2-0'].length).to.equal(1);
            chai.expect(decomposeContexts[0].ParentToChildTable['2-1'].length).to.equal(1);
            chai.expect(decomposeContexts[0].ParentToChildTable['2-2'].length).to.equal(1);
            chai.expect(decomposeContexts[0].Orderfolio['3'].length).to.equal(3);
            chai.expect(decomposeContexts[0].Orderfolio['3'][0].EntityId).to.equal('z');
            //assert second decompose context
            chai.expect(decomposeContexts[1].Orderfolio['2'].length).to.equal(1);
            chai.expect(decomposeContexts[1].Orderfolio['2'][0].EntityId).to.equal('b');
            chai.expect(decomposeContexts[1].ParentToChildTable['1-0'].length).to.equal(1);
            chai.expect(decomposeContexts[1].ChildToParentTable['2-0'].Key).to.equal('1');
            done();
        });
    });
});

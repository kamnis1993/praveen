var app = angular.module('dataExplorerApp', ['ngCookies']);
app.controller('deCtrl', function ($scope, $http, $cookies, $location) {
    $scope.Search = function () {
        $scope.AddToRecentSearches();
        $scope.SetCookies();
        var absUrl = $location.absUrl();
        var url = absUrl.replace("DataExplorer", "api/dataexplorer/getgraphdata");
        if (!$scope.search.Parent) {
            $scope.search.IncludeDescendents = false;
            $scope.search.TopLevelOnly = false;
        }
        var req = {
            method: "POST",
            url: url,
            headers: {
                "Content-Type": "application/json",
                "accept": "text/plain"
            },
            data: $scope.search
        };
        $http(req).then(function (response) {
            $scope.result = response.data;
        }, function (response) {
            $scope.result = "Error Occurred";
        });
    };
    $scope.ClearSearch = function () {
        $scope.search = {
            "Parent": "",
            "Key": "",
            "Value": "",
            "SortByKey": false,
            "IncludeDescendents": false,
            "EncodeValues": false,
            "TopLevelOnly": false
        };
        $scope.result = "";
    };
    $scope.AddToRecentSearches = function () {
        $scope.recentSearches.unshift($scope.CloneSearch($scope.search));
    };
    $scope.ClearRecentSearches = function () {
        $scope.recentSearches = [];
        $cookies.put("RecentSearches", JSON.stringify($scope.recentSearches));
    };
    $scope.RecallSearch = function (index) {
        $scope.search = $scope.CloneSearch($scope.recentSearches[index]);
    };
    $scope.CloneSearch = function (search) {
        return JSON.parse(JSON.stringify(search));
    };
    $scope.SetCookies = function () {
        $cookies.put("CurrentSearch", JSON.stringify($scope.search));
        $cookies.put("RecentSearches", JSON.stringify($scope.recentSearches));
    };
    $scope.GetCookies = function () {
        var search = $cookies.get("CurrentSearch");
        if (search) {
            $scope.search = JSON.parse(search);
        }
        var recentSearches = $cookies.get("RecentSearches");
        if (recentSearches) {
            $scope.recentSearches = JSON.parse(recentSearches);
        }
    };
    $scope.ClearSearch();
    $scope.recentSearches = [];
    $scope.GetCookies();
});

//# sourceMappingURL=DataExplorer.js.map

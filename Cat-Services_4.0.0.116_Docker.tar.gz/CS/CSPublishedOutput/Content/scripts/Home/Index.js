var app = angular.module('indexApp', []);
app.controller('homeCtrl', function ($scope, $http, $timeout, $location) {
    $scope.status = {
        DatastoreCssClass: "error",
        Version: "x",
        DatastoreStatus: "Polling",
        IsImporting: false,
        DataFile: "",
        CatalogDetails: {
            DateImported: "",
            DateExtracted: "",
            DatastoreName: "",
            LogicalCatalogId: "",
            TestSetId: "",
            CatalogVersion: "",
            CatalogJobId: "",
            DbServerName: "",
            DbServerDetail: "",
            PublishComment: ""
        },
        IsActive: false
    };
    $scope.PollStatus = function (interval) {
        var absUrl = $location.absUrl();
        var url = null;
        if (absUrl != null && absUrl.substr(absUrl.length - 1) == '/') {
            url = absUrl + "api/status";
        }
        else {
            url = absUrl + "/api/status";
        }
        var poller = function () {
            var req = {
                method: "GET",
                url: url,
                headers: {
                    "accept": "application/json"
                }
            };
            $http(req).then(function (r) {
                $scope.status = r.data;
                $timeout(poller, interval);
                $scope.status.DatastoreCssClass = $scope.status.IsActive === true ? "active" : "error";
            });
        };
        poller();
    };
    $scope.PollStatus(1200);
});

//# sourceMappingURL=Index.js.map

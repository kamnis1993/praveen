app.service('RecursiveTreeHandler', ['DataVisUtilities', function (DataVisUtilities) {
        var RecursiveTreeHandler = this;
        var topLevel = [
            "SMap_CopyConfigValue",
            "Component",
            "Package",
            "Bundle",
            "Promotion",
            "Rate",
            "Component_Group"
        ];
        var fields = [
            "Product_To_Charge",
            "Product_To_Product",
            "Product_To_Cost",
            "CBDiscounts",
            "Product_To_Charge_Group",
            "Charge_Relation",
            "Product_To_Discount_Group",
            "Discount_Relation",
            "ProductCandidate",
            "ChildEntity",
            "OrderCandidate",
            "ChildOrderItem",
            "CustomerPortfolio",
            "AffectedPortfolioItem"
        ];
        var childFields = [
            "Charge",
            "Product",
            "Cost",
            "Discount",
            "Charge_Group",
            "Discount_Group",
            "ChildEntity",
            "OrderItem",
            "ChildOrderItem",
            "AffectedPortfolioItem"
        ];
        var infoFields = [
            "Name",
            "ID",
            "Element_Guid",
            "Business_ID",
            "Effective_Start_Date",
            "Available_Start_Date",
            "Available_End_Date",
            "Effective_End_Date",
            "ActivationDate",
            "PortfolioItemID",
            "EntityID",
            "ItemAction",
            "ItemSource",
            "RequestID"
        ];
        RecursiveTreeHandler.Expand = function (d) {
            if (DataVisUtilities.CheckForHiddenChildren(d)) {
                for (var a = 0; a < fields.length; a++) {
                    var hiddenFieldName = "_" + fields[a];
                    if (d[hiddenFieldName]) {
                        d[fields[a]] = d[hiddenFieldName];
                        d[hiddenFieldName] = null;
                    }
                }
                for (var x = 0; x < fields.length; x++) {
                    if (d[fields[x]]) {
                        DataVisUtilities.ConvertToArray(d[fields[x]]).forEach(function (item) {
                            for (var y = 0; y < childFields.length; y++) {
                                if (item[childFields[y]]) {
                                    DataVisUtilities.ConvertToArray(item[childFields[y]]).forEach(function (object) {
                                        RecursiveTreeHandler.Expand(object);
                                    });
                                }
                            }
                        });
                    }
                }
            }
            if (DataVisUtilities.CheckForChildField(d)) {
                for (var y = 0; y < childFields.length; y++) {
                    if (d[childFields[y]]) {
                        DataVisUtilities.ConvertToArray(d[childFields[y]]).forEach(function (object) {
                            RecursiveTreeHandler.Expand(object);
                        });
                    }
                }
            }
            if (DataVisUtilities.CheckForTopLevel(d)) {
                for (var i = 0; i < topLevel.length; i++) {
                    DataVisUtilities.ConvertToArray(d[topLevel[i]]).forEach(function (item) {
                        for (var y = 0; y < fields.length; y++) {
                            var hiddenFieldName = "_" + fields[y];
                            if (item[hiddenFieldName]) {
                                item[fields[y]] = item[hiddenFieldName];
                                item[hiddenFieldName] = null;
                            }
                        }
                    });
                }
                for (var z = 0; z < topLevel.length; z++) {
                    if (d[topLevel[z]]) {
                        DataVisUtilities.ConvertToArray(d[topLevel[z]]).forEach(function (item) {
                            for (var y = 0; y < fields.length; y++) {
                                if (item[fields[y]]) {
                                    DataVisUtilities.ConvertToArray(item[fields[y]]).forEach(function (object) {
                                        RecursiveTreeHandler.Expand(object);
                                    });
                                }
                            }
                        });
                    }
                }
            }
        };
        RecursiveTreeHandler.ExpandNode = function (d) {
            if (DataVisUtilities.CheckForTopLevel(d)) {
                for (var x = 0; x < topLevel.length; x++) {
                    if (d[topLevel[x]]) {
                        DataVisUtilities.ConvertToArray(d[topLevel[x]]).forEach(function (item) {
                            for (var y = 0; y < fields.length; y++) {
                                var hiddenFieldName = "_" + fields[y];
                                if (item[hiddenFieldName]) {
                                    item[fields[y]] = item[hiddenFieldName];
                                    item[hiddenFieldName] = null;
                                }
                            }
                        });
                    }
                }
            }
            else {
                for (var i = 0; i < fields.length; i++) {
                    var hiddenFieldName = "_" + fields[i];
                    if (d[hiddenFieldName]) {
                        d[fields[i]] = d[hiddenFieldName];
                        d[hiddenFieldName] = null;
                    }
                }
            }
        };
        RecursiveTreeHandler.Collapse = function (d) {
            var hasTopLevel = false;
            if (d.children) {
                for (var i = 0; i < topLevel.length; i++) {
                    if (d[topLevel[i]]) {
                        hasTopLevel = true;
                        DataVisUtilities.ConvertToArray(d[topLevel[i]]).forEach(function (item) {
                            for (var x = 0; x < fields.length; x++) {
                                if (item[fields[x]]) {
                                    var hiddenFieldName = "_" + fields[x];
                                    item[hiddenFieldName] = item[fields[x]];
                                    DataVisUtilities.ConvertToArray(item[fields[x]]).forEach(function (childItem) {
                                        for (var y = 0; y < childFields.length; y++) {
                                            if (childItem[childFields[y]]) {
                                                DataVisUtilities.ConvertToArray(childItem[childFields[y]]).forEach(function (object) {
                                                    RecursiveTreeHandler.Collapse(object);
                                                });
                                            }
                                        }
                                    });
                                    item[fields[x]] = null;
                                }
                            }
                        });
                    }
                }
            }
            if (!hasTopLevel && d.children) {
                for (var x = 0; x < fields.length; x++) {
                    if (d[fields[x]]) {
                        var hiddenFieldName = "_" + fields[x];
                        d[hiddenFieldName] = d[fields[x]];
                        DataVisUtilities.ConvertToArray(d[fields[x]]).forEach(function (item) {
                            for (var y = 0; y < childFields.length; y++) {
                                if (item[childFields[y]]) {
                                    DataVisUtilities.ConvertToArray(item[childFields[y]]).forEach(function (object) {
                                        RecursiveTreeHandler.Collapse(object);
                                    });
                                }
                            }
                        });
                        d[fields[x]] = null;
                    }
                }
            }
        };
        RecursiveTreeHandler.CollapseNode = function (d) {
            if (DataVisUtilities.CheckForTopLevel(d) && d.children) {
                for (var x = 0; x < topLevel.length; x++) {
                    DataVisUtilities.ConvertToArray(d[topLevel[x]]).forEach(function (item) {
                        for (var y = 0; y < fields.length; y++) {
                            var hiddenFieldName = "_" + fields[y];
                            if (item[fields[y]]) {
                                item[hiddenFieldName] = item[fields[y]];
                                item[fields[y]] = null;
                            }
                        }
                    });
                }
            }
            else if (d.children) {
                for (var i = 0; i < fields.length; i++) {
                    var hiddenFieldName = "_" + fields[i];
                    if (d[fields[i]]) {
                        d[hiddenFieldName] = d[fields[i]];
                        d[fields[i]] = null;
                    }
                }
            }
        };
        RecursiveTreeHandler.Search = function (searchValue, node) {
            if (searchValue === node.Name || searchValue === node._meta.ID) {
                console.log("Found Target");
                node.foundTarget = true;
                return;
            }
            else if (node.children) {
                for (var x = 0; x < fields.length; x++) {
                    if (node[fields[x]]) {
                        DataVisUtilities.ConvertToArray(node[fields[x]]).forEach(function (item) {
                            for (var y = 0; y < childFields.length; y++) {
                                if (item[childFields[y]]) {
                                    DataVisUtilities.ConvertToArray(item[childFields[y]]).forEach(function (object) {
                                        return RecursiveTreeHandler.Search(searchValue, object);
                                    });
                                }
                            }
                        });
                    }
                }
            }
        };
        RecursiveTreeHandler.BuildChildren = function (d) {
            var result = [];
            var hasTopLevel = false;
            for (var x = 0; x < topLevel.length; x++) {
                if (d[topLevel[x]]) {
                    hasTopLevel = true;
                    DataVisUtilities.ConvertToArray(d[topLevel[x]]).forEach(function (item) {
                        RecursiveTreeHandler.BuildFields(result, item);
                    });
                }
            }
            if (!hasTopLevel) {
                RecursiveTreeHandler.BuildFields(result, d);
            }
            return result;
        };
        RecursiveTreeHandler.BuildFields = function (result, item) {
            for (var y = 0; y < fields.length; y++) {
                if (item[fields[y]]) {
                    DataVisUtilities.ConvertToArray(item[fields[y]]).forEach(function (childItem) {
                        var _loop_1 = function (z) {
                            if (childItem[childFields[z]]) {
                                parent = childItem;
                                var type_1 = childFields[z];
                                DataVisUtilities.ConvertToArray(childItem[childFields[z]]).forEach(function (object) {
                                    object.cardinality = RecursiveTreeHandler.CheckCardinality(object, parent);
                                    object.info = RecursiveTreeHandler.GetItemInfo(object, type_1);
                                    result.push(object);
                                });
                            }
                        };
                        var parent;
                        for (var z = 0; z < childFields.length; z++) {
                            _loop_1(z);
                        }
                    });
                }
            }
        };
        RecursiveTreeHandler.CheckCardinality = function (d, parent) {
            var result = "";
            if (parent) {
                DataVisUtilities.ConvertToArray(parent).forEach(function (object) {
                    if (object.Min_Occurs !== undefined && object.Max_Occurs !== undefined) {
                        result = object.Min_Occurs + ":" + object.Max_Occurs;
                    }
                });
            }
            return result;
        };
        RecursiveTreeHandler.GetItemInfo = function (item, type) {
            var result = "";
            var itemInfo = [];
            if (type) {
                itemInfo.push("Type: " + type);
            }
            var hasTopLevel = false;
            for (var x = 0; x < topLevel.length; x++) {
                if (item[topLevel[x]]) {
                    hasTopLevel = true;
                    itemInfo.push("Type: " + topLevel[x]);
                    DataVisUtilities.ConvertToArray(item[topLevel[x]]).forEach(function (item) {
                        RecursiveTreeHandler.GetInfoFields(itemInfo, item);
                    });
                }
            }
            if (!hasTopLevel) {
                RecursiveTreeHandler.GetInfoFields(itemInfo, item);
            }
            var count = 1;
            var xOffset = 30;
            var yOffset = 30;
            var lineHeight = 12;
            for (var k = 0; k < itemInfo.length; k++) {
                var x = xOffset;
                var y = yOffset + (count * lineHeight);
                result += "<tspan x='" + x + "' y='" + y + "'>" + itemInfo[k] + "</tspan>";
                count++;
            }
            return result;
        };
        RecursiveTreeHandler.GetInfoFields = function (itemInfo, item) {
            for (var j = 0; j < infoFields.length; j++) {
                if (item[infoFields[j]]) {
                    itemInfo.push(infoFields[j] + ": " + item[infoFields[j]]);
                }
            }
        };
    }]);

//# sourceMappingURL=RecursiveTreeHandler.js.map

var angular;
var d3;
var app = angular.module('dataVisualiserApp', ['ngCookies', 'jsonFormatter', 'angularSpinkit', 'ui.codemirror']);
app.directive('onReadFile', function ($parse) {
    return {
        restrict: 'A',
        scope: false,
        link: function (scope, element, attrs) {
            element.bind('change', function (e) {
                var onFileReadFn = $parse(attrs.onReadFile);
                var reader = new FileReader();
                reader.onload = function () {
                    var fileContents = reader.result;
                    scope.$apply(function () {
                        onFileReadFn(scope, { 'contents': fileContents });
                    });
                };
                reader.readAsText(element[0].files[0]);
            });
        }
    };
});
app.directive('onResize', ['$window', function ($window) {
        return { link: link };
        function link(scope) {
            scope.resize();
            angular.element($window).bind('resize', function () {
                scope.resize(true);
            });
        }
    }]);
app.controller('dvCtrl', ['$scope', '$http', '$cookies', '$location', 'DataVisUtilities', 'RecursiveTreeHandler', '$window',
    function ($scope, $http, $cookies, $location, DataVisUtilities, RecursiveTreeHandler, $window) {
        $scope.editorOptions = {
            lineWrapping: true,
            lineNumbers: true,
            readOnly: true,
            mode: "json",
        };
        $scope.refresh = true;
        $scope.headerShown = true;
        $scope.searchShown = false;
        $scope.resultsShown = false;
        $scope.visualiserShown = true;
        $scope.hasResult = false;
        $scope.viewMode = 2;
        $scope.bypassCache = true;
        var defaultUrl = 'api/ordercandidate/decompose';
        var absUrl = $location.absUrl();
        $scope.rootUrl = absUrl.toLowerCase().replace("datavisualiser", "");
        $scope.requestUrl = $scope.rootUrl + defaultUrl;
        $scope.EDResults = [];
        var width = window.innerWidth;
        var height = window.innerHeight;
        var i = 0, duration = 0, root, tree, diagonal, svg, menu;
        BuildContextMenuItems();
        SetupScopeFields();
        $scope.requestTypes = [{ name: "POST" }, { name: "GET" },];
        $scope.messageFormats = [{ name: "application/json" }, { name: "application/xml" },];
        $scope.resize = function (iswindowResize) {
            if (iswindowResize === void 0) { iswindowResize = false; }
            if ($scope.headerShown) {
                $scope.rsWindowHeight = 600;
            }
            else {
                var searchHeight = $scope.searchShown ? 36 : 0;
                var rootGuidsHeight = $scope.activeTab == 2 || $scope.activeTab == 3 ? 37 : 0;
                $scope.rsWindowHeight = window.innerHeight - 240 - searchHeight - rootGuidsHeight;
                if (iswindowResize) {
                    $scope.$digest();
                }
            }
        };
        $scope.$watch("searchShown", function () { $scope.resize(); });
        $scope.$watch("activeTab", function () { $scope.resize(); });
        $scope.gotoTab = function (tab) {
            $scope.activeTab = tab;
            switch (tab) {
                case 0:
                    $scope.GotoRequest();
                    break;
                case 1:
                    $scope.UpdateTextResult($scope.originalResponse);
                    $scope.BuildTree($scope.originalResponse);
                    break;
                case 2:
                    $scope.GetProductSpec();
                    break;
                case 3:
                    $scope.GetCompiledSpec();
                    break;
                case 4:
                    break;
                case 5:
                    $scope.UpdateTextResult($scope.currentEDetail.JsonResult);
                    break;
            }
        };
        $scope.ToggleExpandTraces = function () {
            $scope.expandAllTraces = !$scope.expandAllTraces;
            var expand = function (traceEvents) {
                for (var i_1 = 0; i_1 < traceEvents.length; i_1++) {
                    var te = traceEvents[i_1];
                    te.expand = $scope.expandAllTraces;
                    if (te.TraceEvents !== null && te.TraceEvents.length > 0) {
                        expand(te.TraceEvents);
                    }
                }
            };
            expand($scope.diagnosticsData.TraceEvents);
        };
        $scope.toggleViewMode = function (type) {
            if (type == "tree") {
                $scope.viewMode = $scope.viewMode == 2 ? 3 : 2;
            }
            if (type == "text") {
                $scope.viewMode = $scope.viewMode == 2 ? 1 : 2;
            }
        };
        $scope.GotoRequest = function () {
            var requestBody = $scope.postData;
            var requestJson = JSON.parse(requestBody);
            $scope.BuildTree(requestJson);
            $scope.UpdateTextResult(requestJson);
        };
        $scope.SetViewTab = function (tab) {
            $scope.viewTab = tab;
            $cookies.put('viewTab', $scope.viewTab);
        };
        $scope.SetDiagnosticsView = function (tab) {
            $scope.diagnosticsView = tab;
        };
        $scope.DisplayFileContents = function (contents) {
            $scope.postData = contents;
        };
        $scope.Reset = function () {
            $scope.currentEntityGuid = "";
        };
        $scope.Send = function () {
            if ($scope.requestUrl === "") {
                return alert("No API url entered");
            }
            var contentType = $scope.postData.charAt(0) == "<" ? 'application/xml' : 'application/json';
            var req;
            if ($scope.typeOfRequest === 'POST') {
                req = {
                    method: $scope.typeOfRequest,
                    url: $scope.requestUrl,
                    dataType: 'json',
                    data: $scope.postData,
                    headers: {
                        'Content-Type': contentType,
                        'Accept': 'application/json',
                        'IncludeDiagnostics': 'true',
                        'BypassCaching': $scope.bypassCache
                    }
                };
            }
            else if ($scope.typeOfRequest === 'GET') {
                req = {
                    method: $scope.typeOfRequest,
                    url: $scope.requestUrl,
                    headers: {
                        'Accept': 'application/json',
                        'IncludeDiagnostics': 'true',
                        'BypassCaching': $scope.bypassCache
                    }
                };
            }
            $scope.request = req;
            $scope.loading = true;
            $http(req).then(function (response) {
                if (response.data) {
                    $scope.originalResponse = response.data;
                }
                else {
                    $scope.originalResponse = response;
                }
                var result = $scope.originalResponse;
                $scope.UpdateTextResult(result);
                $scope.BuildTree(result);
                $scope.resultsShown = true;
                $scope.errors = "";
                $scope.loading = false;
                $scope.traceRequestId = response.headers('Request-Id');
                $scope.GetDiagnosticsData($scope.traceRequestId);
                SaveSendOptions();
                $scope.headerShown = false;
                $scope.hasResult = true;
                $scope.activeTab = 1;
                $scope.resize();
            }, function (response) {
                $scope.errors = response;
                $scope.requestStatus = "Error";
                $scope.loading = false;
                $scope.headerShown = true;
                $scope.resultsShown = false;
            });
        };
        $scope.Indent = function (zOrder) {
            var indent = "";
            for (var i = 0; i < zOrder; i++) {
                indent += "<ul><li>";
            }
            return indent;
        };
        $scope.Outdent = function (zOrder) {
            var indent = "";
            for (var i = 0; i < zOrder; i++) {
                indent += "</li></ul>";
            }
            return indent;
        };
        $scope.UpdateTextResult = function (result) {
            $scope.jsonResult = result;
            $scope.rawResult = JSON.stringify($scope.jsonResult, null, 2);
            $scope.SetViewTab(0);
        };
        $scope.GetDiagnosticsData = function (traceRequestId) {
            var req = {
                method: "GET",
                url: $scope.rootUrl + "api/diagnostics/" + traceRequestId,
                headers: { 'Accept': 'application/json' }
            };
            $http(req).then(function (response) {
                if (response.data) {
                    $scope.diagnosticsData = response.data;
                }
                else {
                    $scope.diagnosticsData = response;
                }
                if ($scope.diagnosticsData.RequestContext != null) {
                    $scope.currentEntityGuid = $scope.diagnosticsData.RequestContext.RootEntityGuids[0];
                }
                $scope.UpdateDiagnostics();
            });
        };
        $scope.UpdateDiagnostics = function () {
            $scope.jsonDiagnostics = $scope.diagnosticsData;
            $scope.rawDiagnostics = JSON.stringify($scope.jsonDiagnostics, null, 2);
            $scope.TraceEvents = $scope.diagnosticsData.TraceEvents;
            $scope.TraceEventCategories = $scope.diagnosticsData.TraceEvents.reduce(function (sum, te) {
                if (sum.indexOf(te.Category) < 0)
                    sum.push(te.Category);
                return sum;
            }, []);
            $scope.searchTraceEventCategory = "All";
            $scope.diagnosticsView = 2;
            if ($scope.TraceEvents != null) {
                $scope.SetTraceContext($scope.TraceEvents[0]);
            }
        };
        $scope.SetTraceContext = function (traceEvent) {
            if ($scope.TraceEvents == null || traceEvent == null) {
                $scope.traceEventContext = {};
                $scope.rawTraceEventContext = "";
                return;
            }
            $scope.SelectedTraceEvent = traceEvent.Index;
            $scope.traceEventContext = traceEvent.Context;
            $scope.rawTraceEventContext = JSON.stringify($scope.traceEventContext, null, 2);
        };
        $scope.Search = function () {
            $scope.searchCount = 0;
            var search = function (traceEvents) {
                for (var i = 0; i < traceEvents.length; i++) {
                    var te = traceEvents[i];
                    console.log("searching " + te.Index);
                    te.found = false;
                    if ($scope.searchTraceEventCategory != "All" &&
                        $scope.searchTraceEventCategory != te.Category) {
                        continue;
                    }
                    if (te.Message.toLowerCase().indexOf($scope.searchValue.toLowerCase()) > -1) {
                        te.found = true;
                        $scope.searchCount++;
                        continue;
                    }
                    for (var key in te.Context) {
                        if (te.Context.hasOwnProperty(key)
                            && (typeof te.Context[key] === 'string' || te.Context[key] instanceof String)
                            && te.Context[key].toLowerCase().indexOf($scope.searchValue.toLowerCase()) > -1) {
                            console.log("found in context");
                            te.found = true;
                            $scope.searchCount++;
                            break;
                        }
                    }
                    if (te.TraceEvents != null && te.TraceEvents.length > 0) {
                        search(te.TraceEvents);
                    }
                }
            };
            search($scope.diagnosticsData.TraceEvents);
        };
        $scope.ClearSearch = function () {
            $scope.searchCount = null;
            var clear = function (traceEvents) {
                for (var i = 0; i < traceEvents.length; i++) {
                    var te = traceEvents[i];
                    te.found = false;
                    if (te.TraceEvents != null && te.TraceEvents.length > 0) {
                        clear(te.TraceEvents);
                    }
                }
            };
            clear($scope.diagnosticsData.TraceEvents);
        };
        $scope.GetSpec = function (entityGuid) {
            $scope.currentEntityGuid = entityGuid;
            if ($scope.activeTab == 2) {
                $scope.GetProductSpec();
            }
            else if ($scope.activeTab == 3) {
                $scope.GetCompiledSpec();
            }
        };
        $scope.GetProductSpec = function () {
            if (!$scope.currentEntityGuid) {
                return alert("Missing current Entity Guid");
            }
            var req = {
                method: 'GET',
                url: $scope.rootUrl + 'api/find/productspecification/guid/' + $scope.currentEntityGuid,
                headers: { 'Accept': 'application/json' }
            };
            $scope.loading = true;
            $http(req).success(function (response) {
                $scope.UpdateTextResult(response);
                $scope.BuildTree(response);
                $scope.errors = "";
                $scope.loading = false;
            }).error(function (response) {
                $scope.errors = response;
                $scope.loading = false;
            });
        };
        $scope.GetCompiledSpec = function () {
            if (!$scope.currentEntityGuid) {
                return alert("Missing current Entity Guid");
            }
            var req = {
                method: 'GET',
                url: $scope.rootUrl + 'api/internal/find/compiled/guid/' + $scope.currentEntityGuid,
                headers: {
                    'Accept': 'application/json',
                    'IncludeDiagnostics': 'true'
                }
            };
            $scope.loading = true;
            $http(req).success(function (response) {
                $scope.UpdateTextResult(response);
                $scope.errors = "";
                $scope.loading = false;
            }).error(function (response) {
                $scope.errors = response;
                $scope.loading = false;
            });
        };
        $scope.BuildTree = function (input) {
            var mydata = JSON.parse(JSON.stringify(input));
            if (!mydata) {
                return alert("Missing data for Treeview");
            }
            d3.select("svg").remove();
            svg = d3.select("#treeview").append("svg")
                .call(d3.behavior.zoom().on("zoom", function () {
                svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")");
            })).on("dblclick.zoom", null)
                .attr("viewBox", "0 0 " + width + " " + (height * 2))
                .append("g")
                .attr('preserveAspectRatio', 'xMinYMid')
                .attr('transform', 'translate(' + width / 2 + ',' + 20 + ')');
            tree = d3.layout.tree()
                .nodeSize([100, height])
                .children(function (d) {
                var nodes = RecursiveTreeHandler.BuildChildren(d);
                return nodes;
            });
            diagonal = d3.svg.diagonal().projection(function (d) { return [d.x, d.y]; });
            if (mydata.data === undefined) {
                mydata = DataVisUtilities.ConvertToArray(mydata);
            }
            else {
                mydata = DataVisUtilities.ConvertToArray(mydata.data);
            }
            root = mydata[0];
            if (root == undefined) {
                return;
            }
            root.info = RecursiveTreeHandler.GetItemInfo(root, null);
            var entityId = DataVisUtilities.GetEntityID(root);
            if (entityId !== undefined) {
                $scope.currentEntityGuid = entityId;
            }
            root.x = width / 2;
            root.y = 0;
            root.x0 = width / 2;
            root.y0 = 0;
            Update(root);
        };
        $scope.ExpandAll = function () {
            RecursiveTreeHandler.Expand(root);
            Update(root);
        };
        $scope.CollapseAll = function () {
            RecursiveTreeHandler.Collapse(root);
            Update(root);
        };
        $scope.Export = function () {
            var request;
            if ($scope.typeOfRequest === "POST") {
                request = $scope.postData;
            }
            var postContent = {
                RequestSummary: {
                    Url: $scope.requestUrl,
                    Host: $scope.rootUrl,
                    TraceId: $scope.traceRequestId,
                    RootEntities: $scope.diagnosticsData.RequestContext.RootEntityGuids
                },
                Request: request,
                Response: $scope.originalResponse,
                Errors: $scope.errors.data
            };
            CallExportPostApi(postContent);
        };
        function CallExportPostApi(content) {
            $scope.exportLoading = true;
            var res = $http.post($scope.rootUrl + "api/diagnostics/export", content, { responseType: 'arraybuffer' });
            res.success(function (exportResponse) {
                var a = document.createElement('a');
                var blob = new Blob([exportResponse], { 'type': 'application/zip' });
                a.href = URL.createObjectURL(blob);
                a.download = "Export.zip";
                a.click();
                a.remove();
            });
            res.error(function (exportResponse) {
                return alert(HandleResponse(exportResponse));
            });
        }
        function HandleResponse(response) {
            if (response.data) {
                return JSON.stringify(response.data, null, 2);
            }
            else {
                return JSON.stringify(response, null, 2);
            }
        }
        function Update(source) {
            var nodes = tree.nodes(root).reverse();
            var links = tree.links(nodes);
            nodes.forEach(function (d) { d.y = d.depth * 150; });
            var node = svg.selectAll("g.node")
                .data(nodes, function (d) { return d.id || (d.id = ++i); });
            var nodeEnter = node.enter().append("g")
                .attr("class", "node")
                .attr("transform", function (d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
                .on("mouseover", function (d) {
                var g = d3.select(this);
                g.append("rect")
                    .classed('popup', true)
                    .attr("x", "25px")
                    .attr("y", "25px")
                    .attr("rx", "10px")
                    .attr("ry", "10px")
                    .attr("width", "300px")
                    .attr("height", "90px")
                    .attr("fill", "#f1f1f1");
                g.append('text')
                    .classed('popupText', true)
                    .attr('x', 20)
                    .attr('y', -20)
                    .html(function (d) { return d.info; });
            })
                .on("mouseout", function () {
                d3.select(this).select('rect.popup').remove();
                d3.select(this).select('text.popupText').remove();
            })
                .on('mousedown', d3.contextMenu(menu));
            nodeEnter.append("rect")
                .attr("x", "-45px")
                .attr("y", "-10px")
                .attr("rx", "10px")
                .attr("ry", "10px")
                .attr("width", "90px")
                .attr("height", "60px")
                .attr("fill", "white");
            nodeEnter.append("image")
                .attr("href", function (d) { return DataVisUtilities.GetImage(d); })
                .attr("x", "-18px")
                .attr("y", "-8px")
                .attr("width", "36px")
                .attr("height", "36px");
            nodeEnter.append("text")
                .attr("dy", "40px")
                .attr("fill", "#555")
                .attr("text-anchor", "middle")
                .text(function (d) { return DataVisUtilities.GetName(d); });
            nodeEnter.append("text")
                .attr("dy", "-16px")
                .attr("dx", "-26px")
                .attr("fill", "#555")
                .attr("text-anchor", "right")
                .text(function (d) {
                return d.cardinality;
            });
            var nodeUpdate = node.transition()
                .duration(duration)
                .attr("transform", function (d) { return "translate(" + d.x + "," + d.y + ")"; });
            nodeUpdate.select("text")
                .style("fill-opacity", 1)
                .style("font-weight", function (d) {
                if (DataVisUtilities.CheckForHiddenChildren(d) || d.foundTarget === true) {
                    return "bold";
                }
                if (source === d && DataVisUtilities.CheckForTopLevel(d)) {
                    var toplevel = DataVisUtilities.GetTopLevel(d);
                    if (DataVisUtilities.CheckForHiddenChildren(toplevel)) {
                        return "bold";
                    }
                }
            })
                .style("font-size", function (d) {
                if (d.foundTarget === true) {
                    return "60px";
                }
            });
            var nodeExit = node.exit().transition()
                .duration(duration)
                .attr("transform", function (d) { return "translate(" + source.x + "," + source.y + ")"; })
                .remove();
            nodeExit.select("text")
                .style("fill-opacity", 0);
            var link = svg.selectAll("path.link")
                .data(links, function (d) { return d.target.id; });
            link.enter().insert("path", "g")
                .attr("class", "link")
                .attr("d", function (d) {
                var o = { x: source.y0, y: source.x0 };
                return diagonal({ source: o, target: o });
            });
            link.transition()
                .duration(duration)
                .attr("d", diagonal);
            link.exit().transition()
                .duration(duration)
                .attr("d", function (d) {
                var o = { x: d.source.x, y: d.source.y };
                return diagonal({ source: o, target: o });
            })
                .remove();
            nodes.forEach(function (d) {
                d.x0 = d.y;
                d.y0 = d.x;
            });
        }
        $scope.GetEDResults = function (x) {
            if ($scope.activeTab != 5) {
                $scope.activeTab = 5;
            }
            $scope.currentEDetail = x;
            $scope.UpdateTextResult(x.JsonResult);
        };
        function IsEDetailsExist(entityName) {
            var Result = {
                status: false,
                index: -1
            };
            for (var i = 0; i < $scope.EDResults.length; i++) {
                var d = $scope.EDResults[i];
                if (d.Title === entityName) {
                    Result.status = true;
                    Result.index = i;
                    break;
                }
            }
            return Result;
        }
        function UpdateEntityDetailsResult(result, entityName, entityID) {
            var details = {
                Title: entityName,
                JsonResult: result,
                EntityID: entityID
            };
            $scope.EDResults.push(details);
            $scope.GetEDResults(details);
        }
        function GetEntityDetails(d) {
            var entityName = DataVisUtilities.GetName(d, 30);
            var result = IsEDetailsExist(entityName);
            if (result.status === true) {
                $scope.GetEDResults($scope.EDResults[result.index]);
                $scope.$apply();
                return;
            }
            var entityID = DataVisUtilities.GetEntityID(d);
            var req = {
                method: "POST",
                url: $scope.rootUrl + "api/entitydetailsbuilder/entitydetails",
                dataType: 'json',
                data: {
                    rootGuid: $scope.currentEntityGuid,
                    targetGuid: entityID
                },
                headers: { 'Accept': 'application/json' }
            };
            $http(req).success(function (response) {
                UpdateEntityDetailsResult(response, entityName, entityID);
                $scope.errors = "";
                $scope.loading = false;
            }).error(function (response) {
                $scope.errors = response;
                $scope.loading = false;
            });
        }
        function BuildContextMenuItems() {
            menu = [{
                    title: 'Get Entity Details',
                    action: function (elm, d, i) {
                        GetEntityDetails(d);
                    }
                },
                {
                    title: 'Close Children',
                    action: function (elm, d, i) {
                        RecursiveTreeHandler.Collapse(d);
                        Update(d);
                    }
                },
                {
                    title: 'Expand Children',
                    action: function (elm, d, i) {
                        RecursiveTreeHandler.Expand(d);
                        Update(d);
                    }
                },
                {
                    title: 'Close Node',
                    action: function (elm, d, i) {
                        RecursiveTreeHandler.CollapseNode(d);
                        Update(d);
                    }
                },
                {
                    title: 'Expand Node',
                    action: function (elm, d, i) {
                        RecursiveTreeHandler.ExpandNode(d);
                        Update(d);
                    }
                },
                {
                    title: 'Search',
                    action: function (elm, d, i) {
                        RecursiveTreeHandler.Search($scope.searchValue, d);
                        Update(d);
                    }
                }];
        }
        function SetupScopeFields() {
            $scope.typeOfRequest = GetCookie("typeOfRequest", "GET");
            var requestUrl = GetCookie("url", "");
            if (requestUrl !== "") {
                $scope.requestUrl = requestUrl;
            }
            $scope.requestId = GetCookie("requestId", "");
            $scope.datasetResponseStatus = "";
            $scope.datasetPath = GetCookie("datasetPath", "");
            $scope.response = "";
            $scope.errors = "";
            $scope.requestStatus = "";
            $scope.customHeaders = GetCookie("customHeaders", "");
            $scope.postData = GetCookie("postData", "");
            $scope.showRawJson = GetCookie("showRawJson", 'true') == 'true';
            $scope.viewTab = GetCookie("viewTab", '0');
            $scope.showRawContext = GetCookie("showRawContext", 'true') == 'true';
            $scope.searchValue = "";
            $scope.loading = false;
        }
        function GetCookie(key, defaultValue) {
            var result = $cookies.get(key);
            if (!result || result === "") {
                result = defaultValue;
            }
            return result;
        }
        function SaveSendOptions() {
            $cookies.put('typeOfRequest', $scope.typeOfRequest);
            $cookies.put('url', $scope.requestUrl);
            $cookies.put('requestId', $scope.requestId);
            $cookies.put('customHeaders', $scope.customHeaders);
            $cookies.put('postData', $scope.postData);
            $cookies.put('showRawJson', $scope.showRawJson);
            $cookies.put('viewTab', $scope.viewTab);
            $cookies.put('showRawContext', $scope.showRawContext);
        }
    }]);

//# sourceMappingURL=DataVisualiser.js.map

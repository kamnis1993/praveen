app.service('DataVisUtilities', function () {
    var DataVisUtilities = this;
    var fields = [
        "SMap_CopyConfigValue",
        "Component",
        "Package",
        "Bundle",
        "Promotion",
        "Rate"
    ];
    DataVisUtilities.ConvertToArray = function (obj) {
        if (!DataVisUtilities.IsDefined(obj)) {
            return [];
        }
        if (Array.isArray(obj)) {
            return obj;
        }
        return [].concat.apply([], [obj]);
    };
    DataVisUtilities.IsDefined = function (item) {
        return !DataVisUtilities.IsNotDefined(item);
    };
    DataVisUtilities.IsNotDefined = function (item) {
        return item === undefined || item === null || item.length === 0;
    };
    DataVisUtilities.GetImage = function (d) {
        var result, imageDir = "/Content/Images/";
        if (d._meta && d._meta.type) {
            var type = d._meta.type;
            if (type === "Bundle") {
                result = imageDir + "Bundle.svg";
            }
            else if (type === "Package") {
                result = imageDir + "Package.svg";
            }
            else if (type === "Credit_Non_Recurring_Charge_Template") {
                result = imageDir + "NonRecurringCharge.svg";
            }
            else if (type === "Credit_Recurring_Charge_Template" || type === "Tariff_Plan_Recurring_Charge_Template") {
                result = imageDir + "RecurringCharge.svg";
            }
            else if (type === "NonRecCost") {
                result = imageDir + "NonRecurringCost.svg";
            }
            else if (type === "RecCost") {
                result = imageDir + "RecurringCost.svg";
            }
            else if (type === "NonRecCostBasedChrg") {
                result = imageDir + "NonRecurringCostBasedCharge.svg";
            }
            else if (type === "RecCostBasedChrg") {
                result = imageDir + "RecurringCostBasedCharge.svg";
            }
            else if (type === "SChgBsdProdDisco" || type === "Product_Non_Event_Discount") {
                result = imageDir + "GenericDiscount.svg";
            }
            else if (type === "Product_Discount_Group") {
                result = imageDir + "ProductDiscountGroup.svg";
            }
            else if (type === "Default_Charge_Group_Template") {
                result = imageDir + "ChargeGroup.svg";
            }
            else {
                result = DataVisUtilities.PickComponentImage();
            }
        }
        else {
            result = DataVisUtilities.PickComponentImage();
        }
        return result;
    };
    DataVisUtilities.PickComponentImage = function () {
        var imageDir = "/Content/Images/";
        var listOfImages = [imageDir + "ComponentGreen.svg",
            imageDir + "ComponentIndigo.svg",
            imageDir + "ComponentIndigo.svg",
            imageDir + "ComponentTangerine.svg",
            imageDir + "ComponentTurquoise.svg",
            imageDir + "ComponentViolet.svg"];
        var image = Math.floor(Math.random() * listOfImages.length);
        return listOfImages[image];
    };
    DataVisUtilities.PickComponentGroupImage = function () {
        var imageDir = "/Content/Images/";
        var listOfImages = [imageDir + "ComponentGreen.svg",
            imageDir + "ComponentGroupIndigo.svg",
            imageDir + "ComponentGroupOrange.svg",
            imageDir + "ComponentGroupTangerine.svg",
            imageDir + "ComponentGroupTurquoise.svg",
            imageDir + "ComponentGroupViolet.svg"];
        var image = Math.floor(Math.random() * listOfImages.length);
        return listOfImages[image];
    };
    DataVisUtilities.GetName = function (d, substrlength) {
        if (substrlength === void 0) { substrlength = 12; }
        if (d.Name) {
            return d.Name.substring(0, substrlength);
        }
        if (d.ProductCandidate && d.ProductCandidate.Name) {
            return d.ProductCandidate.Name.substring(0, substrlength);
        }
        if (d.ID) {
            return d.ID.substring(0, substrlength);
        }
        for (var x = 0; x < fields.length; x++) {
            if (d[fields[x]]) {
                if (d[fields[x]].Name !== undefined) {
                    return d[fields[x]].Name.substring(0, substrlength);
                }
                else {
                    return [fields[x]].toString();
                }
            }
        }
        return "Root";
    };
    DataVisUtilities.CheckForHiddenChildren = function (d) {
        if (DataVisUtilities.IsDefined(d)
            && (d._Product_To_Product
                || d._Product_To_Cost
                || d._Product_To_Charge
                || d._CBDiscounts
                || d._ProductCandidate
                || d._ChildEntity
                || d._OrderCandidate
                || d._ChildOrderItem
                || d._CustomerPortfolio
                || d._Product_To_Charge_Group
                || d._Charge_Relation
                || d._Product_To_Discount_Group
                || d._Discount_Relation)) {
            return true;
        }
        else {
            return false;
        }
    };
    DataVisUtilities.GetMeta = function (d) {
        var meta;
        if (DataVisUtilities.CheckForTopLevel(d)) {
            for (var x = 0; x < fields.length; x++) {
                if (d[fields[x]]) {
                    DataVisUtilities.ConvertToArray(d[fields[x]]).forEach(function (item) {
                        meta = item._meta;
                    });
                }
            }
        }
        else if (d._meta) {
            meta = d._meta;
        }
        return meta;
    };
    DataVisUtilities.GetEntityID = function (d) {
        if (DataVisUtilities.IsDefined(d.EntityID)) {
            return d.EntityID;
        }
        var meta = DataVisUtilities.GetMeta(d);
        if (meta !== undefined) {
            return meta.ID;
        }
        return undefined;
    };
    DataVisUtilities.CheckForTopLevel = function (d) {
        if (DataVisUtilities.IsDefined(d)
            && (d.Component
                || d.SMap_CopyConfigValue
                || d.Package
                || d.Bundle
                || d.Promotion
                || d.Rate)) {
            return true;
        }
        else {
            return false;
        }
    };
    DataVisUtilities.CheckForChildField = function (d) {
        if (DataVisUtilities.IsDefined(d)
            && (d.Charge
                || d.Product
                || d.Cost
                || d.Discount
                || d.Charge_Group
                || d.Discount_Group
                || d.ChildEntity
                || d.OrderItem
                || d.ChildOrderItem
                || d.AffectedPortfolioItem)) {
            return true;
        }
        else {
            return false;
        }
    };
    DataVisUtilities.GetTopLevel = function (d) {
        if (DataVisUtilities.IsDefined(d)) {
            for (var x = 0; x < fields.length; x++) {
                if (d[fields[x]]) {
                    return d[fields[x]];
                }
            }
        }
        else {
            return null;
        }
    };
    DataVisUtilities.GetUrls = function () {
        var result = [
            { type: "GET", url: "internal/find/compiled/guid/" },
            { type: "GET", url: "find/productspecification/guid/" },
            { type: "GET", url: "find/productspecification/commercial/guid/" },
            { type: "GET", url: "find/productcandidate/template/guid/" },
            { type: "GET", url: "find/productspecification/withoutSchema/guid/" },
            { type: "GET", url: "debug/specificationbreakdown/guid/" },
            { type: "POST", url: "productcandidate/price/fixed" },
            { type: "POST", url: "ordercandidate/price/fixed" },
            { type: "POST", url: "debug/entitydetails" },
            { type: "POST", url: "manage/RefreshFromLocalDataStore" },
            { type: "POST", url: "ordercandidate/decompose" },
            { type: "GET", url: "" },
            { type: "POST", url: "" }
        ];
        return result;
    };
});

//# sourceMappingURL=DataVisUtilities.js.map
